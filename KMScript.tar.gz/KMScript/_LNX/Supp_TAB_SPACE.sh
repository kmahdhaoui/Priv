#!/bin/bash
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export Fich_TEMP1=/tmp/tmp_supprimeB_$$_${KMymdhms}_TEMP1.tmp
#
sed -r "s/\t//ig" $1 > $Fich_TEMP1
sed -r "s/ //ig" $Fich_TEMP1 > $1
#
#
