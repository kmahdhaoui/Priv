#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
#
#============================================
#
echo "exec dbms_stats.gather_FIXED_OBJECTS_STATS \;"
echo "exec dbms_stats.gather_DICTIONARY_STATS (degree=>48) \;"
#
date
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
set feedback off
set lines 133
col value format a80
--
--
exec dbms_stats.gather_FIXED_OBJECTS_STATS ;
--
exec dbms_stats.gather_DICTIONARY_STATS (degree=>48);
--
exit
EOT
#
date
#
#
. $KMscript/KMlogout.sh
#
#
