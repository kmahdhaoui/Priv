#!/bin/bash
# kma
#
# set before $ORACLE_HOME
#
#
# la base
if [ "$1" == "" ]
then
   echo "Usage is : $0 <Base>"
   exit 101
else
   export leSID=$1
fi
#
# les variables pour le batch
export ORACLE_SID=$leSID
. /usr/local/etc/oracle/kenv_batch.sh $leSID
. $BINDIR/kenv_nls.sh
#
cd $BINDIR
#
rm -f ${WORKDIR}/kgather_db_$$.tmp* 1>/dev/null 2>&1
#
export SQLTMP=${WORKDIR}/kgather_db_$$.tmp
export SPOOLFILE=${WORKDIR}/kgather_db_$$.lst
#
echo $SQLTMP $SPOOLFILE
#
##########################
export a_error_svg=0
#
export FLASHBACK_TIME=systimestamp
#
sqlplus -s '/ as sysdba' <<EOT
set pages 0 heading off feedback off verify off lines 80
spool $SPOOLFILE
select username from all_users where username not in 
('SYS','SYSTEM','OUTLN','DIP','DBSNMP','APPQOSSYS','WMSYS','SYSMAN','MGMT_VIEW','ORDSYS','ORDDATA','ORDPLUGINS','MDSYS','MDDATA','SPATIAL_WFS_ADMIN_USR','SPATIAL_CSW_ADMIN_USR','XDB','OLAPSYS','OWBSYS','OWBSYS_AUDIT','APEX_PUBLIC_USER','APEX_030200','SCOTT','XS\$NULL')
and username in ('ZABBIX','ORACLE_OCM')
;
spool off
exit
EOT
#
for leschema in `cat $SPOOLFILE `
do
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
#
#####################
sqlplus -s '/ as sysdba' 2>/dev/null <<EOT
set echo off heading off feedback off verify off
--
whenever sqlerror exit 1;
whenever oserror exit 2;
--
spool $SQLTMP.$KMymdhms.1
--
prompt "------------- $ORACLE_SID : $leschema-----------------------"
--
prompt gather statstics ...
exec dbms_stats.gather_schema_stats('$leschema',cascade=>true,degree=>24);
--
prompt "-------------------------------------------------"
--
exit 0
EOT
#####################
#
if [ $? -ne 0 ]
then
   export a_error_svg=1
else
   export a_error_svg=0
fi 
#
#########
#
export STATUS=$a_error_svg
if [ $STATUS != 0 ]
then
   echo bash $BINDIR/db_mailx.sh $SQLTMP.$KMymdhms.1 ProblemeStats "$LISTEMAIL" "Schema=$leschema"
   bash $BINDIR/db_mailx.sh $SQLTMP.$KMymdhms.1 ProblemeStats "$LISTEMAIL" "Schema=$leschema"
   # Mail et continuer
fi
#
##############
#
rm -f ${WORKDIR}/kgather_db_$$.tmp* 1>/dev/null 2>&1
rm -f ${WORKDIR}/$SQLTMP.$KMymdhms.1 1>/dev/null 2>&1
#
done
#
