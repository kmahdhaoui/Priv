#!/bin/ksh
# 
# Variables defaut
# 
unset ListeHostsTest ListeHostsTout_1 ListeHostsTout_2 ListeHostsDMZ ListeHostsSaturne ListeHostsDev ListeHostsRec ListeHostsPrex ListeHostsProd ListeHostsDevTest ListeHostsRecTest ListeHostsPrexTest
# 
# -----------------------------------------------------------
export ListeHostsDMZ="dasgbdformb2 dasgbdbasb2 dasgbddevb2 dasgbdrab2 dasgbdintb2 dasgbdrecb2 dasgbdrefb2 dasgbdsasb2 "
#
export ListeHostsProd_1=" dasgbdproda1 dasgbdprodb1 dasgbdprodc1 dasgbdprodc2 dasgbdprodd1 "
export ListeHostsProd_ssd1=" dasgbdproda1 dasgbdprodb1 dasgbdprodc1 dasgbdprodc2 "
export ListeHostsProd_ssd2=" dasgbdproda1 dasgbdprodb1 dasgbdprodc1 dasgbdprodc2 "
export ListeHostsProd_2=" dainfproda1 dssgbdprod1 "
export ListeHostsProd=" dainfproda1 dametroproda1 dasgbdproda1 dasgbdproda2 dasgbdprodb1 dasgbdprodc1 dasgbdprodc2 dasgbdprodd1 dasgbdprodi1 dsprodep5 dssgbdprod1"
export ListeHostsPGI="dapgisimulc1 dapgiprodc1"
# -----------------------------------------------------------
export ListeHostsSimu=" "
# -----------------------------------------------------------
export ListeHostsPrexTest=" dasgbdprexa1 dasgbdprexb1 dasgbdprexd1 "
#export ListeHostsPrex=" dafedprex1 daprexd3 dasgbdprexa1 dasgbdprexb1 dasgbdprexd1 dsprex2"
export ListeHostsPrex=" dafedprex1 dasgbdprexa1 dasgbdprexb1 dasgbdprexd1 dsprex2"
# -----------------------------------------------------------
export ListeHostsInt=" dasgbdintb2"
# -----------------------------------------------------------
export ListeHostsRecTest=" dasgbdreca1 dasgbdrecb1 dasgbdrecd1  "
export ListeHostsRec=" dasgbdreca1 dasgbdrecb1 dasgbdrecb2 dasgbdrecc1 dasgbdrecd1 dasgbdreci1"
# -----------------------------------------------------------
export ListeHostsDevTest=" dasgbddeva1 dasgbddevb1 dasgbddevd1 "
export ListeHostsDev=" dasgbddeva1 dasgbddevb1 dasgbddevb2 dasgbddevd1 dasgbddriee0 dasgbdrecd1 dssgbdrp1 "
# -----------------------------------------------------------
# 
export ListeHostsAutre=" dasgbdbasb2 dasgbdformb2 dasgbdrab2 dasgbdrefb2 dasgbdsasb2 dsadmx1 dsdataep1 dsgide dssgbdrp1"
export ListeHostsQuarantaine=" dsdevc1 dsdfpe1 daprodd3 dsdev1"
# -----------------------------------------------------------
export ListeHostsSaturne="dasgbdformb2 dasgbdbasb2 dasgbddevb2 dasgbdrab2 dasgbdintb2 dasgbdrecb2 dasgbdrefb2 dasgbdsasb2 "
# -----------------------------------------------------------
# 
export ListeHostsTout_1="$ListeHostsProd $ListeHostsSimu $ListeHostsPrex $ListeHostsInt $ListeHostsRec $ListeHostsDev"
export ListeHostsTout_ssd1="$ListeHostsProd_ssd1 $ListeHostsSimu $ListeHostsPrex $ListeHostsInt $ListeHostsRec $ListeHostsDev"
#
export ListeHostsTout_2="$ListeHostsProd $ListeHostsSimu $ListeHostsPrex $ListeHostsInt $ListeHostsRec $ListeHostsDev $ListeHostsAutre"
export ListeHostsTout_ssd2="$ListeHostsProd_ssd2 $ListeHostsSimu $ListeHostsPrex $ListeHostsInt $ListeHostsRec $ListeHostsDev $ListeHostsAutre"
#
export ListeHostsTest="$ListeHostsPrexTest $ListeHostsRecTest $ListeHostsDevTest $ListeHostsSaturne"
#
#
#

