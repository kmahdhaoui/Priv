#!/bin/bash
#
. /sitr/exploit/dba/SITR_env.sh
#
export ORACLE_SID=XSITRMDO
export ORAENV_ASK=NO
. oraenv 1>/dev/null
export ORAENV_ASK=YES
export PATH=$ORACLE_HOME/bin:$PATH
#
###############################################
#
bash sleep_PS.sh "oracle" "sqlplus" 6 60
#
###############################################
#
#
sqlplus -s / as sysdba 1>/dev/null 2>&1 <<EOT
create table mdo_recieved_kk as 
--
select 'TOTAL' AS REQ_SQL,
       MIN(MIN_DATE) AS MIN_DT ,
       max(MAX_DATE) AS MAX_DT,
       SUM(IMD_CNT) AS IMD_COUNT,
       SUM(EVT_CNT) AS EVT_COUNT,
       SUM(COUNT_IE) AS IMD_EVT_COUNT,
      (max(MAX_DATE) - MIN(MIN_DATE))*86400 AS TIME_USED,
       SUM(COUNT_IE) / ((max(MAX_DATE) - MIN(MIN_DATE))*86400) IMD_SEC,
       round((SUM(COUNT_IE) / ((max(MAX_DATE) - MIN(MIN_DATE))*86400) * 86400)) as NB_IMD_DAY_ESTIM
from (
        select /*+ parallel(imd,42) */ MAX(imd.CRE_DTTM) as MAX_DATE,
               MIN(imd.CRE_DTTM) as MIN_DATE,
               COUNT(*) AS COUNT_IE,
               COUNT(*) AS IMD_CNT,
               0 AS EVT_CNT
        from cisadm.D1_INIT_MSRMT_DATA imd
        where IMD.CRE_DTTM >= sysdate-1/24 
          and IMD.D1_TO_DTTM > sysdate-31
        --and IMD.BUS_OBJ_CD not in ('CM-InitialLoadIMDScalarIdxCal', 'CM-InitialLoadIMDScalarInterpo')
        --and IMD.BO_STATUS_CD <> 'ERROR'
        union all
        select MAX(evt.CRE_DTTM) as MAX_DATE,
               MIN(evt.CRE_DTTM) as MIN_DATE,
               COUNT(*),
               0,
               COUNT(*) AS EVT_CNT
        from cisadm.D1_DVC_EVT evt
        where evt.CRE_DTTM >= sysdate-1/24
     )
union all
select 'DATA_RECEIVED',
       MIN(MIN_DATE),
       max(MAX_DATE),
       SUM(IMD_CNT) AS IMD_COUNT,
       SUM(EVT_CNT) AS EVT_COUNT,
       SUM(COUNT_IE) AS IMD_EVT_COUNT,
      (max(MAX_DATE) - MIN(MIN_DATE))*86400 AS TOT_TIME_F,
       SUM(COUNT_IE) / ((max(MAX_DATE) - MIN(MIN_DATE))*86400) IE_SEC,
       round((SUM(COUNT_IE) / ((max(MAX_DATE) - MIN(MIN_DATE))*86400) * 86400)) as NB_IMD_DAY_ESTIM
from (
        select /*+ parallel(imd,42) */ MAX(imd.CRE_DTTM) as MAX_DATE,
               MIN(imd.CRE_DTTM) as MIN_DATE,
               COUNT(*) AS COUNT_IE,
               COUNT(*) AS IMD_CNT,
               0 AS EVT_CNT
        from cisadm.D1_INIT_MSRMT_DATA imd
        where IMD.CRE_DTTM >= sysdate-1/24
          and IMD.D1_TO_DTTM > sysdate-31
     and IMD.BUS_OBJ_CD not in ('CM-InitialLoadIMDScalarIdxCal1', 'CM-InitialLoadIMDScalarIdxCal6', 'CM-InitialLoadIMDScalarInterpo')
          and IMD.BO_STATUS_CD <> 'ERROR'
        union all
        select MAX(evt.CRE_DTTM) as MAX_DATE,
               MIN(evt.CRE_DTTM) as MIN_DATE,
               COUNT(*),
               0,
               COUNT(*) AS EVT_CNT
        from cisadm.D1_DVC_EVT evt
        where evt.CRE_DTTM >= sysdate-1/24
     );

exit
EOT
#
sqlplus -s / as sysdba <<EOT
var v_cnt number;
var v_ddeb varchar2(20);
var v_dfin varchar2(20);
--
insert into mdo_recieved_kk 
--
select 'TOTAL' AS REQ_SQL,
       MIN(MIN_DATE) AS MIN_DT ,
       max(MAX_DATE) AS MAX_DT,
       SUM(IMD_CNT) AS IMD_COUNT,
       SUM(EVT_CNT) AS EVT_COUNT,
       SUM(COUNT_IE) AS IMD_EVT_COUNT,
      (max(MAX_DATE) - MIN(MIN_DATE))*86400 AS TIME_USED,
       SUM(COUNT_IE) / ((max(MAX_DATE) - MIN(MIN_DATE))*86400) IMD_SEC,
       round((SUM(COUNT_IE) / ((max(MAX_DATE) - MIN(MIN_DATE))*86400) * 86400)) as NB_IMD_DAY_ESTIM
from (
        select /*+ parallel(imd,42) */ MAX(imd.CRE_DTTM) as MAX_DATE,
               MIN(imd.CRE_DTTM) as MIN_DATE,
               COUNT(*) AS COUNT_IE,
               COUNT(*) AS IMD_CNT,
               0 AS EVT_CNT
        from cisadm.D1_INIT_MSRMT_DATA imd
        where IMD.CRE_DTTM >= sysdate-1/24 
          and IMD.D1_TO_DTTM > sysdate-31
        --and IMD.BUS_OBJ_CD not in ('CM-InitialLoadIMDScalarIdxCal', 'CM-InitialLoadIMDScalarInterpo')
        --and IMD.BO_STATUS_CD <> 'ERROR'
        union all
        select MAX(evt.CRE_DTTM) as MAX_DATE,
               MIN(evt.CRE_DTTM) as MIN_DATE,
               COUNT(*),
               0,
               COUNT(*) AS EVT_CNT
        from cisadm.D1_DVC_EVT evt
        where evt.CRE_DTTM >= sysdate-1/24
     )
union all
select 'DATA_RECEIVED',
       MIN(MIN_DATE),
       max(MAX_DATE),
       SUM(IMD_CNT) AS IMD_COUNT,
       SUM(EVT_CNT) AS EVT_COUNT,
       SUM(COUNT_IE) AS IMD_EVT_COUNT,
      (max(MAX_DATE) - MIN(MIN_DATE))*86400 AS TOT_TIME_F,
       SUM(COUNT_IE) / ((max(MAX_DATE) - MIN(MIN_DATE))*86400) IE_SEC,
       round((SUM(COUNT_IE) / ((max(MAX_DATE) - MIN(MIN_DATE))*86400) * 86400)) as NB_IMD_DAY_ESTIM
from (
        select /*+ parallel(imd,42) */ MAX(imd.CRE_DTTM) as MAX_DATE,
               MIN(imd.CRE_DTTM) as MIN_DATE,
               COUNT(*) AS COUNT_IE,
               COUNT(*) AS IMD_CNT,
               0 AS EVT_CNT
        from cisadm.D1_INIT_MSRMT_DATA imd
        where IMD.CRE_DTTM >= sysdate-1/24
          and IMD.D1_TO_DTTM > sysdate-31
          and IMD.BUS_OBJ_CD not in ('CM-InitialLoadIMDScalarIdxCal1', 'CM-InitialLoadIMDScalarIdxCal6', 'CM-InitialLoadIMDScalarInterpo')
          and IMD.BO_STATUS_CD <> 'ERROR'
        union all
        select MAX(evt.CRE_DTTM) as MAX_DATE,
               MIN(evt.CRE_DTTM) as MIN_DATE,
               COUNT(*),
               0,
               COUNT(*) AS EVT_CNT
        from cisadm.D1_DVC_EVT evt
        where evt.CRE_DTTM >= sysdate-1/24
     );

commit;
--
exit
EOT
#
sqlplus -s / as sysdba <<EOT
--
set feedback off
set verify off
set lines 132
set pages 132
alter session set nls_date_format='yyyy-mm-dd hh24:mi:ss' ;
--
set heading on
select * from mdo_recieved_kk where MIN_DT > sysdate -31 order by REQ_SQL,MIN_DT;
--
exit
EOT
#
