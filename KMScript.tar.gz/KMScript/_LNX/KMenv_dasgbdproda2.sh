#!/bin/ksh
export KMlogin_dw=oracle #default
export KMsite=arceuil
#
export Liste_dbsingle="dxrg1eng dxpa5n4d dxrg1mon "
#
export Liste_host_dw=""
export Liste_host_info=$Liste_host_dw
alias dasgbdprodd1='ssh -X ${KMlogin_dw}@dasgbdprodd1'
#
for singleSID in $Liste_dbsingle
do
   export instSID=$singleSID
   export racSID=$singleSID
   export mininstSID=`echo $instSID|tr "ABCDEFGHIJKLMNOPQRSTUVWXYZ" "abcdefghijklmnopqrstuvwxyz"`
   export majinstSID=`echo $instSID|tr "abcdefghijklmnopqrstuvwxyz" "ABCDEFGHIJKLMNOPQRSTUVWXYZ"`
   # alias $instSID="export ORACLE_SID=$instSID ; export ORAENV_ASK=NO; . oraenv; export ORAENV_ASK=YES; b"
   # alias $mininstSID="export ORACLE_SID=$instSID ; export ORAENV_ASK=NO; . oraenv; export ORAENV_ASK=YES; b"
   # alias $majinstSID="export ORACLE_SID=$instSID ; export ORAENV_ASK=NO; . oraenv; export ORAENV_ASK=YES; b"
   # alias log$instSID='tail -42 $ORACLE_BASE/admin/$mininstSID/bdump/alert_$instSID.log'
   # alias log$mininstSID='tail -42 $ORACLE_BASE/admin/$mininstSID/bdump/alert_$instSID.log'
   # alias log$majinstSID='tail -42 $ORACLE_BASE/admin/$mininstSID/bdump/alert_$instSID.log'
done
#
#export ORACLE_SID=dxyr1cat ; export ORAENV_ASK=NO; . oraenv; export ORAENV_ASK=YES; b
# export ORACLE_SID=dxyr1cat ; 
ora $ORACLE_SID; cd - 
export PATH=$PATH:$KMscript:$ORACLE_HOME/OPatch
b
#
