#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
set lines 132
set pages 4444
col "First Time" format a25
col "Next Time" format a25
select   
-- thread#, 
sequence#,   
-- applied,
to_char(first_time,'yyyy-mm-dd HH24:MI:SS') "First Time",
to_char(next_time, 'yyyy-mm-dd HH24:MI:SS') "Next Time"
from      v\$archived_log
order by sequence# desc
;
exit
EOT
#
. $KMscript/KMlogout.sh
#
