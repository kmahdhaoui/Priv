#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
export leowner=CISADM
if [ "$1" == "" ]
then
   export leowner=CISADM
else
   export leowner=$1
fi
#
#============================================
#
echo "exec dbms_stats.gather_schema_stats(ownname=>'$leowner',ESTIMATE_PERCENT=>100,GRANULARITY=>'APPROX_GLOBAL AND PARTITION',cascade=>true,degree=>48)\;"
#
date
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
set feedback off
set lines 133
col value format a80
--
--
exec dbms_stats.gather_schema_stats(ownname=>'$leowner',ESTIMATE_PERCENT=>100,GRANULARITY=>'APPROX_GLOBAL AND PARTITION',cascade=>true,degree=>48);
--
exit
EOT
#
date
#
#
. $KMscript/KMlogout.sh
#
#
