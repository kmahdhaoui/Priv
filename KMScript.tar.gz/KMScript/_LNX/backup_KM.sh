# date "+%Y%m%d"
cd
. ./.bash_profile
cd
cd kamel/Kmscrip
. ./kamel.profile
cd
#
cd kamel
tar -cvf $HOME/kamel/KMscript_`hostname`_1_`date "+%Y%m%d"`.tar ./KMscript 
#
cd /sitr
tar -cvf $HOME/kamel/KMscript_`hostname`_2_`date "+%Y%m%d"`.tar ./exploit 
#
cd /sitr
rm -f ./admin/*/scripts/old/*.log*
tar -cvf $HOME/kamel/KMscript_`hostname`_3_`date "+%Y%m%d"`.tar ./admin/*/scripts
#
cd $HOME/kamel
mv KMscript*.tar.gz /tmp
gzip KMscript*.tar 
#
