#!/usr/bin/ksh
# Author : Kamel Mahdhaoui
#
# set -x
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
echo " "
echo "Nombre de CPU : "  
echo "--------------------------------------------------------------"
grep "model name" /proc/cpuinfo
echo " "
#
echo " "
echo "Taille Mémoire : " 
echo "--------------------------------------------------------------"
grep "MemTotal" /proc/meminfo
echo " "
#
echo " "
echo "Ethernet controller : "
echo "--------------------------------------------------------------"
lspci |grep "Ethernet controller" 
echo " "
#
echo " "
echo "Disques : "
echo "--------------------------------------------------------------"
lsblk
echo " "
#
. $KMscript/KMlogout.sh
#
