#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col OWNER format a22
col OBJECT_TYPE format a15
col OBJECT_NAME format a35
col STATUS
set pages 555
set lines 132
--
-- prompt "Nombre d'Indexes ..."
-- select owner,count(*) NB from dba_indexes group by owner;

--
-- prompt "Nombre d' Objets ..."
-- select owner,count(*) NB from dba_objects
-- where owner not like '%SYS%'
-- group by owner
-- ;
--
prompt "... Dont Indexes invalides"
select '-- '||table_name||chr(10)||
'alter index '||owner||'.'||index_name||' rebuild online parallel 8;' from dba_indexes where status not in ('VALID','N/A');
--
prompt "... Dont Indexes Part/ssPartitions invalides"
SELECT '-- '||index_name||chr(10)||
'alter index '||index_owner||'.'||index_name||' rebuild partition '||partition_name||' ;'  
FROM dba_ind_partitions WHERE status in ( 'UNUSABLE') ;
--
SELECT '-- '||index_name||chr(10)||
'alter index '||index_owner||'.'||index_name||' rebuild subpartition '||subpartition_name||' ;'
FROM dba_ind_subpartitions WHERE status in ( 'UNUSABLE') ;
--
prompt "... Dont Objets invalides"
select owner,object_name,object_type,status from dba_objects
where 
-- owner not like '%SYS%'  and 
status != 'VALID'
;

exit
EOT
#
. $KMscript/KMlogout.sh
#
