#!/bin/bash
#
. /sitr/exploit/dba/SITR_env.sh
#
export ORACLE_SID=XSITRMDO
export ORAENV_ASK=NO
. oraenv 1>/dev/null
export ORAENV_ASK=YES
export PATH=$ORACLE_HOME/bin:$PATH
#
###############################################
#
bash sleep_PS.sh "oracle" "sqlplus" 6 60
#
###############################################
#
#
sqlplus -s / as sysdba 1>/dev/null 2>&1 <<EOT
-- create table mdo_estimation_kk (ddeb date,dfin date,cnt number) ;
exit
EOT
#
sqlplus -s / as sysdba <<EOT
var v_cnt number;
var v_ddeb varchar2(20);
var v_dfin varchar2(20);
--
EXEC select to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') into :v_ddeb from dual ;
EXEC select count(*) into :v_cnt from cisadm.d1_msrmt;
EXEC select to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') into :v_dfin from dual ;
EXEC insert into mdo_estimation_kk values (to_date(:v_ddeb,'yyyy-mm-dd hh24:mi:ss'),to_date(:v_dfin,'yyyy-mm-dd hh24:mi:ss'),:v_cnt);
EXEC commit;
--
exit
EOT
#
sqlplus -s / as sysdba <<EOT
alter session set nls_date_format='yyy-mm-dd hh24:mi:ss';
select dd1 date1,dd2 date2,cnt comptage_msrmt,round(cnt_diff * 1 / (dd1-dd2) /1000/1000, 0) Debit_jour_millions from 
( SELECT 
       ddeb dd1,
       LAG(ddeb, 1, ddeb) OVER (ORDER BY cnt) AS dd2,
       cnt,
       LAG(cnt, 1, 0) OVER (ORDER BY cnt) AS cnt_prev,
       cnt - LAG(cnt, 1, 0) OVER (ORDER BY cnt) AS cnt_diff
FROM   mdo_estimation_kk
) where cnt_prev > 0 and cnt_diff is not null  and dd1 is not null and dd1 > sysdate -31
;
exit
EOT
#
