#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col Ligne format a100
--
spool $KMscript/log/indcols_${KMsite}_${KMenv}_${KMhost}_${ORACLE_SID}.lst

select INDEX_OWNER||'.'||table_name||'.'||index_name||'.'||COLUMN_position||'.'||COLUMN_NAME Ligne
from dba_ind_columns where
    table_name not like 'BIN$%'
and table_name like '$2'
and INDEX_OWNER not like 'SYS%' and INDEX_OWNER not like '%SYS'
and index_owner not in ('OUTLN','PUBLIC','DBSNMP','XDB')
-- and index_type not like '%LOB%'
and index_owner like ('$1')
order by INDEX_OWNER,table_name,INDEX_name,COLUMN_position,COLUMN_NAME
;
spool off
exit
EOT
#
. $KMscript/KMlogout.sh
#
