#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
#
if [ "$1" == "" ]
then
   export TEMPS=30
else
   export TEMPS=$1
fi
#
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
-- Excellent: < 1ms
-- Very good: < 5ms
-- Good: 5 – 10ms
-- Poor: 10 – 20ms
-- Bad: 20 – 100ms
-- Shockingly bad: 100 – 500ms
--
--
prompt =============================== Event Metrics (1')    ===================================
set wrap off 
col "Time /Delta" for a14
col name for a40
col INST_ID for 999
set linesize 140
set pagesize 1000
select "Time /Delta",inst_id,name, 
        T_per_wait_fg*10 "Avg_FG_wait_ms", round(T_waited_fg/100,1) "Waited_FG_sec", W_count_fg "W_count_FG",
        round(T_waited/100,1) "Waited_tot_sec", W_count "W_count_tot"       
from (
  select to_char(min(begin_time),'hh24:mi:ss')||' /'||round(avg(intsize_csec/100),0)||'s' "Time /Delta",
       em.inst_id,en.name,
       sum(em.time_waited_fg) T_waited_fg, sum(em.time_waited) T_waited,sum(wait_count) W_count, sum(wait_count_fg) W_count_fg,
       sum(decode(em.wait_count, 0,0,round(em.time_waited/em.wait_count,2))) T_per_wait,
       sum(decode(em.wait_count_fg, 0,0,round(em.time_waited_fg/em.wait_count_fg,2))) T_per_wait_fg
  from gv\$eventmetric em, v\$event_name en
  where em.event#=en.event#
      and en.wait_class <>'Idle'
      and BEGIN_TIME > sysdate - $TEMPS/1440
  group by em.inst_id,en.name,em.event_id
  order by T_waited_fg desc
  ) 
where rownum<=20;
--
prompt =============================== System Metrics (1') ===================================
col "Time+Delta" for a14
col "Metric" for a40
col "Total" for a10
col metric_name for a25
set linesize 140
set pagesize 1000
-- truncates the metric field to max length
 select to_char(min(begin_time),'hh24:mi:ss')||' /'||round(avg(intsize_csec/100),0)||'s' "Time+Delta",
       metric_name||' - '||metric_unit "Metric", 
       sum(value_inst1) inst1, sum(value_inst2) inst2, sum(value_inst3) inst3, sum(value_inst4) inst4,
       sum(value_inst5) inst5, sum(value_inst6) inst6
 from
  ( select begin_time,intsize_csec,metric_name,metric_unit,metric_id,group_id,
       case inst_id when 1 then round(value,1) end value_inst1,
       case inst_id when 2 then round(value,1) end value_inst2,
       case inst_id when 3 then round(value,1) end value_inst3,
       case inst_id when 4 then round(value,1) end value_inst4,
       case inst_id when 5 then round(value,1) end value_inst5,
       case inst_id when 6 then round(value,1) end value_inst6
  from gv\$sysmetric
  where metric_name in ('Host CPU Utilization (%)','Current OS Load', 'Physical Write Total IO Requests Per Sec',
        'Physical Write Total Bytes Per Sec', 'Physical Write IO Requests Per Sec', 'Physical Write Bytes Per Sec',
         'I/O Requests per Second', 'I/O Megabytes per Second',
        'Physical Read Total Bytes Per Sec', 'Physical Read Total IO Requests Per Sec', 'Physical Read IO Requests Per Sec',
        'CPU Usage Per Sec','Network Traffic Volume Per Sec','Logons Per Sec','Redo Generated Per Sec',
        'User Transaction Per Sec','Average Active Sessions','Average Synchronous Single-Block Read Latency','DB Block Changes Per Sec'
)
        and BEGIN_TIME > sysdate - $TEMPS/1440
  )
 group by metric_id,group_id,metric_name,metric_unit
 order by metric_name;
--
prompt =============================== File Metrics (1') ===================================
col name for a60
col sec for 999
col file# for 99999

select sum(physical_block_writes) Phys_BLK_W, sum(physical_block_reads) Phys_BLK_R, file_id file#,
       (select tablespace_name from dba_data_files ddf where ddf.file_id=fh.file_id) TBS_Name, to_char(max(begin_time),'hh24:mi') time, round(max(intsize_csec)/100,0) sec
from gv\$filemetric_history fh
where BEGIN_TIME > sysdate - $TEMPS/1440
group by inst_id,file_id
having sum(physical_block_writes) + sum(physical_block_writes) > 100
order by 1 desc;
--
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
