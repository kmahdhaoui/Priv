#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s '"$conn"<<EOT
@$KMscript/$SQLLOGIN
--
-- DEBUT SQL
-- 
set verify off
set feedback off
set echo off
--
--
col vname new_value x noprint
select name vname from v\$database;
--
ttitle skip center "*** TABLESPACE ALLOCATION ***"
column dummy noprint
col tablespace format a20
col bl_kb format 99
col mgmt format a7
col segment format a6
col contents format a9
col status format a10
col size_mb format 99999999
col real_mb format 99999999
col max_mb format 99999999   heading "Max Mb|Unalloc"
col nfile format 9999
column  pcfree format 999.9     heading "%|Free|Unalloc"
column  pcused format 999.9     heading "%|Used|Unalloc"
break   on report 

-- Tablespaces de la base
select t.tablespace_name tablespace,
      t.block_size/1024 bl_kb,
      t.extent_management mgmt,
      t.segment_space_management segment,
      t.contents contents ,
      t.status,
      f.nfile,
      round(f.size_mb-nvl(fs.free_mb,0)) real_mb,
      f.size_mb,
      f.max_mb,
      round((f.max_mb-(f.size_mb-nvl(fs.free_mb,0)))/f.max_mb*100,2) pcfree,
     100-round((f.max_mb-(f.size_mb-nvl(fs.free_mb,0)))/f.max_mb*100,2) pcused
      --(100*fs.free_mb)/f.size_mb pcused
 from dba_tablespaces t,
      (select tablespace_name,
              round(sum(bytes)/1024/1024) size_mb,
              round(sum(
                case when autoextensible='NO' then bytes
                     else greatest(bytes,maxbytes) end)
                         /1024/1024) max_mb,
              count(file_id) nfile
         from dba_data_files
        group by tablespace_name) f,
      (select tablespace_name,
              round(sum(bytes)/1024/1024) free_mb
         from dba_free_space
        group by tablespace_name) fs
where t.tablespace_name=f.tablespace_name
  and t.tablespace_name=fs.tablespace_name(+)
order by size_mb;

--
ttitle skip center "*** TABLESPACE USAGE ***"
column dummy noprint
column  pct_used format 999.9       heading "%|Used" 
column  name    format a20      heading "Tablespace Name" 
column  Mbytes   format 99999999    heading "MBytes" 
column  used    format 99999999   heading "Used" 
column  free    format 99999999  heading "Free" 
column  largest    format 9999999  heading "Largest" 
break   on report 
compute sum of mbytes on report 
compute sum of free on report 
compute sum of used on report 
--
select	nvl(b.tablespace_name,nvl(a.tablespace_name,'UNKNOWN'))	name
,	mbytes_alloc						Mbytes
,	mbytes_alloc-nvl(mbytes_free,0)				used
,	nvl(mbytes_free,0)					free
,	((mbytes_alloc-nvl(mbytes_free,0))/mbytes_alloc)*100	pct_used
,	nvl(largest,0)						largest
from	(select	sum(bytes)/1024/1024		Mbytes_free
	,		max(bytes)/1024		largest
	,		tablespace_name
	from 		dba_free_space
	group by	tablespace_name)			a
,	(select		sum(bytes)/1024/1024	Mbytes_alloc
	,		tablespace_name
	from		dba_data_files
	group by	tablespace_name)			b
where	a.tablespace_name (+) = b.tablespace_name
order by 1
/
-- ALL
define ts_name= ""
--
ttitle skip center "*** DATAFILE USAGE ***"
clear computes
clear breaks
set trims on
col tablespace_name format a12            heading "Tablespace Name"
col file_name       format a50            heading "File Name"
col total_size_MB   format 99999999      heading "Size MB"
col free_space_MB   format 99999999      heading "Free MB"
col total_size      format 99999999       heading "Size MB"
col free_space      format 99999999       heading "Free MB"
col pct_used        format 999.0         heading "%|Used"
col Autoext         format a4         heading "Auto|Ext"
clear breaks
--
select /*+ ORDERED */
       df.tablespace_name
,      df.file_name
,      df.AUTOEXTENSIBLE                         Autoext
,      df.bytes/1024/1024                        total_size_MB
,      nvl(fr.bytes/1024/1024,0)                 free_space_MB
,      df.bytes/1024/1024                        total_size
,      nvl(fr.bytes/1024/1024,0)                 free_space
,      ((df.bytes-nvl(fr.bytes,0))/df.bytes)*100 pct_used
from   (select sum(bytes) bytes
        ,      file_id
        from   dba_free_space
        group by file_id)     fr
,       dba_data_files        df
where df.file_id = fr.file_id(+)
and   DECODE(UPPER('&&ts_name'),NULL,'x',df.tablespace_name) like DECODE(UPPER('&&ts_name'),NULL,'x',UPPER('&&ts_name'))
order by 1, df.file_id
/
--
ttitle skip center "*** DATAFILE AUTOEXTEND BY MOUNT POINT ***"
clear computes
clear breaks
--
-- break on mount_point skip 1
col mount_point format a18 heading "Mnt"
-- compute sum of max_size cur_size unallocated on mount_point
col file_name   format a50              heading "Data File Name"
col tabsp_name  format a12              heading "Tablespace Name"
col max_size    format 99999999        heading "Max|Size MB"
col inc_by      format 99999           heading "Inc|By MB"
col unallocated format 99999999         heading "Unalloc|MB"
col cur_size    format 99999999        heading "Current|Size MB"
--
select  /*+ ORDERED */
        DISTINCT
        SUBSTR(ddf.file_name,1,DECODE(INSTR(ddf.file_name,'/',2),0,INSTR(ddf.file_name,':',1),INSTR(ddf.file_name,'/',2))) mount_point
,       tn.name                                            tabsp_name
,       ddf.file_name                                            file_name
,       ddf.bytes/1024/1024                                cur_size
,       decode(fex.maxextend,
                NULL,ddf.bytes/1024/1024
                    ,fex.maxextend*tn.blocksize/1024/1024) max_size
,       nvl(fex.maxextend,0)*tn.blocksize/1024/1024 -
        decode(fex.maxextend,NULL,0,ddf.bytes/1024/1024)   unallocated
,       nvl(fex.inc,0)*tn.blocksize/1024/1024              inc_by
from    dba_data_files  ddf
,       sys.ts$         tn
,       sys.filext$     fex
,       sys.file$       ft
where   ddf.file_id = ft.file#
and     ddf.file_id = fex.file#(+)
and     tn.ts# = ft.ts#
and     SUBSTR(ddf.file_name,1,DECODE(INSTR(ddf.file_name,'/',2),0,INSTR(ddf.file_name,':',1),INSTR(ddf.file_name,'/',2)))
                            IN (SELECT DISTINCT
                                   SUBSTR(file_name,1,DECODE(INSTR(file_name,'/',2),0,INSTR(file_name,':',1),INSTR(file_name,'/',2)))
                                FROM dba_data_Files
                                WHERE DECODE(UPPER('&&ts_name'),NULL,'x',tablespace_name) like DECODE(UPPER('&&ts_name'),NULL,'x',UPPER('&&ts_name')))
order by SUBSTR(ddf.file_name,1,5)
/
--
--
-- FIN SQL
--
exit
EOT
. $KMscript/KMlogout.sh
#
