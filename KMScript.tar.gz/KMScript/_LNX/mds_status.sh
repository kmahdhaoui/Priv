#!/bin/bash
# kma
#
# seuil (non utilise pour l'instant)
if [ "$1" == "" ]
then
   export SEUIL_1=5
else
   export SEUIL_1=$1
fi
#
export DATE=$(date "+%d/%m/%Y %H:%M:%S")
#
export PATH=$PATH:/usr/local/bin
export PATH=$PATH:$ORACLE_HOME/bin
#
##########################
# La liste c'est la base SITRMDS qui tourne
cat <<EOF |sort -u | grep -v '^$'| grep SITRMDS|while read leSID ; do
$(ps -ef |grep smon|grep -v grep|grep -v '+ASM'|awk -F_ '{print $3}'|sed 's/ //g')
EOF
export ORACLE_SID=$leSID
export ORAENV_ASK=NO
. oraenv 1>/dev/null
export ORAENV_ASK=YES
export PATH=$ORACLE_HOME/bin:$PATH
#
sqlplus -s '/ as sysdba' <<EOT
set echo off heading on feedback off verify off
--
whenever sqlerror exit 1; 
whenever oserror exit 2; 
--
prompt DBTIMEZONE
prompt ===============================================================
select DBTIMEZONE  from dual;
prompt
--
prompt INSTANTDECIMALSERIE_DATA : Index
prompt ===============================================================
select max(data_datetime+(SYSTIMESTAMP-SYS_EXTRACT_UTC(SYSTIMESTAMP))) DateIndex
, count(1) Comptage 
from ocea.instantdecimalserie_data ids, OCEA.METERINFO m 
where ids.id=m.INDEXSERIE and 
data_datetime >= sysdate-15 
and data_datetime < sysdate +5
group by trunc(data_datetime)
order by 1 desc 
;
--
prompt 
--
prompt INSTANTDECIMALSERIE_DATA : Indexes
prompt ===============================================================
SELECT DateIndex,COUNT(1) Comptage
FROM   
(SELECT MI.matricule, trunc(IDSD.DATA_DATETIME) DateIndex
FROM    ocea.METERINFO  MI, ocea.INSTANTDECIMALSERIE_DATA IDSD
WHERE   MI.INDEXSERIE      =  IDSD.ID
        AND IDSD.DATA_DATETIME >= trunc(sysdate-15)
        AND IDSD.DATA_DATETIME <  trunc(sysdate + 1) 
GROUP BY MI.MATRICULE,trunc(IDSD.DATA_DATETIME)
)
group by DateIndex
order by DateIndex desc
;
--
exit 0
EOT
#
export STATUS=$?
if [ $STATUS != 0 ]
then
   echo "Erreur $0 : $STATUS : SQL/OS 1/2 ..." >&2
   exit 3
fi
#
done
##########################
#
#
