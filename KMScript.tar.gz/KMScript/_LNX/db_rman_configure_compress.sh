#!/bin/ksh
# Author : Kamel Mahdhaoui
#
# extrait rman configure
# 
. ~oracle/.profile 1>/dev/null 2>&1
export ORACLE_SID=lastbase
. ~oracle/scripts/kamel/kamel.profile silent 1>/dev/null 2>&1
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh 1>/dev/null 1>/dev/null 2>&1
#
export host=$(uname -n)
export listbases=/tmp/kamel_listbases_$$
export listSID=/tmp/kamel_listSID_$$
export OK=`echo "OK"`
export KO=`echo "KO"`
#
> $listbases
if [ "$host" == "dsgide" ]
then 
   export OraTab=/var/opt/oracle/oratab
else
   export OraTab=/etc/oratab
fi
# test : export OraTab=oratabkk
cat $OraTab | sed '/^#/d' | grep -v "*" | grep -v "lastbase" > $listbases
#
cat <<EOF |sort -u | grep -v '^$'  > $listSID
$(cat $listbases |awk -F: '{print $1}')
$(ps -ef |grep smon|grep -v grep|awk -F_ '{print $3}'|sed 's/ //g')
EOF
#
for SID in `cat $listSID`
do
# on initialise des choses
export fictmp=/tmp/kamel_$$_$SID.txt
export fictmpexec=/tmp/kamel_exec_$$_$SID.txt
>$fictmp
>$fictmpexec
#
export ORACLE_SID=$SID
export ORACLE_HOME=`cat $listbases | grep -w ^${SID} | awk -F: '{print $2}'`
export PATH=$ORACLE_HOME/bin:$PATH
export LIBPATH=/usr/lib:$ORACLE_HOME/lib32:$ORACLE_HOME/lib:$ORACLE_HOME/jlib:$ORACLE_HOME/network/jlib
#
# ---------- configure
export dblink="N"
export mystatut=9
>$fictmp
>$fictmpexec
rman target / <<EOT 1>$fictmp 3>&1
show all ;
EOT
export mystatut=$?
#
if [ $mystatut -eq 0 ]
then
   cat $fictmp|grep CONFIGURE | grep -v "^#"|grep -v "^$" |grep "CONFIGURE DEVICE TYPE 'SBT_TAPE' PARALLELISM "| grep -v "COMPRESSED"| sed 's/BACKUP TYPE TO BACKUPSET/BACKUP TYPE TO COMPRESSED BACKUPSET/' > $fictmpexec
   export NBLIG=`cat $fictmpexec | wc -l `
   if [ $NBLIG -eq 1 ]
   then
      cat $fictmpexec
      export Reponse="N"
      echo "Executer sur base $ORACLE_SID  ... O/N ? \c"
      read Reponse
      if [ "$Reponse" == "O" ]
      then
         echo "Execution : `cat $fictmpexec` # ..."
         rman target / < $fictmpexec
      fi
   fi
fi
#
# -----------------------------
#
rm -f $fictmp 1>/dev/null 2>&1
rm -f $fictmpexec 1>/dev/null 2>&1
#
done
#
rm $listbases 1>/dev/null 2>&1
#
. $KMscript/KMlogout.sh 1>/dev/null 2>&1
#

