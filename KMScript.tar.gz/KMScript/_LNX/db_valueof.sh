#!/bin/ksh
# Author : Kamel Mahdhaoui
# 
#
if [ "$1" == "" ]
then 
   echo "Usage is : $0 <parameter> ..."
   exit 102
fi
#
export LeParam=$1
. ~oracle/.profile 1>/dev/null 2>&1
export ORACLE_SID=lastbase
. ~oracle/scripts/kamel/kamel.profile silent 1>/dev/null 2>&1
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
#
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh 1>/dev/null 1>/dev/null 2>&1
#
export host=$(uname -n)
export listbases=/tmp/kamel_listbases_$$
export OK=`echo "OK"`
export KO=`echo "KO"`
#
> $listbases
if [ "$host" == "dsgide" ]
then 
   export OraTab=/var/opt/oracle/oratab
else
   export OraTab=/etc/oratab
fi
cat $OraTab | sed '/^#/d' | grep -v "*" | grep -v "lastbase" > $listbases
#
cat <<EOF |sort -u | grep -v '^$' | while read SID ; do
$(cat $listbases |awk -F: '{print $1}')
$(ps -ef |grep smon|grep -v grep|awk -F_ '{print $3}'|sed 's/ //g')
EOF
# on initialise des choses pour LeParam
export value_param="no_recup"
verins="-1"
#
# 2eme char
export XPUVD=`echo $SID|cut -c2-2`
export codeappli=`echo $SID|cut -c3-5`
#
STS=$OK ; MSG=''
export TimU=$(ps -eo etime,user,args| grep "smon_${SID} *$"|awk '{print $1}')
export UPTime=`echo $TimU |awk '{print $1}'`
export Version=$(cat $listbases |grep -w ^${SID} | awk -F: '{print $2}'| awk 'FS="/" {print $5}')
export Inter=$(cat $listbases |grep -w ^${SID} | awk -F: '{print $4}'| awk 'FS=" " {print $1}')
export Dem=$(cat $listbases |grep -w ^${SID} | awk -F: '{print $3}'| awk 'FS=" " {print $1}')
#
export fictmp=/tmp/kamel_$$_$SID.txt
>$fictmp
#
export lsnr=$(ps -ef |grep lsnr |grep ${SID} |awk '{print $10}')
#
export ORACLE_SID=$SID
export ORACLE_HOME=`cat $listbases | grep -w ^${SID} | awk -F: '{print $2}'`
export PATH=$ORACLE_HOME/bin:$PATH
export LIBPATH=/usr/lib:$ORACLE_HOME/lib32:$ORACLE_HOME/lib:$ORACLE_HOME/jlib:$ORACLE_HOME/network/jlib
#
#
# ---------- LeParam
# ---------- verins
export mystatut=9
>$fictmp
sqlplus -s "$conn" 1>/dev/null 2>&1 <<EOT >/dev/null
set echo off termout off head off verify off feedback off serveroutput off
spool $fictmp
whenever sqlerror exit 1
select 'value_param'||':'||'v'||':'||VALUE from v\$parameter where upper(name) like upper('$LeParam');
select 'verins'||':'||'v'||':'||VERSION from v\$instance where INSTANCE_NUMBER=1 ;
spool off
exit 0
EOT
export mystatut=$?
if [ $mystatut -eq 0 ]
then
   export value_param=`cat $fictmp|grep value_param | sed '/^$/d' | sed 's/[ \t]*$//'|awk -F:v: '{print $2}' `
   export verins=`cat $fictmp|grep verins | sed '/^$/d' | sed 's/[ \t]*$//'|awk -F:v: '{print $2}' `
else
   export value_param="no_recup"
   export verins="-1"
fi
#
rm -f $fictmp 1>/dev/null 2>&1
#
# verins c ce qui vient de v$instance
#
echo "$host;" "$SID;" "$XPUVD;" "$codeappli;" "$verins;" "$value_param;"
done
#
rm $listbases 1>/dev/null 2>&1
#
. $KMscript/KMlogout.sh 1>/dev/null 2>&1
#

