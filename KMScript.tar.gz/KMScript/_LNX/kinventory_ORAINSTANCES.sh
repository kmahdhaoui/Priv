#!/bin/ksh
# Author : Kamel Mahdhaoui
# 
. ~oracle/.profile 1>/dev/null 2>&1
export ORACLE_SID=lastbase
#
export HOST=$(uname -n)
export listbases=/tmp/kinventory_oracle_$$.tmp
export OK=`echo "OK"`
export KO=`echo "KO"`
#
#
#########################################################
#
# les variables pour le batch
. /usr/local/etc/oracle/kenv_batch.sh
#
export SUPFILE=${SUPDIR}/kinventory_ORAINSTANCES.sup
mv -f $SUPFILE $LOGDIR
> $SUPFILE
cd $BINDIR
#########################################################
#
> $listbases
if [ "$HOST" == "sunOS" ]
then 
   export OraTab=/var/opt/oracle/oratab
else
   export OraTab=/etc/oratab
fi
cat $OraTab|sed '/^#/d'|grep -v "*"|grep -v "^db:"|grep -v "^lastbase:" |grep -v "^asm:"|grep -v "^client"|grep -v "^odi:" > $listbases
#
cat <<EOF |sort -u | grep -v '^$' | while read SID ; do
$(cat $listbases |awk -F: '{print $1}')
$(ps -ef |grep smon|grep -v grep|awk -F_ '{print $3}'|sed 's/ //g')
EOF
# on initialise des choses
TIMU="-1"
UPTIME="-1"
VERSION="-1"
VERSION2="-1"
XPUVD="ERR"
CODEAPPLI="ERR"
PORTLSNR=-1
SPFILE="ERR"
NBDBF=-1
DEM="ERR"
STS="ERR"
MSG="ERR"
KEEPTIME="-1"
COMPRESSION="ERR"
PARALLELISME="-1"
TDPO="ERR"
VERINS="-1"
BUNDLEPSU="ERR"
V_SEEE="ERR"
LOGMODE="ERR"
NBDBF=-1
TAILLEGO=-1
TYPEAPPLI="ERR"
COMPAT="-1"
# 2eme char
export XPUVD=`echo $SID|cut -c1-1`
export CODEAPPLI=`echo $SID|cut -c2-5`
export TYPEAPPLI=`echo $SID|cut -c6-8`
#
STS=$OK ; MSG=''
export TIMU=$(ps -eo etime,user,args| grep "smon_${SID} *$"|awk '{print $1}')
export UPTIME=`echo $TIMU |awk '{print $1}'`
export VERSION=$(cat $listbases |grep -w ^${SID} | awk -F: '{print $2}'| awk 'FS="/" {print $5}')
export INTER=$(cat $listbases |grep -w ^${SID} | awk -F: '{print $4}'| awk 'FS=" " {print $1}')
export DEM=$(cat $listbases |grep -w ^${SID} | awk -F: '{print $3}'| awk 'FS=" " {print $1}')
#
export fictmp=/tmp/kamel_$$_$SID.txt
>$fictmp
#
export lsnr=$(ps -ef |grep lsnr )
#
# les variables pour le batch
. /usr/local/etc/oracle/kenv_batch.sh $SID
. $BINDIR/kenv_nls.sh
#
export LIBPATH=/usr/lib:$ORACLE_HOME/lib32:$ORACLE_HOME/lib:$ORACLE_HOME/jlib:$ORACLE_HOME/network/jlib
#
sqlplus -s '/as sysdba' 1>/dev/null 2>&1 <<EOT >/dev/null
set echo off termout off head off verify off feedback off serveroutput off
spool $fictmp
select STATUS from v\$instance;
spool off
exit
EOT
#
if [ -z "$UPTIME" ]
then
    UPTIME="-1"
    STA='DOWN'
  #  MSG=`echo "$R {{(([[Pas de mode Intervention]]))}} $F"`
else
    UPTIME="+"`echo $UPTIME|grep "\-" |awk -F\- '{print $1}'`
    if [ "$UPTIME" == "+" ] 
    then
       UPTIME="+0"
    fi
    if [ -z "$lsnr" ]
    then
      STA='LSNR'
      MSG=`echo "$J PB_LSNR $F"`
    else
      STA=`cat $fictmp | sed '/^$/d' | sed 's/[ \t]*$//'`
    fi
#
#
#
# ---------- VERINS
# ---------- KEEPTIME
# ---------- SPFILe
export mystatut=9
>$fictmp
sqlplus -s '/as sysdba' 1>/dev/null 2>&1 <<EOT >/dev/null
set echo off termout off head off verify off feedback off serveroutput off
spool $fictmp
whenever sqlerror exit 1
select 'KEEPTIME'||':'||'v'||':'||VALUE from v\$parameter where name like 'control_file_record_keep_time';
whenever sqlerror exit 2
select 'SPFILe'||':'||'v'||':'||'Y'||'ES' from v\$parameter where name like 'SPFILe' and value is not null;
whenever sqlerror exit 3
select 'VERINS'||':'||'v'||':'||VERSION from v\$instance where INSTANCE_NUMBER=1 ;
whenever sqlerror exit 4
select 'COMPAT'||':'||'v'||':'||VALUE from v\$parameter where name like 'compatible' ;
spool off
exit 0
EOT
export mystatut=$?
if [ $mystatut -eq 0 ]
then
   export VERINS=`cat $fictmp|grep VERINS | sed '/^$/d' | sed 's/[ \t]*$//'|awk -F:v: '{print $2}' `
   export KEEPTIME=`cat $fictmp | grep KEEPTIME |sed '/^$/d' | sed 's/[ \t]*$//'|awk -F:v: '{print $2}' `
   export SPFILe=`cat $fictmp | grep SPFILe |sed '/^$/d' | sed 's/[ \t]*$//'|awk -F:v: '{print $2}' `
   export COMPAT=`cat $fictmp|grep COMPAT | sed '/^$/d' | sed 's/[ \t]*$//'|awk -F:v: '{print $2}' `
else
   export VERINS="-1"
   export KEEPTIME="-1"
   export SPFILe="N"
   export COMPAT="-1"
fi
#
# ---------- COMPRESSION
# ---------- PARALLELISME
# ---------- TDPO
#
export mystatut=9
>$fictmp
sqlplus -s '/as sysdba' 1>/dev/null 2>&1 <<EOT >/dev/null
set echo off termout off head off verify off feedback off serveroutput off
spool $fictmp
whenever sqlerror exit 1
select rtrim(ltrim(a1.VALUE)) from v\$rman_configuration a1
  where a1.NAME='DEVICE TYPE'
  and a1.VALUE like '%SBT_TAPE%'
union
select rtrim(ltrim(a2.VALUE)) from v\$rman_configuration a2
  where a2.NAME='CHANNEL'
  and a2.VALUE like '%SBT_TAPE%'
  and not exists (select 'x' from v\$rman_configuration b where b.NAME='DEVICE TYPE')
  and exists (select 'x' from v\$rman_configuration c where c.NAME like 'DEFAULT DEVICE TYPE%'
              and c.VALUE like '%SBT_TAPE%')
;
spool off
exit 0
EOT
export mystatut=$?
if [ $mystatut -eq 0 ]
then
   export COMPRESSION='NOCOMP'
   export PARALLELISME=1
   for i in 1 2 3 4 5 6 7 8 9 10 11 12
   do
   export UnMot=`cat $fictmp |grep SBT_TAPE | cut -d' ' -f$i`
   case "$UnMot" in 
        COMPRESSED)  COMPRESSION="COMP"
                     ;;
        PARALLELISM) iplus1=`expr $i + 1 `
                     PARALLELISME=` cat $fictmp |grep SBT_TAPE | cut -d' ' -f$iplus1`
                     ;;
   esac
   done
else
   export COMPRESSION="N"
   export PARALLELISME="-1"
fi
#
export mystatut=9
>$fictmp
sqlplus -s '/as sysdba' 1>/dev/null 2>&1 <<EOT >/dev/null
set echo off termout off head off verify off feedback off serveroutput off
spool $fictmp
whenever sqlerror exit 1
select 'TDPO'||':'||'v'||':'||
substr ( c1,instr(c1,'/',1,3)+1,20) from
(select
substr( VALUE, instr(VALUE,'TDPO_OPTFILE')+13, 1+
instr(VALUE,'.',instr(VALUE,'TDPO_OPTFILE')) - instr(VALUE,'TDPO_OPTFILE')-13 ) c1
from V\$RMAN_CONFIGURATION where NAME='CHANNEL'
)
;
spool off
exit 0
EOT
export mystatut=$?
if [ $mystatut -eq 0 ]
then
   export TDPO=`cat $fictmp|grep TDPO | sed '/^$/d' | sed 's/[ \t]*$//'|awk -F:v: '{print $2}' `
   export TDPO=`echo $TDPO |tr -d ' '|tr -d ')'|tr -d '/'|tr -d '.'`
   if [ "$TDPO" == "tdpo_$ORACLE_SID" ]
   then 
      export TDPO="Ok"
   else
      export TDPO="Pb Cfg"
   fi
else
   export TDPO="Non"
fi
#
# ---------- LOGMODE
# ---------- TAILLEGO
# ---------- NBDBF
# ---------- BUNDLEPSU
export mystatut=9
>$fictmp
sqlplus -s '/as sysdba' 1>/dev/null 2>&1 <<EOT >/dev/null
set echo off termout off head off verify off feedback off serveroutput off
spool $fictmp
whenever sqlerror exit 1
select 'LOGMODE'||':'||'v'||':'||decode(substr(LOG_MODE,1,4),'NOAR','NO',substr(LOG_MODE,1,4))  from  v\$database ;
whenever sqlerror exit 2
select 'TAILLEGO'||':'||'v'||':'||round(sum(bytes)/1024/1024/1024) GB from v\$datafile; 
whenever sqlerror exit 3
select 'NBDBF'||':'||'v'||':'||count(*) NBDBF from v\$datafile;
whenever sqlerror exit 4
-- 999 erreur speciale car elle peut arriver si pas de psu
whenever sqlerror exit 999
select 'BUNDLEPSU'||':'||'v'||':'||a.bundle_series||' '||ID from dba_registry_history a where a.action_time in
(select max(b.action_time) from dba_registry_history b where b.bundle_series like 'PSU%') ;
spool off
exit 0
EOT
export mystatut=$?
if [ $mystatut -eq 999 ]
then 
   export BUNDLEPSU=`cat $fictmp|grep BUNDLEPSU | sed '/^$/d' | sed 's/[ \t]*$//'||awk -F:v: '{print $2}' `
else
   export BUNDLEPSU="N"
   export mystatut=0
fi
#
if [ $mystatut -eq 0 ]
then
   export LOGMODE=`cat $fictmp | grep LOGMODE |sed '/^$/d' | sed 's/[ \t]*$//'|awk -F:v: '{print $2}' `
   export TAILLEGO=`cat $fictmp | grep TAILLEGO |sed '/^$/d' | sed 's/[ \t]*$//'|awk -F:v: '{print $2}' `
   export NBDBF=`cat $fictmp | grep NBDBF |sed '/^$/d' | sed 's/[ \t]*$//'|awk -F:v: '{print $2}' `
   export BUNDLEPSU=`cat $fictmp|grep BUNDLEPSU | sed '/^$/d' | sed 's/[ \t]*$//'|awk -F:v: '{print $2}' `
else
   export LOGMODE="N"
   export TAILLEGO="-1"
   export NBDBF="-1"
   export BUNDLEPSU="N"
fi
#
# -----------------------------
fi
# ---------- port listener
#
renvoi_port() {
ARGS="$*"
for arg in ${ARGS}
do
    case "$arg" in
         PORT=*|port=*) leport=`echo "$arg" | sed -e 's/^[^=]*=//'` ;;
    esac
done
echo $leport
}
>$fictmp
lsnrctl 1> $fictmp 2>&1 <<EOT
status $ORACLE_SID
exit
EOT
#
export lsnrgrep=`grep -i port $fictmp|grep \= |grep \(|grep \) `
export lsnrgrep=`echo $lsnrgrep|tr "()" "  " `
export lsnrgrep=`echo $lsnrgrep|sed 's/ =/=/g'|sed 's/= /=/g' `
export PORTLSNR=`renvoi_port $lsnrgrep`
# -----------------------------------------------------------------
#
if [ "$Inter" == "I" ]
then
     MSG=`echo "$M MODE_I $MSG $F"`
fi
#
if [ -z "$VERSION" ]
then
     VERSION2='N/A'
     STS=$KO
     #Dem='?'
     MSG=`echo "${J}PB_ORATAB$F"`
else
     if [ $VERSION == "distrib" ]
     then
       VERSION2=$(cat $listbases | grep -w ^${SID} | awk -F: '{print $2}'| awk 'FS="/" {print $6}')
     else
       VERSION2=`echo ${VERSION} | awk -Fa '{print $2}'`
    fi
fi
#
patchOA=`expr substr ${VERSION2} 1 1`
#
if [ $patchOA == "o" ]
then
VERSION2=`expr substr ${VERSION2} 4 6`
fi
#
# VERINS c ce qui vient de v$instance
export VERSIONX=$(cat $listbases | grep -w ^${SID} | awk -F: '{print $2}'| awk 'FS="/" {print $7}')
#
if [ $VERSION2 == "se" ]
then
   VERSIONX=$(cat $listbases | grep -w ^${SID} | awk -F: '{print $2}'| awk 'FS="/" {print $7}')
   if [ "$VERINS" != "-1" ]
   then
      VERSIONX=$VERINS
   fi
   VERSION2=`echo $VERSIONX`
   V_SEEE="SE"
else
   if [ "$VERINS" != "-1" ]
   then
      VERSIONX=$VERINS
   fi
   VERSION2=`echo $VERSIONX`
   V_SEEE="EE"
fi
#
if [ -z "$STA" ]
then
   STS=`echo "${R}FAILED$F"`
else
   if [ $STA == "OPEN" ]
   then
      STS=`echo "${V}$STA$F"`
   else
      if [ $STA == "STARTED" ] && [ "$SID" == "+ASM" ]
      then
          STS=`echo "$V$STA$F"`
      else
          STS=`echo "$R$STA$F"`
      fi
  fi
fi
#
rm -f $fictmp 1>/dev/null 2>&1
#
if [ "$i" == "" ]
then
export TIMU=null
fi
if [ "$i" == "" ]
then
export UPTIME=null
fi
if [ "$i" == "" ]
then
export VERSION=null
fi
if [ "$i" == "" ]
then
export VERSION2=null
fi
if [ "$i" == "" ]
then
export XPUVD=null
fi
if [ "$i" == "" ]
then
export CODEAPPLI=null
fi
if [ "$i" == "" ]
then
export PORTLSNR=null
fi
if [ "$i" == "" ]
then
export SPFILE=null
fi
if [ "$i" == "" ]
then
export NBDBF=null
fi
if [ "$i" == "" ]
then
export DEM=null
fi
if [ "$i" == "" ]
then
export STS=null
fi
if [ "$i" == "" ]
then
export MSG=null
fi
if [ "$i" == "" ]
then
export KEEPTIME=null
fi
if [ "$i" == "" ]
then
export COMPRESSION=null
fi
if [ "$i" == "" ]
then
export PARALLELISME=null
fi
if [ "$i" == "" ]
then
export TDPO=null
fi
if [ "$i" == "" ]
then
export VERINS=null
fi
if [ "$i" == "" ]
then
export BUNDLEPSU=null
fi
if [ "$i" == "" ]
then
export V_SEEE=null
fi
if [ "$i" == "" ]
then
export LOGMODE=null
fi
if [ "$i" == "" ]
then
export NBDBF=null
fi
if [ "$i" == "" ]
then
export TAILLEGO=null
fi
if [ "$i" == "" ]
then
export TYPEAPPLI=null
fi
if [ "$i" == "" ]
then
export COMPAT=null
fi
#
echo " HOST=$HOST; SID=$SID; LOGMODE=$LOGMODE; XPUVD=$XPUVD; CODEAPPLI=$CODEAPPLI; TYPEAPPLI=$TYPEAPPLI; PORTLSNR=$PORTLSNR; VERSION2=$VERSION2; V_SEEE=$V_SEEE; BUNDLEPSU=$BUNDLEPSU; SPFILE=$SPFILE; COMPAT=$COMPAT; NBDBF=$NBDBF; TAILLEGO=$TAILLEGO; KEEPTIME=$KEEPTIME; COMPRESSION=$COMPRESSION; PARALLELISME=$PARALLELISME; TDPO=$TDPO; UPTIME=$UPTIME; DEM=$DEM; STS=$STS; MSG=$MSG; " >> $SUPFILE
done
#
rm -f $listbases 1>/dev/null 2>&1
#
#
