#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
set lines 132
col Directory format a131
set heading off
prompt 
prompt =========================== Directories ===========================
select 
'alter session set current_schema='||OWNER||';' 
||chr(10)||
'create or replace directory '||DIRECTORY_NAME||' as '''||DIRECTORY_PATH||''';' Directory
from dba_directories ;
--
-- ;
exit
EOT
#
. $KMscript/KMlogout.sh
#
