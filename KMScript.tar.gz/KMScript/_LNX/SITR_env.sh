#!/bin/bash
#
export SITRscript=/sitr/exploit/dba  # first and only set
export PATH=$PATH:$SITRscript:$ORACLE_HOME/OPatch
#
. $SITRscript/SITR_env_commun.sh
#
. $SITRscript/SITR_env_machine.sh
#
case $SITRenv in
#.................... environnement production
Prod*)  echo "$SITRhost PRODUCTION !!!"
        ;;
Rece*)  echo "$SITRhost RECETTE !!!"
        ;;
#.................... environnement autre
*)      echo "$SITRenv Perso"
        ;;
esac
#
