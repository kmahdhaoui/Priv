#!/bin/bash
# kma
#
# set before $ORACLE_HOME
#
#
# la base
if [ "$1" == "" ]
then
   echo "Usage is : $0 <Base>"
  exit 101
else
   export leSID=$1
fi
#
# les variables pour le batch dont WINDOW_DUMP et WINDOW_RMAN
export ORACLE_SID=$leSID
. /usr/local/etc/oracle/kenv_batch.sh $leSID
. $BINDIR/kenv_nls.sh
#
cd $BINDIR
#
rm -f ${WORKDIR}/kpurge_logs_base_$$.tmp* 1>/dev/null 2>&1
#
export SQLTMP=${WORKDIR}/kpurge_logs_base_$$.tmp
#
export MAJoracle_sid=`echo $ORACLE_SID|tr '[:lower:]' '[:upper:]'`
export MINoracle_sid=`echo $ORACLE_SID|tr '[:upper:]' '[:lower:]'`
#
export a_error_svg=0
#
export LOGFILE=kpurge_logs_base_${ORACLE_SID}_FULL_$KMymdhms.log
export CONFILE=kpurge_logs_base_${ORACLE_SID}_FULL_$KMymdhms.cfg
#
##################################################################
#
# asm 
find /sitr/app/oracle/product/11.2.0/asm/log/diag/asm/+asm/+ASM -name "*+ASM*.tr*" -mtime +${WINDOW_RMAN} -exec rm -f {} \;
find /sitr/admin/+ASM/adump -name "*+ASM*.aud*" -mtime +${WINDOW_RMAN} -exec rm -f {} \;
find /sitr/app/oracle/product/11.2.0/*/rdbms/audit -name "*+ASM*.aud*" -mtime +${WINDOW_RMAN} -exec rm -f {} \;
#
# audit
find /sitr/admin/${ORACLE_SID}/adump -name "*${ORACLE_SID}*.aud*" -mtime +${WINDOW_RMAN} -exec rm -f {} \; 
find /sitr/app/oracle/product/11.2.0/*/rdbms/audit -name "*${ORACLE_SID}*.aud*" -mtime +${WINDOW_RMAN} -exec rm -f {} \; 
#
# traces
find /sitr/diag/rdbms/$MINoracle_sid/$ORACLE_SID -name "*${ORACLE_SID}*.tr*" -mtime +${WINDOW_RMAN} -exec rm -f {} \; 
#
# cores
find /sitr/diag/rdbms/$MINoracle_sid/$ORACLE_SID/cdump -name "*core*" -mtime +${WINDOW_RMAN} -exec rm -f {} \; 
#
# alerte
mv /sitr/diag/rdbms/$MINoracle_sid/$ORACLE_SID/trace/alert_${ORACLE_SID}.log /sitr/diag/rdbms/$MINoracle_sid/$ORACLE_SID/trace/alert_${ORACLE_SID}.log.$KMymdhms
gzip /sitr/diag/rdbms/$MINoracle_sid/$ORACLE_SID/trace/alert_${ORACLE_SID}.log.$KMymdhms
find /sitr/diag/rdbms/$MINoracle_sid/$ORACLE_SID -name "alert_${ORACLE_SID}.log.*" -mtime +${WINDOW_RMAN} -exec rm -f {} \; 
echo " " >> /sitr/diag/rdbms/$MINoracle_sid/$ORACLE_SID/trace/alert_${ORACLE_SID}.log
#
# /sitr/exploit/log
find /sitr/exploit/log -name "*${ORACLE_SID}*.*" -mtime +${WINDOW_RMAN} -exec rm -f {} \; 
#
# /sitr/exploit/work/log
find /sitr/exploit/work/log -name "*${ORACLE_SID}*.*" -mtime +${WINDOW_RMAN} -exec rm -f {} \;
#
#
###################################################################
#
rm -f ${WORKDIR}/kpurge_logs_base_$$.tmp* 1>/dev/null 2>&1
rm -f $WORKDIR/$CONFILE 1>/dev/null 2>&1
#
