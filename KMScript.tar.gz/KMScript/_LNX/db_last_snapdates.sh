#!/bin/bash
# Author : Kamel Mahdhaoui
#
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export KMymd=`date "+%Y%m%d"`
#
#
sqlplus -s "$conn"  <<EOT
--
set time off timi off echo off verify off feedback off heading off
set time off timi off echo off verify off feedback off heading off pages 0 lines 80
--
select trim(to_char(min(begin_interval_time) ,'yyyy-mm-dd_hh24:mi:ss')) || ' ' || 
       trim(to_char(max(begin_interval_time),'yyyy-mm-dd_hh24:mi:ss' )) snapdates from 
(
select begin_interval_time
from dba_hist_snapshot where begin_interval_time > sysdate - 6/24
order by begin_interval_time desc 
) 
where rownum < 3
;
--
exit
EOT
#
#######################################
#
#
#
