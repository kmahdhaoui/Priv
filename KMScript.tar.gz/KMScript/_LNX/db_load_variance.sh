#!/bin/bash
# Author : Kamel Mahdhaoui
#
#
if [ "$1" == "" ] 
then
   export nbjour=1
else
   export nbjour=$1
fi
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export KMymd=`date "+%Y%m%d"`
#
#
sqlplus -s "$conn"  <<EOT
--
set time off timi off echo off verify off feedback off 
set heading on 
set pagesize 50000
set feedback off
--
col BEGIN_INTERVAL_TIME format a33
col END_INTERVAL_TIME format a33
--
select
to_char(round(sub1.sample_time, 'HH24'), 'YYYY-MM-DD HH24:MI') as sample_hour,
round(avg(sub1.on_cpu),1) as oncpu_avg,
round(avg(sub1.waiting),1) as waiting_avg,
round(avg(sub1.active_sessions),1) as active_sess_avg,
round( (variance(sub1.active_sessions)/avg(sub1.active_sessions)),1) as "variance/moy"
from
( 
select
sample_id,
sample_time,
sum(decode(session_state, 'ON CPU', 1, 0))  as on_cpu,
sum(decode(session_state, 'WAITING', 1, 0)) as waiting,
count(*) as active_sessions
from
dba_hist_active_sess_history
where
sample_time > trunc(sysdate) + 1 - $nbjour
group by
sample_id,
sample_time
) sub1
group by
round(sub1.sample_time, 'HH24')
order by
round(sub1.sample_time, 'HH24')
/
--
exit
EOT
#
#######################################
#
date
#
#
