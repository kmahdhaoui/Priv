#!/bin/bash
# Author : Kamel Mahdhaoui
#
# idle_time:hundredths of a second that a processor has been idle, totaled over all processors
# busy_time:The number(in hundredths of a second) that a processor has been busy 
          # executing user or kernel code, totaled over all processors
# user_time:hundredths of a second that a processor has been busy executing user code, totaled over all processors
# sys_time:hundredths of a second that a processor has been busy executing kernel code, totaled over all processors
# iowait_time:hundredths of a second that a processor has been waiting for I/O to complete, totaled over all processors
# os_cpu_wait_time:hundredths of a second that processes have been in a ready state, 
                 # waiting to be selected by the operating system scheduler to run
# vm_page_in_bytes: number of bytes of data that have been paged in due to virtual memory paging
# physical_memory_bytes: Total number of bytes of physical memory
# load : Current number of processes that are either running or in the ready state, 
       # waiting to be selected by the operating-system scheduler to run. On many platforms, 
       # this statistic reflects the average load over the past minute.
#
if [ "$1" == "" ] 
then
   export NBJOURS=1
else
   export NBJOURS=$1
fi
#
if [ "$2" == "" ]
then
   export lastat=%
else
   export lastat=$2
fi
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export KMymd=`date "+%Y%m%d"`
#
export Ftmp=/tmp/tmp_os_trends.$KMymdhms.tmp
rm -f $Ftmp
#
date
#
export leowner=CISADM
#
sqlplus -s "$conn" <<EOT
set feedback off heading off verify off
set lines 133
spool $Ftmp
select distinct STAT_NAME from dba_hist_osstat where STAT_NAME like '$lastat'  order by 1
;
spool off
exit
EOT
#
#######################################
#
for lastat in `cat $Ftmp`
do
echo "lastat:$lastat"
sqlplus -s "$conn"  <<EOT
set pagesize 50000
set trimspool on
set lines 133
col value format a20
set time off timi off echo off verify off feedback off heading off 
--
col OWNER format a10
col TABLE_NAME format a30
col INCREMENTAL format a10
col GRANULARITY format a10
col STALE_PERCENT format A6
col ESTIMATE_PERCENT format a30
col CASCADEA format a10
col METHOD_OPT format a20
--
define m_stat_name = '$lastat'
 
column  instance_number   new_value m_instance  noprint
column  dbid              new_value m_dbid      noprint
 
select
        ins.instance_number,
        db.dbid
from
        v\$instance        ins,
        v\$database        db
;
--
column        value      format        999,999,999,999
column        curr_value format        999,999,999,999
column        prev_value format        999,999,999,999
col stat_name format a30
break on stat_name
set heading on
--
with base_line as (
        select
                /*+ materialize */
                snp.snap_id,
                to_char(snp.end_interval_time,'Mon-dd hh24:mi:ss')     end_time,
                ost.value
        from
                dba_hist_snapshot       snp,
                dba_hist_osstat         ost
        where
                snp.dbid            = &m_dbid
        and     snp.instance_number = &m_instance
        and     end_interval_time   between sysdate - 30 and sysdate
        and     ost.dbid            = snp.dbid
        and     ost.instance_number = snp.instance_number
        and     ost.snap_id         = snp.snap_id
        and     ost.stat_name       = '&m_stat_name'
        and     snp.end_interval_time > trunc(sysdate - $NBJOURS + 1)
)
select
        substr('$lastat                             ',1,30) stat_name,
        b1.end_time           start_of_delta,
        b1.value              prev_value,
        b2.value              curr_value,
        b2.value - b1.value   value
from
        base_line        b1,
        base_line        b2
where
        b2.snap_id = b1.snap_id + 1
order by
        b1.snap_id
;
--
exit
EOT
#
done
#
#######################################
#
date
#
rm -f $Ftmp 1>/dev/null 2>&1
#
