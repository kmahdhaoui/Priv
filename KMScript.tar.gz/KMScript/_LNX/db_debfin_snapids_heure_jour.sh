#!/bin/bash
# Author : Kamel Mahdhaoui
#
#
if [ "$1" == "" ] 
then
   echo "Usage is : $0 <heure deb:hh> <heure fin>"
   echo "Exemple  : $0 08 09"
   echo "Exemple  : db_main_wait_event_periode.sh \`bash $0 08 09\`"
   exit 1
else
   export heure_d=$1
fi
#
if [ "$2" == "" ]
then
   echo "Usage is : $0 <heure deb:hh> <heure fin>"
   echo "Exemple  : $0 08 09"
   echo "Exemple  : db_main_wait_event_periode.sh \`bash $0 08 09\`"
   exit 2
else
   export heure_f=$2
fi
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export KMymd=`date "+%Y%m%d"`
#
export dateheure_d=`date "+%Y-%m-%d_"`${heure_d}:00:00
export dateheure_f=`date "+%Y-%m-%d_"`${heure_f}:00:00
#
export snapids=`bash db_debfin_snapids.sh $dateheure_d $dateheure_f`
export snapid_d=`echo $snapids |awk -F" " '{print $1}'` 
export snapid_f=`echo $snapids |awk -F" " '{print $2}'` 
echo "$snapid_d $snapid_f"
#
#######################################
#
#
#
