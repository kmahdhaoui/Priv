#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
export CLAUSENOTIN="('CONNECT', 'RESOURCE', 'DBA', 'SELECT_CATALOG_ROLE',"
export CLAUSENOTIN="$CLAUSENOTIN 'EXECUTE_CATALOG_ROLE', 'DELETE_CATALOG_ROLE', 'EXP_FULL_DATABASE',"
export CLAUSENOTIN="$CLAUSENOTIN 'IMP_FULL_DATABASE', 'LOGSTDBY_ADMINISTRATOR', 'DBFS_ROLE',"
export CLAUSENOTIN="$CLAUSENOTIN 'AQ_ADMINISTRATOR_ROLE', 'AQ_USER_ROLE', 'DATAPUMP_EXP_FULL_DATABASE',"
export CLAUSENOTIN="$CLAUSENOTIN 'DATAPUMP_IMP_FULL_DATABASE', 'ADM_PARALLEL_EXECUTE_TASK',"
export CLAUSENOTIN="$CLAUSENOTIN 'GATHER_SYSTEM_STATISTICS', 'JAVA_DEPLOY', 'RECOVERY_CATALOG_OWNER',"
export CLAUSENOTIN="$CLAUSENOTIN 'SCHEDULER_ADMIN', 'HS_ADMIN_SELECT_ROLE', 'HS_ADMIN_EXECUTE_ROLE',"
export CLAUSENOTIN="$CLAUSENOTIN 'HS_ADMIN_ROLE', 'GLOBAL_AQ_USER_ROLE', 'OEM_ADVISOR', 'OEM_MONITOR',"
export CLAUSENOTIN="$CLAUSENOTIN 'WM_ADMIN_ROLE', 'JAVAUSERPRIV', 'JAVAIDPRIV', 'JAVASYSPRIV',"
export CLAUSENOTIN="$CLAUSENOTIN 'JAVADEBUGPRIV', 'EJBCLIENT', 'JMXSERVER', 'JAVA_ADMIN', 'CTXAPP',"
export CLAUSENOTIN="$CLAUSENOTIN 'XDBADMIN', 'XDB_SET_INVOKER', 'AUTHENTICATEDUSER', 'XDB_WEBSERVICES',"
export CLAUSENOTIN="$CLAUSENOTIN 'XDB_WEBSERVICES_WITH_PUBLIC', 'XDB_WEBSERVICES_OVER_HTTP', 'OLAP_DBA',"
export CLAUSENOTIN="$CLAUSENOTIN 'ORDADMIN', 'OLAP_XS_ADMIN', 'CWM_USER','OLAP_USER','SPATIAL_WFS_ADMIN',"
export CLAUSENOTIN="$CLAUSENOTIN 'WFS_USR_ROLE', 'SPATIAL_CSW_ADMIN', 'CSW_USR_ROLE', 'MGMT_USER',"
export CLAUSENOTIN="$CLAUSENOTIN 'APEX_ADMINISTRATOR_ROLE','OWB\$CLIENT','OWB_DESIGNCENTER_VIEW','OWB_USER')"
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col ROLE format a22
col HOST  format a22
col OWNER format a22
col USERNAME format a22
set heading off
set lines 152
col DbLink format a151
prompt 
prompt =========================== DB ROLES ===========================
select 
'create role '||role||';' from dba_roles  where role not in 
$CLAUSENOTIN
;
--
select 'grant '||GRANTED_ROLE||' to '||GRANTEE ||';'
from dba_role_privs where GRANTED_ROLE in 
(select  role from dba_roles  where role not in 
$CLAUSENOTIN
)
;
--
select 'grant '||GRANTED_ROLE||' to '||GRANTEE ||';'
from dba_role_privs where GRANTEE in
(select  role from dba_roles  where role not in
$CLAUSENOTIN
)
;
--
-- 
exit
EOT
#
. $KMscript/KMlogout.sh
#

