#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
#
if [ "$1" == "" ] 
then
   echo "Usage is : $0 <owner> "
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
set lines 132
set pages 555
col PERE format a35
col FILS format a31
col CONST_F format a31
col STATUS_F format a12
--
col ED format a3
col table_name format a31
col const format a31
col fkcolumn format a31
col index_name format a31
col index_columns format a31
--
select
case
   when a.status='ENABLED'  then
      'EN'
   else
      'DIS'
end as ED,
   a.table_name       table_name,
   a.constraint_name  const,
  a.fkcolumn       fkcolumn,
  nvl(b.index_name,'-- no index --')   index_name
--  ,b.index_columns    index_columns
from
( select a.table_name, a.constraint_name, b.status,
   listagg(a.column_name, ',') within group (order by a.position) fkcolumn
 from dba_cons_columns a, dba_constraints b
 where a.constraint_name = b.constraint_name and 
   b.constraint_type = 'R' and a.owner = '$1' and a.owner = b.owner
 group by a.table_name, a.constraint_name, b.status
) a
,
( select table_name, index_name,
   listagg(c.column_name, ',') within group (order by c.column_position) index_columns
 from dba_ind_columns c
 where c.index_owner = '$1'
 group by table_name, index_name
) b
where a.table_name = b.table_name(+)
and b.index_columns(+) like a.fkcolumn || '%'
order by 1 desc, 2
;
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
