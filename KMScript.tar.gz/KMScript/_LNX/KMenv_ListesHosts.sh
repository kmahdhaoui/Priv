#!/bin/ksh
#
# Variables defaut
#
unset ListeHostsTest ListeHostsTout_1 ListeHostsTout_2 ListeHostsDMZ ListeHostsSaturne ListeHostsDev ListeHostsRec ListeHostsPrex ListeHostsProd ListeHostsDevTest ListeHostsRecTest ListeHostsPrexTest
#
export ListeHostsDev=""
export ListeHostsRec=""
export ListeHostsInt=""
export ListeHostsBen=""
export ListeHostsSat=""
#
export ListeHostsAutre=""
export ListeHostsPrex=""
export ListeHostsProd=""
#
export ListeHostsDMZ=""
export ListeHostsRIM=""
#
export ListeHostsErreur=""
#
export ListeHostsSimu=""
#
export ListeHostsProd_ssd=""
export ListeHostsRIM_ssd=""
#
export ListeHostsPGI="dapgisimulc1 dapgiprodc1"
export ListeHostsQuarantaine="dsdevc1 dsdfpe1 daprodd3 dsdev1"
#
#------------------------------------------------------------------
#
cat copie_listserv.cnf | while read LINE
do
export LeHst=`echo $LINE |awk -F" "  '{print $1 }'`
export LeEnv=`echo $LINE |awk -F" "  '{print substr($2,1,3) }'`
export LeRes=`echo $LINE |awk -F" "  '{print substr($3,1,3) }'`
#
case $LeRes in 
     DMZ) export ListeHostsDMZ="$ListeHostsDMZ $LeHst" ;;
     RIM) export ListeHostsRIM="$ListeHostsRIM $LeHst" 
          case $LeHst in 
	       dasgbdprodd1*) ListeHostsRIM_ssd="$ListeHostsRIM_ssd"        ;;
                           *) ListeHostsRIM_ssd="$ListeHostsRIM_ssd $LeHst" ;;
 	  esac
          ;;
       *) export ListeHostsErreur="$ListeHostsErreur $LeHst" ;;
esac
#
if [ "$LeRes" != "DMZ" ]
then
case $LeEnv in 
     Dev) export ListeHostsDev="$ListeHostsDev $LeHst" ;;
     Rec) export ListeHostsRec="$ListeHostsRec $LeHst" ;;
     Int) export ListeHostsInt="$ListeHostsInt $LeHst" ;;
     Ben) export ListeHostsBen="$ListeHostsBen $LeHst" ;;
     Sat) export ListeHostsSat="$ListeHostsSat $LeHst" ;;
     Pro) export ListeHostsProd="$ListeHostsProd $LeHst" 
          case $LeHst in 
	       dasgbdprodd1*) ListeHostsProd_ssd="$ListeHostsProd_ssd"        ;;
                           *) ListeHostsProd_ssd="$ListeHostsProd_ssd $LeHst" ;;
 	  esac
          ;;
     Pre) export ListeHostsPrex="$ListeHostsPrex $LeHst" ;;
       *) export ListeHostsErreur="$ListeHostsErreur $LeHst" ;;
esac
fi
#
#
done
#
#------------------------------------------------------------------
#
export ListeHostsAutre="$ListeHostsAutre $ListeHostsDev $ListeHostsRec  $ListeHostsInt  $ListeHostsBen $ListeHostsSat"
#
export ListeHostsSaturne="$ListeHostsSat"
#
export ListeHostsDevTest="$ListeHostsDev"
export ListeHostsRecTest="$ListeHostsRec"
export ListeHostsPrexTest="$ListeHostsPrex"
export ListeHostsTest="$ListeHostsTestDev $ListeHostsRecTest $ListeHostsPrexTest"
#
export ListeHostsProd_1="$ListeHostsProd"
export ListeHostsProd_2="$ListeHostsProd"
export ListeHostsProd_ssd1="$ListeHostsProd_ssd"
export ListeHostsProd_ssd2="$ListeHostsProd_ssd"
#
export ListeHostsTout_1="$ListeHostsRIM"
export ListeHostsTout_2="$ListeHostsRIM"
export ListeHostsTout_ssd1="$ListeHostsRIM_ssd"
export ListeHostsTout_ssd2="$ListeHostsRIM_ssd"
#
#------------------------------------------------------------------
#
#
