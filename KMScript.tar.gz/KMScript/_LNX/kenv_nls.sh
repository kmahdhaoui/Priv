#!/bin/bash
# kamel Mahdhaoui
# la base c'est $ORACLE_SID
# si pas de ORACLE_SID on ne sette pas le sid
#
#
export FIC_NLS=nls_lang.$ORACLE_SID.$KMymdhms.$$
#
sqlplus -s $conn 1>/dev/null <<EOT
set verify off feedback off heading off pages 0 lines 80 pause off
whenever sqlerror exit 1;
whenever oserror exit 2;
spool /tmp/$FIC_NLS
-- dans l'ordre
select value from NLS_DATABASE_PARAMETERS where PARAMETER='NLS_CHARACTERSET' ;
select value||'.' from NLS_DATABASE_PARAMETERS where PARAMETER='NLS_TERRITORY' ;
select value||'_' from NLS_DATABASE_PARAMETERS where PARAMETER='NLS_LANGUAGE' ;
--
spool off
exit 0
EOT
#
if [ $? -ne 0 ]
then
   echo "Erreur Recup NLS_LANG !!!"
   export NLS_LANG=AMERICAN_AMERICA.WE8MSWIN1252
   echo "MIS PAR DEFAUT A : --> $NLS_LANG <--"
   return 1
fi
GETNLSLANG=""
for ii in `cat /tmp/$FIC_NLS`
do
  export GETNLSLANG="$ii$GETNLSLANG"
done
export NLS_LANG=$GETNLSLANG
echo "$NLS_LANG"
rm -f /tmp/$FIC_NLS 1>/dev/null 2>&1
#
return 0
#
#
