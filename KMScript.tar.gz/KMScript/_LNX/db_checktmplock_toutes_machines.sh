#!/bin/ksh
# Author : Kamel Mahdhaoui
# 
# db_listbase_toutes_machines.sh |tee -a work/listbase_toutes_machines_rim.txt 
# 
. ~oracle/.profile 1>/dev/null 2>&1
export ORACLE_SID=lastbase
. ~oracle/kamel/KMscript/kamel.profile silent 1>/dev/null 2>&1
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh 1>/dev/null 1>/dev/null 2>&1
#
# met a jour : ListeHostsTout_2 
. $KMscript/KMenv_ListesHosts.sh
#
echo "host;" "sid;" "tmplock;"
#
export ListeHosts="$ListeHostsProd"
export ListeHosts="$ListeHostsTout_2"
#
for MACHINE_EXE in $ListeHosts
do
   ssh $MACHINE_EXE "~oracle/kamel/KMscript/db_checktmplock.sh"	
done 
#
. $KMscript/KMlogout.sh 1>/dev/null 2>&1
#

