#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s '/ as sysdba' <<EOT
@$KMscript/$SQLLOGIN
--
--
set pages 0
set lines 130
set feedback off
set termout off
spool /tmp/tmp_get_ddl_users_$$.tmp 
select 'SET LONGCHUNKSIZE 150' from dual;
select 'set long 200000000' from dual;
select 'set pages 0' from dual;
select 'set feedback off ' from dual;
select 'set lines 132 ' from dual;

select 'execute DBMS_METADATA.SET_TRANSFORM_PARAM(DBMS_METADATA.SESSION_TRANSFORM,''STORAGE'',false); ' from dual;
select 'execute DBMS_METADATA.SET_TRANSFORM_PARAM(DBMS_METADATA.SESSION_TRANSFORM,''PRETTY'',true); ' from dual;
select 'execute DBMS_METADATA.SET_TRANSFORM_PARAM(DBMS_METADATA.SESSION_TRANSFORM,''SQLTERMINATOR'',true); ' from dual;

select 'select dbms_metadata.get_ddl(''USER'','''||username||''') from dual;' from dba_users where username = '$1' ;
select 'select dbms_metadata.GET_GRANTED_DDL(''ROLE_GRANT'','''||username||''') from dual;' from dba_users where username = '$1' ;
-- select 'select dbms_metadata.GET_GRANTED_DDL(''SYSTEM_GRANT'','''||username||''') from dual;' from dba_users where username = '$1' ;
-- select 'select dbms_metadata.GET_GRANTED_DDL(''OBJECT_GRANT'','''||username||''') from dual;' from dba_users where username = '$1' ;

select 'EXECUTE DBMS_METADATA.SET_TRANSFORM_PARAM(DBMS_METADATA.SESSION_TRANSFORM,''DEFAULT''); ' from dual;
spool off 
set termout on
--
--
select '-----------------------------------------' from dual;
@/tmp/tmp_get_ddl_users_$$.tmp
select '-----------------------------------------' from dual;
--
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
