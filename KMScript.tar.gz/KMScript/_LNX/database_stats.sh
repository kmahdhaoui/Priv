#
sqlplus / as sysdba <<EOT
--
exec dbms_stats.gather_FIXED_OBJECTS_STATS ;
exec dbms_stats.gather_DICTIONARY_STATS (degree=>48);
exec dbms_stats.gather_database_stats(cascade=>true,degree=>48,ESTIMATE_PERCENT=>100,GRANULARITY=>'APPROX_GLOBAL AND PARTITION');
--
commit;
exit
EOT
#
