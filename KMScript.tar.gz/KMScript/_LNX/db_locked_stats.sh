#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
set pages 0
--
SELECT distinct 'execute DBMS_STATS.UNLOCK_TABLE_STATS('''||owner||''','''||TABLE_NAME||''');' FROM DBA_TAB_STATISTICS WHERE STATTYPE_LOCKED = 'ALL' and owner='CISADM'
/
--
-- ;
exit
EOT
#
. $KMscript/KMlogout.sh
#
