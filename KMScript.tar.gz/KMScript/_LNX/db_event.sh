#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
#
if [ "$1" == "" ]
then
   export Event="db file sequential read"
else
   export Event="$1"
fi
#
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
-- Excellent: < 1ms
-- Very good: < 5ms
-- Good: 5 – 10ms
-- Poor: 10 – 20ms
-- Bad: 20 – 100ms
-- Shockingly bad: 100 – 500ms
--
--
col BEGIN_INTERVAL_TIME  format a20
col INSTANCE_NUMBER format 999
col ins format 999
col SNAP_ID format 999999
col EVENT_NAME format a25
col EVENT      format a33
col EVENT_TIME_WAITED  format 999999
col TOTAL_WAITS format 999999999
col PCT format 999999
col AVG_WAIT format 999999
-- 
-- alter session set nls_date_format='yyyy-mm_dd hh24:mi' ;
--
prompt =============================== Wait System Event    ===================================
SELECT * FROM
(SELECT event, total_waits, ROUND(100 * (total_waits / sum_waits),2) pct_waits, time_wait_sec,
       ROUND(100 * (time_wait_sec / GREATEST(sum_time_waited,1)),2) pct_time_waited, total_timeouts,
       ROUND(100 * (total_timeouts / GREATEST(sum_timeouts,1)),2) pct_timeouts, AVG_wait_Msec
FROM (SELECT event, total_waits, ROUND((time_waited / 100),2) time_wait_sec, total_timeouts,
ROUND((average_wait),2)*10 AVG_wait_Msec
FROM sys.v_\$system_event
WHERE event NOT IN (SELECT NAME FROM v\$event_name WHERE wait_class = 'Idle')
AND event NOT LIKE 'DFS%'
AND event NOT LIKE 'KXFX%'),
(SELECT SUM(total_waits) sum_waits, SUM(total_timeouts) sum_timeouts,
SUM(ROUND((time_waited / 100),2)) sum_time_waited
 FROM sys.v_\$system_event WHERE event NOT IN
 (SELECT NAME FROM v\$event_name WHERE wait_class = 'Idle')
AND event NOT LIKE 'DFS%'
AND event NOT LIKE 'KXFX%')
ORDER BY 2 DESC, 1 ASC)
WHERE (pct_time_waited <> 0 OR total_timeouts <> 0 OR pct_timeouts <> 0 OR avg_wait_msec <> 0)
AND pct_waits <> 0
;
--
prompt =============================== Wait Session Event    ===================================
select  event ,WAIT_CLASS_ID,count(*) NBR from V\$SESSION_WAIT group by event ,WAIT_CLASS_ID order by 3 desc
;
-- 
-- 
-- 
prompt =============================== HISTORICAL : $Event ===================================
select to_char(s.begin_interval_time,'yyyy-mm_dd hh24')||'' begin_interval_time,m.* from
(select ee.instance_number ,ee.snap_id,ee.event_name,round(ee.event_time_waited/1000000) event_time_waited,ee.total_waits,
round((ee.event_time_waited*100)/et.total_time_waited,1) pct,round((ee.event_time_waited/ee.total_waits)/1000) avg_wait
from (select ee1.instance_number,ee1.snap_id,ee1.event_name,ee1.time_waited_micro-ee2.time_waited_micro event_time_waited,
 ee1.total_waits - ee2.total_waits total_waits
from DBA_HIST_SYSTEM_EVENT ee1 join DBA_HIST_SYSTEM_EVENT ee2
  on ee1.snap_id = ee2.snap_id+1 and ee1.instance_number = ee2.instance_number and ee1.event_id = ee2.event_id
  and ee1.wait_class_id <> 2723168908 and ee1.time_waited_micro-ee2.time_waited_micro > 0
 union
 select st1.instance_number,st1.snap_id,st1.stat_name event_name,st1.value - st2.value event_time_waited,1 total_waits
 from DBA_HIST_SYS_TIME_MODEL st1 join DBA_HIST_SYS_TIME_MODEL st2 on st1.instance_number = st2.instance_number
 and st1.snap_id = st2.snap_id + 1 and st1.stat_id = st2.stat_id and st1.stat_name='DB CPU'
 and st1.value - st2.value > 0) ee join
(select et1.instance_number,et1.snap_id,et1.value - et2.value total_time_waited
from DBA_HIST_SYS_TIME_MODEL et1 join DBA_HIST_SYS_TIME_MODEL et2 on et1.snap_id=et2.snap_id+1
and et1.instance_number = et2.instance_number and et1.stat_id = et2.stat_id and et1.stat_name='DB time'
and et1.value - et2.value > 0 ) et
on ee.instance_number = et.instance_number and ee.snap_id = et.snap_id) m join DBA_HIST_SNAPSHOT s on m.snap_id = s.snap_id
 where event_name like '$Event' -- and pct>10
order by m.instance_number,m.snap_id,event_time_waited desc
;
--
exit
EOT
#
if [ "$Event" == "db file sequential read" ]
then
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
-- 
col segment_name format a35
col NBR format 9999999
--
prompt =============================== Segments for db file sequential read =====
-- P1 = file#
-- P2 = block#
-- P3 = blocks
--
SELECT e.owner , e.segment_name , e.segment_type,count(*) NBR 
FROM dba_extents e,v\$session_wait sw
where  sw.event='db file sequential read'
and e.file_id = sw.P1 AND sw.P2 BETWEEN e.block_id AND e.block_id + sw.P2 -1
group by e.owner , e.segment_name , e.segment_type
;
--
exit
EOT
fi
#
#
if [ "$Event" == "db file scattered read" ]
then
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col segment_name format a35
col NBR format 9999999
--
prompt =============================== Segments for db file scattered read =====
-- P1 = file#
-- P2 = block#
-- P3 = blocks
--
SELECT sw.SID, o.owner,o.object_name, b.FILE#, b.dbablk
FROM v\$session_wait sw, sys.x\$bh b,dba_objects o
WHERE 
    b.obj=o.object_id 
AND sw.p1 = b.FILE#(+)
AND sw.p2 = b.dbablk(+)
AND sw.event = 'db file scattered read'
-- AND sw.SID like '%'
;
--
exit
EOT
fi
#
. $KMscript/KMlogout.sh
#
