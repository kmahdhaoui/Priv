#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
alter session set nls_date_format='yyyy-mm-dd hh24:mi:ss';
--
col SCHEMA_USER format a12
col job format 9999
col "Intervalle" format  a30
col "Dernier refresh" format a20
col "Prochain refresh" format a20
col "Refresh what" format a70
--
prompt DBA_JOBS 
prompt ********
SELECT job, SCHEMA_USER,
TO_CHAR(last_date, 'yyyy-mm-dd HH24:MI') "Dernier refresh",
TO_CHAR(next_date, 'yyyy-mm-dd HH24:MI') "Prochain refresh",
interval "Intervalle"
FROM dba_jobs
order by SCHEMA_USER,job
;
--
prompt DBA_SCEDULER_JOBS 
prompt *****************
SELECT job_name, enabled FROM dba_scheduler_jobs
;
--
prompt DBA_MVIEWS 
prompt **********
col owner format a15
select OWNER,MVIEW_NAME,FAST_REFRESHABLE,LAST_REFRESH_TYPE,LAST_REFRESH_DATE from dba_mviews 
order by OWNER,LAST_REFRESH_DATE desc ,MVIEW_NAME
;
prompt Invalid DBA_MVIEWS
prompt ******************
select OWNER,MVIEW_NAME,LAST_REFRESH_DATE,COMPILE_STATE from dba_mviews
where COMPILE_STATE != 'VALID'
order by OWNER,MVIEW_NAME
;
--
prompt DBA_MVIEW_REFRESH_TIMES 
prompt ***********************
col MASTER_OWNER format a25
col OWNER format a15
select * from DBA_MVIEW_REFRESH_TIMES 
order by master_owner,OWNER,LAST_REFRESH desc
;
-- col OBJECT_NAME format a40
-- select OWNER,OBJECT_NAME,LAST_DDL_TIME from dba_objects where object_type like 'MATER%' ;
--
prompt DBA_JOBS order by WHAT
prompt **********************
select job,
what "Refresh what",
last_date "Dernier refresh",
next_date "Prochain refresh",
BROKEN 
from dba_jobs
order by what
;
--
col ROWNER format a15
col RNAME format a30
col REFGRP format a20
-- col JOB 
-- col NEXT_DATE
col INTERVAL format a40
col chlid format a43
col refgrp format a32
prompt DBA_REFRESH
prompt ***********
select ROWNER,RNAME,REFGROUP,JOB,NEXT_DATE,INTERVAL,BROKEN from DBA_REFRESH;

prompt DBA_REFRESH_CHILDREN
prompt ********************
select job,REFGROUP,OWNER||'.'||NAME chlid,RNAME refgrp,BROKEN from DBA_REFRESH_CHILDREN
order by OWNER||'.'||NAME
;
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
