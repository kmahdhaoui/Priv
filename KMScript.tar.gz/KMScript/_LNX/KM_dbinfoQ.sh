#!/usr/bin/ksh
# Author : Kamel Mahdhaoui
#
# date "+day=%d; month=%m; year=%Y"
# date "+day=%d; month=%m; year=%Y"
# eval `date "+day=%d; month=%m; year=%Y ; myHour=%k ; jour=%w" `
export chaine=`date "+day=%d; month=%m; year=%Y ; myHour=%k ; jour=%w ; semaine=%W "`
export chaine=`echo $chaine | tr -d ' ' `
eval $chaine
#jour=$(printf "%01d" $jour)
#day=$(printf "%02d" $day)
#month=$(printf "%02d" $month)
#myHour=$(printf "%02d" $myHour)
#year=$(printf "%04d" $year)
export day month year myHour jour
#
#
anch ()
{
# echo "<a href='$1'>$2 : $year$month$day</a>"
echo "<a href='$1'>$2 </a>"
}

trec ()
{
echo "<tr>"
export i=1
while [ i -le $# ]
do
   echo "<td>$1</td>" 
   shift
done
echo "</tr>"
}
#
##################
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
cd $KMscript
#
# 
export LISTE_PRIMARY="db_ind_cols.sh db_recup_commun.sh db_recup_prim.sh db_rsrc_sess.sh db_rsrc.sh df_m.sh db_fic_alert.sh db_asm.sh db_bckprog.sh db_bcksum.sh db_dfi.sh db_dgmessage.sh db_files.sh db_fra.sh db_holder.sh db_incarnation.sh db_infosauvegarde.sh db_locks.sh db_loghis.sh db_service.sh db_sess.sh db_seuils.sh db_snap.sh db_space.sh db_stat_job.sh db_status.sh db_sync.sh db_thread.sh dbup.sh db_uptime.sh dgm_config.sh dgm_status.sh prd_dest2status.sh prd_dest3status.sh db_ash.sh db_dp.sh db_longops.sh db_invalid.sh db_sql_sess.sh db_top_sess.sh"
#
export LISTE_ERREUR="dbup.sh df_m.sh"
#
export LISTE_STANDBY="db_recup_commun.sh db_recup_stdby.sh df_m.sh db_fic_alert.sh db_asm.sh db_bckprog.sh db_bcksum.sh db_dgmessage.sh db_files.sh db_fra.sh db_holder.sh db_incarnation.sh db_infosauvegarde.sh db_loghis.sh db_service.sh db_sess.sh db_status.sh db_sync.sh db_thread.sh dbup.sh db_uptime.sh dgm_config.sh dgm_status.sh sec_managed_stdby.sh"
#
case $KMhost in
    zz*)  export tt="1"
         export LISTE_T="$LISTE_A $LISTE_B"
         export Liste_dbsingle=""
         ;;
    xxx*)
         export tt="2"
         export LISTE_T="$LISTE_A $LISTE_B"
         export Liste_dbsingle=""
         ;;
esac
#
# recup_champlan_db3-psw_ECOM_2011081112.txt: recup_${KMsite}_${KMhost}_*_${year}${month}${day}.txt
export log_jour_prefix=info_${year}${month}${day}_${KMsite}_${KMhost}_${jour}
export log_jour=${log_jour_prefix}_${myHour}h
export repOut=$KMscript/log/${log_jour}
mkdir -p $KMscript/log/${log_jour}
#
echo " " > $repOut/index.html
for mydb in $Liste_dbsingle
do
export LISTE_T="$LISTE_ERREUR"
export ORACLE_SID=$mydb
export mydbrole=`/usr/bin/ksh $KMscript/db_role.sh $ORACLE_SID`
case $mydbrole  in
    PRIMARY*) export LISTE_T="$LISTE_COMMUNE $LISTE_PRIMARY" ;;
    PSTDBY*)  export LISTE_T="$LISTE_COMMUNE $LISTE_STANDBY" ;;
    *)        export LISTE_T="$LISTE_ERREUR" ;;
esac
#
mkdir  -p $repOut/$mydb
echo "<p>`anch $mydb/$mydb.html $mydb`</p>" >> $repOut/index.html
> $repOut/$mydb/$mydb.html
#
cd $KMscript/log
export ORACLE_SID=$mydb
export ORAENV_ASK=NO
#. oraenv
export ORAENV_ASK=YES
#
###################
# trier un peu
export LISTE_ACT=""
export LISTE_VOL=""
export LISTE_BCK=""
export LISTE_ERR=""
export LISTE_CFG=""
export LISTE_DGB=""
export LISTE_XXX=""
#
for ii in $LISTE_T
do
   base_ii=`basename $ii .sh`
   lib_base_ii=`/usr/bin/ksh $KMscript/db_libelle_script.sh $base_ii`
   case $lib_base_ii in
   ACT*) export LISTE_ACT="$LISTE_ACT $ii" ;;
   VOL*) export LISTE_VOL="$LISTE_VOL $ii" ;;
   BCK*) export LISTE_BCK="$LISTE_BCK $ii" ;;
   ERR*) export LISTE_ERR="$LISTE_ERR $ii" ;;
   CFG*) export LISTE_CFG="$LISTE_CFG $ii" ;;
   DGB*) export LISTE_DGB="$LISTE_DGB $ii" ;;
      *) export LISTE_XXX="$LISTE_XXX $ii" ;;
   esac
done
export LISTE_T="$LISTE_ACT $LISTE_VOL $LISTE_BCK $LISTE_ERR $LISTE_CFG $LISTE_DGB $LISTE_XXX"
#
###################
for ii in $LISTE_T
do
   base_ii=`basename $ii .sh`
   lib_base_ii=`/usr/bin/ksh $KMscript/db_libelle_script.sh $base_ii|awk -F":" '{print $2}'`
   mod_base_ii=`/usr/bin/ksh $KMscript/db_libelle_script.sh $base_ii|awk -F":" '{print $1}'`
   echo "<p><div id="$mod_base_ii">`anch $base_ii.html "$lib_base_ii"`</p>" >> $repOut/$mydb/$mydb.html.notsorted
   # /usr/bin/ksh $base_ii.sh       > $repOut/$mydb/$base_ii.out
   /usr/bin/ksh $base_ii.sh -html > $repOut/$mydb/$base_ii.html
done
sort $repOut/$mydb/$mydb.html.notsorted >> $repOut/$mydb/$mydb.html
rm -f $repOut/$mydb/$mydb.html.notsorted
#
done
#
cd $KMscript/log
rm -f ${log_jour}.tar.gz
#
cp $KMscript/log/recup_${KMsite}_${KMhost}_*_${year}${month}${day}*.txt ./${log_jour}
tar -cvf ${log_jour}.tar ./${log_jour}
gzip -f ${log_jour}.tar
#
if [ $? -eq 0 ]
then
   # supprimer $repOut
   rm -rf $KMscript/log/${log_jour}
fi
#
find  $KMscript/log -name "info_*_${KMsite}_${KMhost}*.tar.gz*" -mtime +2 -exec rm {} \;
#
. $KMscript/KMlogout.sh
#
