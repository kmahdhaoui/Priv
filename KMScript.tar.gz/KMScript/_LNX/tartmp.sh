#!/bin/bash
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export MyHost=`hostname`
#
export nomp=`pwd`
export nomp=`echo $nomp|tr '/' '_'|tr -d 'a'|tr -d 'e'|tr -d 'i'|tr -d 'o'|tr -d 'u'`
export nom=SVG_${MyHost}_${nomp}
#
tar -cvf /tmp/$nom.$KMymdhms.tar ./ --exclude "*log*" --exclude "*tmp*" --exclude "*dmp*" --exclude "*tar*" --exclude "*temp*" --exclude "*diag*" --exclude "*trace*" --exclude "*DMP*"
gzip /tmp/$nom.$KMymdhms.tar 
#
ll /tmp/$nom.$KMymdhms.tar*
cp /tmp/$nom.$KMymdhms.tar* /sitr/backup
chmod o+rw /sitr/backup/SVG_*
scp /tmp/$nom.$KMymdhms.tar* oracle@sefrapp00153:/sitr/backup
scp /tmp/$nom.$KMymdhms.tar* oracle@sefrapp00154:/sitr/backup
#
