#!/bin/bash
# kma
#
# set before $CISMWTAB_SID
#
#
# -
if [ "$1" == "" ]
then
   export startoption=""
else
   export startoption=$1
fi
#
#
export nomPROG=kstart_all_mdms.sh
export NombrePS=`ps -ef |grep $nomPROG |grep -v grep|grep ">"|wc -l`
if [ "$NombrePS" -gt 1 ]
then
   echo "Il y a deja $0 qui tourne !"
   ps -ef |grep $nomPROG |grep -v grep
   exit 103
fi
#
# les variables pour le batch
. /sitr/exploit/wls/local_cismwenv
#
cd $BINDIR
#
export DATE=$(date "+%d/%m/%Y %H:%M:%S")
rm -f ${WORKDIR}/kstart_all_mdms_$$.tmp* 1>/dev/null 2>&1
#
export SQLTMP=${WORKDIR}/kstart_all_mdms_$$.tmp
#
##########################
# La liste c'est les mdms de $BINDIR/cismwtab
cat $BINDIR/cismwtab |sort -u | grep -v '^$'| grep -v '^#' |grep ":" | awk -F: '{print $1}'|sed 's/ //g' | while read leSID 
do
#
##############
echo bash $BINDIR/kstart_un_mdm.sh $leSID $startoption
echo bash $BINDIR/kstart_un_mdm.sh $leSID $startoption 1>$LOGDIR/kstart_un_mdm_$leSID.$$.log 2>&1 

##############
#
done
##########################
#
#
