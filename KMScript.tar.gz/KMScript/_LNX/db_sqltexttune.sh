#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
#
export task_id=$KMymdhms
echo $task_id
#
if [ "$1" == "" ]
then
   export v_sql_text=`cat sqltexttune.req`
else
   export v_sql_text="$1"
fi
#
echo "$v_sql_text"
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col RESOURCE_CONSUMER_GROUP format a25
col sid format 999999
col USERNAME format a18
col MACHINE format a18
col program format a26
col spid format  a13
--
-- tuning task
set heading on  feedback off verify off
set serveroutput on
declare
  l_sql_tune_task_id  varchar2(100);
begin
  l_sql_tune_task_id := dbms_sqltune.create_tuning_task (
                          sql_text    => '$v_sql_text',
                          scope       => dbms_sqltune.scope_comprehensive,
                          time_limit  => 60,
                          task_name   => 'task_$task_id',
                          description => 'tuning task for statement $task_id .');
  dbms_output.put_line('sql_tune_task_id: ' || l_sql_tune_task_id);
end;
/
--
-- executing 
exec dbms_sqltune.execute_tuning_task(task_name => 'task_$task_id');
--
-- displaying the recommendations
set long 100000;
set longchunksize 1000
set pagesize 10000
set linesize 100
select dbms_sqltune.report_tuning_task('task_$task_id') as recommendations from dual;
--
exec dbms_sqltune.drop_tuning_task(task_name => 'task_$task_id');
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
