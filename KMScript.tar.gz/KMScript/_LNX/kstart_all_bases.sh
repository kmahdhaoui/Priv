#!/bin/bash
# kma
# Config necessaire dans:/sitr/exploit/dba/kstopstart.dba.oratab
# Exemple:ODMEDP:/opt/app/oracle/product/12.1.0/db_1:N:StartOnBoot
# Remarque:ajouter "StartOnBoot" pour demarrage automatique
#
# set before $ORACLE_HOME
#
#
# -s start optiona (OPEN, MOUNT, or NOMOUNT)
if [ "$1" == "" ]
then
   export startoption=""
else
   export startoption=" $1"
fi
#
#
export nomPROG=kstart_all_bases.sh
export NombrePS=`ps -ef |grep $nomPROG |grep -v grep|grep ">"|wc -l`
if [ "$NombrePS" -gt 1 ]
then
   echo "Il y a deja $0 qui tourne !"
   ps -ef |grep $nomPROG |grep -v grep
   exit 103
fi
#
# les variables pour le batch
. /usr/local/etc/oracle/kenv_batch.sh
#
cd $BINDIR
#
export DATE=$(date "+%d/%m/%Y %H:%M:%S")
rm -f ${WORKDIR}/kstart_all_$$.tmp* 1>/dev/null 2>&1
#
export SQLTMP=${WORKDIR}/kstart_all_$$.tmp
#
#
echo "=========== AVANT : pmon : "
ps -ef |grep pmon |grep -v grep
echo "======================================================="
#
##########################
# La liste c'est oratab avec marqueur "K"
cat $BINDIR/kstopstart.dba.oratab|sort -u|grep -v '^#'|grep -v '+ASM'|grep -i ':StartOnBoot'|awk -F: '{print $1}'|sed 's/ //g'|while read leSID ; do
##############
echo bash $BINDIR/kstart_une_base.sh $leSID $startoption
bash $BINDIR/kstart_une_base.sh $leSID $startoption 1>$LOGDIR/kstart_une_base_$leSID.$$.log 2>&1 
##############
done
##########################
#
echo "=========== APRES : pmon : "
ps -ef |grep pmon |grep -v grep
echo "======================================================="
#
#
#
