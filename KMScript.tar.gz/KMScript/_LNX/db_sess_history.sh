#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col RESOURCE_CONSUMER_GROUP format a25
col sid format 999999
col USERNAME format a18
col MACHINE format a18
col program format a26
col spid format  a13
col SAMPLE_TIME format a25
col MIN_SAMPLE_TIME format a25
col MAX_SAMPLE_TIME format a25
select min(ss.SAMPLE_TIME) MIN_SAMPLE_TIME,max(ss.SAMPLE_TIME) MAX_SAMPLE_TIME from v\$active_session_history ss 
;
--
select ss.SAMPLE_TIME,ss.SESSION_ID, uu.username,ss.MACHINE,substr(ss.PROGRAM,1,25) PROGRAM 
from v\$active_session_history ss, dba_users uu
where uu.user_id = ss.user_id and uu.username like '$1'
order by ss.SESSION_ID
;
exit
EOT
#
. $KMscript/KMlogout.sh
#
