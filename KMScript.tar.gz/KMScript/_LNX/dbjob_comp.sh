#!/bin/bash
#----------------------------------------------------------------
# AUTEUR            : Kamel Mahdhaoui
#----------------------------------------------------------------
#set -x
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
#---------------------------------------------------------------------
# VARIABLES

export ARGS="$*"
export PID=${$}
export LANG=C
export mycoderror=0
export a_error_warn=4

# Logs et journaux
export LOG_RETENTION=10
export LOGDIR=./log                           
export JOBNAME=`basename ${0} .sh`                
export TMPLOG=/tmp/$JOBNAME.${INSTANCE}.${PID}.${RANDOM}.log
export LOGFILE="${LOGDIR}/${JOBNAME}.log"              
export DET_LOGFILE=/dev/null                    
#
export mycoderror=0
#---------------------------------------------------------------------
# FONCTIONS
Usage() {
   echo -e "\n\t-> Usage :"
   echo -e "\t\t`basename ${0}` "
   echo -e "\t\t                --tablespace|-tbs    =<Tablespace> "
   echo -e "\t\t                --schema|-s          =<Schema> "
   echo -e "\t\t                --table|-t           =<Table> "
   echo -e "\t\t                --verbose|-v              "
   echo -e "\n\t\tDependances : n/a"
   echo -e ""
   exit 1
   }

fMsgLog() {

   TYPINFO=${1}
   CODAPLI=${2}
   MSGINFO=${3}
   if [ ${MODE_VERBOSE} ]; then  
	case "${TYPINFO}" in
		TITRE*)	echo -e "\n\t=> ${MSGINFO}"|tee -a ${DET_LOGFILE};;
		TEXTE*)	echo -e "\t${MSGINFO}"|tee -a ${DET_LOGFILE};;
		INFO*) 	echo -e "\t- ${MSGINFO}"|tee -a ${DET_LOGFILE};;
		*)	echo -e "\t${TYPINFO} : ${MSGINFO}"|tee -a ${DET_LOGFILE};;
	esac 
   fi
   case "${TYPINFO}" in
	INFO*|ALERTE*|ERR*) 
		echo -e "`/bin/date +\%Y%m%d-%Hh%M`:${TYPINFO}:${CODAPLI}:${MSGINFO}" >> ${LOGFILE}		
		;;
   esac
}


fFinJob() {
	
   . $KMscript/KMlogout.sh
   #
   CODRETOUR=${1}
   # Suppression des fichiers temporaires et lock
   rm -f /tmp/rman_purge.${INSTANCE}.${PID}*

   fMsgLog "TEXTE" "" "\n"
   fMsgLog "TEXTE" "" "Le job ${JOBNAME} s'est termine le `/bin/date +\%A\ %d\ %B\ %Y\ \a\ %H\h%M` avec le code ${CODRETOUR}.\n"
   exit ${CODRETOUR}
}

#---------------------------------------------------------------------
# CONTROL PARAMETRES ET TESTS

if [ "${1}" = "" ]; then Usage; fi

for arg in ${ARGS} 
do
    case "$arg" in
      --tablespace=*|-tbs=*)     TABELSPACE=`echo -e "$arg" | sed -e 's/^[^=]*=//'` ;;
      --schema=*|-s=*)           SCHEMA=`echo -e "$arg" | sed -e 's/^[^=]*=//'` ;;
      --table=*|-t=*)            TABLE=`echo -e "$arg" | sed -e 's/^[^=]*=//'` ;;
      --verbose|-v)          MODE_VERBOSE=0;;
      --help|-h)             Usage;;
      *)                     Usage;;         
    esac
done
#
#if [ "${LOGNAME}" != "${OSUSER}" ]; then
#echo -e "\n\t-> Switch on login ${OSUSER} for running this shell\n"
#su - ${OSUSER} -c "${0} ${*}"
#exit ${?}
#fi
#
if [ ! -w /tmp ]; then
        echo -e "\n\t-> Impossible d'ecrire dans le repertoire temporaire"
        exit 1
fi

#---------------------------------------------------------------------
# INITIALISATIONS

fMsgLog "TEXTE" "" "\n\t----------------------------------------------------" 
fMsgLog "TEXTE" "" "Compressed Elements  " 
fMsgLog "TEXTE" "" "----------------------------------------------------" 

fMsgLog "TITRE" "" "Starting at ... `/bin/date +\%A\ %d\ %B\ %Y\ \a\ %H\h%M`" 
fMsgLog "TEXTE" "" "          ORACLE_SID = ${ORACLE_SID}" 
fMsgLog "TEXTE" "" "          TABLESPACE = ${TABLESPACE}" 
fMsgLog "TEXTE" "" "              SCHEMA = ${SCHEMA}" 
fMsgLog "TEXTE" "" "               TABLE = ${TABLE}" 
fMsgLog "TEXTE" "" "       LOG DETAILLEE = ${DET_LOGFILE}"
#
#---------------------------------------------------------------------
# AUTOPURGES DES LOGS DU JOB

# Purge des anciens fichiers de LOG
fMsgLog "TITRE" "" "Purge des logs de $0 :"
NB_PURGE=$(expr `find ${DET_LOGDIR} -name "${JOBNAME}.${ORACLE_SID}.*.log" -mtime +${LOG_RETENTION} -print |wc -l`)
find ${DET_LOGDIR} -name "${JOBNAME}.${ORACLE_SID}.*.log" -mtime +${LOG_RETENTION} -exec rm {} \;
if [ ${?} -ne 0 ]; then
   fMsgLog "ALERTE " ${ORACLE_SID} "Purge des logs impossible..."
else
   fMsgLog "TEXTE" "" "...Ok - ${NB_PURGE} fichier(s) purge(s)"
fi
#
#=====================================================================
#=====================================================================
# Le traitement ... 
#=====================================================================
#=====================================================================
#
export JourSemaine=`/bin/date +%a`
#
fMsgLog "TITRE" "" "Sauvegarde des controlfile/trace/param/ini :"
#
#
echo -e "traitement ..." 1>>$TMPLOG 2>&1
#
sqlplus -s "$conn"  <<EOT
@$KMscript/$SQLLOGIN
--
set lines 132
set pages 132

define 1="$SCHEMA"
define 2="$TABLE"
define 3="$TABELSPACE"

set feedback off
alter session set nls_date_format='yy-mm-DD hh24:mi:ss';
set feedback on


clear breaks
clear columns
clear computes
ttitle "Table Partitions"

set trims on
set verify off
col table_name  format a25 trunc heading "Owner.Table"
col COLUMN_NAME format a22 heading "Colonne"
-- col table_name  format a35 heading "Owner.Table"
--
--
--
select owner||'.'||table_name table_name
, PARTITIONING_TYPE
, SUBPARTITIONING_TYPE 
, PARTITION_COUNT
FROM dba_part_tables
WHERE DECODE(UPPER('&&1'),NULL,'x',owner) = NVL(UPPER('&&1'),'x')
AND   DECODE(UPPER('&&2'),NULL,'x',table_name) = NVL(UPPER('&&2'),'x')
and owner not like 'SYS%'
ORDER BY 1,2
/
select table_owner||'.'||table_name table_name
, column_name
, lob_name
, lob_index_name
FROM dba_part_lobs
WHERE DECODE(UPPER('&&1'),NULL,'x',table_owner) = NVL(UPPER('&&1'),'x')
AND   DECODE(UPPER('&&2'),NULL,'x',table_name) = NVL(UPPER('&&2'),'x')
and table_owner not like 'SYS%'
ORDER BY 1,2
/
--
--
--
col high_value format a20
col composite format a3 heading "CMP"
col partition_position format 999 heading "Pos"
col subpartition_count format 999 heading "Cnt"
col init_kb format 999999 heading "Init KB"
col next_kb format 999999 heading "Next KB"
col num_rows format 9999999 heading "Num Rows"
col pct_increase format 999 heading "Pct|Inc"
col partition_name format a25 heading "Part Name"
col tablespace_name format a25 heading "Tabsp Name"
break on table_name skip 1
--
--
prompt ****************** TABLES *************************
SELECT tablespace_name,table_name,compress_for FROM dba_tables where
DECODE(UPPER('&&1'),NULL,'x',owner) = NVL(UPPER('&&1'),'x')
AND   DECODE(UPPER('&&2'),NULL,'x',table_name) = NVL(UPPER('&&2'),'x')
AND   DECODE(UPPER('&&3'),NULL,'x',tablespace_name) = NVL(UPPER('&&3'),'x')
and compression not like 'DISAB%' and compression not like 'N/A%' and compression not like 'NONE'
order by 1,2
;

prompt ****************** LOBS   *************************
SELECT tablespace_name,table_name,segment_name,compression FROM dba_lobs where
DECODE(UPPER('&&1'),NULL,'x',owner) = NVL(UPPER('&&1'),'x')
AND   DECODE(UPPER('&&2'),NULL,'x',table_name) = NVL(UPPER('&&2'),'x')
AND   DECODE(UPPER('&&3'),NULL,'x',tablespace_name) = NVL(UPPER('&&3'),'x')
and compression not like 'DISAB%' and compression not like 'N/A%' and compression not like 'NONE'
order by 1,2
;

prompt ****************** PARTIT *************************
SELECT tablespace_name,table_name,partition_name,compression,compress_for FROM dba_tab_partitions where
DECODE(UPPER('&&1'),NULL,'x',table_owner) = NVL(UPPER('&&1'),'x')
AND   DECODE(UPPER('&&2'),NULL,'x',table_name) = NVL(UPPER('&&2'),'x')
AND   DECODE(UPPER('&&3'),NULL,'x',tablespace_name) = NVL(UPPER('&&3'),'x')
and compression not like 'DISAB%' and compression not like 'N/A%' and compression not like 'NONE'
order by 1,2
;

prompt ****************** LOB P  *************************
SELECT tablespace_name,table_name,PARTITION_NAME,compression FROM dba_lob_partitions where
DECODE(UPPER('&&1'),NULL,'x',table_owner) = NVL(UPPER('&&1'),'x')
AND   DECODE(UPPER('&&2'),NULL,'x',table_name) = NVL(UPPER('&&2'),'x')
AND   DECODE(UPPER('&&3'),NULL,'x',tablespace_name) = NVL(UPPER('&&3'),'x')
and compression not like 'DISAB%' and compression not like 'N/A%' and compression not like 'NONE'
order by 1,2
;

prompt ****************** SUBPAR *************************
SELECT DISTINCT 
tablespace_name,table_name,
PARTITION_NAME,
-- SUBPARTITION_NAME,
compression,compress_for FROM dba_tab_subpartitions where
DECODE(UPPER('&&1'),NULL,'x',table_owner) = NVL(UPPER('&&1'),'x')
AND   DECODE(UPPER('&&2'),NULL,'x',table_name) = NVL(UPPER('&&2'),'x')
AND   DECODE(UPPER('&&3'),NULL,'x',tablespace_name) = NVL(UPPER('&&3'),'x')
and compression not like 'DISAB%' and compression not like 'N/A%' and compression not like 'NONE'
order by 1,2
;

prompt ****************** LOB SP *************************
SELECT DISTINCT
ls.tablespace_name,ls.table_name,
ts.PARTITION_NAME,
-- ls.SUBPARTITION_NAME,
ls.compression 
FROM dba_lob_subpartitions  ls,dba_lob_partitions ts
where
ls.table_owner=ts.table_owner and
ls.table_name=ts.table_name and
ls.LOB_PARTITION_NAME=ts.LOB_PARTITION_NAME and
DECODE(UPPER('&&1'),NULL,'x',ls.table_owner) = NVL(UPPER('&&1'),'x')
AND   DECODE(UPPER('&&2'),NULL,'x',ls.table_name) = NVL(UPPER('&&2'),'x')
AND   DECODE(UPPER('&&3'),NULL,'x',ls.tablespace_name) = NVL(UPPER('&&3'),'x')
and ls.compression not like 'DISAB%' and ls.compression not like 'N/A%' and ls.compression not like 'NONE'
order by 1,2
;

--
--
exit
EOT
#
export mycoderror=$?
export a_error_warn=4
#
#=====================================================================
#=====================================================================
#
# si Verbose afficher autrement mettre dans le DET_LOGFILE
if [ ${MODE_VERBOSE} ]; then fMsgLog "TEXTE" "" "\n"; cat ${TMPLOG}|tee -a ${DET_LOGFILE}; else cat ${TMPLOG}>>${DET_LOGFILE}; fi
#
if [ $mycoderror -eq 0 ] && [ $a_error_warn -eq 4 ]
then
   fMsgLog "WARNING " ${ORACLE_SID} " Warning ..."
   export mycoderror=4
fi
#
if [ $a_error_warn -eq 0 ]
then
   fMsgLog "INFO   " ${ORACLE_SID} " Info ... "
fi
#---------------------------------------------------------------------
# FIN DU JOB

fFinJob ${mycoderror}
