# Author : Kamel Mahdhaoui
# Unautorized use is forbidden 
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
if [ "$KSHOUTPUT" == "HTML" ]
then
   echo "<table border='1' width='90%' align='center' summary='Script output'>"
   echo "<tr>"
fi
#
export Valeur=`db_rdbf.sh` ; echo "Redo Buffe :$Valeur"
export Valeur=`db_lbch.sh` ; echo "Lib  Cache :$Valeur"
export Valeur=`db_dcch.sh` ; echo "Dict Cache :$Valeur"
export Valeur=`db_bfch.sh` ; echo "Buff Cache :$Valeur"
#
if [ "$KSHOUTPUT" == "HTML" ]
then
   echo "</tr>"
   echo "</TABLE>"
fi
#
. $KMscript/KMlogout.sh
#
