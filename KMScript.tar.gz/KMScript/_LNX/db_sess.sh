#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col RESOURCE_CONSUMER_GROUP format a25
col sid format 999999
col sid format a16
col USERNAME format a18
col MACHINE format a18
col program format a26
col spid format  a13
set lines 155
--
prompt ====================================== Session/Process ====================================
select ss.sid||','||ss.serial# sid, ss.USERNAME,ss.OSUSER,ss.MACHINE,substr(ss.PROGRAM,1,25) PROGRAM , resource_consumer_group,pp.spid 
from v\$session ss, v\$process pp
where pp.addr=ss.paddr
order by ss.sid
;
prompt ====================================== Session/Transaction ================================
select ss.sid||','||ss.serial# sid,ss.USERNAME,ss.OSUSER,ss.MACHINE,pp.spid,
t.USED_UREC Records, t.USED_UBLK Blocks, (t.USED_UBLK*8192/1024) KBytes from v\$transaction t,
v\$session ss, v\$process pp
where t.addr = ss.taddr
and pp.addr=ss.paddr
order by ss.sid
;
prompt ====================================== Session/Active =====================================
select ss.sid||','||ss.serial# sid,ss.USERNAME,ss.OSUSER,ss.MACHINE,pp.spid,
t.USED_UREC Records, t.USED_UBLK Blocks, (t.USED_UBLK*8192/1024) KBytes from v\$transaction t,
v\$session ss, v\$process pp
where t.addr = ss.taddr
and pp.addr=ss.paddr
and ss.STATUS like 'ACTIVE'
order by ss.sid
;
prompt ====================================== Session/Datapupm ===================================
select ss.sid||','||ss.serial# sid, ss.MACHINE,ss.PROGRAM , pp.spid,d.SESSION_TYPE,d.job_name
from v\$session ss, dba_datapump_sessions d,v\$process pp
where ss.saddr = d.saddr
and pp.addr=ss.paddr
order by ss.sid
;

exit
EOT
#
. $KMscript/KMlogout.sh
#
