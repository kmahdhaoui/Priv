#!/bin/bash
# Author : Kamel Mahdhaoui
#
#
. ~oracle/.bash_profile
#
#============================================
if [ "$1" == "" ]
then
   if [ "$ORACLE_SID" == "" ]
   then 
      export ORACLE_SID=XSITRMDO
   fi
else
    export ORACLE_SID=$1
fi
#
# les variables pour le batch
. /usr/local/etc/oracle/kenv_batch.sh $ORACLE_SID
. $BINDIR/kenv_nls.sh
#
cd $BINDIR
#
#============================================
#
############ OTHERS ###################
#
date
echo "gather_stats_CISADM_AUTRE.sh pour $ORACLE_SID ... en Cours !"
nohup bash gather_stats_CISADM_AUTRE.sh 1>gather_stats_CISADM_AUTRE.out 2>&1 &
#
############ FIXED TABLES #############
#
date
sqlplus -s CISADM/CISADM <<EOT &
--
!echo "exec dbms_stats.GATHER_FIXED_OBJECTS_STATS;"
exec dbms_stats.GATHER_FIXED_OBJECTS_STATS;
--
exec DBMS_STATS.GATHER_TABLE_STATS ('SYS', 'X\$KTFBUE') ;
--
exit
EOT
#
########### PART BY DATE ##############
#
date
#
# part : D1_INIT_MSRMT_DATA_CHAR D1_INIT_MSRMT_DATA_K D1_INIT_MSRMT_DATA_LOG_PARM D1_INIT_MSRMT_DATA_LOG
# part date : D1_INIT_MSRMT_DATA
# part date : D1_MSRMT_CHAR D1_MSRMT_LOG_PARM D1_MSRMT_LOG D1_MSRMT
#
export leowner=CISADM
for latable in D1_MSRMT_CHAR D1_MSRMT_LOG_PARM D1_MSRMT_LOG D1_MSRMT D1_INIT_MSRMT_DATA
do
# Last partition
export LASTPART=`bash db_last_part.sh CISADM $latable|grep "^$latable"|awk -F"." '{print $2}'|awk -F" " '{print $1}'|head -1`
#
sqlplus -s CISADM/CISADM <<EOT
--
!echo "exec dbms_stats.gather_table_stats(ownname=>'$leowner',tabname=>'$latable',PARTNAME=>'$LASTPART',ESTIMATE_PERCENT=>100,GRANULARITY=>'APPROX_GLOBAL AND PARTITION',cascade=>true,degree=>23);"
--
exec dbms_stats.gather_table_stats(ownname=>'$leowner',tabname=>'$latable',PARTNAME=>'$LASTPART',ESTIMATE_PERCENT=>100,GRANULARITY=>'APPROX_GLOBAL AND PARTITION',cascade=>true,degree=>23);
--
exit
EOT
done
#
########### D1_INIT_MSRMT_DATA_K ####################
#
date
export latable=D1_INIT_MSRMT_DATA_K
#
sqlplus -s CISADM/CISADM <<EOT
--
!echo "exec dbms_stats.gather_table_stats(ownname=>'$leowner',tabname=>'$latable',ESTIMATE_PERCENT=>100,GRANULARITY=>'APPROX_GLOBAL AND PARTITION',cascade=>true,degree=>23);"
--
exec dbms_stats.gather_table_stats(ownname=>'$leowner',tabname=>'$latable',ESTIMATE_PERCENT=>100,GRANULARITY=>'APPROX_GLOBAL AND PARTITION',cascade=>true,degree=>23);
--
exit
EOT
#
#######################################
#
date
#
#
