#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
set feedback off
SELECT THREAD#, MAX(SEQUENCE#) "Last Seq Rec" FROM V\$ARCHIVED_LOG val, V\$DATABASE vdb
WHERE val.RESETLOGS_CHANGE#=vdb.RESETLOGS_CHANGE#
GROUP BY THREAD#
ORDER BY THREAD#;

SELECT THREAD#, MAX(SEQUENCE#) "Last Seq App" FROM V\$ARCHIVED_LOG val, V\$DATABASE vdb
WHERE APPLIED = 'YES' AND val.RESETLOGS_CHANGE#=vdb.RESETLOGS_CHANGE#
GROUP BY THREAD#
ORDER BY THREAD#;

exit;
exit
EOT
#
. $KMscript/KMlogout.sh
#
