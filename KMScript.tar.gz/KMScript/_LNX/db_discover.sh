#!/bin/bash
# Author : Kamel Mahdhaoui
#
# set -x
listbases=/etc/oratab  ;export listbases
dbname=""  ;export dbname
dblist=""  ;export dblist
#
# List of Database 
cat <<EOF |sort -u | grep -v '^$' |grep -v '^#' | while read dbname ; do
$(cat $listbases |grep -v '^$' |grep -v '^#'|grep -v '^*'|awk -F: '{print $1}')
$(ps -ef |grep smon|grep -v grep|awk -F_ '{print $3}'|sed 's/ //g')
EOF
    dblist="$dblist,"'{"{#DBNAME}":"'$dbname'"}'
    export dblist
done
#echo '{"data":['${dblist#,}' ]}'
echo '{"data":[{"{#DBNAME}":"ORCL"},{"{#DBNAME}":"TEST"} ]}'
date >>/home/cinstall/kamel/KMscript/log/db_discover.log
echo $0 $* >>/home/cinstall/kamel/KMscript/log/db_discover.log
#
