#!/bin/bash
# Author : Kamel Mahdhaoui
#
#
export nbsqlids=1
if [ "$1" == "" ]
then
   export nbsqlids=1
else
   export nbsqlids=$1
fi
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export KMymd=`date "+%Y%m%d"`
#
export snapids=`db_last_snapids.sh`
export d_snapid=`echo $snapids |awk -F" " '{print $1}'`
export f_snapid=`echo $snapids |awk -F" " '{print $2}'`
#
sqlplus -s "$conn"  <<EOT
--
set time off timi off echo off verify off feedback off heading off pages 0 lines 80
set heading on
set pages 5000
--
select
sub.sql_id,
sub.seconds,
sub.execs,
sub.gets
from
( 
select
sql_id,
round(sum(elapsed_time_delta)/1000000) as seconds,
sum(executions_delta) as execs,
sum(buffer_gets_delta) as gets
from
dba_hist_snapshot natural join dba_hist_sqlstat
where
snap_id between $d_snapid and $f_snapid
group by
sql_id
order by
2 desc
) sub
where
rownum < 30
;
--
exit
EOT
#
#######################################
#
#
#
