#!/bin/bash
#
export NLS_LANG=AMERICAN_AMERICA.WE8MSWIN1252
export a_error_svg=0
#
    oratab.sh;
    echo -e "db ...? \c";
    read ORACLE_SID;
    export PATH=$ORACLE_HOME/bin:$PATH:$ORACLE_HOME/OPatch;
    export ORAENV_ASK=NO;
    . oraenv;
    export ORAENV_ASK=YES;
    b
#
export myrep=/sitr/backup/$ORACLE_SID/dump
mkdir -p $myrep
cp $ORACLE_SID.AM.CISADM2.par $myrep/
#
echo "$myrep >>>>>>>>>>>>>>>>>>>>>>"
ls -ltr $myrep/$ORACLE_SID.AM.CISADM2*
echo "$myrep <<<<<<<<<<<<<<<<<<<<<<"
#
echo "BASE : $ORACLE_SID"
echo "OK ... ? <Enter> or <CTRL-C> : "
read toto
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export FLASHBACK_TIME="TO_TIMESTAMP('$KMymdhms','YYYYMMDDHH24MISS')"
sleep 5
#
cd $myrep
#
sqlplus '/ as sysdba' <<EOT
create or replace DIRECTORY kamel as '$myrep/';
exit
EOT
#
# parfile : $ORACLE_SID.AM.CISADM2.par
#
# COMPRESSION=all
# dumpfile=$ORACLE_SID.AM.CISADM2.%u.dmp
# logfile=$ORACLE_SID.AM.CISADM2.log
# exclude=statistics
# exclude=TABLE:\"LIKE \'SYS_IMPORT%\'\"
# exclude=TABLE:\"LIKE \'SYS_IMPORT%\'\"
# exclude=TABLE:\"LIKE \'SYS_EXPORT%\'\"
# exclude=TABLE:\"LIKE \'Q%_CONSO_%\'\"
# exclude=TABLE:\"LIKE \'ID_DOUBLONS%\'\"
# exclude=TABLE:\"LIKE \'HORS_Q%_CONSO_%\'\"
# exclude=TABLE:\"LIKE \'DOUBLE_Q%_CONSO%\'\"
# exclude=TABLE:\"LIKE \'DP_1%_%B\'\"
# exclude=TABLE:\"LIKE \'DP_1%_%A\'\"
# exclude=TABLE:\"LIKE \'TEST%NLAO%\'\"
# exclude=TABLE:\"LIKE \'KK\'\"
# exclude=TABLE:\"LIKE \'PLAN_TABLE\'\"
# exclude=TABLE:\"LIKE \'TOAD_PLAN_TABLE\'\"
#
# expdp "CISADM2/kamel" FLASHBACK_TIME=systimestamp-1/96 schemas=CISADM2 directory=kamel parfile=$ORACLE_SID.AM.CISADM2.par 
expdp "CISADM2/kamel" schemas=CISADM2 directory=kamel parfile=$ORACLE_SID.AM.CISADM2.par 
#
echo "RetCode : $?"
#
ls -ltr $myrep/$ORACLE_SID.AM.CISADM2*
#
