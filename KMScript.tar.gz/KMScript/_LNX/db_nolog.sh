#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
select owner,count(*) Nbre from dba_tables where logging != 'YES' 
and owner not in ('SYS','SYSTEM','SYSMAN','OUTLN','MDSYS','QUEST','DBSNMP','SCOTT','XDB','EXFSYS','WMSYS','OLAPSYS')
and owner not like 'QUEST%'
group by owner
;
select TABLESPACE_NAME ,STATUS,LOGGING from dba_tablespaces where LOGGING != 'LOGGING' 
;

--
exit
EOT
#
. $KMscript/KMlogout.sh
#
