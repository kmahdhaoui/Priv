#
# Author : Kamel Mahdhaoui
# Unautorized use is forbidden 
sqlplus -s "$conn" <<EOT
col DCCH format "9999999"
set pages 0
set feedb off
set verify off
set echo off
--
select round(((1-(sum(getmisses)/sum(gets)))*100),4) DCCH
from v\$rowcache
;
exit
EOT
#
