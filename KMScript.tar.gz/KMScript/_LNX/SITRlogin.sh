#!/bin/ksh
# Author : Kamel Mahdhaoui
# set -x
#
export BASE_NAME=`basename $0 .sh`
if [ "$BASE_NAME" == "" ]
then
   export BASE_NAME="DUMMY"
   echo "No dummy shell ... $0 $*"
   return 
fi
export LIB_SITR_SCRIPT=`/usr/bin/ksh $SITRscript/db_libelle_script.sh $BASE_NAME`
#
if [ "$ORACLE_SID" == "" ]
then
   echo "Please set ORACLE_SID ..."
   return 101
fi
#
export combien=`ps -ef |grep "$BASE_NAME.sh"|grep -v grep|wc -l `
typeset  -i combien
if [ $combien -gt 5 ]
then
   echo "--> $combien Process $BASE_NAME !!! "
   return
fi
#
case $1 in
     -html|-HTML) export SQLLOGIN=login_HTML.sql
                  export KSHOUTPUT=HTML
                  echo "<HTML><p></p>"
                  echo "<table border='1' width='90%' align='center' bgcolor=\"66bbff\"><tr><td>"
                  echo "`date`: "
                  echo "-SITE=$SITRsite "
                  echo "-HOST=`hostname` "
                  echo "-BASE=$ORACLE_SID "
                  echo "-SCRIPT=$LIB_SITR_SCRIPT"
                  echo "</td></tr></TABLE><HTML>"
               ;;
     *)           export SQLLOGIN=login_TEXT.sql
                  export KSHOUTPUT=TEXT
                  b
                  echo -n "`date`: "
                  echo -n "-SITE=$SITRsite "
                  echo -n "-HOST=`hostname` "
                  echo -n "-BASE=$ORACLE_SID "
                  echo    "-SCRIPT=$LIB_SITR_SCRIPT"
               ;;
esac
#
if [ "$SITRscript" == "" ]
then
   echo "Positionner SITRscript ..."
   return 101
fi
#
if [ "$SITRlog" == "" ]
then
   export SITRlog=$SITRscript/log 
   echo "SITRlog = $SITRscript/log ..."
fi
#
if [ ! -x "$SITRlog" ]
then
   echo "Creating $SITRlog ..."
   mkdir -p $SITRlog
fi
#
