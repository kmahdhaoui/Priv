#!/usr/bin/ksh
#
export ListeHostsDev=" dasgbddeva1 dasgbddevb1 dasgbddevd1"
export ListeHostsRec=" dasgbdreca1 dasgbdrecb1 dasgbdrecd1  "
export ListeHostsPrex=" dasgbdprexa1 dasgbdprexb1 dasgbdprexd1 "
export ListeHostsSimu=" dapgisimulc1 "
export ListeHostsProd_1=" dasgbdproda1 dasgbdprodb1 dasgbdprodc1 dasgbdprodc2 dasgbdprodd1 "
export ListeHostsProd_2=" dainfproda1 dssgbdprod1 daprodd3"
#
export ListeHosts="$ListeHostsDev $ListeHostsSimu $ListeHostsRec $ListeHostsPrex $ListeHostsProd_1 $ListeHostsProd_2"
#
# c quoi $1 ???
for lehost in $ListeHosts
do
if [ "$KMhost" != "$lehost" ]
then
   echo "------------------------------ $lehost ---------------------------------"
   ssh $lehost "sum scripts/$1"
fi
done
#
#
