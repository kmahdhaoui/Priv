#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col RESOURCE_CONSUMER_GROUP format a25
col sid format 999999
col NAME format a56
--
SELECT NAME,DETECTED_USAGES AS "USAGE",
CURRENTLY_USED,
FIRST_USAGE_DATE,LAST_USAGE_DATE
FROM DBA_FEATURE_USAGE_STATISTICS WHERE DETECTED_USAGES>0 order by 1
/
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
