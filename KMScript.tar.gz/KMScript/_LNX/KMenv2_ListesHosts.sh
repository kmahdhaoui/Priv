#!/bin/ksh
#
# Variables defaut
#
unset ListeHostsTest ListeHostsTout_1 ListeHostsTout_2 ListeHostsDMZ ListeHostsSaturne ListeHostsDev ListeHostsRec ListeHostsPrex ListeHostsProd ListeHostsDevTest ListeHostsRecTest ListeHostsPrexTest
#
export ListHostsDev=""
export ListHostsRec=""
export ListHostsInt=""
export ListHostsBen=""
export ListHostsSat=""
#
export ListHostsAutre=""
export ListHostsPrex=""
export ListHostsProd=""
#
export ListHostsDMZ=""
export ListHostsRIM=""
#
export ListHostsErreur=""
#
cat copie_listserv.cnf | while read LINE
do
export LeHst=`echo $LINE |awk -F" "  '{print $1 }'`
export LeEnv=`echo $LINE |awk -F" "  '{print substr($2,1,3) }'`
export LeRes=`echo $LINE |awk -F" "  '{print substr($3,1,3) }'`
#
case $LeRes in 
     DMZ) export ListHostsDMZ="$ListHostsDMZ $LeHst" ;;
     RIM) export ListHostsRIM="$ListHostsRIM $LeHst" ;;
       *) export ListHostsErreur="$ListHostsErreur $LeHst" ;;
esac
#
if [ "$LeRes" != "DMZ" ]
then
case $LeEnv in 
     Dev) export ListHostsDev="$ListHostsDev $LeHst" ;;
     Rec) export ListHostsRec="$ListHostsRec $LeHst" ;;
     Int) export ListHostsInt="$ListHostsInt $LeHst" ;;
     Ben) export ListHostsBen="$ListHostsBen $LeHst" ;;
     Sat) export ListHostsSat="$ListHostsSat $LeHst" ;;
     Pro) export ListHostsProd="$ListHostsProd $LeHst" ;;
     Pre) export ListHostsPrex="$ListHostsPrex $LeHst" ;;
       *) export ListHostsErreur="$ListHostsErreur $LeHst" ;;
esac
fi
#
#
done
#
export ListHostsAutre="$ListHostsAutre $ListHostsDev $ListHostsRec  $ListHostsInt  $ListHostsBen $ListHostsSat"
#
export ListeHostsSaturne="$ListeHostsSat"
#
export ListeHostsDevTest="$ListeHostsDev"
export ListeHostsRecTest="$ListeHostsRec"
export ListeHostsPrexTest="$ListeHostsPrex"
export ListeHostsTest="$ListeHostsTestDev $ListeHostsRecTest $ListeHostsPrexTest"
#
export ListeHostsTout_1="$ListeHostsRIM"
export ListeHostsTout_2="$ListeHostsRIM"
#
#
