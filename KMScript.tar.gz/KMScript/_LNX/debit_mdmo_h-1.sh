#
while true
do
sqlplus -s '/ as sysdba' <<EOT
@"debit_mdmo_h-1.sql"
exit
EOT
sleep 3600
done
#
