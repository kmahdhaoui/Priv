#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col sid format 999999
col USERNAME format a20
col MACHINE format a15
col program format a44
--
-- desc V\$FLASHBACK_DATABASE_LOGFILE
-- desc V\$FLASHBACK_DATABASE_LOG
-- desc V\$FLASHBACK_DATABASE_STAT
-- desc V\$FLASH_RECOVERY_AREA_USAGE
-- desc DBMS_FLASHBACK
--
alter session set nls_date_format='yyyy-mm-dd hh24:mi:ss' ;
--
set echo off feedback off lines 132 pages 132
--
-- DBA_OUTSTANDING_ALERTS
--
-- select * from V\$FLASHBACK_DATABASE_LOGFILE ;
--
-- select * from V\$FLASHBACK_DATABASE_STAT ;
--
col DATABASE_INCARNATION format 999999 
col INCARN format 9999 
col SCN format 9999999999 
col PERCENT_SPACE_USED format 99999
col RESTORE_POINT_TIME format a20
col time format a30
col size_m format 9999999
col est_size_m format 9999999
col reclamable_size_m format 9999999
col size_f format 9999999
col est_size_f format 9999999
col reclamable_size_f format 9999999
--
prompt 
prompt  db_recovery_file_dest_size   
prompt ==============================================================================================
select p.VALUE/1024/1024/1024 GBytes from v\$parameter p where p.name like 'db_recovery_file_dest_size';
--
prompt 
prompt  Flashback Logs     
prompt ==============================================================================================
select OLDEST_FLASHBACK_SCN,
 OLDEST_FLASHBACK_TIME,
 RETENTION_TARGET,
 FLASHBACK_SIZE/1024/1024/1024 size_g,
 ESTIMATED_FLASHBACK_SIZE/1024/1024/1024 est_size_g
from V\$FLASHBACK_DATABASE_LOG ;
--
set pages 500
set feedback off
prompt 
prompt  Flashback Area   
prompt ==============================================================================================
select 
 FILE_TYPE,
 PERCENT_SPACE_USED,
 PERCENT_SPACE_USED * p.VALUE/1024/1024/1024/100 size_g ,
 PERCENT_SPACE_RECLAIMABLE * p.VALUE/1024/1024/1024/100 reclamable_size_g ,
 NUMBER_OF_FILES
from V\$FLASH_RECOVERY_AREA_USAGE,v\$parameter p
where p.name like 'db_recovery_file_dest_size'
;
--
prompt :
set pages 0
set feedback off
select
 'Total :  ' FILE_TYPE,
 sum(PERCENT_SPACE_USED) PERCENT_SPACE_USED,
 sum(PERCENT_SPACE_USED * p.VALUE)/1024/1024/1024/100 size_g ,
 sum(PERCENT_SPACE_RECLAIMABLE * p.VALUE)/1024/1024/1024/100 reclamable_size_g ,
 sum(NUMBER_OF_FILES) NUMBER_OF_FILES
from V\$FLASH_RECOVERY_AREA_USAGE,v\$parameter p
where p.name like 'db_recovery_file_dest_size'
group by 'Total :  '
;
prompt 
prompt  Restore Points
prompt ==============================================================================================
set pages 500
set feedback on
select SCN ,DATABASE_INCARNATION# INCARN,TIME ,RESTORE_POINT_TIME,NAME from v\$restore_point;
prompt 
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
