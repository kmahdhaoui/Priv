#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$1" == "" ]
then
   export LaTable=%
else
   export LaTable=$1
fi
#
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
date
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
set feedback off
set lines 133
col value format a80
--
col OWNER format a10
col TABLE_NAME format a30
col INCREMENTAL format a10
col GRANULARITY format a10
col STALE_PERCENT format A6
col ESTIMATE_PERCENT format a30
col CASCADEA format a10
col METHOD_OPT format a20
--
exec dbms_stats.gather_table_stats(ownname=>'CISADM',tabname=>'$LaTable',estimate_percent=>dbms_stats.auto_sample_size,method_opt=>'for all indexed columns',cascade=>true,degree=>42);
-- 
select owner,table_name, sample_size, last_analyzed from dba_tab_statistics 
where owner='CISADM' and table_name like '$LaTable' and
( STALE_STATS ='YES' or STALE_STATS is null )  
and last_analyzed is not null
;
--
--
--


--
exit
EOT
date
#
. $KMscript/KMlogout.sh
#
