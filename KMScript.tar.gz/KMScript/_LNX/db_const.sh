#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
#
if [ "$2" == "" ] 
then
   echo "Usage is : $0 <owner|%>  <table|%>"
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
set lines 132
set pages 555
col PERE format a35
col FILS format a31
col CONST_F format a31
col STATUS_F format a12
--
select decode(level,1,'',lpad(' ',(level-1))||'->' )
||Pere Pere,Fils, CONST_F,STATUS_F
from
(
    select  ac.owner ,ac.table_name Fils
           ,ac.CONSTRAINT_NAME CONST_F,ac.STATUS STATUS_F
           ,r.owner Owner_P,r.table_name  Pere
           ,r.CONSTRAINT_NAME CONST_P,r.STATUS STATUS_P
    from    all_constraints     ac
           ,all_constraints     r
    where   r.Owner             = ac.r_Owner
    and     r.Constraint_Name   = ac.r_Constraint_Name
    and     ac.Constraint_Type  = 'R'
    and r.owner ='$1'
)
start with Pere like  '$2%'
connect by prior Fils =  Pere
;
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
