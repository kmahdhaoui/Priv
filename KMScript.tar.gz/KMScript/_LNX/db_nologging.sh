#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col OWNER format a22
col OBJECT_TYPE format a15
col OBJECT_NAME format a35
col STATUS
set pages 555
set lines 132
--
prompt "... Dont Tables nologging"
select distinct '-- '||table_name||chr(10)||
'alter table '||owner||'.'||table_name||' logging;' from dba_tables where logging not like 'YES' and owner='CISADM';
--
prompt "... Dont tables Part/ssPartitions invalides"
SELECT distinct '-- '||table_name||chr(10)||
'alter table '||table_owner||'.'||table_name||'  logging; '
FROM dba_tab_partitions WHERE logging not in ( 'YES')  and table_owner='CISADM' ; 
--
SELECT distinct '-- '||table_name||chr(10)||
'alter table '||table_owner||'.'||table_name||'  logging; '
FROM dba_tab_subpartitions WHERE logging not in ( 'YES')  and table_owner='CISADM' ;
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
