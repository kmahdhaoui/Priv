#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
SELECT
   output 
FROM TABLE(dbms_workload_repository.awr_report_text (null,null,
select min(snap_id) from dba_hist_snapshot where begin_interval_time > systimestamp - 11  and end_interval_time < systimestamp - 1/10
,
select max(snap_id) from dba_hist_snapshot where begin_interval_time > systimestamp - 11  and end_interval_time < systimestamp - 1/10
));

EXEC dbms_workload_repository.create_snapshot;
--
-- awrrpt.sql
-- awrsqrpt.sql
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
