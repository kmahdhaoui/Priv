#
# char:0 fonce,1 clair,4 souligné,7 fond,9 barre
export Noir="\e[0;30m"
export Gris_fonce="\e[1;30m"
export Bleu="\e[0;34m"
export Bleu_clair="\e[1;34m"
export Vert="\e[0;32m"
export Vert_clair="\e[1;32m"
export Cyan="\e[0;36m"
export Cyan_clair="\e[1;36m"
export Rouge="\e[0;31m"
export Rouge_clair="\e[1;31m"
export Violet="\e[0;35m"
export Violet_clair="\e[1;35m"
export Brun="\e[0;33m"
export Jaune="\e[1;33m"
export Gris_clair="\e[0;37m"
export Blanc="\e[1;37m"
#
export FinCoul="\e[0m"
# eval "DebCoul=\$Coul"
for Coul in Noir Gris_fonce Bleu Bleu_clair Vert Vert_clair Cyan Cyan_clair Rouge Rouge_clair Violet Violet_clair Brun Jaune Gris_clair Blanc
do
    eval "DebCoul=\$$Coul"
    export PS_$Coul="$DebCoul[\u@\h:\W>\$?]\\$ \[$(tput sgr0)\]$FinCoul"
done
#
# PS_rouge="\e[1;31m[\u@\h \W]\$ \e[0m"
# PS_Rouge=\e[1;31m[\u@\h:\W>$?]\$ \[\]\e[0m

echo $PS_Vert_clair
export PS1=$PS_Vert_clair
env |grep PS_
#
