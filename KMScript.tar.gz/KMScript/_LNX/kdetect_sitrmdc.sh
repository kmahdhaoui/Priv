#!/bin/bash
# kma
#
# seuil (non utilise pour l'instant)
if [ "$1" == "" ]
then
   export SEUIL_1=5
else
   export SEUIL_1=$1
fi

#
#
export SUPDIR=/sitr/exploit/sup
export LOGDIR=/sitr/exploit/sup/log
export WORKDIR=/sitr/exploit/sup/log
mkdir -p $WORKDIR
chmod 775 $WORKDIR;chgrp oinstall $WORKDIR
#
export DATE=$(date "+%d/%m/%Y %H:%M:%S")
rm -f ${WORKDIR}/ksitrmdc$$.tmp* 1>/dev/null 2>&1
#
export SUPFILE=${SUPDIR}/ksitrmdc.sup
#
export SQLTMP=${WORKDIR}/ksitrmdc$$.tmp
export PATH=$PATH:/usr/local/bin
export PATH=$PATH:$ORACLE_HOME/bin
#
##########################
# La liste c'est les bases SITRMDC qui tournent
cat <<EOF |sort -u | grep -v '^$'| grep SITRMDC|while read leSID ; do
$(ps -ef |grep smon|grep -v grep|grep -v '+ASM'|awk -F_ '{print $3}'|sed 's/ //g')
EOF
export ORACLE_SID=$leSID
export ORAENV_ASK=NO
. oraenv 1>/dev/null
export ORAENV_ASK=YES
export PATH=$ORACLE_HOME/bin:$PATH
#
sqlplus -s '/ as sysdba' 1>/dev/null 2>&1 <<EOT
set echo off heading off feedback off verify off
--
whenever sqlerror exit 1; 
whenever oserror exit 2; 
-- Acquisition ; In: files; Out:MSMQ(redundancy),TXREDUNDANCY,ORHANFRAME
-- InMemoryRed ; In:MSMQ(red) Out:MSMQ(mdmO),TXFRAME
--
--
select count(*) from  TELECOLLECT_ACQUISITION.subcontract ;
--
spool $SQLTMP.$leSID.2
select 'DOCUMENT' ||';'||to_char( count(*)) latbcnt from TELECOLLECT_ACQUISITION.document where CREATEDDATE >
to_date(to_char(sysdate -1 ,'yyyymmdd'),'yyyymmdd')
;
--
select 'TXREDUNDANTFRAME'  ||';'||to_char( count(*)) latbcnt from TELECOLLECT_ACQUISITION.TXREDUNDANTFRAME where TIMESTAMP >
to_date(to_char(sysdate -1 ,'yyyymmdd'),'yyyymmdd')
;
exit 0
EOT
#
export STATUS=$?
if [ $STATUS != 0 ]
then
   echo "Erreur $0 : $STATUS : SQL/OS 1/2 ..." >&2
   exit 3
fi
#
sed '/^$/d' ${SQLTMP}.$leSID.2 >${SQLTMP}.$leSID.1
export nb=`cat ${SQLTMP}.$leSID.1|wc -l`
#
##############
for ((i=1;i<=$nb;i++))
do
export latb=`sed -n ${i}p ${SQLTMP}.$leSID.1|awk -F";" '{print $1}'`
export cnt=`sed -n ${i}p ${SQLTMP}.$leSID.1|awk -F";" '{print $2}'`
export CNT=`echo $cnt`
export cnt=$CNT
#
#echo $latb $cnt 
#set -x
   echo -n `date +%Y/%m/%d" "%H:%M:%S` 					>>$SUPFILE
   echo -n "|"`hostname`"|$leSID|INFO______|comptage depuis 00h" 	>>$SUPFILE
   echo -n " J-1 =   ${cnt}|" 				 	>>$SUPFILE
   echo    `sed -n ${i}p ${SQLTMP}.$leSID.1|awk -F";" '{print $1}'` 	>>$SUPFILE
#
#set +x
#
done
##############
done
##########################
#
rm -f ${WORKDIR}/kresult$$.tmp* 1>/dev/null 2>&1
#
