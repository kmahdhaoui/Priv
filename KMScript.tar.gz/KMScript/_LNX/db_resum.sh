#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
set lines 132
set pages 132
--
col USER_ID format 9999999
col SESSION_ID format 9999999
col STATUS format a12
col START_TIME format a20
col SUSPEND_TIME format a20
col RESUME_TIME format a20
col ERROR_MSG format a55
--
prompt "=============================== RESUMABLE     ==================================="
select user_id,session_id, status, start_time, suspend_time,resume_time, error_msg from dba_resumable;
-- 
col OWNER_NAME format a15
col JOB_MODE format A10
col OPERATION format A10
col STATE format A15
col ATTACHED_SESSIONS format 9999999
col DEGREE format 99999
prompt "=============================== DATAPUMP_JOBS ==================================="
SELECT * FROM DBA_DATAPUMP_JOBS; 
exit
EOT
#
. $KMscript/KMlogout.sh
#
