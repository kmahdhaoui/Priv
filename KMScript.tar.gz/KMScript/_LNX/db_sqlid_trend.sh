#!/bin/bash
# Author : Kamel Mahdhaoui
#
#
if [ "$1" != "" ] 
then
   export lesqlid=$1
else
   echo "Usage is : $0 <sql ID> "
   exit 1
fi
#
if [ "$2" != "" ]
then
   export nbjour=$2
else
   export nbjour=1
fi
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export KMymd=`date "+%Y%m%d"`
#
# export Ftmp=/tmp/tmp_event_trends.$KMymdhms.tmp
# rm -f $Ftmp
#
# date
#
sqlplus -s "$conn"  <<EOT
--
set lines 132
set pages 44
--
set time off timi off echo off verify off feedback off 
set heading on
set pagesize 555
col ELAPSED_TIME_DELTA format 999,999,999,999,999
col IOWAIT_DELTA format 999,999,999,999,999
--
select
 s.snap_id,
 to_char(s.begin_interval_time,'dd-HH24:MI') d_date,
 sql.executions_delta ,
 sql.buffer_gets_delta ,
 sql.disk_reads_delta ,
 sql.iowait_delta ,
sql.cpu_time_delta ,
 sql.elapsed_time_delta 
 from
 dba_hist_sqlstat sql,
 dba_hist_snapshot s
 where
 s.snap_id = sql.snap_id
 and s.begin_interval_time > trunc(sysdate) + 1 - $nbjour
 and
sql.sql_id='$lesqlid'
 order by 2 
/
--
exit
EOT
#
#######################################
#
date
#
#
