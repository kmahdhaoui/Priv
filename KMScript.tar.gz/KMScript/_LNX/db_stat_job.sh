#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
set feedback off
alter session set nls_timestamp_tz_format='yyyy-mm-dd HH24:MI:SS';
set feedback on
--
col WINDOW_NAME format a23
col SCHEDULE_NAME format a28
col START_DATE format a23
col REPEAT_INTERVAL format a40
--
SELECT
   a.enabled,
   c.window_name,
   c.schedule_name,
   c.start_date,
   c.repeat_interval
FROM
   dba_scheduler_jobs             a,
   dba_scheduler_wingroup_members b,
   dba_scheduler_windows          c
WHERE
   job_name='GATHER_STATS_JOB'
And
   a.schedule_name=b.window_group_name
And
   b.window_name=c.window_name
;
--
column owner format a10
column job_name format a30
column operation format a10
column status format a10
column log_date format a27
--
select
   operation,
   status,
   log_date
from
   dba_scheduler_job_log
where
   job_name = decode(upper('GATHER_STATS_JOB'), 'ALL', job_name, upper('GATHER_STATS_JOB'))
order by
   log_date
;
-- GATHER_STATS_JOB
--
-- recupere de la 10g
SELECT JOB_NAME, SCHEDULE_NAME, SCHEDULE_TYPE, ENABLED
FROM DBA_SCHEDULER_JOBS
WHERE PROGRAM_NAME = 'GATHER_STATS_PROG';
--
-- automatic en 11g
col STATUS format a33
select log_date,status
from dba_scheduler_job_run_details
where job_name='BSLN_MAINTAIN_STATS_JOB'
order by log_date desc;
--
--
-- dbms_auto_task_admin.disable(client_name => 'auto optimizer stats collection', operation => NULL, window_name => NULL);
-- dbms_auto_task_immediate.gather_optimizer_stats;
--
select TAB_STAT.job_name,TAB_STAT.status,TAB_STAT.job_complet,duration,info
from
(select b.job_name,
           b.status,
           to_char(b.log_date,'dd-mm-yy hh24:mi:ss') as job_complet,
           b.RUN_DURATION as duration,
           substr(a.ADDITIONAL_INFO,47,24) as info
  from dba_scheduler_job_log a,dba_scheduler_job_run_details b
  where to_char(a.log_date,'dd-mm-yy hh24:mi:ss') = to_char(b.log_date,'dd-mm-yy hh24:mi:ss')
  and a.job_name=b.job_name
  and a.job_name like 'ORA$AT_OS_MANUAL%'
  and a.additional_info like '%GATHER_STATS_PROG%'
  order by  b.log_date desc) TAB_STAT
  where rownum = 1;
--
select * from dba_autotask_client where client_name =
'auto optimizer stats collection'
;
--
select * from dba_scheduler_running_jobs;
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
