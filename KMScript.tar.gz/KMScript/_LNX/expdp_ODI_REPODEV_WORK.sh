#
# export ORACLE_SID=ISITREMT
export SITR_APP=ODI_REPODEV_WORK
export KMymdhms=`date "+%Y%m%d%H%M%S"`
#
export SITR_DMP=${SITR_APP}_${KMymdhms}_%U.dmp
export SITR_LOG=${SITR_APP}_${KMymdhms}.log
#
sqlplus "/ as sysdba" <<EOT
create or replace directory kamel as '/sitr/backup/$ORACLE_SID/dump/' ;
exit
EOT
#
# query="nom_schema1.nom_table1:where rownum<1"
# query="nom_schema2.nom_table2:where rownum<1"
# echo QUERY="${SITR_APP}.EMT_LOT:WHERE rownum<1"> expAPP_Restrict_LOT.par
#
# expdp "'/ as sysdba'" DIRECTORY=kamel CONTENT=ALL PARALLEL=8 SCHEMAS=${SITR_APP} DUMPFILE=${SITR_DMP} LOGFILE=${SITR_LOG} PARFILE=expAPP_Restrict_LOT.par compression=ALL
#
expdp "'/ as sysdba'" DIRECTORY=kamel CONTENT=ALL PARALLEL=8 SCHEMAS=${SITR_APP} DUMPFILE=${SITR_DMP} LOGFILE=${SITR_LOG} compression=ALL
#
#
