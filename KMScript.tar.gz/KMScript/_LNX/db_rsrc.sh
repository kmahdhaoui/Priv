#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col TYPE format a15
col resource_consumer_group form a22 heading "Consumer Group"
col name form a22 heading "Name"
col plan form a27 heading "Plan Name"
col Sub-Plan format a27
col group_or_subplan form a27 heading "Sub-Plan"
col status form a6 heading "Status"
col cpu_p1 form 999 heading "CPU1"
col cpu_p2 form 999 heading "CPU2"
col cpu_p3 form 999 heading "CPU3"
col cpu_p4 form 999 heading "CPU4"

col WINDOW_NAME format a20
col NEXT_START_DATE format a35
col LAST_START_DATE  format a35
col RESOURCE_PLAN format a27
--
select RESOURCE_PLAN,WINDOW_NAME,NEXT_START_DATE,LAST_START_DATE from DBA_SCHEDULER_WINDOWS ;
;
--
SELECT name, is_top_plan FROM v\$rsrc_plan
/
--
select * from  DBA_RSRC_GROUP_MAPPINGS ;
--
-- select * from dba_rsrc_plans; 
--
select plan, group_or_subplan, type, cpu_p1, cpu_p2, cpu_p3, cpu_p4, status 
  from dba_rsrc_plan_directives 
order by 8,1,2,3,4,5,6; 
--
select username, initial_rsrc_consumer_group from dba_users; 
--
select * from dba_rsrc_consumer_group_privs; 
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
