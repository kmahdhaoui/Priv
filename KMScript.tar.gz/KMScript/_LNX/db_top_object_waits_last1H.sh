#!/bin/bash
# Author : Kamel Mahdhaoui
#
#
if [ "$1" == "" ]
then 
   export NBH=1
else
   export NBH=$1
fi
#
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export KMymd=`date "+%Y%m%d"`
#
# export Ftmp=/tmp/tmp_event_trends.$KMymdhms.tmp
# rm -f $Ftmp
#
# date
#
sqlplus -s "$conn"  <<EOT
--
set lines 132
set pages 44
--
set time off timi off echo off verify off feedback off 
set heading on
set pagesize 555
--
col username format a26
col sid format 9999
col state format a18
col event format a40
col wait_time format 99999999999
col OBJECT_NAME format a35
col OBJECT_TYPE  format a20
col EVENT format a44
col TTL_WAIT_TIME format 99999999999
--
select * from
(
  select dba_objects.object_name,
 dba_objects.object_type,
active_session_history.event,
 sum(active_session_history.wait_time +
  active_session_history.time_waited) ttl_wait_time
from v\$active_session_history active_session_history,
    dba_objects
 where
active_session_history.sample_time between sysdate - $NBH/24 and sysdate
and active_session_history.current_obj# = dba_objects.object_id
 group by dba_objects.object_name, dba_objects.object_type, active_session_history.event
 order by 4 desc)
where rownum < 6
/
--
exit
EOT
#
#######################################
#
date
#
#
