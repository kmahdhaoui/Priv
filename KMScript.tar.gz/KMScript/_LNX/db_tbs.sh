#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
col TABLESPACE_NAME format a44
col TAILLE format 99999999
col OCCUPE format 99999999
col PCT_OCCUPE format 999.9
col LIBRE  format 99999999
col PCT_LIBRE format 999.9
col AUT format a6
--
        select
                A.TableSpace_Name, B.Bytes/1024/1024 taille,
                B.Bytes/1024/1024 - A.Bytes/1024/1024 occupe,
                ((B.Bytes - A.Bytes)/B.Bytes)*100 pct_occupe,
                A.Bytes/1024/1024 libre,
                (A.Bytes / B.Bytes) * 100 pct_libre,
                C.Autoextensible
                From
                        (select tablespace_name, sum(nvl(bytes,0)) bytes
                                from dba_free_space group by tablespace_name) A,
                        (select tablespace_name, sum(nvl(bytes,0)) bytes
                                from DBA_Data_Files group by tablespace_name) B,
                        (select tablespace_name, max(autoextensible) as autoextensible
                                from DBA_Data_Files group by tablespace_name) C
                Where A.tablespace_name = B.tablespace_name
                and A.tablespace_name = C.tablespace_name
union 
        select
                A.TableSpace_Name, B.Bytes/1024/1024 taille,
                B.Bytes/1024/1024 - A.Bytes/1024/1024 occupe,
                ((B.Bytes - A.Bytes)/B.Bytes)*100 pct_occupe,
                A.Bytes/1024/1024 libre,
                (A.Bytes / B.Bytes) * 100 pct_libre,
                C.Autoextensible
                From
                        (select tablespace_name,sum(nvl(BYTES_FREE,0)) bytes
                                from V\$TEMP_SPACE_HEADER group by tablespace_name) A,
                        (select tablespace_name, sum(nvl(bytes,0)) bytes
                                from DBA_Temp_Files group by tablespace_name) B,
                        (select tablespace_name, max(autoextensible) as autoextensible
                                from DBA_Temp_Files group by tablespace_name) C
                Where A.tablespace_name = B.tablespace_name
                and A.tablespace_name = C.tablespace_name
/
exit
EOT
#
. $KMscript/KMlogout.sh
#
