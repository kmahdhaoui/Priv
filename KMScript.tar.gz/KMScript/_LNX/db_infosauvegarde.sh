#!/bin/bash
# Author : Kamel Mahdhaoui
# Unautorized use is forbidden 
#
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
#
if [ "$KSHOUTPUT" == "HTML" ]
then
   echo "<table border='1' width='90%' align='center' summary='Script output'>"
   echo "<PLAINTEXT>"
fi
#
export STATUT=0
cd $KMscript
export dmy=`date +"%d%m%y"`
export rep=$KMscript/log
export rapport=$KMscript/log/infosauvegarde.txt
export erreur_export=$KMscript/erreur_export.$dmy
export NLS_DATE_FORMAT='YYYY-MM-DD HH24:MI:SS'
#
rman target / 1>$rapport 2>&1 <<EOT
show all ;
report need backup ;
list backup summary ;
EOT
#
cat $rapport
#
export STATUT=0
if [ $STATUT = 0 ]
then
   . $KMscript/KMlogout.sh
   exit 0
else
   . $KMscript/KMlogout.sh
   exit 101
fi
#
#
if [ "$KSHOUTPUT" == "HTML" ]
then
   echo "</TABLE>"
fi
#
#
. $KMscript/KMlogout.sh
#

