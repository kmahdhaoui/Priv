#!/bin/ksh
# Author : Kamel Mahdhaoui
#
# regarde s i ya des dblink 
# 
. ~oracle/.profile 1>/dev/null 2>&1
export ORACLE_SID=lastbase
. ~oracle/kamel/KMscript/kamel.profile silent 1>/dev/null 2>&1
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh 1>/dev/null 1>/dev/null 2>&1
#
export host=$(uname -n)
export listbases=/tmp/kamel_listbases_$$
export OK=`echo "OK"`
export KO=`echo "KO"`
#
> $listbases
if [ "$host" == "dsgide" ]
then 
   export OraTab=/var/opt/oracle/oratab
else
   export OraTab=/etc/oratab
fi
# test : export OraTab=oratabkk
cat $OraTab | sed '/^#/d' | grep -v "*" | grep -v "lastbase" > $listbases
#
cat <<EOF |sort -u | grep -v '^$' | while read SID ; do
$(cat $listbases |awk -F: '{print $1}')
$(ps -ef |grep smon|grep -v grep|awk -F_ '{print $3}'|sed 's/ //g')
EOF
# on initialise des choses
export fictmp=/tmp/kamel_$$_$SID.txt
>$fictmp
#
export ORACLE_SID=$SID
export ORACLE_HOME=`cat $listbases | grep -w ^${SID} | awk -F: '{print $2}'`
export PATH=$ORACLE_HOME/bin:$PATH
export LIBPATH=/usr/lib:$ORACLE_HOME/lib32:$ORACLE_HOME/lib:$ORACLE_HOME/jlib:$ORACLE_HOME/network/jlib
#
# ---------- dblink
export dblink="N"
export mystatut=9
>$fictmp
sqlplus -s "$conn" 1>/dev/null 2>&1 <<EOT >/dev/null
set echo off termout off head off verify off feedback off serveroutput off
spool $fictmp
whenever sqlerror exit 1
select 
'dblink'||':'||'v:'||
rpad('$ORACLE_SID:'||a.owner||'.'||a.DB_LINK||' ',40,'-') ||
lower(rpad('> host:'||HOST||' ',30,' ')) ||
upper(rpad(' user:'||USERNAME||' ',20,' ')) 
from dba_db_links a;
spool off
exit 0
EOT
export mystatut=$?
#
if [ $mystatut -eq 0 ]
then
   # export dblink=`cat $fictmp|grep dblink | sed '/^$/d' | sed 's/[ \t]*$//'|awk -F:v: '{print $2}' `
   cat $fictmp|grep dblink | sed '/^$/d' | sed 's/[ \t]*$//'|awk -F:v: '{print $2}'
else
   export dblink="N"
fi
#
# -----------------------------
#
rm -f $fictmp 1>/dev/null 2>&1
#
done
#
rm $listbases 1>/dev/null 2>&1
#
. $KMscript/KMlogout.sh 1>/dev/null 2>&1
#

