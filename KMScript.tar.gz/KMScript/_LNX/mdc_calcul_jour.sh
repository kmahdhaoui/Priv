#!/bin/bash
#
. /sitr/exploit/dba/SITR_env.sh
#
export ORACLE_SID=XSITRMDC
export ORAENV_ASK=NO
. oraenv 1>/dev/null
export ORAENV_ASK=YES
export PATH=$ORACLE_HOME/bin:$PATH
#
# 
if [ "$1" != "" ]
then
   export datedeb="$1"
else
   echo "Usage : $0 <date debut : yyyymmdd-hh24mi> <date fin   : yyyymmdd-hh24mi>"
   exit 1
fi
#
if [ "$2" != "" ]
then
   export datefin="$2"
else
   echo "Usage : $0 <date debut : yyyymmdd-hh24mi> <date fin   : yyyymmdd-hh24mi>"
   exit 2
fi
#
sqlplus -s / as sysdba <<EOT
--
set feedback off
set verify off
set lines 132
set pages 132
alter session set nls_date_format='yyyy-mm-dd hh24:mi:ss' ;
--
set heading on
prompt Comptage Fichiers
prompt =====================================================
select count(*) Comptage from TELECOLLECT_ACQUISITION.document 
where CREATEDDATE >= to_date('$datedeb','yyyymmdd-hh24mi')
and   CREATEDDATE <= to_date('$datefin','yyyymmdd-hh24mi')
;
prompt
prompt Comptage Trame MDMO
prompt =====================================================
set feedback off
set verify off
set lines 132
set pages 132
alter session set nls_date_format='yyyy-mm-dd hh24:mi:ss' ;
--
set heading on
--
select count(*) from TELECOLLECT_BUSINESS.TXFRAME where subcontractid in 
(select id from TELECOLLECT_ACQUISITION.subcontract where subcontracttypeid='A995F4096B525D4390805DEA739D4F14') 
and TIMESTAMP >= to_date('$datedeb','yyyymmdd-hh24mi')
and TIMESTAMP <= to_date('$datefin','yyyymmdd-hh24mi')
;
prompt
prompt Comptage Trame par heure
prompt =====================================================
select to_char ( timestamp, 'YYYYMMDD HH24' ), count(*)
from   TELECOLLECT_BUSINESS.TXFRAME
where  subcontractid in (select id from TELECOLLECT_ACQUISITION.subcontract
                         where subcontracttypeid='A995F4096B525D4390805DEA739D4F14')
and TIMESTAMP >= to_date('$datedeb','yyyymmdd-hh24mi')
and TIMESTAMP <= to_date('$datefin','yyyymmdd-hh24mi')
group by to_char ( timestamp, 'YYYYMMDD HH24' )
order by 1 ;
--
exit
EOT
#
