#!/bin/ksh
export KMlogin_dw=oracle #default
export KMsite=arceuil
#
export Liste_dbsingle=" dpuq0spi dpsu1des dpsu1eng dppm8wkf dpaf4bop dpso1not dpoc1eai dpwm0opt dpqr0 dpwn3ele dpwm2eai dpwm0ofi dpwq0rh dpsa0ea2 dpwm0o4i dpwm9eai dpwm5eai dpwm2ea2 dpud0 dpco3cor dprc2fer dpqx1inf dpvl1gad dpoe1eai dpsr1syr dphr0ath dpsr1bat dprc2ea2 dpsu1mon dptf2ea2 dpsu5suf dpsr1gie dpqw0el2 "
#
export Liste_host_dw=""
export Liste_host_info=$Liste_host_dw
alias dasgbdprexa1='ssh -X ${KMlogin_dw}@dasgbdprexa1'
#
for singleSID in $Liste_dbsingle
do
   export instSID=$singleSID
   export racSID=$singleSID
   export mininstSID=`echo $instSID|tr "ABCDEFGHIJKLMNOPQRSTUVWXYZ" "abcdefghijklmnopqrstuvwxyz"`
   export majinstSID=`echo $instSID|tr "abcdefghijklmnopqrstuvwxyz" "ABCDEFGHIJKLMNOPQRSTUVWXYZ"`
   # alias $instSID="export ORACLE_SID=$instSID ; export ORAENV_ASK=NO; . oraenv; export ORAENV_ASK=YES; b"
   # alias $mininstSID="export ORACLE_SID=$instSID ; export ORAENV_ASK=NO; . oraenv; export ORAENV_ASK=YES; b"
   # alias $majinstSID="export ORACLE_SID=$instSID ; export ORAENV_ASK=NO; . oraenv; export ORAENV_ASK=YES; b"
   # alias log$instSID='tail -42 $ORACLE_BASE/admin/$mininstSID/bdump/alert_$instSID.log'
   # alias log$mininstSID='tail -42 $ORACLE_BASE/admin/$mininstSID/bdump/alert_$instSID.log'
   # alias log$majinstSID='tail -42 $ORACLE_BASE/admin/$mininstSID/bdump/alert_$instSID.log'
done
#
# export ORACLE_SID=dphr0ath ; export ORAENV_ASK=NO; . oraenv; export ORAENV_ASK=YES; b
# export ORACLE_SID=dphr0ath ; 
ora $ORACLE_SID; cd - 
export PATH=$PATH:$KMscript:$ORACLE_HOME/OPatch
b
#
