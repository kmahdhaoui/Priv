#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
set linesize 132
set pagesize 132
 
COLUMN "Item" FORMAT A30
COLUMN "Space Used (GB)" FORMAT 99999
COLUMN "Schema" FORMAT A25
COLUMN "Move Procedure" FORMAT A40
--
SELECT  occupant_name "Item",
    space_usage_kbytes/1048576 "Space Used (GB)",
    schema_name "Schema",
    move_procedure "Move Procedure"
FROM v\$sysaux_occupants
where space_usage_kbytes/1024 > 10
ORDER BY 1
;
--
col Mb form 9,999,999
col SEGMENT_NAME form a40
col SEGMENT_TYPE form a6
set lines 120
select sum(bytes/1024/1024) Mb, segment_name,segment_type 
from dba_segments
where  tablespace_name = 'SYSAUX'
and segment_name like 'WRI$_OPTSTAT%'
and segment_type='TABLE'
group by segment_name,segment_type 
having sum(bytes/1024/1024) > 1
order by 1 asc
;
--
col Mb form 9,999,999
col SEGMENT_NAME form a40
col SEGMENT_TYPE form a6
set lines 120
select sum(bytes/1024/1024) Mb, segment_name,segment_type from dba_segments
where  tablespace_name = 'SYSAUX'
and segment_name like '%OPT%'
and segment_type='INDEX'
group by segment_name,segment_type 
having sum(bytes/1024/1024) > 1
order by 1 asc
;
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
