bash /sitr/app/oracle/product/11.2.0/asm/bin/crs_stat -t |grep -v "ora.diskmon" |grep -v "ora.ons"
