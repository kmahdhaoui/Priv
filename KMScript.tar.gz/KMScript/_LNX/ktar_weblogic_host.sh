#!/bin/bash
# kma
#
if [ "$LOGNAME" != "weblogic" ]
then
   echo "$LOGNAME is not weblogic !!!"
   exit 1
fi
#
# les variables pour le batch : on a besoin de $BACKUP_SITR_TAR
# en excluant .log .out .old .tmp .dbf .aud .trc .trm ...
#
. /usr/local/etc/oracle/kenv_cismw.sh 
#
rm -f ${WORKDIR}/ktar_weblogic_host_$$.tmp* 1>/dev/null 2>&1
export SQLTMP=${WORKDIR}/ktar_weblogic_host_$$.tmp
#
export a_error_svg=0
#
export repsvg=$BACKUP_SITR_TAR/tars
mkdir -p $repsvg
#
# !!! tous les tars se font en relatif a partir de / en ./ !!!
cd /
#
#------------------------------------
export Chemin=./sitr/app ; export Nom=x
for Nom in hibernate java mdm mdm1 mdm2 mdm3 mdm4 mdm5 mdm6 mdm7 mdm8 mdm9
do
if [ -x "${Chemin}/${Nom}" ]
then
echo "tar -cvzf $repsvg/$LOGNAME.$Nom.$KMymdhms.tar.gz ${Chemin}/${Nom} --exclude ..."
tar -cvzf $repsvg/$LOGNAME.$Nom.$KMymdhms.tar.gz ${Chemin}/${Nom} --exclude "*/redo/*" --exclude "*/arch/*" --exclude "*/log*/*" --exclude "*.tmp*" --exclude "*.dmp*" --exclude "*.tar*" --exclude "*/temp*/*" --exclude "*/diag/*" --exclude "*/trace/*" --exclude "*.DMP*" --exclude "*.dbf*" --exclude "*.aud*" --exclude "*.out" --exclude "*.iso" --exclude "*.trc" --exclude "*.trm"
#
fi
done
#
#------------------------------------
export Chemin=./sitr/app/oracle ; export Nom=x
for Nom in middleware middleware1 middleware2 middleware3 middleware4 middleware5 middleware6 middleware7 middleware8 middleware9 
do
if [ -x "${Chemin}/${Nom}" ]
then
echo "tar -cvzf $repsvg/$LOGNAME.$Nom.$KMymdhms.tar.gz ${Chemin}/${Nom} --exclude ..."
tar -cvzf $repsvg/$LOGNAME.$Nom.$KMymdhms.tar.gz ${Chemin}/${Nom} --exclude "*/redo/*" --exclude "*/arch/*" --exclude "*/log*/*" --exclude "*.tmp*" --exclude "*.dmp*" --exclude "*.tar*" --exclude "*/temp*/*" --exclude "*/diag/*" --exclude "*/trace/*" --exclude "*.DMP*" --exclude "*.dbf*" --exclude "*.aud*" --exclude "*.out" --exclude "*.iso" --exclude "*.trc" --exclude "*.trm"
#
fi
done
#
#------------------------------------
export Chemin=./sitr ; export Nom=exploit
if [ -x "${Chemin}/${Nom}" ]
then
echo "tar -cvzf $repsvg/$LOGNAME.$Nom.$KMymdhms.tar.gz ${Chemin}/${Nom} --exclude ..."
tar -cvzf $repsvg/$LOGNAME.$Nom.$KMymdhms.tar.gz ${Chemin}/${Nom} --exclude "*/redo/*" --exclude "*/arch/*" --exclude "*/log*/*" --exclude "*.tmp*" --exclude "*.dmp*" --exclude "*.tar*" --exclude "*/temp*/*" --exclude "*/diag/*" --exclude "*/trace/*" --exclude "*.DMP*" --exclude "*.dbf*" --exclude "*.aud*" --exclude "*.out" --exclude "*.iso" --exclude "*.trc" --exclude "*.trm"
#
fi
#
#------------------------------------
#
rm -f ${WORKDIR}/ktar_weblogic_host_$$.tmp* 1>/dev/null 2>&1
rm -f $WORKDIR/$CONFILE 1>/dev/null 2>&1
#
