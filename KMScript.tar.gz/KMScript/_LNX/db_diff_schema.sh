#!/bin/bash
#----------------------------------------------------------------
# AUTEUR            : Kamel Mahdhaoui
#----------------------------------------------------------------
#set -x
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
#---------------------------------------------------------------------
# VARIABLES

export ARGS="$*"
export PID=${$}
export LANG=C
export mycoderror=0
export a_error_warn=4

# Logs et journaux
export LOG_RETENTION=10
export LOGDIR=./log                           
export JOBNAME=`basename ${0} .sh`                
export TMPLOG=/tmp/$JOBNAME.${INSTANCE}.${PID}.${RANDOM}.log
export LOGFILE="${LOGDIR}/${JOBNAME}.log"              
export DET_LOGFILE=/dev/null                    
#
export mycoderror=0
#---------------------------------------------------------------------
# FONCTIONS
Usage() {
   echo -e "\n\t-> Usage :"
   echo -e "\t\t`basename ${0}` "
   echo -e "\t\t                --dtbase1|-d1          =<Dtbase1> "
   echo -e "\t\t                --schema1|-s1          =<Schema1> "
   echo -e "\t\t                --tnsnam2|-t2          =<Tnsnam2> "
   echo -e "\t\t                --schema2|-s2          =<Schema2> "
   echo -e "\t\t                --objet|-o           =<Objet> "
   echo -e "\t\t                --verbose|-v              "
   echo -e "\n\t\tDependances : n/a"
   echo -e ""
   exit 1
   }

fMsgLog() {

   TYPINFO=${1}
   CODAPLI=${2}
   MSGINFO=${3}
   if [ ${MODE_VERBOSE} ]; then  
	case "${TYPINFO}" in
		TITRE*)	echo -e "\n\t=> ${MSGINFO}"|tee -a ${DET_LOGFILE};;
		TEXTE*)	echo -e "\t${MSGINFO}"|tee -a ${DET_LOGFILE};;
		INFO*) 	echo -e "\t- ${MSGINFO}"|tee -a ${DET_LOGFILE};;
		*)	echo -e "\t${TYPINFO} : ${MSGINFO}"|tee -a ${DET_LOGFILE};;
	esac 
   fi
   case "${TYPINFO}" in
	INFO*|ALERTE*|ERR*) 
		echo -e "`/bin/date +\%Y%m%d-%Hh%M`:${TYPINFO}:${CODAPLI}:${MSGINFO}" >> ${LOGFILE}		
		;;
   esac
}


fFinJob() {
	
   . $KMscript/KMlogout.sh
   #
   CODRETOUR=${1}
   # Suppression des fichiers temporaires et lock
   rm -f /tmp/rman_purge.${INSTANCE}.${PID}*

   fMsgLog "TEXTE" "" "\n"
   fMsgLog "TEXTE" "" "Le job ${JOBNAME} s'est termine le `/bin/date +\%A\ %d\ %B\ %Y\ \a\ %H\h%M` avec le code ${CODRETOUR}.\n"
   exit ${CODRETOUR}
}

#---------------------------------------------------------------------
# CONTROL PARAMETRES ET TESTS

if [ "${1}" = "" ]; then Usage; fi

for arg in ${ARGS} 
do
    case "$arg" in
      --dtbase1=*|-d1=*)            DTBASE1=`echo -e "$arg" | sed -e 's/^[^=]*=//'` ;;
      --schema1=*|-s1=*)           SCHEMA1=`echo -e "$arg" | sed -e 's/^[^=]*=//'` ;;
      --tnsnam2=*|-t2=*)           TNSNAM2=`echo -e "$arg" | sed -e 's/^[^=]*=//'` ;;
      --schema2=*|-s2=*)           SCHEMA2=`echo -e "$arg" | sed -e 's/^[^=]*=//'` ;;
      --objet=*|-o=*)              OBJET=`echo -e "$arg" | sed -e 's/^[^=]*=//'` ;;
      --verbose|-v)          MODE_VERBOSE=0;;
      --help|-h)             Usage;;
      *)                     Usage;;         
    esac
done
#
#if [ "${LOGNAME}" != "${OSUSER}" ]; then
#echo -e "\n\t-> Switch on login ${OSUSER} for running this shell\n"
#su - ${OSUSER} -c "${0} ${*}"
#exit ${?}
#fi
#
if [ ! -w /tmp ]; then
        echo -e "\n\t-> Impossible d'ecrire dans le repertoire temporaire"
        exit 1
fi
#
#---------------------------------------------------------------------
# INITIALISATIONS

fMsgLog "TEXTE" "" "\n\t----------------------------------------------------" 
fMsgLog "TEXTE" "" "Compressed Elements  " 
fMsgLog "TEXTE" "" "----------------------------------------------------" 

fMsgLog "TITRE" "" "Starting at ... `/bin/date +\%A\ %d\ %B\ %Y\ \a\ %H\h%M`" 
fMsgLog "TEXTE" "" "          ORACLE_SID = ${ORACLE_SID}" 
fMsgLog "TEXTE" "" "              SCHEMA1 = ${SCHEMA1}" 
fMsgLog "TEXTE" "" "              SCHEMA2 = ${SCHEMA2}" 
fMsgLog "TEXTE" "" "               OBJET = ${OBJET}" 
fMsgLog "TEXTE" "" "       LOG DETAILLEE = ${DET_LOGFILE}"
#
#---------------------------------------------------------------------
# AUTOPURGES DES LOGS DU JOB

# Purge des anciens fichiers de LOG
fMsgLog "TITRE" "" "Purge des logs de $0 :"
NB_PURGE=$(expr `find ${DET_LOGDIR} -name "${JOBNAME}.${ORACLE_SID}.*.log" -mtime +${LOG_RETENTION} -print |wc -l`)
find ${DET_LOGDIR} -name "${JOBNAME}.${ORACLE_SID}.*.log" -mtime +${LOG_RETENTION} -exec rm {} \;
if [ ${?} -ne 0 ]; then
   fMsgLog "ALERTE " ${ORACLE_SID} "Purge des logs impossible..."
else
   fMsgLog "TEXTE" "" "...Ok - ${NB_PURGE} fichier(s) purge(s)"
fi
#
#=====================================================================
#=====================================================================
# Le traitement ... 
#=====================================================================
#=====================================================================
#
export JourSemaine=`/bin/date +%a`
#
fMsgLog "TITRE" "" "Comparaison Schemas/Objets :"
#
echo -e "traitement ..." 1>>$TMPLOG 2>&1
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export KMms=`date "+%M%S"`
export tmp_link=tmpl_diff_$$_$KMms
export tmp_obj=tmpo_diff_$$_$KMms
export tmp_indexes=tmp_ind_$$_$KMms
export tmp_ind_columns=tmp_indcol_$$_$KMms
#
# conn1 
export conn1="/ as sysdba"
export ORACLE_SID
export ORAENV_ASK=NO; . oraenv; export ORAENV_ASK=YES
# conn2
export Arond=`head -1 $KMscript/conn/$TNSNAM2|grep "@"|wc -l`
if [ $Arond -eq 0 ]
then
   export conn2=`head -1 $KMscript/conn/$TNSNAM2`@$TNSNAM2
else
   export conn2=`head -1 $KMscript/conn/$TNSNAM2`
fi
# zz
export DBL_U=`echo $conn2|awk -F"/" '{print $1}'`
export DBL_P=`echo $conn2|awk -F"/" '{print $2}'|awk -F"@" '{print $1}'`
export DBL_T=`echo $conn2|awk -F"/" '{print $2}'|awk -F"@" '{print $2}'`
#
if [ "$DBL_T" == "" ]
then
   "Erreur tns 2 : $TNSNAM2 doit etre la base distante ..."
   exit 1
fi
#
#
sqlplus -s "$conn1"  <<EOT
@$KMscript/$SQLLOGIN
--
set lines 132
set pages 132
--
set feedback off
alter session set nls_date_format='yy-mm-DD hh24:mi:ss';
set feedback on
--
clear breaks
clear columns
clear computes
--
set trims on
set verify off
col table_name  format a22 
col COLUMN_NAME format a20 
col high_value format a20
col composite format a3 heading "CMP"
col partition_position format 999 heading "Pos"
col subpartition_count format 999 heading "Cnt"
col init_kb format 999999 heading "Init KB"
col next_kb format 999999 heading "Next KB"
col num_rows format 9999999 heading "Num Rows"
col pct_increase format 999 heading "Pct|Inc"
col partition_name format a25 heading "Part Name"
col tablespace_name format a25 heading "Tabsp Name"
col DATA_LENGTH format 99999999
col DLENGTH format 99999999
col DSCALE format 99999999
col DPRECISION format 99999999
col DATA_TYPE format a12
col owner format A12
col INDEX_OWNER format A12
col COLUMN_POSITION format 99999
col CPOS format 99999
--
------------------------------------------------------------------------------------------------
set feedback off
CREATE DATABASE LINK $tmp_link CONNECT TO "$DBL_U" IDENTIFIED BY "$DBL_P" USING '$DBL_T'
       ;
CREATE TABLE $tmp_obj as 
       select object_name,object_type from dba_objects
       where owner='$SCHEMA1' and object_name like '$OBJET' 
       and object_name not like 'SYS_EXPORT%' 
       and object_name not like 'SYS_IMPORT%'
       and object_name not like 'ID_DOUBLONS%'
       and object_name not like 'Q%CONSO%'
       and object_name not like 'TMP%'
       and object_name not like 'KAMEL%'
       and object_name not like 'KK%'
       and object_name not like 'TEST%'
       and object_name not like 'PLAN_TABLE%'
       and object_name not like 'ET\$%'
       and object_name not like 'RE\$%'
       and object_name not like 'BIN\$%'
       intersect 
       select object_name,object_type from dba_objects@$tmp_link 
       where owner='$SCHEMA2' and object_name like '$OBJET' 
       ;
CREATE TABLE $tmp_indexes as select * from dba_indexes@$tmp_link where table_owner='$SCHEMA2' 
       and TABLE_NAME like '$OBJET'
       ;
CREATE INDEX i1_$tmp_indexes on $tmp_indexes (table_owner,TABLE_NAME)
       ;
CREATE TABLE $tmp_ind_columns as select INDEX_OWNER,INDEX_NAME,TABLE_OWNER,TABLE_NAME,COLUMN_NAME,
       COLUMN_POSITION,COLUMN_LENGTH 
       from dba_ind_columns@$tmp_link where table_owner='$SCHEMA2' 
       and TABLE_NAME like '$OBJET'
       ;
CREATE INDEX i1_$tmp_ind_columns on $tmp_ind_columns (TABLE_OWNER,TABLE_NAME,index_name,COLUMN_NAME)
       ;

--
set feedback on
-----------------------------------------------------------------------------------------------
--
prompt =======================================================================
prompt *                        TABLES MANQUANTES                            *
prompt =======================================================================
--
prompt >>>>>>>>>>>>>>>>>> $DTBASE1 > $TNSNAM2 
select owner,table_name from dba_tables where owner='$SCHEMA1' and table_name like '$OBJET'
       and table_name not like 'SYS_EXPORT%'
       and table_name not like 'SYS_IMPORT%'
       and table_name not like 'ID_DOUBLONS%'
       and table_name not like 'Q%CONSO%'
       and table_name not like 'TMP%'
       and table_name not like 'KAMEL%'
       and table_name not like 'KK%'
       and table_name not like 'TEST%'
       and table_name not like 'PLAN_TABLE%'
       and table_name not like 'ET\$%'
       and table_name not like 'RE\$%'
       and table_name not like 'BIN\$%'
minus 
select owner,table_name from dba_tables@$tmp_link where owner='$SCHEMA2' and table_name like '$OBJET'
order by 1,2
;
prompt <<<<<<<<<<<<<<<<<< $DTBASE1 < $TNSNAM2 
select owner,table_name from dba_tables@$tmp_link where owner='$SCHEMA2' and table_name like '$OBJET'
       and table_name not like 'SYS_EXPORT%'
       and table_name not like 'SYS_IMPORT%'
       and table_name not like 'ID_DOUBLONS%'
       and table_name not like 'Q%CONSO%'
       and table_name not like 'TMP%'
       and table_name not like 'KAMEL%'
       and table_name not like 'KK%'
       and table_name not like 'TEST%'
       and table_name not like 'PLAN_TABLE%'
       and table_name not like 'ET\$%'
       and table_name not like 'RE\$%'
       and table_name not like 'BIN\$%'
minus
select owner,table_name from dba_tables where owner='$SCHEMA1' and table_name like '$OBJET'
order by 1,2
;
--
prompt =======================================================================
prompt *        COLONNES (TABLES COMMUNES) DIFFERENTES OU MANQUANTES         *
prompt =======================================================================
--
prompt >>>>>>>>>>>>>>>>>> $DTBASE1 > $TNSNAM2
select owner,table_name,column_name,DATA_TYPE,DATA_LENGTH dlength,DATA_PRECISION dprecision,DATA_SCALE dscale,NULLABLE 
from dba_tab_columns where owner='$SCHEMA1' and table_name like '$OBJET'
and (owner,table_name) in (select owner,object_name from $tmp_obj where object_type like 'TABLE')
minus
select owner,table_name,column_name,DATA_TYPE,DATA_LENGTH dlength,DATA_PRECISION dprecision,DATA_SCALE,NULLABLE from dba_tab_columns@$tmp_link where owner='$SCHEMA2' and table_name like '$OBJET' 
and (owner,table_name) in (select owner,object_name from $tmp_obj where object_type like 'TABLE')
order by 1,2,3
;
prompt <<<<<<<<<<<<<<<<<< $DTBASE1 < $TNSNAM2
select owner,table_name,column_name,DATA_TYPE,DATA_LENGTH dlength,DATA_PRECISION dprecision,DATA_SCALE,NULLABLE from dba_tab_columns@$tmp_link where owner='$SCHEMA2' and table_name like '$OBJET'
and (owner,table_name) in (select owner,object_name from $tmp_obj where object_type like 'TABLE')
minus
select owner,table_name,column_name,DATA_TYPE,DATA_LENGTH dlength,DATA_PRECISION dprecision,DATA_SCALE,NULLABLE from dba_tab_columns where owner='$SCHEMA1' and table_name like '$OBJET'
and (owner,table_name) in (select owner,object_name from $tmp_obj where object_type like 'TABLE')
order by 1,2,3
;
--
prompt =======================================================================
prompt *        INDEXES (TABLES COMMUNES) DIFFERENTS OU MANQUANTS            *
prompt =======================================================================
--
prompt >>>>>>>>>>>>>>>>>> $DTBASE1 > $TNSNAM2
select ii.uniqueness,ic.index_owner,ic.table_name,ic.index_name,ic.column_name,ic.column_position CPOS
from dba_ind_columns ic,dba_indexes ii 
where ic.INDEX_OWNER=ii.owner and ic.index_name=ii.index_name
and ic.table_owner='$SCHEMA1' and ic.table_name like '$OBJET'
and (ic.table_owner,ic.table_name) in (select owner,object_name from $tmp_obj where object_type like 'TABLE')
minus
select ii.uniqueness,ic.index_owner,ic.table_name,ic.index_name,ic.column_name,ic.column_position CPOS
from $tmp_ind_columns ic, $tmp_indexes ii 
where ic.INDEX_OWNER=ii.owner and ic.index_name=ii.index_name
and ic.table_owner='$SCHEMA2' and ic.table_name like '$OBJET'
and (ic.table_owner,ic.table_name) in (select owner,object_name from $tmp_obj where object_type like 'TABLE')
order by 2,3,4,6
;
prompt <<<<<<<<<<<<<<<<<< $DTBASE1 < $TNSNAM2
select ii.uniqueness,ic.index_owner,ic.table_name,ic.index_name,ic.column_name,ic.column_position CPOS
from $tmp_ind_columns ic, $tmp_indexes ii 
where ic.INDEX_OWNER=ii.owner and ic.index_name=ii.index_name
and ic.table_owner='$SCHEMA1' and ic.table_name like '$OBJET'
and (ic.table_owner,ic.table_name) in (select owner,object_name from $tmp_obj where object_type like 'TABLE')
minus
select ii.uniqueness,ic.index_owner,ic.table_name,ic.index_name,ic.column_name,ic.column_position CPOS
from dba_ind_columns ic,dba_indexes ii 
where ic.INDEX_OWNER=ii.owner and ic.index_name=ii.index_name
and ic.table_owner='$SCHEMA2' and ic.table_name like '$OBJET'
and (ic.table_owner,ic.table_name) in (select owner,object_name from $tmp_obj where object_type like 'TABLE')
order by 2,3,4,6
;
--
--
--
------------------------------------------------------------------------------------------------
set feedback off
DROP DATABASE LINK $tmp_link ;
DROP TABLE $tmp_obj ;
DROP TABLE $tmp_indexes ;
DROP TABLE $tmp_ind_columns ;

set feedback on
------------------------------------------------------------------------------------------------
exit
EOT
#
export mycoderror=$?
export a_error_warn=4
#
#=====================================================================
# FIN
#=====================================================================
#
# si Verbose afficher autrement mettre dans le DET_LOGFILE
if [ ${MODE_VERBOSE} ]; then fMsgLog "TEXTE" "" "\n"; cat ${TMPLOG}|tee -a ${DET_LOGFILE}; else cat ${TMPLOG}>>${DET_LOGFILE}; fi
#
if [ $mycoderror -eq 0 ] && [ $a_error_warn -eq 4 ]
then
   fMsgLog "WARNING " ${ORACLE_SID} " Warning ..."
   export mycoderror=4
fi
#
if [ $a_error_warn -eq 0 ]
then
   fMsgLog "INFO   " ${ORACLE_SID} " Info ... "
fi
#---------------------------------------------------------------------
# FIN DU JOB

fFinJob ${mycoderror}
