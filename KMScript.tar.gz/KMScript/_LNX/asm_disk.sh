#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s '/ as sysdba' <<EOT
@$KMscript/$SQLLOGIN
--
set feedback off heading off
set pagesize 0
alter session set nls_date_format = 'DD/MM/YYYY HH24:MI:SS';
select to_char(sysdate) heure from dual;
set feedback on heading on

SET LINESIZE  145
SET PAGESIZE  9999
SET VERIFY    off

COLUMN group_name             FORMAT a20           HEAD 'Disk Group|Name'
COLUMN type                   FORMAT a6            HEAD 'Type'
COLUMN total_mb               FORMAT 999,999,999   HEAD 'Total Size (MB)'
COLUMN free_mb                FORMAT 999,999,999   HEAD 'Free Size (MB)'
COLUMN used_mb                FORMAT 999,999,999   HEAD 'Used Size (MB)'
COLUMN pct_used               FORMAT 999.99        HEAD 'Pct. Used'

break on report on disk_group_name skip 1

compute sum label "Grand Total: " of total_mb used_mb on report

SELECT
    name                                     group_name
  , type                                     type
  , total_mb                                 total_mb
  , free_mb                                  free_mb
  , (total_mb - free_mb)                     used_mb
  , ROUND((1- (free_mb / total_mb))*100, 2)  pct_used
FROM
    v\$asm_diskgroup
ORDER BY
    name;
--
col PATH format a50
col NAME format a20

select MOUNT_STATUS,TOTAL_MB,FREE_MB,NAME,PATH from V\$ASM_DISK
order by PATH
;
exit
EOT
#
b
#
. $KMscript/KMlogout.sh
#
