#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col SID_SERIAL format a22
col ORAUSER format a15
col PROGRAM format a33
col UNDOSEG format a33
col Undo format a22
set lines 132
set pages 132

SELECT TO_CHAR(s.sid)||','||TO_CHAR(s.serial#) sid_serial,
NVL(s.username, 'None') orauser,
s.program,
r.name undoseg,
t.used_ublk * TO_NUMBER(x.value)/1024||'K' "Undo"
FROM sys.v_\$rollname r,
sys.v_\$session s,
sys.v_\$transaction t,
sys.v_\$parameter x
WHERE s.taddr = t.addr
AND r.usn = t.xidusn(+)
AND x.name = 'db_block_size'
/
col mb format 99999999
select status,TABLESPACE_NAME,sum(BYTES)/1024/1024 mb from DBA_UNDO_EXTENTS group by status,TABLESPACE_NAME
/
--
prompt --> Retention Optimale 
SELECT d.undo_size/(1024*1024) "ACTUAL UNDO SIZE [MByte]",
       SUBSTR(e.value,1,25) "UNDO RETENTION [Sec]",
       ROUND((d.undo_size / (to_number(f.value) *
       g.undo_block_per_sec))) "OPTIMAL UNDO RETENTION [Sec]"
  FROM (
       SELECT SUM(a.bytes) undo_size
          FROM v\$datafile a,
               v\$tablespace b,
               dba_tablespaces c
         WHERE c.contents = 'UNDO'
           AND c.status = 'ONLINE'
           AND b.name = c.tablespace_name
           AND a.ts# = b.ts#
       ) d,
       v\$parameter e,
       v\$parameter f,
       (
       SELECT MAX(undoblks/((end_time-begin_time)*3600*24))
              undo_block_per_sec
         FROM v\$undostat
       ) g
WHERE e.name = 'undo_retention'
  AND f.name = 'db_block_size';
--
prompt --> Undo Needed
SELECT d.undo_size/(1024*1024) "ACTUAL UNDO SIZE [MByte]",
       SUBSTR(e.value,1,25) "UNDO RETENTION [Sec]",
       (TO_NUMBER(e.value) * TO_NUMBER(f.value) *
       g.undo_block_per_sec) / (1024*1024) 
      "NEEDED UNDO SIZE [MByte]"
  FROM (
       SELECT SUM(a.bytes) undo_size
         FROM v\$datafile a,
              v\$tablespace b,
              dba_tablespaces c
        WHERE c.contents = 'UNDO'
          AND c.status = 'ONLINE'
          AND b.name = c.tablespace_name
          AND a.ts# = b.ts#
       ) d,
      v\$parameter e,
       v\$parameter f,
       (
       SELECT MAX(undoblks/((end_time-begin_time)*3600*24))
         undo_block_per_sec
         FROM v\$undostat
       ) g
 WHERE e.name = 'undo_retention'
  AND f.name = 'db_block_size'
;
exit
EOT
#
. $KMscript/KMlogout.sh
#

