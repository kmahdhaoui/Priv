#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
#
mkdir -p log
nohup vmstat 900 900 1>log/vmstat_$KMymdhms.log 2>&1 &
#
