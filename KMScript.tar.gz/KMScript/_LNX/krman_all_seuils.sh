#!/bin/bash
# kma
#
# set before $ORACLE_HOME
#
#
# Les archive logs sont sur /sitr : /sitr/oradata/R*/arch
# le seuil est de 50%
if [ "$1" == "" ]
then
   export lefs="/sitr"
else
   export lefs=$1
fi
#
# le seuil
if [ "$2" == "" ]
then
   export lepct=50
else
   export lepct=$2
fi
#
#
export nomPROG=krman_all_seuils.sh
export NombrePS=`ps -ef |grep $nomPROG |grep -v grep|grep ">"|wc -l`
if [ "$NombrePS" -gt 1 ]
then
   echo "Il y a deja $0 qui tourne !"
   ps -ef |grep $nomPROG |grep -v grep
   exit 103
fi
#
# les variables pour le batch
. /usr/local/etc/oracle/kenv_batch.sh
#
cd $BINDIR
#
rm -f ${WORKDIR}/krman_all_seuils_$$.tmp* 1>/dev/null 2>&1
#
export SQLTMP=${WORKDIR}/krman_all_seuils_$$.tmp
#
##########################
# La liste c'est les bases qui tournent
cat <<EOF |sort -u | grep -v '^$'| while read leSID ; do
$(ps -ef |grep smon|grep -v grep|grep -v '+ASM'|awk -F_ '{print $3}'|sed 's/ //g')
EOF

##############

# params : SID FS PCT
echo bash $BINDIR/krman_seuil_arch.sh $leSID $lefs $lepct 
bash $BINDIR/krman_seuil_arch.sh $leSID $lefs $lepct 1>$LOGDIR/krman_seuil_arch_$leSID.$$.log 2>&1

##############
done
##########################
#
rm -f ${WORKDIR}/krman_all_seuils_$$.tmp* 1>/dev/null 2>&1
#
