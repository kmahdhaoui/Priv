#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
set lines 200
set pages 200
col USER_NAME format a15
col MACHINE_NAME format a15
col logon_time format a25
col OS_ID format a10
col TOTAL_PHYSICAL_IO  format 999999
col TOTAL_LOGICAL_IO  format 999999
col TOTAL_MEMORY_USAGE     format 999999 
col PARSES   format 999999
col TOTAL_CPU format 999999
--
select * from
(select b.sid sid,
     decode (b.username,null,e.name,b.username) user_name,
     d.spid os_id,
     b.machine machine_name,
     to_char(logon_time,'dd-mon-yy hh:mi:ss pm') logon_time,
    (sum(decode(c.name,'physical reads  ',value,0)) +
     sum(decode(c.name,'physical writes',value,0)) +
     sum(decode(c.name,'physical writes direct',value,0)) +
     sum(decode(c.name,'physical writes direct (lob)',value,0))+
     sum(decode(c.name,'physical reads  direct (lob)',value,0)) +
     sum(decode(c.name,'physical reads   direct',value,0)))
     total_physical_io,
    (sum(decode(c.name,'db block gets',value,0)) +
     sum(decode(c.name,'db block changes',value,0)) +
     sum(decode(c.name,'consistent changes',value,0)) +
     sum(decode(c.name,'consistent gets ',value,0)) )
     total_logical_io,
    (sum(decode(c.name,'session pga memory',value,0))+
     sum(decode(c.name,'session uga memory',value,0)) )
     total_memory_usage,
     sum(decode(c.name,'parse count (total)',value,0)) parses,
     sum(decode(c.name,'cpu used by this session',value,0))
     total_cpu,
     sum(decode(c.name,'parse time cpu',value,0)) parse_cpu,
     sum(decode(c.name,'recursive cpu usage',value,0))
       recursive_cpu,
     sum(decode(c.name,'cpu used by this session',value,0)) -
     sum(decode(c.name,'parse time cpu',value,0)) -
     sum(decode(c.name,'recursive cpu usage',value,0))
       other_cpu,
     sum(decode(c.name,'sorts (disk)',value,0)) disk_sorts,
     sum(decode(c.name,'sorts (memory)',value,0)) memory_sorts,
     sum(decode(c.name,'sorts (rows)',value,0)) rows_sorted,
     sum(decode(c.name,'user commits',value,0)) commits,
     sum(decode(c.name,'user rollbacks',value,0)) rollbacks,
     sum(decode(c.name,'execute count',value,0)) executions
from sys.v_\$sesstat  a,
     sys.v_\$session b,
     sys.v_\$statname c,
     sys.v_\$process d,
     sys.v_\$bgprocess e
where a.statistic#=c.statistic# and
a.sid=b.sid and
d.addr=b.paddr and
e.PADDR=b.paddr and
      c.NAME in ('physical reads  ',
                 'physical writes',
                 'physical writes direct',
                 'physical reads   direct',
                 'physical writes direct (lob)',
                 'physical reads   direct (lob)',
                 'db block gets',
                 'db block changes',
                 'consistent changes',
                 'consistent gets ',
                 'session pga memory',
                 'session uga memory',
                 'parse count (total)',
                 'CPU used by this session',
                 'parse time cpu',
                 'recursive cpu usage',
                 'sorts (disk)',
                 'sorts (memory)',
                 'sorts (rows)',
                 'user commits',
                 'user rollbacks',
                 'execute count'
)
group by b.sid,
         d.spid,
         decode (b.username,null,e.name,b.username),
         b.machine,
         to_char(logon_time,'dd-mon-yy hh:mi:ss pm')
order by 6 desc)
where rownum < 6
;
--
/*
select * from (
 select stat.sql_id as sql_id, round(sum(elapsed_time_delta) / 1000000) as elapsed, 
     (select cast(substr(st.sql_text, 1, 4000) AS VARCHAR2(4000))
     from dba_hist_sqltext st
     where st.dbid = stat.dbid and st.sql_id = stat.sql_id) as sql_text_fragment
 from dba_hist_sqlstat stat, dba_hist_sqltext text
 where stat.sql_id = text.sql_id and
       stat.dbid   = text.dbid
 group by stat.dbid, stat.sql_id
 order by elapsed desc
) where ROWNUM <= 10;
*/
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
