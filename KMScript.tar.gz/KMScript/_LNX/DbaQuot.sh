#!/bin/bash
# 
# Author : Kamel Mahdhaoui
# Unautorized use is forbidden 
#
export alert_dir=`sqlplus -s / as sysdba <<EOT
set pages 0
set headi off
set feedb off
set verify off
set pages 155
col value format a70
select value from v\\$parameter where name='background_dump_dest';
exit
EOT
`
export alert_log="alert_${ORACLE_SID}.log"
# *****************************************************************************
#
# ENVOI FICHIER ALERT POUR DBA
sh $KMscript/db_fic_alert.sh
#
echo $alert_dir/$alert_log
#
echo "************************************************************************"
echo "*                        Control File to trace                         *"
echo "************************************************************************"
date
sqlplus -s / as sysdba <<EOT             
set pages 600
alter database backup controlfile to '$KMscript/log/svgcontrol$ORACLE_SID$$.ctl';
alter database backup controlfile to trace;
exit;
EOT
#
find  $KMscript/log -name "svgcontrol$ORACLE_SID*.ctl"  -mtime +8 -exec rm {} \;
#
echo "************************************************************************"
echo "*                        Sauvegarde precedente                         *"
echo "************************************************************************"
date
sh $KMscript/db_infosauvegarde.sh
#
echo "************************************************************************"
echo "-                        Startup Time                                  -"
echo "************************************************************************"
date
sh $KMscript/db_uptime.sh
#
echo "************************************************************************"
echo "-                        SGA                                           -"
echo "************************************************************************"
date
sqlplus -s / as sysdba <<EOT
set pages 600
select * from v\$sga
/
exit;
EOT
#
echo "************************************************************************"
echo "-                        Ratios                                        -"
echo "************************************************************************"
date
sh db_seuils.sh
#
echo "************************************************************************"
echo "-                        Locked OBJ                                    -"
echo "************************************************************************"
date
sqlplus -s / as sysdba <<EOT
set pages 600
select * from v\$locked_object
/
exit;
EOT
#
echo "************************************************************************"
echo "-                        Locks                                         -"
echo "************************************************************************"
date
sh db_locks.sh
#
echo "************************************************************************"
echo "-                        Jobs                                          -"
echo "************************************************************************"
date
sh db_snap.sh
#
echo "************************************************************************"
echo "-                        Free Space                                    -"
echo "************************************************************************"
date
b
sh db_dfi.sh
exit
EOT
#
# df -k
#
echo "************************************************************************"
echo "-                        File Systems oracle                           -"
echo "************************************************************************"
date
sh df_m.sh
sh db_asm.sh
#
echo "************************************************************************"
echo "-                        Fragmentation                                 -"
echo "************************************************************************"
date
frag
#
# Process
#
echo "************************************************************************"
echo "-                        Processes Unix                                -"
echo "************************************************************************"
date
ps -ef 
#
echo "************************************************************************"
echo "-                        Processes Oracle                              -"
echo "************************************************************************"
date
sh db_sess.sh 
#
# Combien
echo "************************************************************************"
echo "-                        Combien de Process Oracle                     -"
echo "************************************************************************"
date
combien=`ps -ef |grep LOC|grep ora|grep $ORACLE_SID|grep -v grep|wc -l `
echo "$combien Process Oracle "
#
# Corrupted
echo "************************************************************************"
echo "-                        Corrupted block                               -"
echo "************************************************************************"
date
grep -in  "corrupt" $alert_dir/$alert_log|grep -i "block"
#
# ORA-00600
echo "************************************************************************"
echo "-                        ORA-00600                                     -"
echo "************************************************************************"
date
egrep -e  "ORA-00600|ORA-0600|ORA-600" $alert_dir/$alert_log
#
# ORA-xxxxx
echo "************************************************************************"
echo "-                        ORA-xxxxx                                     -"
echo "************************************************************************"
date
grep -n  "ORA-" $alert_dir/$alert_log|grep -v "ORA-00600"
#
echo "************************************************************************"
echo "-                        parameter                                     -"
echo "************************************************************************"
date
sqlplus -s / as sysdba <<EOT
set pages 600
col name format A40
col value format A20
col value isdefault A10
set pause off
select 
name,value
from v\$parameter 
where ISDEFAULT not like 'TRUE' 
order by name
;
exit
EOT
#
# Coalesce 
echo "************************************************************************"
echo "-                        COALISATION                                   -"
echo "************************************************************************"
date
#
# Compile 
echo "************************************************************************"
echo "-                        COMPILE                                       -"
echo "************************************************************************"
date
#
# Chained 
echo "************************************************************************"
echo "-                        CHAINED ROWS                                  -"
echo "************************************************************************"
date
#
date
#
