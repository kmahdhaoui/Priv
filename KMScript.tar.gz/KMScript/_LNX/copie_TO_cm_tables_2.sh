#
for tb in MSRMT INIT_MSRMT_DATA_K INIT_MSRMT_DATA
do
#
sqlplus -s / as sysdba <<EOT
alter user cisadm2 identified by kamel;
exit
EOT
#
sqlplus -s "cisadm2/kamel" <<EOT &
--
set time on timi on echo on
host echo "<<<<<<<<<<<<<<<<<<<< `date` : $tb "
--
alter session set current_schema=cisadm2;
--
drop table cm_$tb ;
--
create table cm_$tb tablespace MSRMT_HIST_TBL nologging as select * from D1_$tb ;
commit;
--
exit
--
EOT
#
done
#
