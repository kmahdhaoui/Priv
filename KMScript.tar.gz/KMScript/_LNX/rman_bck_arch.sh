#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export ORACLE_SID=XSITRMDO
export RMANTAG=arch_$KMymdhms
#
rman target / <<EOT
# sql 'ALTER SYSTEM ARCHIVE LOG CURRENT';

backup archivelog ALL TAG ${RMANTAG} delete input;

backup current controlfile TAG ${RMANTAG};
exit
EOT
#

