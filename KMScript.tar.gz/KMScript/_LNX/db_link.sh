#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col DB_LINK format a22
col HOST  format a22
col OWNER format a22
col USERNAME format a22
set heading off
set lines 152
col DbLink format a151
prompt 
prompt =========================== DB LINKS ===========================
select decode(OWNER,'PUBLIC','',
'alter session set current_schema='||OWNER||';' ||chr(10)
             )||
'create '||decode(OWNER,'PUBLIC','PUBLIC','')||' DATABASE LINK '||DB_LINK||' connect to '||USERNAME||' IDENTIFIED BY ' ||USERNAME|| ' USING '''||HOST||''';' DbLink
from dba_db_links ;
--
-- ;
exit
EOT
#
. $KMscript/KMlogout.sh
#

