#!/bin/bash
# Author : Kamel Mahdhaoui
#
#
if [ "$1" != "" ] 
then
   export d_heure=$1
else
   echo "Usage is : $0 <heure_debut> <heure_fin>"
   exit 1
fi
#
if [ "$2" != "" ]
then
   export f_heure=$2
else
   echo "Usage is : $0 <heure_debut> <heure_fin>"
   exit 2
fi
##
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export KMymd=`date "+%Y%m%d"`
#
# export Ftmp=/tmp/tmp_event_trends.$KMymdhms.tmp
# rm -f $Ftmp
#
# date
#
sqlplus -s "$conn"  <<EOT
--
set lines 132
set pages 44
--
set time off timi off echo off verify off feedback off 
set heading on
set pagesize 555
--
select * from (
select
SQL_ID,
 sum(CPU_TIME_DELTA),
sum(DISK_READS_DELTA),
count(*)
from
DBA_HIST_SQLSTAT a, dba_hist_snapshot s
where
s.snap_id = a.snap_id
and s.begin_interval_time > trunc(sysdate)
and EXTRACT(HOUR FROM S.END_INTERVAL_TIME) between $d_heure  and $f_heure
group by
SQL_ID
order by
sum(CPU_TIME_DELTA) desc
)
where rownum < 6
/
--
exit
EOT
#
#######################################
#
date
#
#
