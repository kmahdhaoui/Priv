#!/bin/bash
#
. /sitr/exploit/dba/SITR_env.sh
#
export ORACLE_SID=XSITRMDO
export ORAENV_ASK=NO
. oraenv 1>/dev/null
export ORAENV_ASK=YES
export PATH=$ORACLE_HOME/bin:$PATH
#
#
#
sqlplus -s / as sysdba <<EOT
--
set feedback off
set verify off
set lines 132
set pages 132
alter session set nls_date_format='yyyy-mm-dd hh24:mi:ss' ;
--
set heading on
prompt Estimation D1_MSRMT
prompt =====================================================
select dd1 date1,dd2 date2,cnt comptage_msrmt,round(cnt_diff * 1 / (dd1-dd2) /1000/1000, 0) Debit_jour_millions from
( SELECT
       ddeb dd1,
       LAG(ddeb, 1, ddeb) OVER (ORDER BY cnt) AS dd2,
       cnt,
       LAG(cnt, 1, 0) OVER (ORDER BY cnt) AS cnt_prev,
       cnt - LAG(cnt, 1, 0) OVER (ORDER BY cnt) AS cnt_diff
FROM   mdo_estimation_kk
) where cnt_prev > 0 and cnt_diff is not null  and dd1 is not null and dd1 > sysdate -31
;
prompt
prompt Estimation IMD Total/Recieved
prompt =====================================================
select * from mdo_recieved_kk where MIN_DT > sysdate -31 order by REQ_SQL,MIN_DT ;
prompt
prompt Comptage IMD par heure et statut
prompt =====================================================
select * from mdo_statut_kk where to_date(substr(heure,1,10),'yyyy-mm-dd') > sysdate -31 order by heure,BO_STATUS_CD;
--
exit
EOT
#
