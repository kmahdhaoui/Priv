#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col sess format a33
SELECT DECODE(request,0,'Holder: ','Waiter: ')||ss.sid||','||ss.serial# sess, ll.id1, ll.id2, ll.lmode, ll.request, ll.type
FROM V\$LOCK ll, v\$session ss
WHERE ss.sid=ll.sid
and (ll.id1, ll.id2, ll.type) IN (
  SELECT ll2.id1, ll2.id2, ll2.type
  FROM V\$LOCK ll2
  WHERE ll2.request>0)
ORDER BY ll.id1, ll.request;
--
-- SELECT count(*) retvalue FROM V\$LOCK WHERE (id1, id2, type) IN
--                     ( SELECT id1, id2, type FROM V\$LOCK WHERE request>0)
-- ;
exit
EOT
#
if [ "$1" == "TX" ]
then
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col sess format a33
--
prompt ======================== SQL ==================================
select sid, sql_text from v\$session s, v\$sql q where sid in 
(select sid from v\$session where state in ('WAITING') and wait_class != 'Idle' 
and event='enq: TX - row lock contention' and (q.sql_id = s.sql_id or q.sql_id = s.prev_sql_id))
;
-- select sid, sql_text from v$session s, v$sql q 
-- where sid in (select sid from v$session where state in ('WAITING') and
--        wait_class != 'Idle' and event='enq: TX - row lock contention' and 
--       (q.sql_id = s.sql_id or q.sql_id = s.prev_sql_id));
--
prompt ======================== Blocking =============================
select blocking_session, sid, serial#, wait_class, seconds_in_wait from v\$session 
where blocking_session is not NULL order by blocking_session
;
--
exit
EOT
fi
#
. $KMscript/KMlogout.sh
#
