#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col tablespace_name format a40
col allocated_mb format 999999999
col allocated_mb format free_mb
col allocated_mb format recycle_mb
col tablespace_name format a40
select a.tablespace_name,allocated_mb, free_mb, recycle_mb
from
( select tablespace_name, nvl(sum(bytes)/1024/1024,0) free_mb from dba_free_space
  group by tablespace_name ) a,
( select tablespace_name,sum(bytes)/1024/1024 allocated_mb from dba_data_files
    group by tablespace_name ) b,
( select ts_name tablespace_name, nvl(sum(space)*8/1024,0) recycle_mb from dba_recyclebin
group by ts_name ) c
where a.tablespace_name=b.tablespace_name and
a.tablespace_name=c.tablespace_name 
/
exit
EOT
#
. $KMscript/KMlogout.sh
#
