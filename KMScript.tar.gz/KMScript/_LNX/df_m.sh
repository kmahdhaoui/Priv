#!/usr/bin/ksh
# Author : Kamel Mahdhaoui
#
# set -x
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
if [ "$KSHOUTPUT" == "HTML" ]
then
   /usr/bin/ksh $KMscript/asm_disk.sh -html
   echo "<table border='1' width='90%' align='center' summary='Script output'>"
   echo "<tr><td>Volume</td><td>Blocs MB</td><td>Free</td><td>%Used</td><td>Iused</td><td>%Iused</td><td>Mounted on</tr>"
   df -Pm | grep -v Available |grep -v Disponible |while read LINE
   do
      echo $LINE |awk -F" " '{print "<tr><td>"$1"</td><td>"$2"</td><td>"$3"</td><td>"$4"</td><td>"$5"</td><td>"$6"</td><td>"$7"</tr>" }'
   done
   echo "</TABLE>"
else
   echo "------------------------------------------------------------------------------------------------"
   /usr/bin/ksh $KMscript/asm_disk.sh 
   echo "------------------------------------------------------------------------------------------------"
   df -Pm
   echo "------------------------------------------------------------------------------------------------"
   if [ "$1" == "" ]
   then 
      export leseuil=80
   else
      export leseuil=$1
   fi
   df -Pm |grep -v "/proc"|grep -v "/boot"| grep -v Available |grep -v Disponible |while read LINE
   do
      typeset  -i lepct
      export lepct=`echo $LINE | tr -s "  " " "|cut -d" " -f5| tr % 0`
      if [ $? != 0 ]
      then 
         export lepct=0
      fi
      #
      if [ $lepct -gt ${leseuil}0 ]
      then 
         echo "check ?%0 $lepct > ${leseuil}0 : $LINE"
      fi
   done
   echo "------------------------------------------------------------------------------------------------"
fi
#
. $KMscript/KMlogout.sh
#
