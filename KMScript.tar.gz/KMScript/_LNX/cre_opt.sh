sqlplus '/ as sysdba' <<EOT
set timi on time on echo on
connect ecomreportoa/ecomreportoa
CREATE MATERIALIZED VIEW ecom_option NOLOGGING PARALLEL storage(initial 100m next 100m pctincrease 0) REFRESH FORCE AS SELECT * FROM ecom_option@ecom_link_b;
!date
CREATE INDEX IDX_ECOM_OPTION_CODE ON ECOM_OPTION (CODE) nologging parallel TABLESPACE REPORTSXAA;
!date
CREATE INDEX IDX_ECOM_OPTION_MP ON ECOM_OPTION (MOBILEPLAN_OPTION_ID) nologging parallel TABLESPACE REPORTSXAA;
!date
CREATE INDEX IDX_ECOM_OPTION_MPBENEFID ON ECOM_OPTION (MOBILEPLAN_BENEFIT_ID) nologging parallel TABLESPACE REPORTSXAA;
!date
CREATE INDEX IDX_ECOM_OPTION_PAYMENTID ON ECOM_OPTION (PAYMENT_ID) nologging parallel TABLESPACE REPORTSXAA;
!date

@refresh_ecom_option.sql

exit ;
EOT
date



