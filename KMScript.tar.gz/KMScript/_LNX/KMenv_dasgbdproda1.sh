#!/bin/ksh
export KMlogin_dw=oracle #default
export KMsite=arceuil
#
export Liste_dbsingle="dxqt0spa dxdf0arp dxsr1syr dxuq0spi dxab2grh dxfw0sta dxuj0pil dxuj0sec dxoe1eai dxoc1eai dxhe0pre dxvl1gad dxso1not dxwm0opt dxhr0ath dxsu1mon dxsu1des dxqx1inf dvqx1inf dxun0crp dxaf3inf dxhs0sec dxwm2eai dxqr0 dvmc0gpo dxrc2fer dxwn3ele dxsa0ea2 dxwm2ea2 dxsu1eng dxwm5eai dxco3cor dxhy0opl dxae2bdp dxrk0cor dxrk0bis dxrk0his dxdi3rdi dxaf4bop dxbo3ccd dxhr0arc dxhs0tmp dxqx1rec dxsu5suf dxud0 dxmp0 dxwq0rh dxrc2ea2 "
#
export Liste_host_dw=""
export Liste_host_info=$Liste_host_dw
alias dasgbdprodd1='ssh -X ${KMlogin_dw}@dasgbdprodd1'
#
for singleSID in $Liste_dbsingle
do
   export instSID=$singleSID
   export racSID=$singleSID
   export mininstSID=`echo $instSID|tr "ABCDEFGHIJKLMNOPQRSTUVWXYZ" "abcdefghijklmnopqrstuvwxyz"`
   export majinstSID=`echo $instSID|tr "abcdefghijklmnopqrstuvwxyz" "ABCDEFGHIJKLMNOPQRSTUVWXYZ"`
   # alias $instSID="export ORACLE_SID=$instSID ; export ORAENV_ASK=NO; . oraenv; export ORAENV_ASK=YES; b"
   # alias $mininstSID="export ORACLE_SID=$instSID ; export ORAENV_ASK=NO; . oraenv; export ORAENV_ASK=YES; b"
   # alias $majinstSID="export ORACLE_SID=$instSID ; export ORAENV_ASK=NO; . oraenv; export ORAENV_ASK=YES; b"
   # alias log$instSID='tail -42 $ORACLE_BASE/admin/$mininstSID/bdump/alert_$instSID.log'
   # alias log$mininstSID='tail -42 $ORACLE_BASE/admin/$mininstSID/bdump/alert_$instSID.log'
   # alias log$majinstSID='tail -42 $ORACLE_BASE/admin/$mininstSID/bdump/alert_$instSID.log'
done
#
#export ORACLE_SID=dxyr1cat ; export ORAENV_ASK=NO; . oraenv; export ORAENV_ASK=YES; b
# export ORACLE_SID=dxyr1cat ; 
ora $ORACLE_SID; cd - 
export PATH=$PATH:$KMscript:$ORACLE_HOME/OPatch
b
#
