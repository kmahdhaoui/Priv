#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
set feedback off
set lines 133
col value format a80
select name,value from v\$parameter where
name in (
'log_archive_dest_state_2',
'log_archive_dest_state_3',
'log_archive_dest_2',
'log_archive_dest_3',
'db_unique_name',
'background_dump_dest',
'local_listener',
'remote_listener',
'log_archive_config',
'log_archive_local_first',
'standby_file_management',
'service_names',
'job_queue_Processes',
'aq_tm_processes'
);
--
SELECT DATABASE_ROLE, DB_UNIQUE_NAME , FLASHBACK_ON, OPEN_MODE, force_logging, -
       PROTECTION_MODE, PROTECTION_LEVEL, SWITCHOVER_STATUS -
       FROM V\$DATABASE
;
--
set feedback off
select INST_NUMBER ,substr(INST_NAME,1,30) INST_NAME from V\$ACTIVE_INSTANCES
;
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
