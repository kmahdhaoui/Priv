#!/bin/bash
# Author : Kamel Mahdhaoui
#
#
if [ "$1" == "" ] 
then
   export NBJOURS=2
else
   export NBJOURS=$1
fi
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export KMymd=`date "+%Y%m%d"`
#
#
sqlplus -s "$conn"  <<EOT
--
set time off timi off echo off verify off feedback off 
set heading on 
set pagesize 50000
set feedback off
--
col BEGIN_INTERVAL_TIME format a33
col END_INTERVAL_TIME format a33
--
select snap_id,begin_interval_time,end_interval_time,EXTRACT(HOUR FROM begin_interval_time) heure
from dba_hist_snapshot
where begin_interval_time > trunc(sysdate) + 1 - $NBJOURS
order by 1
/
--
exit
EOT
#
#######################################
#
date
#
#
