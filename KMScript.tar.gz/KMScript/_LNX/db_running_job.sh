#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
alter session set nls_date_format='yyyy-mm-dd hh24:mi:ss';
--
col LOG_USER format a14
col PRIV_USER format a14
col SCHEMA_USER format a12
col job format 9999
col "Intervalle" format  a30
col "Dernier" format a20
col "Prochain" format a20
col "Dernier refresh" format a20
col "Prochain refresh" format a20
col "Refresh what" format a70
col "what" format a60
--
prompt DBA_SCEDULER_JOBS 
prompt *****************
SELECT job_name, enabled FROM dba_scheduler_jobs
;
--
prompt DBA_JOBS 
prompt ********
SELECT job, SCHEMA_USER,
TO_CHAR(last_date, 'yyyy-mm-dd HH24:MI') "Dernier refresh",
TO_CHAR(next_date, 'yyyy-mm-dd HH24:MI') "Prochain refresh",
interval "Intervalle"
FROM dba_jobs
order by SCHEMA_USER,job
;
--
prompt DBA_JOBS order by WHAT
prompt **********************
select job,
what "Refresh what",
last_date "Dernier refresh",
next_date "Prochain refresh",
BROKEN 
from dba_jobs
order by what
;
--
prompt Running JOBS
prompt ************
select
  djr.sid                        ,
  djr.job                        ,
  -- dj.log_user                    ,
  -- dj.priv_user                   ,
  dj.what                        ,
  TO_CHAR(dj.last_date, 'yyyy-mm-dd HH24:MI') "Dernier",
  TO_CHAR(dj.next_date, 'yyyy-mm-dd HH24:MI') "Prochain",
  djr.failures                   
from sys.dba_jobs dj, sys.dba_jobs_running djr
where djr.job = dj.job
;
prompt Running Sid JOBS LOCK
prompt *********************
SELECT SID, TYPE, ID1, ID2
   FROM V\$LOCK
   WHERE TYPE = 'JQ'; 

prompt Running Sid,spid,serial JOBS
prompt ****************************
select j.sid, s.spid, s.serial#, j.log_user, j.job, j.broken, j.failures, j.what
from (select djr.SID,
dj.LOG_USER, dj.JOB, dj.BROKEN, dj.FAILURES,
dj.LAST_DATE, dj.LAST_SEC, dj.THIS_DATE, dj.THIS_SEC,
dj.NEXT_DATE, dj.NEXT_SEC, dj.INTERVAL, dj.WHAT
from dba_jobs dj, dba_jobs_running djr
where dj.job = djr.job ) j,
(select p.spid, s.sid, s.serial#
from v\$process p, v\$session s
where p.addr = s.paddr ) s
where j.sid = s.sid;
-- EXEC DBMS_JOB.BROKEN(job#,TRUE);
-- ALTER SYSTEM KILL SESSION 'sid,serial#';
--
prompt dba_scheduler_running_jobs !!!
select * from dba_scheduler_running_jobs;
--
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
