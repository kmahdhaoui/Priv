#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
if [ "$1" == "" ]
then
   echo "Sql ID ... ?"
   read TexteRecherche
else
   export lesqlid=$1
fi
#
export lesqlid
#
if [ "$lesqlid" == "" ]
then
   echo "Fin ..."
   exit
fi
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
set pages 132
set lines 132
col TEXT format a88
col SQL_ID format a22
--
SELECT sql_id, hash_value, SUBSTR(sql_text,1,40) Text
FROM v\$sql
WHERE sql_id = '$lesqlid'
--
start sqlhc.sql N $lesqlid
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
