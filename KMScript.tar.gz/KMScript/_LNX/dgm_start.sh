#!/usr/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
if [ "$KSHOUTPUT" == "HTML" ]
then
   echo "<table border='1' width='90%' align='center' summary='Script output'>"
   echo "<PLAINTEXT>"
fi
##################
#
# get database name in config dg
#
if [ "$1" == "" ] && [ "$ORACLE_SID" == ""  ]
then
   echo "Problem settez l'oracle_sid ou Usage : $0 <oracle_sid> ..."
   exit 101
fi
if [ "$1" != ""  ]
then
   export ORACLE_SID=$1
fi
#
export ORAENV_ASK=NO
. oraenv
export ORAENV_ASK=YES
sqlplus -s '/ as sysdba' <<EOT
startup mount
exit
EOT
#
b
#
export labase=""
export Liste_dgm=""
export mydbrole=`/usr/bin/ksh $KMscript/db_role.sh $ORACLE_SID`
case $mydbrole  in
    PRIMARY*) export Liste_dgm="$Liste_dgm" ;;
    PSTDBY*)  export Liste_dgm="$Liste_dgm $ORACLE_SID" ;;
    *)        export Liste_dgm="$Liste_dgm" ;;
esac
#
export mydb=""
for mydb in $Liste_dgm
do
echo "-----------------------------------------------"
#
# Instance 'FRONTRES' of database 'frontres'
export labase=`sh $KMscript/dgm_instance.sh|grep "^Instance" |cut -d" " -f5`
dgmgrl -silent sys/f6tem <<EOT
edit database $labase set state='LOG-APPLY-OFF';
edit database $labase set state='ONLINE';
EOT
#
sh $KMscript/dgm_config.sh
#
dgmgrl -silent sys/f6tem <<EOT
SHOW DATABASE verbose $labase ;
EOT
echo "-----------------------------------------------"
done
#
if [ "$KSHOUTPUT" == "HTML" ]
then
   echo " "
fi
#
. $KMscript/KMlogout.sh
#
