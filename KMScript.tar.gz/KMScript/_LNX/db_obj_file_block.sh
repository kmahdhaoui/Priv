#!/bin/bash
# Author : Kamel Mahdhaoui
#
#
if [ "$2" == "" ]
then
    echo "Usage is : $0 <file_id> <Block_id>"
    exit 1
fi
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
SET PAUSE off
SET PAGESIZE 132
SET LINESIZE 132
 
COLUMN segment_name FORMAT A30
COLUMN segment_type FORMAT A20

prompt ============================ OBJECT ========================
select * from dba_objects where 
(owner,object_name,object_type,SUBOBJECT_NAME) in 
(
SELECT owner,segment_name,segment_type,partition_name
   FROM   dba_extents
   WHERE
          file_id = $1
   AND
          ( $2 BETWEEN block_id AND ( block_id + blocks ) )
)
;
prompt ========================== SEGMENT =========================
SELECT 'alter '||segment_type||' '||owner||'.'||segment_name , PARTITION_NAME, block_id, blocks
   FROM   dba_extents
   WHERE
          file_id = $1
   AND
          ( $2 BETWEEN block_id AND ( block_id + blocks ) )
/
--
-- 
exit
EOT
#
. $KMscript/KMlogout.sh
#
