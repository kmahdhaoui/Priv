#!/bin/bash
#
echo sitr2014
read
#
cd 
bash kamel/KMscript/backup_KM.sh
#
ssh oracle@sefrapp00154 "bash kamel/KMscript/backup_KM.sh"
ssh oracle@sefrapp00148 "bash kamel/KMscript/backup_KM.sh"
ssh oracle@sefrapp00155 "bash kamel/KMscript/backup_KM.sh"
#
cd 
cd kamel
scp oracle@sefrapp00154:kamel/KMscript_*_*_20*.tar.gz .
scp oracle@sefrapp00148:kamel/KMscript_*_*_20*.tar.gz .
scp oracle@sefrapp00155:kamel/KMscript_*_*_20*.tar.gz .
#
