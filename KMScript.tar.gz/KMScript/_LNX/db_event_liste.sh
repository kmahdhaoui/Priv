#!/bin/bash
# Author : Kamel Mahdhaoui
#
#
if [ "$1" == "" ]
then
   export levent=%
else
   export levent=$1
fi
#
sqlplus -s "$conn" <<EOT
set feedback off heading off verify off
set lines 133
--
col name format a65
col wait_class format a16
SELECT wait_class, name FROM V\$EVENT_NAME where 
name like '$levent'
and
wait_class like '%' 
ORDER BY wait_class,name 
;
--
spool off
exit
EOT
#
#
