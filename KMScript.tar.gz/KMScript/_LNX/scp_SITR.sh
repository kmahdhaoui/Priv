#!/bin/bash
#
cd /sitr/exploit/dba
mkdir -p svg
#
if [ "$1" == "" ]
then
# export liste_leuserhost="oracle@10.34.32.172 oracle@sefrapp00154 oracle@sefrapp00153 oracle@sefrapp00148 oracle@sefrapp00155"
export liste_leuserhost="oracle@10.34.32.172 oracle@sefrapp00154 oracle@sefrapp00153"
else
export liste_leuserhost="oracle@$1"
fi
#
for leuserhost in $liste_leuserhost
do
rm -f /sitr/exploit/dba/psw
scp /sitr/exploit/dba/* $leuserhost:/sitr/exploit/dba/ 1>/dev/null 
#
done
#
echo weblogic123
#
scp /sitr/exploit/dba/kenv_cismw.sh /sitr/exploit/dba/ktar_weblogic_host.sh weblogic@sefrapp00148:/sitr/exploit/wls
scp /sitr/exploit/dba/kenv_cismw.sh /sitr/exploit/dba/ktar_weblogic_host.sh weblogic@sefrapp00155:/sitr/exploit/wls
