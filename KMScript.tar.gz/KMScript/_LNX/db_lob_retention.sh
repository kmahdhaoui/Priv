#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
#
if [ "$3" == "" ]
then
   echo "Usage is : $0 <owner> <tables|%> <tablespace|%> ..."
   exit 101
fi
#
export leowner=$1
export latable=$2
export letbs=$3
#
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
set lines 132
col COLUMN_NAME format a22
col owner format a15
col table_owner format a14
col index_owner format a14
col tabcol format a45
col OWNER format a12
col retention format a12
col pctversion format a12
col ret/pct format a12
col lob_tbs format a12
col tab_tbs format a12
--
prompt ======> dba_lobs 
prompt ======> $1 $2 $3 : rentention/pctversion 
select 
-- owner,
table_name ||'.'|| column_name tabcol,
-- segment_name,
-- index_name ,
retention||'/'|| pctversion "ret/pct" ,tablespace_name lobtbs
from dba_lobs where
tablespace_name like '$letbs' and owner like '$leowner'
and TABLE_NAME like '$latable'
and table_name not like 'BIN$%'
;
--
select 'alter table '||owner||'.'||table_name||' MODIFY LOB ('||COLUMN_NAME||') (retention) ;' from 
dba_lobs where tablespace_name like '$letbs' and owner like '$leowner'
and TABLE_NAME like '$latable'
and table_name not like 'BIN$%'
;
--
prompt ======> dba_lobs 
prompt ======> $1 $2 $3 : deduplication/securefile 
select 
-- OWNER,
TABLE_NAME||'.'||COLUMN_NAME tabcol,CACHE,COMPRESSION,DEDUPLICATION,SECUREFILE from dba_lobs
where OWNER='$leowner' and TABLE_NAME not like '%2014%' and TABLE_NAME not like '%CONSO%' and 
TABLE_NAME not like 'SYS%PORT_%' 
and TABLE_NAME not like '%DP_1%' and TABLE_NAME not like '%PLAN_TABLE%' 
and tablespace_name like '$letbs'
and TABLE_NAME like '$latable'
and table_name not like 'BIN$%'
;
--
-- parts
prompt ======> dba_lob_partitions 
prompt ======> $1 $2 $3 : rentention/pctversion 
select TABLE_OWNER,TABLE_NAME||'.'||COLUMN_NAME tabcol,
-- PARTITION_NAME,
-- LOB_NAME,
retention||'/'|| pctversion "ret/pct"
, count(*) NB
from dba_lob_partitions
where 
TABLE_OWNER like '$leowner' and
TABLE_OWNER not in 
      ('SYS','SYSTEM','OUTLN','QUEST','SYSMAN','MDSYS','OLAPSYS','XDB','ORACLE_OCM','DBSNMP',
       'APPQOSSYS','MDDATA','EXFSYS','CTXSYS','ORDSYS','ORDDATA','ORDPLUGINS','SPATIAL_WFS_ADMIN_USR',
       'SPATIAL_CSW_ADMIN_USR','MGMT_VIEW','PATROL','XS$NULL')
and table_name not in ('PLAN_TABLE','TOAD_PLAN_TABLE')
and tablespace_name like '$letbs'
and TABLE_NAME like '$latable'
and table_name not like 'BIN$%'
group by TABLE_OWNER,TABLE_NAME||'.'||COLUMN_NAME ,
-- PARTITION_NAME,
-- LOB_NAME,
retention||'/'|| pctversion
;
-- sub part
prompt ======> dba_lob_subpartitions 
prompt ======> $1 $2 $3 : rentention/pctversion 
select 
-- TABLE_OWNER,
TABLE_NAME||'.'||COLUMN_NAME tabcol,
-- PARTITION_NAME,
-- LOB_NAME,
retention||'/'|| pctversion "ret/pct"
, count(*) NB
from dba_lob_subpartitions
where
TABLE_OWNER like '$leowner' and
TABLE_OWNER not in
      ('SYS','SYSTEM','OUTLN','QUEST','SYSMAN','MDSYS','OLAPSYS','XDB','ORACLE_OCM','DBSNMP',
       'APPQOSSYS','MDDATA','EXFSYS','CTXSYS','ORDSYS','ORDDATA','ORDPLUGINS','SPATIAL_WFS_ADMIN_USR',
       'SPATIAL_CSW_ADMIN_USR','MGMT_VIEW','PATROL','XS$NULL')
and table_name not in ('PLAN_TABLE','TOAD_PLAN_TABLE')
and tablespace_name like '$letbs'
and TABLE_NAME like '$latable'
and table_name not like 'BIN$%'
group by TABLE_OWNER,TABLE_NAME||'.'||COLUMN_NAME ,
-- PARTITION_NAME,
-- LOB_NAME,
retention||'/'|| pctversion
;
--
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
