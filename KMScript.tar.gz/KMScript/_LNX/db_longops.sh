#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
set lines 150
COL NOW FORMAT A20
COL SID FORMAT 99999
COL SERIAL# FORMAT 99999
COL ELAPSED FORMAT A10
COL TIME_REMAINING FORMAT A15
COL CMPLT FORMAT 99.99
col ope format a72

-- Progression de la sauvegarde
SELECT 
OPNAME||' '||message Ope,
TO_CHAR (SYSDATE, 'DD/MM/YYYY HH24:MI:SS') NOW,
SID, 
to_char ((trunc (sysdate)) + (ELAPSED_SECONDS/86400), 'HH24:MI:SS') ELAPSED,
to_char ((trunc (sysdate)) + (TIME_REMAINING/86400), 'HH24:MI:SS') TIME_REMAINING,
ROUND(SOFAR/TOTALWORK*100,2) "CMPLT"
FROM V\$SESSION_LONGOPS
WHERE 
TOTALWORK != 0 AND SOFAR <> TOTALWORK;
exit
EOT
#
. $KMscript/KMlogout.sh
#
