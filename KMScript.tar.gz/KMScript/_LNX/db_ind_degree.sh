#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
if [ "$1" == "" ]
then
   echo "Usage : $0 <Owner> <table|%>"
   exit 1
fi
#
if [ "$2" == "" ]
then
   echo "$0 $1 %"
   export latable=%
else
   export latable=$2
fi
#
#
if [ "$3" == "" ]
then
   echo "$0 $1 % 2"
   export NUM=2
else
   export NUM=$3
fi
#
export leowner=$1
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col DEGREE format a5
set pages 0
set feedback off
!echo "-- ======================================== DEGREE ======================================="
select distinct 'alter index '||OWNER||'.'||INDEX_NAME||' parallel '|| DEGREE ||' ;' from dba_indexes 
where degree is not null and degree not like 'DEFAU%' and degree > 1
and tablespace_name like '%' and Owner like '$leowner' and table_name like '$latable';
--
-----------------------------------------------------------------------------------------------------------------------
--
!echo "--  =================================== NON PART INITRANS ==================================="
select distinct 'alter index '||i.OWNER||'.'||i.INDEX_NAME||' INITRANS '|| INI_TRANS ||' ;' from dba_indexes i 
where nvl(i.INI_TRANS,0) > $NUM and i.INDEX_TYPE not like '%LOB%'
and i.tablespace_name like '%' and i.Owner like '$leowner' and i.table_name like '$latable'
and (i.OWNER,i.INDEX_NAME) not in 
(select ii.OWNER,ii.INDEX_NAME from dba_part_indexes ii where ii.OWNER=i.OWNER and ii.INDEX_NAME=i.INDEX_NAME)
;

!echo "--  =================================== DEFAULT PART INITRANS ==================================="
select distinct 'alter index '||i.OWNER||'.'||i.INDEX_NAME||' MODIFY DEFAULT ATTRIBUTES INITRANS '|| 
INI_TRANS ||' ;' from dba_indexes i where nvl(i.INI_TRANS,0) > $NUM and i.INDEX_TYPE not like '%LOB%'
and i.tablespace_name like '%' and i.Owner like '$leowner' and i.table_name like '$latable'
and (i.OWNER,i.INDEX_NAME) in
(select ii.OWNER,ii.INDEX_NAME from dba_part_indexes ii where ii.OWNER=i.OWNER and ii.INDEX_NAME=i.INDEX_NAME)
;
select 'alter index '||p.INDEX_OWNER||'.'||p.INDEX_NAME ||
' modify DEFAULT ATTRIBUTES '||' INITRANS '|| max(p.INI_TRANS) ||' ;' from dba_ind_partitions p
where nvl(p.INI_TRANS,0) > $NUM and p.tablespace_name like '%' and 
(p.INDEX_OWNER,p.INDEX_NAME) in
( select ii.owner,ii.INDEX_NAME from dba_part_indexes ii
where ii.OWNER=p.INDEX_OWNER and ii.INDEX_NAME=p.INDEX_NAME  and ii.table_name like '$latable'
)
and (p.INDEX_OWNER,p.INDEX_NAME) in (select i.OWNER,i.INDEX_NAME from dba_indexes i 
where i.OWNER=p.INDEX_OWNER and i.INDEX_NAME=p.INDEX_NAME and i.INDEX_TYPE not like '%LOB%'
)
and p.tablespace_name like '%' and p.index_owner like '$leowner' and nvl(p.INI_TRANS,0) > $NUM
group by p.INDEX_OWNER,p.INDEX_NAME
;


!echo "--  =================================== PARTIT INITRANS ==================================="
select distinct 'alter index '||p.INDEX_OWNER||'.'||p.INDEX_NAME || 
' modify partition '||p.partition_name||' INITRANS '|| p.INI_TRANS ||' ;' from dba_ind_partitions p 
where nvl(p.INI_TRANS,0) > $NUM and p.tablespace_name like '%' and 
(p.INDEX_OWNER,p.INDEX_NAME) in 
( select ii.owner,ii.INDEX_NAME from dba_part_indexes ii 
where ii.OWNER=p.INDEX_OWNER and ii.INDEX_NAME=p.INDEX_NAME  and ii.table_name like '$latable' 
and nvl(ii.DEF_SUBPARTITION_COUNT,0) < 1 
)
and (p.INDEX_OWNER,p.INDEX_NAME) in (select i.OWNER,i.INDEX_NAME from dba_indexes i
where i.OWNER=p.INDEX_OWNER and i.INDEX_NAME=p.INDEX_NAME and i.INDEX_TYPE not like '%LOB%'
)
and p.tablespace_name like '%' and p.index_owner like '$leowner' and nvl(p.INI_TRANS,0) > $NUM
;

-- !echo "--  =================================== SUBPAR REBUILD INITRANS ==================================="
-- select distinct 'alter index '||p.INDEX_OWNER||'.'||p.INDEX_NAME ||
-- ' rebuild subpartition '||p.subpartition_name||' INITRANS '|| p.INI_TRANS ||' ;' from dba_ind_subpartitions p
-- where nvl(p.INI_TRANS,0) > $NUM and p.tablespace_name like '%' and 
-- (p.INDEX_OWNER,p.INDEX_NAME) in
-- ( select ii.owner,ii.INDEX_NAME from dba_part_indexes ii
-- where ii.OWNER=p.INDEX_OWNER and ii.INDEX_NAME=p.INDEX_NAME  and ii.table_name like '$latable'
-- and nvl(ii.DEF_SUBPARTITION_COUNT,0) > 0
-- )
-- and (p.INDEX_OWNER,p.INDEX_NAME) in (select i.OWNER,i.INDEX_NAME from dba_indexes i
-- where i.OWNER=p.INDEX_OWNER and i.INDEX_NAME=p.INDEX_NAME and i.INDEX_TYPE not like '%LOB%'
-- )
-- and p.tablespace_name like '%' and p.index_owner like '$leowner' and nvl(p.INI_TRANS,0) > $NUM
-- ;
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
