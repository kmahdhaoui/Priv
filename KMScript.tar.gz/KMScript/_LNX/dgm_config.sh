#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
#
if [ "$KSHOUTPUT" == "HTML" ]
then
   echo "<table border='1' width='90%' align='center' summary='Script output'>"
   echo "<PLAINTEXT>"
fi
##################
#
dgmgrl -silent sys/f6tem <<EOT
rem
show configuration;
rem
EOT
#
if [ "$KSHOUTPUT" == "HTML" ]
then
   echo " "
fi
#
. $KMscript/KMlogout.sh
#
