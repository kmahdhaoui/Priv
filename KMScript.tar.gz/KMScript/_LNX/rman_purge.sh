#
export ORACLE_SID=XSITRMDO
#
rman target / <<EOT
report need backup;
report obsolete;
crosscheck backup;
crosscheck copy;
crosscheck archivelog all;
ALLOCATE CHANNEL FOR MAINTENANCE DEVICE TYPE DISK ;
DELETE NOPROMPT OBSOLETE DEVICE TYPE DISK ;
crosscheck backup;
crosscheck copy;
crosscheck archivelog all;
delete noprompt obsolete;
delete noprompt expired backup;
delete noprompt expired copy;
delete noprompt expired archivelog all;
exit
EOT
#
#

