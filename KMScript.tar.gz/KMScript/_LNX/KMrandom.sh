#!/bin/ksh
#
if [ "$KMscript" == "" ] 
then
   echo "Problem \$KMscript ..."
   exit 101
fi
#
cd $KMscript
#
if [ ! $# -eq 1 ] && [ ! $# -eq 0 ]
then
   echo "Usage $0 <code:MAJ|MIN|ALPHA>"
   # echo "Error 1"
   exit 1
fi
#
case $1 in
MAJ)   < /dev/urandom tr -dc A-Z | head -c8
        ;;
MIN)   < /dev/urandom tr -dc a-z | head -c8
        ;;
ALPHA)  < /dev/urandom tr -dc A-Za-z0-9_ | head -c8
        ;;
*)      < /dev/urandom tr -dc A-Za-z0-9_ | head -c8
        ;;
esac
#
exit 0
#
