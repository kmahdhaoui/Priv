#
export argument=$1
if [ "$argument" == "" ]
then
echo " "
   echo "Item ? Exemple : checkactive ..."
   echo "ou : zabbix_agentd -t zora.running[]"
   read argument
fi
if [ "$argument" == "" ]
then
   echo "Pas d'Item ... Fin."
fi
#
echo " "
echo ".................................................."
echo "bash ..."
bash zabora $argument XXXX
echo ".................................................."
echo "agentd ..."
zabbix_agentd -c /usr/local/etc/zabbix_agentd.conf -t oracle[$argument]
echo ".................................................."
