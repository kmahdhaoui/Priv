#!/bin/bash
# kma
#
# set before $ORACLE_HOME
#
#
# shared
if [ "$1" == "" ]
then
   export to_flush="shared_pool buffer_cache"
else
   export to_flush="$1"
fi
#
# les variables pour le batch
. /usr/local/etc/oracle/kenv_batch.sh 
#
cd $BINDIR
#
rm -f ${WORKDIR}/kflush$$.tmp* 1>/dev/null 2>&1
#
export SQLTMP=${WORKDIR}/kflush$$.tmp
#
##########################
# La liste c'est les bases qui tournent
cat <<EOF |sort -u | grep -v '^$'| while read leSID ; do
$(ps -ef |grep smon|grep -v grep|grep -v '+ASM'|awk -F_ '{print $3}'|sed 's/ //g')
EOF
#
# les variables pour le batch
export ORACLE_SID=$leSID
. /usr/local/etc/oracle/kenv_batch.sh $leSID
. $BINDIR/kenv_nls.sh
#
for ff in $to_flush
do
sqlplus -s '/ as sysdba' 2>/dev/null <<EOT
set echo off heading off feedback off verify off
--
whenever sqlerror exit 1; 
whenever oserror exit 2; 
--
spool $SQLTMP.$leSID.2
--
prompt "------------- $ORACLE_SID -----------------------"
--
prompt flush $ff ... 
--
alter system flush $ff ;
--
prompt "-------------------------------------------------"
--
exit 0
EOT
#
done
#
##############
done
##########################
#
rm -f ${WORKDIR}/kflush$$.tmp* 1>/dev/null 2>&1
#
