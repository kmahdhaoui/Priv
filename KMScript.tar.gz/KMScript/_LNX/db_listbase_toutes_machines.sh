#!/bin/ksh
# Author : Kamel Mahdhaoui
# 
# db_listbase_toutes_machines.sh |tee -a work/listbase_toutes_machines_rim.txt 
# 
. ~oracle/.profile 1>/dev/null 2>&1
export ORACLE_SID=lastbase
. ~oracle/scripts/kamel/kamel.profile silent 1>/dev/null 2>&1
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh 1>/dev/null 1>/dev/null 2>&1
#
# met a jour : ListeHostsTout_2 
. $KMscript/KMenv_ListesHosts.sh
#
echo "host;" "sid;" "log mode;" "env;" "code appli;" "fs appli;" "port lsnr;" "version;" "Edition;" "bundle PSU;" "spfile;" "compatible;" "nbr dbf;" "taille go;" "rman ctrl time;" "rman compress;" "parallelisme rman;" "rman tdpo;" "up time;" "demarrage;" "statut;" "intervention;"
#
for MACHINE_EXE in $ListeHostsTout_2
do
   ssh $MACHINE_EXE "~oracle/scripts/kamel/db_listbase.sh"	
done 
#
. $KMscript/KMlogout.sh 1>/dev/null 2>&1
#

