#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--

column status format a10
set feedback off
set serveroutput on

column username format a20
column sql_text format a55 word_wrapped

set serveroutput on size 1000000

SELECT  C.SQL_TEXT,
        B.NAME,
        COUNT(*),
        SUM(TIME_WAITED) TIME_WAITED
FROM    v\$ACTIVE_SESSION_HISTORY A,
        v\$EVENT_NAME B,
        v\$SQLAREA C
WHERE   A.SAMPLE_TIME BETWEEN (systimestamp - 2* 1/24 ) and systimestamp AND
        A.EVENT# = B.EVENT# AND
        A.SESSION_ID= $1 AND
        A.SQL_ID = C.SQL_ID
GROUP BY C.SQL_TEXT, B.NAME
order by 4 desc 
;
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
