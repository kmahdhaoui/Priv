#!/bin/bash
# Author : Kamel Mahdhaoui
#
#
#
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export KMymd=`date "+%Y%m%d"`
#
# export Ftmp=/tmp/tmp_event_trends.$KMymdhms.tmp
# rm -f $Ftmp
#
# date
#
sqlplus -s "$conn"  <<EOT
--
set lines 132
set pages 44
--
set time off timi off echo off verify off feedback off 
set heading on
set pagesize 555
--
col username format a26
col sid format 9999
col state format a18
col event format a40
col wait_time format 99999999
--
select segment_name,object_type,total_physical_reads
 from ( select owner||'.'||object_name as segment_name,object_type,
value as total_physical_reads
from v\$segment_statistics
 where statistic_name in ('physical reads')
 order by total_physical_reads desc)
where rownum < 11
/
--
exit
EOT
#
#######################################
#
date
#
#
