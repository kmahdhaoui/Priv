chgrp -R oinstall *
chmod -R g+r *

chmod +rx b ll ltr 
chmod +rx asm_disk.sh
chmod +rx chmod.sh
chmod +rx db_dgmessage.sh
chmod +rx db_files.sh
chmod +rx db_incarnation.sh
chmod +rx db_role.sh
chmod +rx db_sess.sh
chmod +rx db_space.sh
chmod +rx db_status.sh
chmod +rx db_thread.sh
chmod +rx df_m.sh
chmod +rx KMenv_arlequin.sh
chmod +rx KMenv_commun.sh
chmod +rx KMenv_pdb1.sh
chmod +rx KMenv_pdb2.sh
chmod +rx KMenv_pdba1.sh
chmod +rx KMenv_pdba2.sh
chmod +rx KMenv_prebond.sh
chmod +rx KMenv.sh
chmod +rx KMenv_vrebond.sh
chmod +rx KMlogin.sh
chmod +rx KMlogout.sh
chmod +rx prd_dest2status.sh
chmod +rx sec_managed_stdby.sh
chmod +rx dgm_config.sh
chmod +rx dgm_status.sh
