#! /bin/bash
# Author : Kamel Mahdhaoui
# Unautorized use is forbidden 
HELP=0; VERBOSE=0
FAILED=0; INSTANCEDOWN=0 
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
if [ "$KSHOUTPUT" == "HTML" ]
then
   echo "<table border='1' width='90%' align='center' summary='Script output'>"
   echo "<TR>"
fi
##################
for INSTANCE in $ORACLE_SID
do
        export INSTANCEDOWN=0
        if [ ${VERBOSE} -eq "1" ] ; then
	   echo -n "Checking instance ${INSTANCE}..." 
        fi
	for PROCESS in pmon smon 
	do
	  RC=$(ps -ef | egrep ${INSTANCE} | egrep -v 'grep' | egrep ${PROCESS}) 
	  if [ "${RC}" = "" ] ; then
	    INSTANCEDOWN=1 
            if [ ${VERBOSE} -eq "1" ] ; then
	       echo "\tERROR: Instance ${INSTANCE} ${PROCESS} down!" 
            fi
	  fi 
	done
        if [ ${INSTANCEDOWN} = "1" ] ; then
	   echo "`date` - Instance ${INSTANCE} est DOWN!!!" 
	   FAILED=1
	else 
	   echo "`date` - Instance ${INSTANCE} est montee." 
	fi	
done
#
if [ "$KSHOUTPUT" == "HTML" ]
then
   echo "</TR>"
   echo "</TABLE>"
fi
#
. $KMscript/KMlogout.sh
#
if [ ${FAILED} = "1" ] ; then
  exit -1
else
  exit 0
fi
