#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
column status format a10
set feedback off
set serveroutput on

column username format a20
column sql_text format a55 word_wrapped
--
select ll.request,ss.sql_id,tt.sql_text from v\$session ss,v\$sqlarea tt,V\$LOCK ll
where ss.sql_id=tt.sql_id and ss.sid=ll.sid and
ll.request = 0 and exists ( SELECT ll2.id1, ll2.id2, ll2.type FROM V\$LOCK ll2 WHERE 
ll.id1=ll2.id1 and ll.id2=ll2.id2 and ll.type=ll2.type and ll2.request=6) 
union all
select ll.request,ss.sql_id,tt.sql_text from v\$session ss,v\$sqlarea tt,V\$LOCK ll
where ss.sql_id=tt.sql_id and ss.sid=ll.sid and
ll.request = 6 and exists ( SELECT ll2.id1, ll2.id2, ll2.type FROM V\$LOCK ll2 WHERE
ll.id1=ll2.id1 and ll.id2=ll2.id2 and ll.type=ll2.type and ll2.request=0)
/
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
