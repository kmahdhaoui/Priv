#!/bin/bash
# Author : Kamel Mahdhaoui
#
# part : D1_INIT_MSRMT_DATA_CHAR D1_INIT_MSRMT_DATA_K D1_INIT_MSRMT_DATA_LOG_PARM D1_INIT_MSRMT_DATA_LOG
# part date : D1_INIT_MSRMT_DATA
# part date : D1_MSRMT_CHAR D1_MSRMT_LOG_PARM D1_MSRMT_LOG D1_MSRMT
#
#============================================
if [ "$1" == "" ]
then
   if [ "$ORACLE_SID" == "" ]
   then
      export ORACLE_SID=XSITRMDO
   fi
else
    export ORACLE_SID=$1
fi
export ORAENV_ASK=NO
. oraenv 1>/dev/null
export ORAENV_ASK=YES
#
export PATH=$ORACLE_HOME/bin:$PATH
#============================================
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export KMymd=`date "+%Y%m%d"`
#
export leowner=CISADM
export Ftmp=/tmp/tmp_gathstatautre$leowner.$KMymdhms.tmp
rm -f $Ftmp
#
date
#
export leowner=CISADM
#
sqlplus -s '/ as sysdba' <<EOT
set feedback off heading off verify off
set lines 133
spool $Ftmp
select table_name from dba_tables where owner='CISADM'
and table_name not in ('D1_MSRMT_CHAR','D1_MSRMT_LOG_PARM','D1_MSRMT_LOG','D1_MSRMT')
and table_name not in ('D1_INIT_MSRMT_DATA')
and table_name not in ('D1_INIT_MSRMT_DATA_K')
and table_name not like 'SYS_IMPORT%'
and table_name not like 'Q%CONSO%'
and table_name not like 'HORS%Q%CONSO%'
and table_name not like 'ID_DOUBLONS%'
and table_name not like '%KAMEL%'
and table_name not like 'KK%'
and table_name not like 'TMP%'
and table_name not like 'PLAN_TABLE%'
and table_name not like 'TOAD%'
and table_name not like 'TEST%'
and table_name not like 'ALIK%'
and table_name not like 'SYS%PORT%'
;
spool off
exit
EOT
#
#######################################
#
for latable in `cat $Ftmp`
do
sqlplus -s '/ as sysdba' <<EOT
set feedback off
set lines 133
col value format a80
set time on timi on echo on verify on feedback on heading on 
--
col OWNER format a10
col TABLE_NAME format a30
col INCREMENTAL format a10
col GRANULARITY format a10
col STALE_PERCENT format A6
col ESTIMATE_PERCENT format a30
col CASCADEA format a10
col METHOD_OPT format a20
--
-- exec dbms_stats.gather_table_stats(ownname=>'$leowner',tabname=>'$latable',estimate_percent=>dbms_stats.auto_sample_size,method_opt=>'for all indexed columns',cascade=>true,degree=>42);
--
-- DBMS_STATS.GATHER_TABLE_STATS(OWNNAME=>'CISADM', TABNAME=>X.TABLE_NAME,  ESTIMATE_PERCENT=>100, DEGREE=>8, GRANULARITY=>'APPROX_GLOBAL AND PARTITION', CASCADE => TRUE);
--
SELECT owner, table_name,
  DBMS_STATS.get_prefs(ownname=>USER,tabname=>table_name,pname=>'INCREMENTAL') incremental,
  DBMS_STATS.get_prefs(ownname=>USER,tabname=>table_name,pname=>'GRANULARITY') granularity,
  DBMS_STATS.get_prefs(ownname=>USER,tabname=>table_name,pname=>'STALE_PERCENT') stale_percent,
  DBMS_STATS.get_prefs(ownname=>USER,tabname=>table_name,pname=>'ESTIMATE_PERCENT') estimate_percent,
  DBMS_STATS.get_prefs(ownname=>USER,tabname=>table_name,pname=>'CASCADE') cascadea,
  DBMS_STATS.get_prefs(pname=>'METHOD_OPT') method_opt
FROM dba_tables where owner='$leowner' and table_name like '$latable'
ORDER BY owner, table_name
;
--
exec dbms_stats.gather_table_stats(ownname=>'$leowner',tabname=>'$latable',ESTIMATE_PERCENT=>100,GRANULARITY=>'APPROX_GLOBAL AND PARTITION', cascade=>true,degree=>42);
--
exit
EOT
#
done
#
#######################################
#
date
#
rm -f $Ftmp 1>/dev/null 2>&1
#
