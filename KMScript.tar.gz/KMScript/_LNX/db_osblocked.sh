mkdir -p tmp/strace
cd tmp/strace
ps axuwf | grep " D" |wc -l
for i in `ps axuwf | grep " D" | awk '{ print $2 }'`
do 
strace -p $i > D-$i.strace 
echo $i
break 
done
