#!/bin/bash
# kma
#
# set before $ORACLE_HOME
#
#
# la base
if [ "$1" == "" ]
then
   echo "Usage is : $0 <Base>"
  exit 101
else
   export leSID=$1
fi
#
# les variables pour le batch
export ORACLE_SID=$leSID
. /usr/local/etc/oracle/kenv_batch.sh $leSID
. $BINDIR/kenv_nls.sh 
#
rm -f ${WORKDIR}/kcopy_pfile_base_$$.tmp* 1>/dev/null 2>&1
export SQLTMP=${WORKDIR}/kcopy_pfile_base_$$.tmp
#
export a_error_svg=0
#
export myrep=$BACKUP_SITR_RMAN
mkdir -p $myrep
#
if [ -x $myrep ]
then
# 
# %d : db name, %s : set num, %p : piece in set
export BACKUP_LEVEL=0
export BACKUP_TYPE=FULL # full ou incr
ARCTAG=${ORACLE_SID}_ARC_1_${KMymdhms}
DTBTAG=${ORACLE_SID}_DTB_${BACKUP_LEVEL}_${KMymdhms}
CTLTAG=${ORACLE_SID}_CTL_${BACKUP_LEVEL}_${KMymdhms}
SPFTAG=${ORACLE_SID}_SPF_${BACKUP_LEVEL}_${KMymdhms}
ARCSET=${ARCTAG}_s%s_p%p
DTBSET=${DTBTAG}_s%s_p%p
CTLSET=${CTLTAG}_s%s_p%p
SPFSET=${SPFTAG}_s%s_p%p
export LOGFILE=kcopy_pfile_base_${ORACLE_SID}_$KMymdhms.log
export CONFILE=kcopy_pfile_base_${ORACLE_SID}_$KMymdhms.cfg
echo $LOGDIR/$LOGFILE
#
##################################################################
#
#
cd /
tar -cvf $myrep/oracle_etc_${ORACLE_SID}.tar ./usr/local/etc/oracle
cd -
#
export DATE=$(date "+%d/%m/%Y %H:%M:%S")
#
pfile1=${myrep}/mem_pfile_$ORACLE_SID.ora
pfile2=${myrep}/spf_pfile_$ORACLE_SID.ora
#
mkdir -p /sitr/admin/$ORACLE_SID/scripts
pfile3=/sitr/admin/$ORACLE_SID/scripts/ini_pfile_$ORACLE_SID.ora
#
ctrlf1=${myrep}/ctrl_$ORACLE_SID.ctl
ctrlf2=/sitr/admin/$ORACLE_SID/scripts/ctrl_$ORACLE_SID.ctl
#
cronf1=${myrep}/crontab_$ORACLE_SID.cron
cronf2=/sitr/admin/$ORACLE_SID/scripts/crontab_$ORACLE_SID.cron
#
rmanf1=${myrep}/rman_$ORACLE_SID.cfg.run
rmanf2=/sitr/admin/$ORACLE_SID/scripts/rman_$ORACLE_SID.cfg.run
#
############################
#
rman target / 1>$rmanf1 2>&1 <<EOT
show all;
exit
EOT
#
cp -f $rmanf1 $rmanf2
#
############################
#
crontab -l > $cronf1
#
cp -f $cronf1 $cronf2
#
############################
#
rm -f $pfile1 1>/dev/null 2>&1
rm -f $pfile2 1>/dev/null 2>&1
rm -f $ctrlf1 1>/dev/null 2>&1
#
sqlplus -s '/ as sysdba' 2>/dev/null <<EOT
set echo off heading off feedback off verify off
--
whenever sqlerror exit 1; 
whenever oserror exit 2; 
--
--
prompt "------------- $ORACLE_SID -----------------------"
--
create pfile='$pfile1' from memory;
create pfile='$pfile2' from spfile;
host cp -f $pfile1 $pfile3
--
alter database backup controlfile to trace as '$ctrlf1' ;
host cp -f $ctrlf1 $ctrlf2 ;
--
prompt "-------------------------------------------------"
--
exit 0
EOT
#
export STATUS=$?
if [ $STATUS != 0 ]
then
   echo "Erreur $0 : $STATUS : SQL/OS 1/2 ..." >&2
fi
#
#
###################################################################
#
#
if [ $? -ne 0 ]
then
   export a_error_svg=1
else
   export a_error_svg=0
fi 
#
#########
#
export STATUS=$a_error_svg
if [ $STATUS != 0 ]
then
   echo bash $BINDIR/db_mailx.sh $LOGDIR/$LOGFILE ProblemePfile "$LISTEMAIL"
   bash $BINDIR/db_mailx.sh $LOGDIR/$LOGFILE ProblemePfile "$LISTEMAIL"
   # Mail et continuer 
   echo ""
fi
#
##############
#
fi
#
cp -f $LOGDIR/$LOGFILE $myrep 1>/dev/null 2>&1
cp -f $WORKDIR/$CONFILE $myrep 1>/dev/null 2>&1
#
rm -f ${WORKDIR}/kcopy_pfile_base_$$.tmp* 1>/dev/null 2>&1
rm -f $WORKDIR/$CONFILE 1>/dev/null 2>&1
#
