#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col DB_LINK format a22
col HOST  format a22
col OWNER format a22
col USERNAME format a22
set heading off
set lines 152
col DbLink format a151
prompt 
prompt =========================== PUB SYNONYMS ===========================
select decode(OWNER,'PUBLIC','',
'alter session set current_schema='||OWNER||';' ||chr(10)
             )||
'create or replace '||decode(OWNER,'PUBLIC','PUBLIC','')||' synonym '||synonym_name||' for '
||TABLE_OWNER||'.' ||TABLE_NAME
||decode(DB_LINK,null,'','@')||DB_LINK||';' PubSyn
from dba_synonyms where OWNER in ('PUBLIC') and 
TABLE_OWNER not in ('XDB','SYS','SYSTEM','SYSMAN','FLOWS_FILES','MDSYS','ORDSYS','OLAPSYS') and
TABLE_OWNER not in ('ORDDATA','CTXSYS','EXFSYS','WMSYS','APPQOSSYS','MDSYS','ORDSYS','OLAPSYS') and
TABLE_OWNER not like 'APEX%';
--
exit
EOT
#
. $KMscript/KMlogout.sh
#

