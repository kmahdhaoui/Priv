#!/bin/bash
# Author : Kamel Mahdhaoui
#
#
if [ "$1" == "" ]
then
   echo "Usage is : $0 <owner> <table|%>"
   exit 1
else
   export LeOwner=$1
fi
#
if [ "$2" == "" ]
then
   export LaTable=%
else
   export LaTable=$1
fi
#
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
set feedback off
alter session set nls_date_format='yyyy-mm-dd hh24:mi:ss' ;
set lines 133
col value format a80
--
col OWNER format a10
col TABLE_NAME format a30
col INCREMENTAL format a10
col GRANULARITY format a10
col STALE_PERCENT format A6
col ESTIMATE_PERCENT format a30
col CASCADEA format a10
col METHOD_OPT format a20
--
-- dba_tab_modifications
prompt ================================== dba_tab_statistics =============================
--
select owner,table_name, sample_size, last_analyzed from dba_tab_statistics 
where owner='$LeOwner' and table_name like '$LaTable' and
( STALE_STATS ='YES' or STALE_STATS is null )  
and last_analyzed is not null
;
--
-- type histogram
prompt ================================== column stats ====================================
alter session set nls_date_format='yyyy-mm-dd' ;
set lines 133
select distinct OWNER,TABLE_NAME,
-- COLUMN_NAME,LOW_VALUE,HIGH_VALUE, sample_size,
trunc(last_analyzed) last_analyzed ,HISTOGRAM
from  dba_tab_col_statistics
where owner='$LeOwner' and table_name like '$LaTable' and
HISTOGRAM not like 'NONE'
/
-- en 10 aussi ok : sysaux qui aumente ...
-- SELECT TRUNC(DBMS_STATS.GET_STATS_HISTORY_RETENTION) FROM DUAL;
-- EXEC DBMS_STATS.alter_stats_history_retention(10);
-- la plus ancienne stat
-- select dbms_stats.get_stats_history_availability from dual;
-- taille de stat
-- select trunc(SAVTIME),count(1) from WRI$_OPTSTAT_HISTHEAD_HISTORY group by  trunc(SAVTIME) order by 1;
-- purge la stat du 13jan2013
-- exec dbms_stats.purge_stats(to_date('13-JAN-2013','DD-MON-YYYY'));
--
-- que 11g : table level
prompt ================================== get_prefs =========================================
set lines 150
col NB_Tables format 9999999
col cascadea format a33
SELECT owner, count(*) NB_Tables,incremental,granularity,stale_percent,estimate_percent,cascadea
from 
(
SELECT owner, table_name,
  DBMS_STATS.get_prefs(ownname=>USER,tabname=>table_name,pname=>'INCREMENTAL') incremental,
  DBMS_STATS.get_prefs(ownname=>USER,tabname=>table_name,pname=>'GRANULARITY') granularity,
  DBMS_STATS.get_prefs(ownname=>USER,tabname=>table_name,pname=>'STALE_PERCENT') stale_percent,
  DBMS_STATS.get_prefs(ownname=>USER,tabname=>table_name,pname=>'ESTIMATE_PERCENT') estimate_percent,
  DBMS_STATS.get_prefs(ownname=>USER,tabname=>table_name,pname=>'CASCADE') cascadea,
  DBMS_STATS.get_prefs(pname=>'METHOD_OPT') method_opt
FROM dba_tables where owner='$LeOwner' and table_name like '$LaTable' 
)
group by owner,incremental,granularity,stale_percent,estimate_percent,cascadea
ORDER BY 1,3,4,5,6,7
;
--
col CLIENT_NAME format a20
col STATUS format a20
col LAST_GOOD_DATE format a35
col NEXT_TRY_DATE format a20
--
select CLIENT_NAME,STATUS,LAST_GOOD_DATE,NEXT_TRY_DATE from DBA_AUTOTASK_TASK ;
--
-- DBMS_STATS.SET_TABLE_PREFS ('$LeOwner','$LaTable','INCREMENTAL','FALSE');
-- que 11g : shema level
/*
SELECT username,
  DBMS_STATS.get_prefs(ownname=>USER,pname=>'INCREMENTAL') incremental,
  DBMS_STATS.get_prefs(ownname=>USER,pname=>'GRANULARITY') granularity,
  DBMS_STATS.get_prefs(ownname=>USER,pname=>'STALE_PERCENT') stale_percent,
  DBMS_STATS.get_prefs(ownname=>USER,pname=>'ESTIMATE_PERCENT') estimate_percent,
  DBMS_STATS.get_prefs(ownname=>USER,pname=>'CASCADE') cascadea,
  DBMS_STATS.get_prefs(pname=>'METHOD_OPT') method_opt
FROM dba_users where username='$LeOwner' 
ORDER BY username
;
*/
-- exec DBMS_STATS.SET_SCHEMA_PREFS ('$LeOwner','STALE_PERCENT','10');
--aque 11g : database level
/*
SELECT 
  DBMS_STATS.get_prefs(pname=>'INCREMENTAL') incremental,
  DBMS_STATS.get_prefs(pname=>'GRANULARITY') granularity,
  DBMS_STATS.get_prefs(pname=>'STALE_PERCENT') publish,
  DBMS_STATS.get_prefs(pname=>'ESTIMATE_PERCENT') estimate_percent,
  DBMS_STATS.get_prefs(pname=>'CASCADE') cascadea,
  DBMS_STATS.get_prefs(pname=>'METHOD_OPT') method_opt
FROM dual
;
*/
-- exec DBMS_STATS.SET_GLOBAL_PREFS('METHOD_OPT','FOR ALL COLUMNS SIZE REPEAT');
--
-- exec dbms_stats.gather_database_stats(degree=>8);
-- exec dbms_stats.gather_database_stats(cascade=>true,degree=>8);
-- exec dbms_stats.gather_database_stats(cascade=>true,degree=>48,ESTIMATE_PERCENT=>100,GRANULARITY=>'APPROX_GLOBAL AND PARTITION');
--
--


--
exit
EOT
#
. $KMscript/KMlogout.sh
#
