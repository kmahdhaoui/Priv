#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
#
if [ "$1" == "" ]
then
   export TEMPS=30
else
   export TEMPS=$1
fi
#
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
-- Excellent: < 1ms
-- Very good: < 5ms
-- Good: 5 – 10ms
-- Poor: 10 – 20ms
-- Bad: 20 – 100ms
-- Shockingly bad: 100 – 500ms
--
prompt =============================== User I/O , System I/O ===================================
select
       decode(wait_class_id,1740759767,'User I/O',4108307767,'System I/O','Other') wait_class,
       n.name event,
       m.wait_count  cnt,
       10*m.time_waited ms,
       nvl(round(10*m.time_waited/nullif(m.wait_count,0),3) ,0) avg_ms
  from v\$eventmetric m,
       v\$event_name n
  where m.event_id=n.event_id
		and ( wait_class_id= 1740759767 or  --  User I/O
              wait_class_id= 4108307767)    --  System I/O
        and m.wait_count > 0
        and BEGIN_TIME > sysdate - $TEMPS/1440
order by 1,2
;
--
prompt =============================== File Operation        ===================================
col file_type for a20
col file_operation for a20
select
    decode(p3,0 ,'Other',
              1 ,'Control File',
              2 ,'Data File',
              3 ,'Log File',
              4 ,'Archive Log',
              6 ,'Temp File',
              9 ,'Data File Backup',
              10,'Data File Incremental Backup',
              11,'Archive Log Backup',
              12,'Data File Copy',
              17,'Flashback Log',
              18,'Data Pump Dump File',
                  'unknown '||p1)  file_type,
    decode(p1,1 ,'file creation',
              2 ,'file open',
              3 ,'file resize',
              4 ,'file deletion',
              5 ,'file close',
              6 ,'wait for all aio requests to finish',
              7 ,'write verification',
              8 ,'wait for miscellaneous io (ftp, block dump, passwd file)',
              9 ,'read from snapshot files',
                 'unknown '||p3) file_operation,
    decode(p3,2,-1,p2) file#,
    count(*)
from dba_hist_active_sess_history
where event ='Disk file operations I/O'
and trunc(SAMPLE_TIME)  > sysdate - $TEMPS/1440
group by p1,p3,
    decode(p3,2,-1,p2)
;
--
--
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
