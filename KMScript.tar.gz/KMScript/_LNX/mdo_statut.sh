#!/bin/bash
#
. /sitr/exploit/dba/SITR_env.sh
#
#============================================
if [ "$1" == "" ]
then
   if [ "$ORACLE_SID" == "" ]
   then
      export ORACLE_SID=XSITRMDO
   fi
else
    export ORACLE_SID=$1
fi
export ORAENV_ASK=NO
. oraenv 1>/dev/null
export ORAENV_ASK=YES
#
export PATH=$ORACLE_HOME/bin:$PATH
#============================================
#
###############################################
#
bash sleep_PS.sh "oracle" "sqlplus" 6 60
#
###############################################
#
sqlplus -s / as sysdba 1>/dev/null 2>&1 <<EOT
create table mdo_statut_kk as 
--
select /*+ parallel(d1_init_msrmt_data,42) */ to_char(CRE_DTTM,'yyyy-mm-dd hh24') Heure,BO_STATUS_CD,count(*) comptage_imd
from cisadm.d1_init_msrmt_data where
CRE_DTTM > sysdate -1/10 and to_char(CRE_DTTM,'yyyy-mm-dd hh24') = to_char(sysdate - 1/24,'yyyy-mm-dd hh24')
and D1_TO_DTTM > sysdate -31
group by to_char(CRE_DTTM,'yyyy-mm-dd hh24'), BO_STATUS_CD
;
exit
EOT
#
sqlplus -s / as sysdba <<EOT
--
insert into mdo_statut_kk 
--
select /*+ parallel(d1_init_msrmt_data,42) */ to_char(CRE_DTTM,'yyyy-mm-dd hh24') Heure,BO_STATUS_CD,count(*) comptage_imd
from cisadm.d1_init_msrmt_data where
CRE_DTTM > sysdate -1/10 and to_char(CRE_DTTM,'yyyy-mm-dd hh24') = to_char(sysdate - 1/24,'yyyy-mm-dd hh24')
and D1_TO_DTTM > sysdate -31
group by to_char(CRE_DTTM,'yyyy-mm-dd hh24'), BO_STATUS_CD
;
commit;
--
exit
EOT
#
sqlplus -s / as sysdba <<EOT
--
set feedback off
set verify off
set lines 132
set pages 132
alter session set nls_date_format='yyyy-mm-dd hh24:mi:ss' ;
--
set heading on
select * from mdo_statut_kk where to_date(substr(heure,1,10),'yyyy-mm-dd') > sysdate -31 order by Heure,BO_STATUS_CD;
--
exit
EOT
#
