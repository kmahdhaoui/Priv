#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
alter session set nls_date_format='yyyy-mm-dd hh24:mi:ss' ;
SELECT dd.dbid,ii.INCARNATION#,ii.RESETLOGS_CHANGE#,ii.RESETLOGS_TIME,STATUS FROM V\$DATABASE_INCARNATION ii,
v\$database dd where dd.LAST_OPEN_INCARNATION# (+) = ii.incarnation#
;
--
-- SELECT RESETLOGS_ID,THREAD#,SEQUENCE#,STATUS,ARCHIVED FROM V\$ARCHIVED_LOG
-- ORDER BY RESETLOGS_ID,SEQUENCE# 
-- ;
exit
EOT
#
date
