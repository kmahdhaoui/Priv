#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col sid format 999999
col USER_NAME format a15
col MACHINE_NAME format a10
col sid format 999999
col USERNAME format a10
col MACHINE format a15
col program format a44
col logon_time format a20
set lines 200
col LOG_ON format a50
--
col pio format 9999999
col lio format 9999999
col mem format 99999999
col cpu format 999999
col dsorts format 999999
col rsorts format 999999
col commits format 999999
col rolls format 999999
col execs format 999999
--
select sid,USER_NAME||' '||OS_ID||' '|| MACHINE_NAME ||' '||LOGON_TIME LOG_ON,
t_p_io pio,
t_l_io lio,
t_memy_usage mem,
t_cpu cpu,
disk_sorts dsorts,
rows_sorted rsorts,
-- commits,
-- rolls,
execs
from
(select b.sid sid,
     decode (b.username,null,e.name,b.username) user_name,
     d.spid os_id,
     b.machine machine_name,
     to_char(logon_time,'dd-mon-yy hh24:mi:ss') logon_time,
    (sum(decode(c.name,'physical reads  ',value,0)) +
     sum(decode(c.name,'physical writes',value,0)) +
     sum(decode(c.name,'physical writes direct',value,0)) +
     sum(decode(c.name,'physical writes direct (lob)',value,0))+
     sum(decode(c.name,'physical reads  direct (lob)',value,0)) +
     sum(decode(c.name,'physical reads   direct',value,0)))
     t_p_io,
    (sum(decode(c.name,'db block gets',value,0)) +
     sum(decode(c.name,'db block changes',value,0)) +
     sum(decode(c.name,'consistent changes',value,0)) +
     sum(decode(c.name,'consistent gets ',value,0)) )
     t_l_io,
    (sum(decode(c.name,'session pga memory',value,0))+
     sum(decode(c.name,'session uga memory',value,0)) )
     t_memy_usage,
     sum(decode(c.name,'parse count (total)',value,0)) parses,
     sum(decode(c.name,'cpu used by this session',value,0))
     t_cpu,
     sum(decode(c.name,'parse time cpu',value,0)) parse_cpu,
     sum(decode(c.name,'recursive cpu usage',value,0))
       recur_cpu,
     sum(decode(c.name,'cpu used by this session',value,0)) -
     sum(decode(c.name,'parse time cpu',value,0)) -
     sum(decode(c.name,'recursive cpu usage',value,0))
       other_cpu,
     sum(decode(c.name,'sorts (disk)',value,0)) disk_sorts,
     sum(decode(c.name,'sorts (memory)',value,0)) mem_sorts,
     sum(decode(c.name,'sorts (rows)',value,0)) rows_sorted,
     sum(decode(c.name,'user commits',value,0)) commits,
     sum(decode(c.name,'user rollbacks',value,0)) rolls,
     sum(decode(c.name,'execute count',value,0)) execs
from sys.v_\$sesstat  a,
     sys.v_\$session b,
     sys.v_\$statname c,
     sys.v_\$process d
     , sys.v_\$bgprocess e
where a.statistic#=c.statistic# and
      d.addr(+)=b.paddr and
      e.paddr(+)=b.paddr and
      a.SID=b.SID and
      c.NAME in ('physical reads  ',
                 'physical writes',
                 'physical writes direct',
                 'physical reads   direct',
                 'physical writes direct (lob)',
                 'physical reads   direct (lob)',
                 'db block gets',
                 'db block changes',
                 'consistent changes',
                 'consistent gets ',
                 'session pga memory',
                 'session uga memory',
                 'parse count (total)',
                 'CPU used by this session',
                 'parse time cpu',
                 'recursive cpu usage',
                 'sorts (disk)',
                 'sorts (memory)',
                 'sorts (rows)',
                 'user commits',
                 'user rollbacks',
                 'execute count'
) 
group by b.sid,
         d.spid,
         decode (b.username,null,e.name,b.username),
         b.machine,
         to_char(logon_time,'dd-mon-yy hh24:mi:ss')
order by 6 desc)
where rownum < 21
;
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
