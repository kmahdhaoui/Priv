#!/bin/bash
# Author : Kamel Mahdhaoui
#
#
for ii in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15
do
sar -u 10 30 1>sar_$ii.out 2>&1 &
echo "------------------------ $ii ----------------------------------"
date
sqlplus -s '/ as sysdba' <<EOT
--
EXEC dbms_workload_repository.create_snapshot;
--
exit
EOT
#
echo "count..."
sqlplus -s '/ as sysdba' <<EOT
--
set time on timi on
select count(*) from ecomoa.ecom_control;
--
exit
EOT
#
#
echo "***************************************************************"
echo " "
echo " "
echo " "
date
#
#
sleep 255
done
