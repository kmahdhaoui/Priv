#!/bin/ksh
#
if [ "$1" == "" ]
then 
   echo "Usage : $0 <directory> <|b>"
   exit 
fi
#
if [ "$2" == "b" ]
then
ls -R $1 | grep ":$" | sed -e 's/:$//' -e 's/[^-][^\/]*\// /g' -e 's/^/ /'
else
ls -R $1 | grep ":$" | sed -e 's/:$//' -e 's/[^-][^\/]*\//--/g' -e 's/^/   /' -e 's/-/|/'
fi
#

