#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export ORACLE_SID=XSITRMDO
export RMANTAG=full_$KMymdhms
#
sqlplus '/ as sysdba' <<EOT
startup nomount
exit
EOT
#
rman target / <<EOT
backup current controlfile ;
sql 'ALTER SYSTEM ARCHIVE LOG CURRENT';

backup archivelog ALL TAG ${RMANTAG} delete input;
backup database TAG ${RMANTAG};

sql 'ALTER SYSTEM ARCHIVE LOG CURRENT';
backup current controlfile TAG ${RMANTAG};
exit
EOT
#

