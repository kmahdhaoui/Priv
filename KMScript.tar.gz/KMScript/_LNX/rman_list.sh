#!/bin/bash
# Author : Kamel Mahdhaoui
#
rman target=/ <<EOT
list backup summary ;
exit
EOT
#
#
