#!/bin/bash
# Author : Kamel Mahdhaoui
# Unautorized use is forbidden
#
export MyHost=`hostname`
export petithost=`hostname | awk -F. '{print $1}' -`
#
export alert_dir=`sqlplus -s "$conn" <<EOT
set pages 0
set headi off
set feedb off
set verify off
set pages 155
col value format a70
select value from v\\$parameter where name='background_dump_dest';
exit
EOT
`
export alert_log="alert_${ORACLE_SID}.log"
# *****************************************************************************
#
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
echo $alert_dir/$alert_log
#
if [ "$KSHOUTPUT" == "HTML" ]
then
   echo "<table border='1' width='90%' align='center' summary='Script output'>"
   grep "ORA-" $alert_dir/$alert_log |tail | awk '{print "<tr><td>",$0,"</td></tr>"}' 
   echo "</TABLE>"
else
   grep "ORA-" $alert_dir/$alert_log |tail | awk '{print $0}'
fi
#
. $KMscript/KMlogout.sh
#
