#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$1" == "" ] 
then
   echo "Usage : $0 <sid> ..."
   exit 101
fi
# positionner des choses pour les scripts
export ficlck=/tmp/kmholder.lck
export fictmp=/tmp/kmholder.$$.tmp
. ~oracle/scripts/backenv $1 1>$fictmp 2>&1
#
sqlplus -s "$conn" 1>$fictmp 2>&1 <<EOT
--
set pages 555
set lines 79
SELECT DECODE(request,0,'Hol'||'der: ','Waiter: ')||sid sess, id1, id2, lmode, request, type
FROM V\$LOCK
WHERE (id1, id2, type) IN (
  SELECT id1, id2, type
  FROM V\$LOCK
  WHERE request>0)
ORDER BY id1, request
;
exit
EOT
#
cat kk |mailx -s "test_$$" "kamel.mahdhaoui@s^Cz-env.com"
export from="dtb2@ondeosystems.com"
export smtp=10.34.34.67

export nblig=`grep Holder $fictmp |wc -l`
if [ $nblig -ne 0  ]
then 
   export SUJETMAIL="Sessions locks `hostname`:$ORACLE_SID"
   if [ ! -f $ficlck ]
   then
      date > $ficlck
      cat $fictmp |mailx -s "$SUJETMAIL" "kamel.mahdhaoui@suez-env.com" 
   fi
else
   rm -f $ficlck
fi
rm -f $fictmp
#
