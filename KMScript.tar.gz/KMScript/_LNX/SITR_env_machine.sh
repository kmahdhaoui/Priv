#!/bin/bash
# set -x
export SITRlogin_dw=oracle
export SITRsite=IBM
#
# Machine ref = vert
# Machine prod = rouge
# Machine Bdd = non inverse
# Machine non bdd = inverse
#
######################
#
case $SITRhost in
sefrapp00153*) export PS1=$PS_vert    ; export SITRlogin_dw=oracle   ;;
sefrapp00154*) export PS1=$PS_rouge   ; export SITRlogin_dw=oracle   ;;
sefrapp00148*) export PS1=$PS_I_rouge ; export SITRlogin_dw=weblogic ;;
sefrapp00155*) export PS1=$PS_I_rouge ; export SITRlogin_dw=weblogic ;;
            *) export PS1=$PS_autre   ; export SITRlogin_dw=cinstall ;;
esac
#
######################
export Liste_host_info=$Liste_host_dw
for lehost in $Liste_host_dw
do
case $lehost  in
sefrapp00153*) alias $lehost="echo '. SITR.profile'; ssh -X oracle@$lehost" ;;
sefrapp00154*) alias $lehost="echo '. SITR.profile'; ssh -X oracle@$lehost" ;;
sefrapp00148*) alias $lehost="echo '. SITR.profile'; ssh -X weblogic@$lehost" ;;
sefrapp00155*) alias $lehost="echo '. SITR.profile'; ssh -X weblogic@$lehost" ;;
            *) alias $lehost="echo '. SITR.profile'; ssh -X cinstall@$lehost" ;;
esac
done
#
######################
