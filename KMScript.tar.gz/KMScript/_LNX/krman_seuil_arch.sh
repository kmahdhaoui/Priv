#!/bin/bash
# kma
#
# Les archive logs sont sur /sitr : /sitr/oradata/R*/arch 
# le seuil est de 50% 
# la base
if [ "$1" == "" ]
then
   echo "Usage : $0 <base> <optionnels : FS PCT>"
   exit 101
else
   export leSID=$1
   export ORACLE_SID=$leSID
fi
#
if [ "$2" == "" ]
then
   export lefs="/sitr"
else
   export lefs=$2
fi
#
# le seuil
if [ "$3" == "" ]
then
   export lepct=50
else
   export lepct=$3
fi
#
export nomPROG=krman_seuil_arch.sh
export NombrePS=`ps -ef |grep $nomPROG |grep -v grep|grep ">"|wc -l`
if [ "$NombrePS" -gt 1 ]
then
   echo "Il y a deja $0 qui tourne !"
   ps -ef |grep $nomPROG |grep -v grep
   exit 103
fi
#
# les variables pour le batch
export ORACLE_SID=$leSID
. /usr/local/etc/oracle/kenv_batch.sh $leSID
. $BINDIR/kenv_nls.sh
#
cd $BINDIR
#
rm -f ${WORKDIR}/krman_seuil_arch_$$.tmp* 1>/dev/null 2>&1
export SQLTMP=${WORKDIR}/krman_seuil_arch_$$.tmp
#
export a_error_svg=0
export myrep=$lefs
export LOGFILE=krman_seuil_arch_${ORACLE_SID}_$KMymdhms.log
#
##################################################################
# Si fs arch specifique :
# export PCT=`df -m "$lefs" |grep "$lefs" |awk -F" "  '{print $4 }'|awk -F"%" '{print $1 }' `
# sinon :
# On declenche a 8 Go avec un seuil de 50% c'est 16g (division par 160=16000/100)
export Taille=`du -sm /sitr/oradata/$ORACLE_SID/arch|awk -F" " '{print $1}'`
export PCT=`expr $Taille / 160`
#
#########
#
if [ "$PCT" -gt "$lepct" ]
then
   # find /sitr/diag -name "*.*" -mtime +${WINDOW_RMAN} -exec rm -f {} \; 1>/dev/null 2>&1 &
   # Archiver 
   echo "$BINDIR/krman_arch_base.sh $ORACLE_SID"
   bash $BINDIR/krman_arch_base.sh $ORACLE_SID 1>$LOGDIR/krman_arch_base_$leSID.$$.log 2>&1
   # check sur la destination des backup
   echo bash $BINDIR/kfs_check.sh $BACKUP_SITR_RMAN 80 
   bash $BINDIR/kfs_check.sh $BACKUP_SITR_RMAN 80 1>/dev/null 2>&1 &
fi
#
#########
#
rm -f ${WORKDIR}/krman_seuil_arch_$$.tmp* 1>/dev/null 2>&1
#
