#!/bin/bash
# kma
#
#
#
# quels tbs traiter (like)
if [ "$1" == "" ]
then
   export lestbs="%"
else
   export lestbs=$1
fi
#
# les tbs a ne pas traiter (not like)
if [ "$2" == "" ]
then
   export nottbs="None"
else
   export nottbs=$2
fi
#
# seuils c'est $3 $4 et $5
if [ "$3" == "" ]
then
   export SEUIL_1=80
else
   export SEUIL_1=$3
fi
#
if [ "$4" == "" ]
then
   export SEUIL_2=90
else
   export SEUIL_2=$4
fi
#
if [ "$5" == "" ]
then
   export SEUIL_3=95
else
   export SEUIL_3=$5
fi
#
export SUPDIR=/sitr/exploit/sup
export LOGDIR=/sitr/exploit/sup/log
export WORKDIR=/sitr/exploit/sup/log
mkdir -p $WORKDIR
chmod 775 $WORKDIR;chgrp oinstall $WORKDIR
#
export DATE=$(date "+%d/%m/%Y %H:%M:%S")
rm -f ${WORKDIR}/kresult$$.tmp* 1>/dev/null 2>&1
#
export SUPFILE=${SUPDIR}/ktbs.sup
#
export SQLTMP=${WORKDIR}/kresult$$.tmp
export PATH=$PATH:/usr/local/bin
export PATH=$PATH:$ORACLE_HOME/bin
#
##########################
# La liste c'est les bases qui tournent
cat <<EOF |sort -u | grep -v '^$'| while read leSID ; do
$(ps -ef |grep smon|grep -v grep|grep -v '+ASM'|awk -F_ '{print $3}'|sed 's/ //g')
EOF
export ORACLE_SID=$leSID
export ORAENV_ASK=NO
. oraenv 1>/dev/null
export ORAENV_ASK=YES
export PATH=$ORACLE_HOME/bin:$PATH
#
sqlplus -s '/ as sysdba' 1>/dev/null 2>&1 <<EOT
set echo off heading off feedback off verify off
--
whenever sqlerror exit 1; 
whenever oserror exit 2; 
--
spool $SQLTMP.$leSID.2
-- tbs;allocable;occup;true_pct_used 
select aa.TABLESPACE_NAME||';'||to_char(round(aa.Allocable))||';'||
to_char(round(nvl(aa.allocated,0)-nvl(bb.libre,0)))||';'||
to_char(round(100*(nvl(aa.allocated,0)-nvl(bb.libre,0))/(aa.Allocable+1))) ligne from 
(
SELECT a.TABLESPACE_NAME,
sum(decode(AUTOEXTENSIBLE,'YES',least(nvl(MAXBYTES,0),b.free_b),nvl(BYTES,0))/1024/1024) Allocable,
sum(nvl(BYTES,0))/1024/1024 Allocated
FROM DBA_DATA_FILES a ,
(SELECT dg.name,sum(dg.free_mb)*1024*1024 free_b FROM v\$asm_diskgroup dg group by dg.NAME) b
where a.file_name like '+'||b.name||'/%'
and a.TABLESPACE_NAME like '$lestbs'
and a.TABLESPACE_NAME not like '$nottbs'
group by a.TABLESPACE_NAME
) aa ,
(
select 	TABLESPACE_NAME,
sum(nvl(BYTES,0)/1024/1024) libre 
from 	dba_free_space 
where   TABLESPACE_NAME like '$lestbs'  and TABLESPACE_NAME not like '$nottbs'
group 	by TABLESPACE_NAME
) bb
where aa.TABLESPACE_NAME=bb.TABLESPACE_NAME (+) 
and aa.TABLESPACE_NAME like '$lestbs' 
and aa.TABLESPACE_NAME not like '$nottbs' 
and round(100*(nvl(aa.allocated,0)-nvl(bb.libre,0))/(aa.Allocable+1)) > $SEUIL_1
/
exit 0
EOT
#
export STATUS=$?
if [ $STATUS != 0 ]
then
   echo "Erreur $0 : $STATUS : SQL/OS 1/2 ..." >&2
   exit 3
fi
#
sed '/^$/d' ${SQLTMP}.$leSID.2 >${SQLTMP}.$leSID.1
export nb=`cat ${SQLTMP}.$leSID.1|wc -l`
#
##############
for ((i=1;i<=$nb;i++))
do
export tbs=`sed -n ${i}p ${SQLTMP}.$leSID.1|awk -F";" '{print $1}'`
export seuil=`sed -n ${i}p ${SQLTMP}.$leSID.1|awk -F";" '{print $4}'`
export SEUIL=`echo $seuil`
export seuil=$SEUIL
#
#echo $tbs $seuil $SEUIL_1 $SEUIL_2 $SEUIL_3
#
#set -x
if [ ${seuil} -ge $SEUIL_3 ] 
then 
   echo -n `date +%Y/%m/%d" "%H:%M:%S` 					>>$SUPFILE
   echo -n "|"`hostname`"|$leSID|CRITIQUE__|tablespace ${seuil}%" 	>>$SUPFILE
   echo -n " depasse ${SEUIL_3}%|" 				 	>>$SUPFILE
   echo    `sed -n ${i}p ${SQLTMP}.$leSID.1|awk -F";" '{print $1}'` 	>>$SUPFILE
#
else
   if [ ${seuil} -ge $SEUIL_2 ] 
   then 
      echo -n `date +%Y/%m/%d" "%H:%M:%S` 				>>$SUPFILE
      echo -n "|"`hostname`"|$leSID|MAJEUR____|tablespace ${seuil}%" 	>>$SUPFILE
      echo -n " depasse ${SEUIL_2}%|" 					>>$SUPFILE
      echo    `sed -n ${i}p ${SQLTMP}.$leSID.1|awk -F";" '{print $1}'`	>>$SUPFILE
   #
   else
      if [ ${seuil} -ge $SEUIL_1 ] 
      then 
         echo -n `date +%Y/%m/%d" "%H:%M:%S` 					>>$SUPFILE
         echo -n "|"`hostname`"|$leSID|ATTENTION_|tablespace ${seuil}%" 	>>$SUPFILE
         echo -n " depasse ${SEUIL_1}%|" 					>>$SUPFILE
         echo    `sed -n ${i}p ${SQLTMP}.$leSID.1|awk -F";" '{print $1}'` 	>>$SUPFILE
      fi
      #
   fi
   #
fi
#set +x
#
done
##############
done
##########################
#
rm -f ${WORKDIR}/kresult$$.tmp* 1>/dev/null 2>&1
#
