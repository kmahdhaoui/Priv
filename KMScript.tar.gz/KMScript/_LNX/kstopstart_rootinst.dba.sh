#!/bin/bash
#
export kstopstarttype=dba
export kstopstartfile=kstopstart.$kstopstarttype.sh
export kstopstartpath=/etc/rc.d/init.d
mkdir -p /root
cp -f $kstopstartpath/$kstopstartfile /root/$kstopstartfile.old.$$
chmod 770 /root/$kstopstartfile.*
chown root:$kstopstarttype /root/$kstopstartfile.*
#
##############################################
cat 1>/root/$kstopstartfile.new 2>/root/$kstopstartfile.err << EndOfText
#!/bin/bash
#
RETVAL=0
#
# la base c'est +ASM
export leSID=+ASM
export ORACLE_SID=$leSID
. /usr/local/etc/oracle/kenv_batch.sh $leSID
#
# See how we were called.
case "$1" in
  start)  sleep 1
          su - oracle -c "/bin/bash $BINDIR/kstart_listener.sh"
          su - oracle -c "/bin/bash $BINDIR/kstart_all_bases.sh"
          ;;
  status) su - oracle -c "/bin/bash $BINDIR/kstatus_listener.sh"
          su - oracle -c "/bin/bash $BINDIR/kstatus_all_bases.sh"
          ;;
  stop)   sync;sleep 1;sync
          su - oracle -c "/bin/bash $BINDIR/kstop_listener.sh"
          su - oracle -c "/bin/bash $BINDIR/kstop_all_bases.sh abort"
          ;;
  *)      echo "Usage: $0 {start|stop|status}"
          RETVAL=2
          ;;
esac
exit ${RETVAL}
#
EndOfText
##############################################
#
cp -f /root/$kstopstartfile.new $kstopstartpath/$kstopstartfile
chmod 770 $kstopstartpath/$kstopstartfile
chown root:$kstopstarttype $kstopstartpath/$kstopstartfile
#
ln -s /etc/init.d/kstopstart.dba.sh /etc/rc.d/rc0.d/K10kstopstart.dba.sh
ln -s /etc/init.d/kstopstart.dba.sh /etc/rc.d/rc1.d/K10kstopstart.dba.sh
ln -s /etc/init.d/kstopstart.dba.sh /etc/rc.d/rc2.d/K10kstopstart.dba.sh
ln -s /etc/init.d/kstopstart.dba.sh /etc/rc.d/rc3.d/S99kstopstart.dba.sh
ln -s /etc/init.d/kstopstart.dba.sh /etc/rc.d/rc4.d/K10kstopstart.dba.sh
ln -s /etc/init.d/kstopstart.dba.sh /etc/rc.d/rc5.d/S99kstopstart.dba.sh
ln -s /etc/init.d/kstopstart.dba.sh /etc/rc.d/rc6.d/K10kstopstart.dba.sh
#

