#!/bin/bash
# Author : Kamel Mahdhaoui
#
#
#
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export KMymd=`date "+%Y%m%d"`
#
# export Ftmp=/tmp/tmp_event_trends.$KMymdhms.tmp
# rm -f $Ftmp
#
# date
#
sqlplus -s "$conn"  <<EOT
--
set lines 132
set pages 44
--
set time off timi off echo off verify off feedback off 
set heading on
set pagesize 555
--
col username format a26
col sid format 9999
col state format a18
col event format a40
col wait_time format 99999999

select s.sid, s.username, se.event, se.state, se.wait_time
from v\$session s, v\$session_wait se
where s.sid=se.sid
and se.event not like 'SQL*Net%'
and se.event not like '%rdbms%'
and s.username is not null
order by se.wait_time
/
--
exit
EOT
#
#######################################
#
date
#
#
