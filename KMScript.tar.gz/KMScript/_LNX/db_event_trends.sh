#!/bin/bash
# Author : Kamel Mahdhaoui
#
#
if [ "$1" == "" ] 
then
   export NBJOURS=1
else
   export NBJOURS=$1
fi
#
if [ "$2" == "" ]
then
   export levent="db file sequential read"
else
   export levent="$2"
fi
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export KMymd=`date "+%Y%m%d"`
#
# export Ftmp=/tmp/tmp_event_trends.$KMymdhms.tmp
# rm -f $Ftmp
#
# date
#
sqlplus -s "$conn"  <<EOT
set time off timi off echo off verify off feedback off heading off 
set pagesize 50000
-- set trimspool on
set lines 133
col value format a20
--
col OWNER format a10
col TABLE_NAME format a30
col INCREMENTAL format a10
col GRANULARITY format a10
col STALE_PERCENT format A6
col ESTIMATE_PERCENT format a30
col CASCADEA format a10
col METHOD_OPT format a20
--
define m_event_name = '$levent'
 
column  instance_number   new_value m_instance  noprint
column  dbid              new_value m_dbid      noprint
 
select
        ins.instance_number,
        db.dbid
from
        v\$instance        ins,
        v\$database        db
;
--
col END_TIME format a33
column        "value nbr"      format        999,999,999,999
column        "value µs"       format        999,999,999,999
column        curr_value format        999,999,999,999
column        prev_value format        999,999,999,999
col event_name format a40
set heading on
break on event_name skip 1
--
select 
'"'||before.event_name||'"'   event_name ,
to_char(sn.end_interval_time,'Mon-dd hh24:mi:ss')     end_time,
(after.total_waits-before.total_waits) "value nbr",
(after.time_waited_micro-before.time_waited_micro)/
(after.total_waits-before.total_waits) "value µs"
from DBA_HIST_SYSTEM_EVENT before, 
DBA_HIST_SYSTEM_EVENT after,
DBA_HIST_SNAPSHOT sn
where 
sn.end_interval_time > trunc(sysdate - $NBJOURS + 1)
and
before.event_name like '$levent' and
after.event_name=before.event_name and
after.snap_id=before.snap_id+1 and
after.instance_number=1 and
before.instance_number=after.instance_number and
after.snap_id=sn.snap_id and
after.instance_number=sn.instance_number and
(after.total_waits-before.total_waits) > 0
-- and round((after.time_waited_micro-before.time_waited_micro) 
-- * (after.total_waits-before.total_waits) )  > 0
order by event_name,after.snap_id
;
--
--
exit
EOT
#
#######################################
#
date
#
#
