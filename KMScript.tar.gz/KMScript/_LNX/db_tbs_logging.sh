#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col OWNER format a22
col OBJECT_TYPE format a15
col OBJECT_NAME format a35
col STATUS
set pages 555
set lines 132
--
prompt "... Tablespaces no/logging"
SELECT 'alter tablespace '||tablespace_name
||decode(force_logging,'NO',' no ','YES',' ',' ')
||' force logging ' || ';' FROM dba_tablespaces;
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
