#!/bin/ksh
# Author : Kamel Mahdhaoui
# 
. ~oracle/.profile 1>/dev/null 2>&1
export ORACLE_SID=lastbase
. ~oracle/scripts/kamel/kamel.profile silent 1>/dev/null 2>&1
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh 1>/dev/null 1>/dev/null 2>&1
#
export host=$(uname -n)
export listbases=/tmp/kamel_listbases_$$
export OK=`echo "OK"`
export KO=`echo "KO"`
#
> $listbases
if [ "$host" == "dsgide" ]
then 
   export OraTab=/var/opt/oracle/oratab
else
   export OraTab=/etc/oratab
fi
cat $OraTab | sed '/^#/d' | grep -v "*" | grep -v "lastbase" > $listbases
#
cat <<EOF |sort -u | grep -v '^$' | while read SID ; do
$(cat $listbases |awk -F: '{print $1}')
$(ps -ef |grep smon|grep -v grep|awk -F_ '{print $3}'|sed 's/ //g')
EOF
# on initialise des choses
TimU="-1"
UPTime="-1"
XPUVD="ERR"
codeappli="ERR"
nbdbf=-1
needbkp="-1"
Dem="ERR"
STS="ERR"
MSG="ERR"
tdpo="ERR"
logmode="ERR"
nbdbf=-1
taillego=-1
fsappli="ERR"
# 2eme char
export XPUVD=`echo $SID|cut -c2-2`
export codeappli=`echo $SID|cut -c3-5`
#
STS=$OK ; MSG=''
export TimU=$(ps -eo etime,user,args| grep "smon_${SID} *$"|awk '{print $1}')
export UPTime=`echo $TimU |awk '{print $1}'`
export Inter=$(cat $listbases |grep -w ^${SID} | awk -F: '{print $4}'| awk 'FS=" " {print $1}')
export Dem=$(cat $listbases |grep -w ^${SID} | awk -F: '{print $3}'| awk 'FS=" " {print $1}')
#
export fictmp=/tmp/kamel_$$_$SID.txt
>$fictmp
#
export lsnr=$(ps -ef |grep lsnr |grep ${SID} |awk '{print $10}')
#
export ORACLE_SID=$SID
export ORACLE_HOME=`cat $listbases | grep -w ^${SID} | awk -F: '{print $2}'`
export PATH=$ORACLE_HOME/bin:$PATH
export LIBPATH=/usr/lib:$ORACLE_HOME/lib32:$ORACLE_HOME/lib:$ORACLE_HOME/jlib:$ORACLE_HOME/network/jlib
#
sqlplus -s "$conn" 1>/dev/null 2>&1 <<EOT >/dev/null
set echo off termout off head off verify off feedback off serveroutput off
spool $fictmp
select STATUS from v\$instance;
spool off
exit
EOT
#
if [ -z "$UPTime" ]
then
    UPTime="-1"
    STA='DOWN'
  #  MSG=`echo "$R {{(([[Pas de mode Intervention]]))}} $F"`
else
    UPTime="+"`echo $UPTime|grep "\-" |awk -F\- '{print $1}'`
    if [ "$UPTime" == "+" ] 
    then
       UPTime="+0"
    fi
    if [ -z "$lsnr" ]
    then
      STA='LSNR'
      MSG=`echo "$J PB_LSNR $F"`
    else
      STA=`cat $fictmp | sed '/^$/d' | sed 's/[ \t]*$//'`
    fi
#
# ---------- tdpo
#
export mystatut=9
>$fictmp
sqlplus -s "$conn" 1>/dev/null 2>&1 <<EOT >/dev/null
set echo off termout off head off verify off feedback off serveroutput off
spool $fictmp
whenever sqlerror exit 1
select 'tdpo'||':'||'v'||':'||
substr ( c1,instr(c1,'/',1,3)+1,20) from
(select
substr( VALUE, instr(VALUE,'TDPO_OPTFILE')+13, 1+
instr(VALUE,'.',instr(VALUE,'TDPO_OPTFILE')) - instr(VALUE,'TDPO_OPTFILE')-13 ) c1
from V\$RMAN_CONFIGURATION where NAME='CHANNEL'
)
;
spool off
exit 0
EOT
export mystatut=$?
if [ $mystatut -eq 0 ]
then
   export tdpo=`cat $fictmp|grep tdpo | sed '/^$/d' | sed 's/[ \t]*$//'|awk -F:v: '{print $2}' `
   export tdpo=`echo $tdpo |tr -d ' '|tr -d ')'|tr -d '/'|tr -d '.'`
   if [ "$tdpo" == "tdpo_$ORACLE_SID" ]
   then 
      export tdpo="Ok"
   else
      export tdpo="Pb Cfg"
   fi
else
   export tdpo="Non"
fi
#
# ---------- needbkp
# need backup
export mystatut=9
>$fictmp
rman target / 1>$fictmp 2>&1 <<EOT
report need backup ;
EOT
export mystatut=$?
if [ $mystatut -eq 0 ]
then
   export NBDBF=`cat $fictmp|grep $ORACLE_SID|grep sgbd|grep -v DBID|grep -v "="|wc -l`
   if [ $NBDBF -eq 0 ]
   then
      export needbkp="0"
   else
      export needbkp="$NBDBF"
   fi
else
   export needbkp="-1"
fi
#
# ---------- logmode
# ---------- taillego
# ---------- nbdbf
# ---------- fsappli
# ---------- bundlepsu
export mystatut=9
>$fictmp
sqlplus -s "$conn" 1>/dev/null 2>&1 <<EOT >/dev/null
set echo off termout off head off verify off feedback off serveroutput off
spool $fictmp
whenever sqlerror exit 1
select 'logmode'||':'||'v'||':'||decode(substr(LOG_MODE,1,4),'NOAR','NO',substr(LOG_MODE,1,4))  from  v\$database ;
whenever sqlerror exit 2
select 'taillego'||':'||'v'||':'||round(sum(bytes)/1024/1024/1024) GB from v\$datafile; 
whenever sqlerror exit 3
select 'nbdbf'||':'||'v'||':'||count(*) NBDBF from v\$datafile;
whenever sqlerror exit 4
select 'fsappli'||':'||'v'||':'||SUBSTR(name,INSTR(name,'/',1,1)+1,INSTR(name,'/',1,2)-2) from v\$datafile where FILE#=1;
spool off
exit 0
EOT
export mystatut=$?
#
if [ $mystatut -eq 0 ]
then
   export logmode=`cat $fictmp | grep logmode |sed '/^$/d' | sed 's/[ \t]*$//'|awk -F:v: '{print $2}' `
   export taillego=`cat $fictmp | grep taillego |sed '/^$/d' | sed 's/[ \t]*$//'|awk -F:v: '{print $2}' `
   export nbdbf=`cat $fictmp | grep nbdbf |sed '/^$/d' | sed 's/[ \t]*$//'|awk -F:v: '{print $2}' `
   export fsappli=`cat $fictmp | grep fsappli |sed '/^$/d' | sed 's/[ \t]*$//'|awk -F:v: '{print $2}' `
else
   export logmode="N"
   export taillego="-1"
   export nbdbf="-1"
   export fsappli="N"
fi
# -----------------------------
fi
#
if [ -z "$STA" ]
then
   STS=`echo "$R FAILED $F"`
else
   if [ $STA == "OPEN" ]
   then
      STS=`echo "$V $STA $F"`
   else
      if [ $STA == "STARTED" ] && [ "$SID" == "+ASM" ]
      then
          STS=`echo "$V $STA $F"`
      else
          STS=`echo "$R $STA $F"`
      fi
  fi
fi
#
rm -f $fictmp 1>/dev/null 2>&1
#
echo "$host;" "$SID;" "$logmode;" "$XPUVD;" "$codeappli;" "$fsappli;" "$nbdbf;" "$needbkp;" "$taillego;" "$tdpo;" "$Dem;" "$STS;" "$MSG;"
done
#
rm $listbases 1>/dev/null 2>&1
#
. $KMscript/KMlogout.sh 1>/dev/null 2>&1
#

