#!/bin/bash
# Author : Kamel Mahdhaoui
#
#
export nbsqlids=1
if [ "$1" == "" ]
then
   export nbsqlids=1
else
   export nbsqlids=$1
fi
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export KMymd=`date "+%Y%m%d"`
#
export snapids=`db_last_snapids.sh`
export d_snapid=`echo $snapids |awk -F" " '{print $1}'`
export f_snapid=`echo $snapids |awk -F" " '{print $2}'`
#
sqlplus -s "$conn"  <<EOT
--
set time off timi off echo off verify off feedback off heading off
set time off timi off echo off verify off feedback off heading off pages 0 lines 80
--
select sql_id from
 (
select 
 sql.sql_id ,sum(sql.iowait_delta)
 from
dba_hist_sqlstat sql,
dba_hist_snapshot s
 where
 s.snap_id = sql.snap_id
and
 s.snap_id between $d_snapid and $f_snapid
 group by sql.sql_id
 order by 2 desc 
) 
where rownum < 1 + $nbsqlids
;
--
exit
EOT
#
#######################################
#
#
#
