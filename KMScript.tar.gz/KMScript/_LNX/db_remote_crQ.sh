#!/bin/bash
# kma
#
# la base
if [ "$2" == "" ]
then
   echo "Usage : $0 <sid local> <RemoteSID,RemoteSID,...>"
   exit 101
else
   export LISTE_KMREMOTE_SID=$2
   export KMREMOTE=YES
   export ORACLE_SID=$1
fi
#
#
export nomPROG=db_remote_crQ.sh
export NombrePS=`ps -ef |grep $nomPROG |grep -v grep|grep ">"|wc -l`
if [ "$NombrePS" -gt 1 ]
then
   echo "Il y a deja $0 qui tourne !"
   ps -ef |grep $nomPROG |grep -v grep
   exit 103
fi
#
export LISTEMAIL="patrick.hamelin@suez-env.com,kamel.mahdhaoui@suez-env.com,sebastien.nayrolles@suez-env.com,mathieu.dailly@suez-env.com"
export LISTEMAIL="kamel.mahdhaoui@suez-env.com"
# Att : KMscript
export BINDIR=/home/oracle/kamel/KMscript
export LOGDIR=/sitr/exploit/work/log
export WORKDIR=/sitr/exploit/work/log
mkdir -p $WORKDIR $LOGDIR
chmod 775 $WORKDIR;chgrp oinstall $WORKDIR
export DATE=$(date "+%d/%m/%Y %H:%M:%S")
rm -f ${WORKDIR}/db_remote_crQ_$$.tmp* 1>/dev/null 2>&1
export SQLTMP=${WORKDIR}/db_remote_crQ_$$.tmp
export PATH=$PATH:/usr/local/bin
export PATH=$PATH:$ORACLE_HOME/bin
#
##########################
# Le sid local c est pour oracle/tns
export ORACLE_SID=$1
export ORAENV_ASK=NO
. oraenv 1>/dev/null
export ORAENV_ASK=YES
export PATH=$ORACLE_HOME/bin:$PATH
#
export myrep=$lefs
# La base c'est remote SID (liste,)
export LISTE_KMREMOTE_SID=$2
export KMREMOTE=YES
export NLS_LANG=AMERICAN_AMERICA.WE8ISO8859P15
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export LOGFILE=db_remote_crQ_${ORACLE_SID}_$KMymdhms.log
rm -f $LOGDIR/$LOGFILE 1>/dev/null 2>&1
echo " " 1> $LOGDIR/$LOGFILE 2>&1
##################################################################
for KMREMOTE_SID in `echo "$LISTE_KMREMOTE_SID"| tr "," " "`
do
echo "======================= $KMREMOTE_SID ==========================================" 1>> $LOGDIR/$LOGFILE 
for levent in `cat $BINDIR/LISTE_WAITEVENT` 
do
echo " " 1>> $LOGDIR/$LOGFILE
echo " " 1>> $LOGDIR/$LOGFILE
echo "----------------------- $levent -----------------------------------" 1>> $LOGDIR/$LOGFILE 
##################################################################
export KMREMOTE_SID
. $BINDIR/remote_oraenv 1>/dev/null;
#
export a_error_svg=0
# 
# echo $BINDIR/db_event_trends.sh 2 \"$levent\"
#
bash $BINDIR/db_event_trends.sh 2 "$levent" 1>>$LOGDIR/$LOGFILE 
#
##################################################################
done
done
##################################################################
#
export SUJET=`echo WaitEvents|tr " &" "__"` 
echo bash $BINDIR/db_remote_mailx.sh $LOGDIR/$LOGFILE CrQuotidien "$LISTEMAIL" $LISTE_KMREMOTE_SID Oui
bash $BINDIR/db_remote_mailx.sh $LOGDIR/$LOGFILE "$SUJET" "$LISTEMAIL" $LISTE_KMREMOTE_SID Oui
#
#########
#
rm -f $LOGDIR/$LOGFILE 1>/dev/null 2>&1
rm -f ${WORKDIR}/db_remote_crQ_$$.tmp* 1>/dev/null 2>&1
#
