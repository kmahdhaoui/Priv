#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# 
if [ "$2" == "" ]
then
   echo "Usage is : $0 <owner> <table>"
   exit 1
fi
export myowner=$1
export matable=$2
#
echo "========================================================================================="
#
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" 1>/dev/null 2>&1 <<EOT
@$KMscript/$SQLLOGIN
--
set lines 132
set pages 132

define 1=""
define 2=""

set feedback off
alter session set nls_date_format='yy-mm-DD hh24:mi:ss';
set feedback on
set trims on
set verify off
col table_name  format a30 trunc heading "Owner.Table"
-- col table_name  format a35 heading "Owner.Table"
--
create or replace function h2char(p clob,t char ) 
return varchar2
is 
c clob; 
v varchar2(32000); 
d date;
n number;

begin 
c:=p;
if   upper(t)='D' 
then
     if c='MAXVALUE' 
     then 
        v:='99991231235959'; 
     elsif upper(c) like '%TO_DATE%(%' 
     then  
        execute immediate 'begin :c := '||c||';end;' using out d;
        v:=to_char(d,'yyyymmddhh24miss');
     else 
        v:=null;
     end if;
elsif upper(t)='N'
then
     if c='MAXVALUE'
     then
        v:='9999999999999999'; -- 16 pos
     else
        execute immediate 'begin :c := '||c||';end;' using out n;
        v:=to_char(n);
     end if;
elsif upper(t) in ('C','V','T')
then
     if c='MAXVALUE'
     then
        v:='zzzzzzzz';
     else
        execute immediate 'begin :c := '||c||';end;' using out v;
     end if;
else
     v:=null;
end if;

return v;
end;
/
--
-- drop table tmp_km_db_show_part_p;
-- drop table tmp_km_db_show_part_sp;
--
set termout off
CREATE GLOBAL TEMPORARY TABLE tmp_km_db_show_part_p ON COMMIT PRESERVE ROWS 
as select table_owner towner,table_name tname,partition_name pname, to_lob(HIGH_VALUE) HVALUE,
PARTITION_POSITION ppos,TABLESPACE_NAME tsname from all_tab_partitions
where 1=2
;
--
CREATE GLOBAL TEMPORARY TABLE tmp_km_db_show_part_sp ON COMMIT PRESERVE ROWS
as select table_owner towner,table_name tname,partition_name pname, to_lob(HIGH_VALUE) HVALUE,
SUBPARTITION_POSITION sppos,subpartition_name spname,TABLESPACE_NAME tsname from all_tab_subpartitions
where 1=2
;
set termout on
--
exit
EOT
#
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
set feedback off
alter session set nls_date_format='yy-mm-DD hh24:mi:ss';
set feedback on
set trims on
set verify off
col table_name  format a30 trunc heading "Owner.Table"
set lines 132
set pages 555
--
col HVALUE format a20
col phv format a16
col sphv format a16
--
col towner format a10
col TNAME format a25
col PNAME format a18
col SPNAME format a18
col PSPNAME format a30
col TPNAME format a40
col ppos   format 9999
col sppos  format 9999
col psppos format a10
--
col TSNAME format a15
col pts format a15
col spts format a15
--
--------------------------------------------
set feedback off
insert into tmp_km_db_show_part_p 
select table_owner towner,table_name tname,partition_name pname, to_lob(HIGH_VALUE) HVALUE,
PARTITION_POSITION ppos,TABLESPACE_NAME tsname from all_tab_partitions
where table_owner='$myowner' and TABLE_NAME like '$matable' and TABLE_NAME not like 'BIN$%'
;
commit;
--
insert into tmp_km_db_show_part_sp 
select table_owner towner,table_name tname,partition_name pname, to_lob(HIGH_VALUE) HVALUE,
SUBPARTITION_POSITION sppos,subpartition_name spname,TABLESPACE_NAME tsname from all_tab_subpartitions
where table_owner='$myowner' and TABLE_NAME like '$matable' and TABLE_NAME not like 'BIN$%'
;
commit;
set feedback on
--------------------------------------------
--
prompt ======> Partitions
prompt ======> $1 $2
set feedback off
alter session set nls_date_format='yyyy-mm-DD';
set feedback on
select p.TNAME||'.'||p.PNAME tpname,
       to_date(h2char(p.HVALUE,'D'),'yyyymmddhh24miss') phv,
       PPOS,
       TSNAME pts 
from tmp_km_db_show_part_p p
where p.towner='$myowner' and p.Tname like '$matable'
order by 2,p.PPOS -- by phv
;
--
prompt ======> Subpartitions
prompt ======> $1 $2
set feedback off
alter session set nls_date_format='yyyy-mm-DD';
set feedback on
select -- p.tname||'.'||
       p.pname||'.'||sp.SPNAME PSPname,
       p.ppos||'->'||sp.SPPOS psppos,
       to_date(h2char(p.HVALUE,'D'),'yyyymmddhh24miss') phv,
       h2char(sp.HVALUE,'C') sphv, 
       sp.TSNAME spts
from tmp_km_db_show_part_sp sp,tmp_km_db_show_part_p p
where sp.PNAME=p.pname and sp.TNAME=p.tname and sp.towner=p.towner
and  p.towner='$myowner' and  p.Tname like '$matable' 
and  sp.towner='$myowner' and  sp.Tname like '$matable' 
order by 3,4,p.PPOS,sp.SPPOS -- by phv,sphv
;
--
set feedback off
commit;
set feedback on
--
exit
EOT
echo "========================================================================================="
#
. $KMscript/KMlogout.sh
#
