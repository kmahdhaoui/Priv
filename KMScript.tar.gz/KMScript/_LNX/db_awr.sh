#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
# NBH nb heures pour le rapport
typeset -i NBH
export NBH=$1
if [ $NBH -eq 0 ]
then 
   export NBH=3
fi
# $KSHOUTPUT:HTML/TEXT
sqlplus -s "$conn" <<EOT
-- @$KMscript/$SQLLOGIN
--
set feedback off
set echo off
col OUTPUT format a140
col BEGIN_INTERVAL_TIME format a22
col END_INTERVAL_TIME format a22
--
SELECT output
FROM TABLE(dbms_workload_repository.awr_report_$KSHOUTPUT (
(select dbid from v\$database)
,1,
(select min(snap_id) from dba_hist_snapshot where begin_interval_time > systimestamp - $NBH/24  and end_interval_time < systimestamp )
,
(select max(snap_id) from dba_hist_snapshot where begin_interval_time > systimestamp - $NBH/24  and end_interval_time < systimestamp )
))
;
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
