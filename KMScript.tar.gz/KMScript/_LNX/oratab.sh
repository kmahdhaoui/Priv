#!/bin/bash
# Author : Kamel Mahdhaoui
# 
. ~oracle/.profile 1>/dev/null 2>&1
export ORACLE_SID=+ASM
. ~oracle/kamel/KMscript/kamel.profile silent 1>/dev/null 2>&1
#
# set -x
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   return 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh 1>/dev/null 1>/dev/null 2>&1
#
export host=$(uname -n)
export DBliste=/tmp/kamel_DBliste_$$
export OK=`echo "OK"`
export KO=`echo "KO"`
#
> $DBliste
#
if [ "$host" == "dsgide" ]
then 
   export OraTab=/var/opt/oracle/oratab
else
   export OraTab=/etc/oratab
fi
cat $OraTab | sed '/^#/d' | grep -v "*" | grep -v '^db:' | grep -v '^asm:'|grep -v "lastbase" > $DBliste
#echo $DBliste
#
cat <<EOF |sort -u | grep -v '^$'| while read SID ; do
$(cat $DBliste |awk -F: '{print $1}')
$(ps -ef |grep smon|grep -v grep|awk -F_ '{print $3}'|sed 's/ //g')
EOF
# on initialise des choses
#
export oracle_sid=$SID
export oracle_home=`cat $DBliste | grep -w ^${SID} | awk -F: '{print $2}'`
#
echo $oracle_sid
#
done
#
#
rm $DBliste 1>/dev/null 2>&1
#
. $KMscript/KMlogout.sh 1>/dev/null 2>&1
#
