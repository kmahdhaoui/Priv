#!/bin/bash
# Author : Kamel Mahdhaoui
#
#
. ~oracle/.bash_profile
#
#============================================
if [ "$1" == "" ]
then
   if [ "$ORACLE_SID" == "" ]
   then 
      echo "Usage is : $0 <Base> "
      exit
   fi
else
    export ORACLE_SID=$1
fi
export ORAENV_ASK=NO
. oraenv 1>/dev/null
export ORAENV_ASK=YES
#
export PATH=$ORACLE_HOME/bin:$PATH
export leowner=CISADM
#
#============================================
#
echo "exec dbms_stats.gather_schema_stats(ownname=>'$leowner',ESTIMATE_PERCENT=>100,GRANULARITY=>'ALL',cascade=>true,degree=>48)\;"
#
date
#
sqlplus -s CISADM/CISADM <<EOT &
--
--
exec dbms_stats.gather_schema_stats(ownname=>'$leowner',ESTIMATE_PERCENT=>100,GRANULARITY=>'ALL',cascade=>true,degree=>48);
--
exit
EOT
#
date
#
#
