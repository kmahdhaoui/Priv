#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
SET LINESIZE 1000
SET TRIMOUT ON
SET TRIMSPOOL ON
SET FEEdbaCK OFF
SET VERIFY OFF


SELECT  STATUS ETAT,
TO_CHAR(START_TIME, 'DD/MM/YYYY HH24:MI:SS') DEBUT,
TO_CHAR(END_TIME, 'DD/MM/YYYY HH24:MI:SS') FIN,
TO_CHAR (TRUNC (SYSDATE) + (((ELAPSED_SECONDS/ 60) / 60) / 24), 'hh24:mi:ss') DUREE,
ROUND (OUTPUT_BYTES/1024000, 2) "TAILLE (MO)",
ROUND (COMPRESSION_RATIO, 2) COMPRESSION
FROM V\$RMAN_BACKUP_JOB_DETAILS
WHERE SESSION_KEY=(
SELECT MAX (SESSION_KEY) FROM V\$RMAN_BACKUP_JOB_DETAILS);

exit
EOT
#
. $KMscript/KMlogout.sh
#
