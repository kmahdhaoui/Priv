#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
col ACTION_TIME format a25
col ACTION format a20
col NAMESPACE format a10
col VERSION format a10
col ID a5
col BUNDLE_SERIES format a10
col COMMENTS format a25
set feedback off
prompt ...
select action_time, action, namespace, version, id, bundle_series, comments from dba_registry_history ;
prompt .....................................
select a.bundle_series||' '||ID MAX_PSU from dba_registry_history a where a.action_time in
(select max(b.action_time) from dba_registry_history b where b.bundle_series like 'PSU%') ;
prompt .....................................
--
set feedback on
exit
EOT
#
. $KMscript/KMlogout.sh
#
