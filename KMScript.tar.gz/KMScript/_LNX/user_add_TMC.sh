# chez IBM rajouter les comptes unix dans :
# /opt/eregldap/uar/configure/protectedid.dat
#
# dl5036:laurent larwence
# kq4035:adlene becis     
#
export leuser=dl5036
export leid=20001
sudo groupadd -g $leid $leuser
sudo useradd  -u $leid -g $leuser -G weblogic,oinstall $leuser
echo $leuser
echo "OK ... ?"
read reponse
sudo passwd $leuser
sudo vi /opt/eregldap/uar/configure/protectedid.dat
#
export leuser=kq4035
export leid=20002
sudo groupadd -g $leid $leuser
sudo useradd  -u $leid -g $leuser -G weblogic,oinstall $leuser
echo $leuser
echo "OK ... ?"
read reponse
sudo passwd $leuser
sudo vi /opt/eregldap/uar/configure/protectedid.dat
#

