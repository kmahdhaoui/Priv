#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn"  <<EOT
@$KMscript/$SQLLOGIN
--
set lines 132
set pages 132

define 1="$1"
define 2="$2"

set feedback off
alter session set nls_date_format='yy-mm-DD hh24:mi:ss';
set feedback on


clear breaks
clear columns
clear computes
ttitle "Table Partitions"

set trims on
set verify off
col table_name  format a30 trunc heading "Owner.Table"
-- col table_name  format a35 heading "Owner.Table"

select owner||'.'||table_name table_name
, PARTITIONING_TYPE
, SUBPARTITIONING_TYPE 
, PARTITION_COUNT
FROM dba_part_tables
WHERE DECODE(UPPER('&&1'),NULL,'x',owner) = NVL(UPPER('&&1'),'x')
AND   DECODE(UPPER('&&2'),NULL,'x',table_name) = NVL(UPPER('&&2'),'x')
and owner not like 'SYS%'
ORDER BY 1,2
/

col high_value format a20
col composite format a3 heading "CMP"
col partition_position format 999 heading "Pos"
col subpartition_count format 999 heading "Cnt"
col init_kb format 999999 heading "Init KB"
col next_kb format 999999 heading "Next KB"
col num_rows format 9999999 heading "Num Rows"
col pct_increase format 999 heading "Pct|Inc"
col partition_name format a30 heading "Part Name"
col tablespace_name format a10 heading "Tabsp Name"
break on table_name skip 1
--
--
prompt ****************** TABLES *************************
SELECT table_name,compress_for FROM dba_tables where
DECODE(UPPER('&&1'),NULL,'x',owner) = NVL(UPPER('&&1'),'x')
AND   DECODE(UPPER('&&2'),NULL,'x',table_name) = NVL(UPPER('&&2'),'x')
and compression not like 'DISAB%' and compression not like 'N/A%' and compression not like 'NONE';

prompt ****************** PARTIT *************************
SELECT table_name,partition_name,compression,compress_for FROM dba_tab_partitions where
DECODE(UPPER('&&1'),NULL,'x',table_owner) = NVL(UPPER('&&1'),'x')
AND   DECODE(UPPER('&&2'),NULL,'x',table_name) = NVL(UPPER('&&2'),'x')
and compression not like 'DISAB%' and compression not like 'N/A%' and compression not like 'NONE';

prompt ****************** SUBPAR *************************
SELECT table_name,SUBPARTITION_NAME,compression,compress_for FROM dba_tab_subpartitions where
DECODE(UPPER('&&1'),NULL,'x',table_owner) = NVL(UPPER('&&1'),'x')
AND   DECODE(UPPER('&&2'),NULL,'x',table_name) = NVL(UPPER('&&2'),'x')
and compression not like 'DISAB%' and compression not like 'N/A%' and compression not like 'NONE';
--
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
