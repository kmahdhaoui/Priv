#!/bin/bash
#
if [ "$KMscript" == "" ] 
then
   echo "Problem \$KMscript ..."
   exit 101
fi
#
cd $KMscript
#
if [ ! $# -eq 1 ] && [ ! $# -eq 0 ]
then
   echo "Usage $0 <passcode>"
   # echo "Error 1"
   exit 1
fi
#
echo -n "pass key ? "
read -t 10 -s mypasskey
if [ "$mypasskey" == "" ]
then 
   echo " "
   exit 3
fi
#
if [ "$1" == "" ]
then
   perl KMcrypt.pl $mypasskey < KMpass.dat
   if [ -r KMpass.txt ]
   then
      echo -n "Ecraser KMpass.dat depuis KMpass.txt ? ... "
      reponse=Non
      read  reponse
      if [ "$reponse" == "Oui" ]
      then
         mv KMpass.dat KMpass.dat.old
         perl KMcrypt.pl $mypasskey < KMpass.txt > KMpass.dat
         echo "OK code:pass ..."
         exit 0
      else
         echo "Non Ecrase !!!"
         exit 0
      fi
   fi
   exit 0
fi
#
export trouved=0
typeset -i trouved
export trouved=`perl KMcrypt.pl $mypasskey < KMpass.dat |grep "^$1"|wc -l ` 
if [ $trouved -eq 0 ]
then 
   # echo "Error 2"
   echo " "
   exit 2
fi
#
echo `perl KMcrypt.pl $mypasskey < KMpass.dat |grep "^$1"|awk -F: '{print $2}'`
#
exit 0
#
