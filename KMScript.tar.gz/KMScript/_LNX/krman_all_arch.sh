#!/bin/bash
# kma
#
# set before $ORACLE_HOME
#
#
# quels tbs traiter (like)
if [ "$1" == "" ]
then
   export lestbs="%"
else
   export lestbs=$1
fi
#
# les tbs a ne pas traiter (not like)
if [ "$2" == "" ]
then
   export nottbs="None"
else
   export nottbs=$2
fi
#
#
export nomPROG=krman_all_arch.sh
export NombrePS=`ps -ef |grep $nomPROG |grep -v grep|grep ">"|wc -l`
if [ "$NombrePS" -gt 1 ]
then
   echo "Il y a deja $0 qui tourne !"
   ps -ef |grep $nomPROG |grep -v grep
   exit 103
fi
#
# les variables pour le batch
. /usr/local/etc/oracle/kenv_batch.sh
#
cd $BINDIR
#
export DATE=$(date "+%d/%m/%Y %H:%M:%S")
rm -f ${WORKDIR}/krman_all_arch_$$.tmp* 1>/dev/null 2>&1
#
export SQLTMP=${WORKDIR}/krman_all_arch_$$.tmp
#
##########################
# La liste c'est les bases qui tournent
cat <<EOF |sort -u | grep -v '^$'| while read leSID ; do
$(ps -ef |grep smon|grep -v grep|grep -v '+ASM'|awk -F_ '{print $3}'|sed 's/ //g')
EOF

##############

echo bash $BINDIR/krman_arch_base.sh $leSID 
bash $BINDIR/krman_arch_base.sh $leSID 1>$LOGDIR/krman_arch_base_$leSID.$$.log 2>&1 &
sleep 30

##############
done
##########################
#
rm -f ${WORKDIR}/krman_all_arch_$$.tmp* 1>/dev/null 2>&1
#
