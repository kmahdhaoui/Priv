#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
set pages 132
set lines 132
column sid format a8
column status format a10
column OWNER format a15
column object_name format a25
column subobject_name format a25
column event format a25
column object_type format a18
--
select trim(sid) sid ,b.event,owner, object_name, subobject_name, object_type
from dba_objects o, v\$session_wait b
where 
b.p1text like 'file#' and
-- b.event like '%' and
object_id in 
(select objd from v\$bh
where	b.p2=block#
and	b.p1=file#)
/
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
