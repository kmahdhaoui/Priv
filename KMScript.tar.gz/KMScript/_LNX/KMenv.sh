#!/bin/bash
#
export PATH=$PATH:$KMscript:$ORACLE_HOME/OPatch
#
. ~oracle/kamel/KMscript/KMenv_commun.sh
#
. ~oracle/kamel/KMscript/KMenv_machinegenerique.sh
#
case $KMenv in
#.................... environnement production
Prod*)  echo "$KMhost PRODUCTION !!!"
        ;;
Prex*)  echo "$KMhost PRE-PRODUCTION !!!"
        ;;
#.................... environnement autre
*)      echo "$KMenv Perso"
        ;;
esac
#
