#!/bin/bash
#
cd ~oracle/kamel/KMscript
read toto
export toto
echo $toto
#
ssh cinstall@sefrapp00154 "sudo chmod 775 kamel/KMscript/*"
ssh cinstall@sefrapp00148 "sudo chmod 775 kamel/KMscript/*"
ssh cinstall@sefrapp00155 "sudo chmod 775 kamel/KMscript/*"
#
for lehost in sefrapp00154 sefrapp00148 sefrapp00155 sefrapp00153
do
for leuser in oracle weblogic odiadmin  zabbix  exploit dl5036  kq4035 
do
    ssh cinstall@$lehost "sudo chage -I -1 -m 0 -M 99999 -E -1 $leuser "
done
done
#
