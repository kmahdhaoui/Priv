#!/bin/ksh
# Author : Kamel Mahdhaoui
#
# set -x
#
if [ "$1" == "" ]
then
   echo "$0 $*"
   echo "Usage : $0 <Instance> <CodeInfo> <Severite> <Texte> <Objet> <MailFile> <SupFile>"
   exit 101
fi
#
if [ "$2" == "" ]
then
   echo "$0 $*"
   echo "Usage : $0 <Instance> <CodeInfo> <Severite> <Texte> <Objet> <MailFile> <SupFile>"
   exit 102
fi
#
if [ "$3" == "" ]
then
   echo "$0 $*"
   echo "Usage : $0 <Instance> <CodeInfo> <Severite> <Texte> <Objet> <MailFile> <SupFile>"
   exit 103
fi
#
if [ "$4" == "" ]
then
   echo "$0 $*"
   echo "Usage : $0 <Instance> <CodeInfo> <Severite> <Texte> <Objet> <MailFile> <SupFile>"
   exit 104
fi
#
if [ "$5" == "" ]
then
   echo "$0 $*"
   echo "Usage : $0 <Instance> <CodeInfo> <Severite> <Texte> <Objet> <MailFile> <SupFile>"
   exit 105
fi
#
if [ "$6" == "" ]
then
   echo "$0 $*"
   echo "Usage : $0 <Instance> <CodeInfo> <Severite> <Texte> <Objet> <MailFile> <SupFile>"
   exit 106
fi
#
if [ "$7" == "" ]
then
   echo "Instance=$1" 
   echo "CodeInfo=$2"
   echo "Severite$3"
   echo "Texte=$4"
   echo "Objet=$5"
   echo "MailFile=$6"
   echo "SupFile=$7"
   echo "$0 $*"
   echo "Usage : $0 <Instance> <CodeInfo> <Severite> <Texte> <Objet> <MailFile> <SupFile>"
   exit 107
fi
#
#
# $1 : instance |
# $2 : codeinfo |
# $3 : severite |
# $4 : texte    |
# $5 : Objet    |
#
# $6 : MAILFILE |
# $7 : SUPFILE  
#
# Exemple sans le codeinfo : 2015/07/30 22:45:08|SITR-DTB2-REC|RMDMEMET|ATTENTION_|tablespace 83% depasse 80%|IMDOTHERS_IDX
# severite : 10 caracteres : CRITIQUE__ , MAJEUR____ ou ATTENTION_
#
# positionner des choses pour les scripts
export KMhost=`hostname`
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export KMymd=`date "+%Y%m%d"`
#
echo -n `date +%Y/%m/%d" "%H:%M:%S`   |tee -a $6 >>$7
echo    "|$KMhost|$1|$2|$3|$4|$5"        |tee -a $6 >>$7
#
#
#

