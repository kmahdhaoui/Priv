#!/bin/bash
# Author : Kamel Mahdhaoui
#
#
if [ "$1" != "" ] 
then
   export lesqlid=$1
else
   echo "Usage is : $0 <sql ID> "
   exit 1
fi
#
if [ "$2" != "" ]
then
   export nbjour=$2
else
   export nbjour=1
fi
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export KMymd=`date "+%Y%m%d"`
#
# export Ftmp=/tmp/tmp_event_trends.$KMymdhms.tmp
# rm -f $Ftmp
#
# date
#
sqlplus -s "$conn"  <<EOT
--
set lines 132
set pages 44
--
set time off timi off echo off verify off 
set feedback off
set heading on
set pagesize 555
alter session set nls_date_format='yyyy-mm-dd hh24:mi:ss' ;
--
-- col SQL_TEXT format a10000
set long 20000
select SQL_TEXT from DBA_HIST_SQLTEXT where SQL_ID='$lesqlid'
;
col VALUE_STRING format a30
set lines 132
col name format a25
select 
SNAP_ID,SQL_ID,LAST_CAPTURED,NAME,POSITION, VALUE_STRING
from DBA_HIST_SQLBIND where SQL_ID='$lesqlid' and WAS_CAPTURED = 'YES'
and LAST_CAPTURED > trunc(sysdate) + 1 - $nbjour
and VALUE_STRING is not null
order by SQL_ID,LAST_CAPTURED,POSITION,LAST_CAPTURED,NAME
;
--
exit
EOT
#
#######################################
#
date
#
#
