#!/bin/bash
# kma
#
#
if [ "$LOGNAME" != "oracle" ]
then
   echo "$LOGNAME is not oracle !!!"
   exit 1
fi
#
#
# les variables pour le batch : on a besoin de $BACKUP_SITR_TAR
# en excluant .log .out .old .tmp .dbf .aud .trc .trm ...
#
. /usr/local/etc/oracle/kenv_batch.sh 
#
rm -f ${WORKDIR}/ktar_oracle_host_$$.tmp* 1>/dev/null 2>&1
export SQLTMP=${WORKDIR}/ktar_oracle_host_$$.tmp
#
export a_error_svg=0
#
export repsvg=$BACKUP_SITR_TAR/tars
mkdir -p $repsvg
#
# !!! tous les tars se font en relatif a partir de / en ./ !!!
cd /
#
#------------------------------------
export Chemin=./sitr/app/oracle/product/11.2.0 ; export Nom=x
for Nom in asm asm1 asm2 asm3 db db1 db2 db3 client client1 client2 client3 client32 client64
do
if [ -x "${Chemin}/${Nom}" ]
then
echo "tar -cvzf $repsvg/$LOGNAME.$Nom.$KMymdhms.tar.gz ${Chemin}/${Nom} --exclude ..."
tar -cvzf $repsvg/$LOGNAME.$Nom.$KMymdhms.tar.gz ${Chemin}/${Nom} --exclude "*/redo/*" --exclude "*/arch/*" --exclude "*/log*/*" --exclude "*.tmp*" --exclude "*.dmp*" --exclude "*.tar*" --exclude "*/temp*/*" --exclude "*/diag/*" --exclude "*/trace/*" --exclude "*.DMP*" --exclude "*.dbf*" --exclude "*.aud*" --exclude "*.out" --exclude "*.iso" --exclude "*.trc" --exclude "*.trm"
#
fi
done
#------------------------------------
export Chemin=./sitr ; export Nom=admin
if [ -x "${Chemin}/${Nom}" ]
then
echo "tar -cvzf $repsvg/$LOGNAME.$Nom.$KMymdhms.tar.gz ${Chemin}/${Nom} --exclude ..."
tar -cvzf $repsvg/$LOGNAME.$Nom.$KMymdhms.tar.gz ${Chemin}/${Nom} --exclude "*/redo/*" --exclude "*/arch/*" --exclude "*/log*/*" --exclude "*.tmp*" --exclude "*.dmp*" --exclude "*.tar*" --exclude "*/temp*/*" --exclude "*/diag/*" --exclude "*/trace/*" --exclude "*.DMP*" --exclude "*.dbf*" --exclude "*.aud*" --exclude "*.out" --exclude "*.iso" --exclude "*.trc" --exclude "*.trm"
#
fi
#
#------------------------------------
export Chemin=./sitr ; export Nom=exploit
if [ -x "${Chemin}/${Nom}" ]
then
echo "tar -cvzf $repsvg/$LOGNAME.$Nom.$KMymdhms.tar.gz ${Chemin}/${Nom} --exclude ..."
tar -cvzf $repsvg/$LOGNAME.$Nom.$KMymdhms.tar.gz ${Chemin}/${Nom} --exclude "*/redo/*" --exclude "*/arch/*" --exclude "*/log*/*" --exclude "*.tmp*" --exclude "*.dmp*" --exclude "*.tar*" --exclude "*/temp*/*" --exclude "*/diag/*" --exclude "*/trace/*" --exclude "*.DMP*" --exclude "*.dbf*" --exclude "*.aud*" --exclude "*.out" --exclude "*.iso" --exclude "*.trc" --exclude "*.trm"
#
fi
#
#------------------------------------
export Chemin=./sitr ; export Nom=oradata
if [ -x "${Chemin}/${Nom}" ]
then
echo "tar -cvzf $repsvg/$LOGNAME.$Nom.$KMymdhms.tar.gz ${Chemin}/${Nom} --exclude ..."
tar -cvzf $repsvg/$LOGNAME.$Nom.$KMymdhms.tar.gz ${Chemin}/${Nom} --exclude "*/redo/*" --exclude "*/arch/*" --exclude "*/log*/*" --exclude "*.tmp*" --exclude "*.dmp*" --exclude "*.tar*" --exclude "*/temp*/*" --exclude "*/diag/*" --exclude "*/trace/*" --exclude "*.DMP*" --exclude "*.dbf*" --exclude "*.aud*" --exclude "*.out" --exclude "*.iso" --exclude "*.trc" --exclude "*.trm"
#
fi
#
#------------------------------------
#
rm -f ${WORKDIR}/ktar_oracle_host_$$.tmp* 1>/dev/null 2>&1
rm -f $WORKDIR/$CONFILE 1>/dev/null 2>&1
#
