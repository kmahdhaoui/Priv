#!/bin/bash
#
# Alreadey set 
# export ORACLE_HOME=
# export ORA_ASM_HOME=
# export ORACLE_HOME_LISTNER=
#
# Variables defaut
#
#
if [ -r "/usr/local/etc/oracle/kenv_batch.sh" ]
then
. /usr/local/etc/oracle/kenv_batch.sh
else
ln -s -f /sitr/exploit/dba/kenv_batch.sh /usr/local/etc/oracle/kenv_batch.sh
. /usr/local/etc/oracle/kenv_batch.sh
fi
#
# export ORACLE_SID=NONE # default
export ORACLE_BASE=/sitr/app/oracle
export ORACLE_HOME_LISTNER=/sitr/app/oracle/product/11.2.0/asm
export NLS_LANG=AMERICAN_AMERICA.WE8MSWIN1252 # default
export ORA_ASM_HOME=/sitr/app/oracle/product/11.2.0/asm
#
export MW_HOME=/sitr/app/oracle/middleware
. $MW_HOME/wlserver_10.3/server/bin/setWLSEnv.sh 1>/dev/null 2>&1
#fi
#
export KMlogin_dw=cinstall # default
#
export KMscript=~oracle/kamel/KMscript
export KMlog=~oracle/kamel/KMscript/log ;mkdir -p $KMlog
export KMhost=`hostname`
#
if [ ! -r $KMscript/psw.$KMhost ]
then
   echo "$KMhost:Inco" > $KMscript/psw.$KMhost
fi
#

#
export KMenv=`grep $KMhost ~oracle/kamel/KMscript/psw.$KMhost |cut -d':' -f2`
#########################################
export PS_rouge="\[\033[1;31m\][\u@\h-$KMenv:\w]$\[\033[0m\] "
export PS_vert="\[\033[1;32m\][\u@\h-$KMenv:\w]$\[\033[0m\] "
export PS_jaune="\[\033[1;33m\][\u@\h-$KMenv:\w]$\[\033[0m\] "
export PS_magenta="\[\033[1;35m\][\u@\h-$KMenv:\w]$\[\033[0m\] "
export PS_bleu="\[\033[1;36m\][\u@\h-$KMenv:\w]$\[\033[0m\] "
export PS_autre="\[\033[1;36m\][\u@\h-$KMenv:\w]$\[\033[0m\] "
export PS_I_rouge=$PS_rouge
export PS_I_vert=$PS_vert
export PS_I_jaune=$PS_jaune
export PS_I_magenta=$PS_magenta
export PS_I_bleu=$PS_bleu
export PS_I_autre=$PS_autre
#########################################
#
export KMlogin=`logname`
export Liste_dbsingle="" # default
export Liste_dbrac="" # default
export PATH=$PATH:$KMscript:/usr/local/bin:/bin:/usr/bin
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export KMymdhm=`date "+%Y%m%d%H%M"`
export KMymdh=`date "+%Y%m%d%H"`
export KMymd=`date "+%Y%m%d"`
export KMym=`date "+%Y%m"`
export KMy=`date "+%Y"`
export LS_COLORS='di=1:fi=0:ln=31:pi=5:so=5:bd=5:cd=5:or=31:mi=0:ex=35:*.rpm=90'
#
if [ "$KMlogin" == "" ]
then 
   export KMlogin=$LOGNAME
fi
if [ "$KMlogin" == "" ]
then 
   export KMlogin=$USER
fi
#############################################################
#
# Libelles des scripts : dans fichier db_libelle_script.sh
#
#############################################################
#
# Aliases
#
#############################################################
#  linux
alias KMstatus='echo KMenv=$KMenv;echo KMhost=$KMhost;echo KMlogin=$KMlogin;echo KMlogin_dw=$KMlogin_dw;echo Liste_host_dw=$Liste_host_dw;echo Liste_dbsingle=$Liste_dbsingle;b'
#
alias mw='cd $MW_HOME'
alias sw='cd $HOME/sw'
alias mdm='cd $HOME/mdm/app/ouaf'
#
alias tartmp='$KMscript/tartmp.sh'
alias ktbs='echo "tail /sitr/exploit/sup/ktbs.sup"; tail /sitr/exploit/sup/ktbs.sup'
alias K='. $KMscript/kamel.profile';alias k=K
alias KM='cd ~oracle/kamel/KMscript';alias km=KM
# alias ksh=/usr/bin/ksh
alias sh=/usr/bin/ksh
alias vi=vi
alias ls=ls
alias ll='ls -ial'
alias ltr='ls -ltr'
alias lsd='ls -l|grep "^d"'
alias lsn='ls -l|grep "^l"'
alias lt='ls -lt'
alias dfdb='df -mP |grep $ORACLE_SID'
alias dfi2013='ksh db_dfi.sh |grep 2013'
alias df100='df -mP |grep 100%'
alias df99='df -mP |grep 99%'
alias df98='df -mP |grep 98%'
alias df97='df -mP |grep 97%'
alias df96='df -mP |grep 96%'
alias df95='df -mP |grep 95%'
alias df_m="sh $KMscript/df_m.sh"
alias dfm="sh $KMscript/df_m.sh"
alias KMpass="sh $KMscript/KMpass.sh"
alias kora='. $KMscript/kora'
alias b='$KMscript/b'
alias cdr='cd $BACKUP_SITR_RMAN'
alias cdd='cd $BACKUP_SITR_DUMP'
alias df='df -P'
alias elog='cd /sitr/exploit/log'
alias wlog='cd /sitr/exploit/work/log'
#
#############################################################
#  oracle
if [ "$KMREMOTE" != "YES" ]
then
   export conn='/ as sysdba'
   export conndba='/ as sysdba'
   export connasm='/ as sysasm'
fi
alias sql='sqlplus $conn @$KMscript/info_login.sql'
alias sysdba='sqlplus $conndba @$KMscript/info_login.sql'
alias sysasm='sqlplus $connasm @$KMscript/info_login.sql'
alias oratab='echo "----------------------------";grep -v "^#" /etc/oratab|grep oracle;echo "----------------------------"'
alias oratab.sh='oratab.sh'
alias oh='cd $ORACLE_HOME'
alias oe="env | egrep 'ORA|LANG|PATH'"
alias tns='cd /sitr/oradata/$ORACLE_SID/network'
alias dbs='cd $ORACLE_HOME/dbs'
alias fra='cd /sitr/backup/$ORACLE_SID/flash_recovery_area/'
alias bck='cd /sitr/backup/$ORACLE_SID'
alias admin='cd /sitr/backup/$ORACLE_SID/admin'
alias logasm='tail -42 $ORA_ASM_HOME/admin/+ASM/bdump/alert_+ASM.log'
alias oradb='ps -eaf | grep ora_pmon_ | grep -v grep | awk -F "_" "{print \$3}"'
#
#############################################################
# tous les db_
export LISTEDB="$KMscript/liste_libelle_script.txt"
for ii in `cat $LISTEDB|grep ":" |grep -v "^#"|grep -v "NOALIAS"|awk -F: '{print $1}' -`
do
   alias $ii="sh $KMscript/$ii.sh"
done
#
#############################################################
alias expl='cd /sitr/exploit'
alias exploit='cd /sitr/exploit'
alias arch='cd /sitr/oradata/$ORACLE_SID/arch'
alias conf='cd /sitr/admin/scripts; ll;'; 
alias adm='cd /sitr/admin/$ORACLE_SID; ll;'; 
alias trace='cd /sitr/diag/rdbms/*/$ORACLE_SID/trace; ls -ltr'
alias alert='tail -100 /sitr/diag/rdbms/*/$ORACLE_SID/trace/alert_$ORACLE_SID.log'
alias dbs='cd $ORACLE_HOME/dbs'; 
alias fsdb='df -mP  | grep $ORACLE_SID'; 
alias dbtab='cat /etc/oratab'; 
alias rtab='cat /sitr/admin/scripts/rmantab'; 
alias etns='vi /sitr/oradata/$ORACLE_SID/network/tnsnames.ora'; 
alias elsnr='vi /sitr/oradata/$ORACLE_SID/network/listener.ora';
#
#############################################################
# tous les dgm_ prd_ sec_
# dgmgrl
alias dgm='dgmgrl sys/f6tem'
alias dgm_config="sh $KMscript/dgm_config.sh"
alias dgm_status="sh $KMscript/dgm_status.sh"
#
# dataguard
alias prd_dest2status="sh $KMscript/prd_dest2status.sh"
alias prd_dest3status="sh $KMscript/prd_dest3status.sh"
alias sec_managed_stdby="sh $KMscript/sec_managed_stdby.sh"
#
#############################################################
# alias des bases locales
alias dbliste='$KMscript/oratab.sh'
alias dblist='$KMscript/oratab.sh'
#
export host=$(uname -n)
export DBliste=/tmp/kamel_DBliste_$$
export DBalias=/tmp/kamel_DBalias_$$
> $DBliste
> $DBalias
if [ "$host" == "dsgide" ]
then 
   export OraTab=/var/opt/oracle/oratab
else
   export OraTab=/etc/oratab
fi
cat $OraTab | sed '/^#/d' | grep -v "*" | grep -v '^db:' | grep -v '^asm:'|grep -v "lastbase" > $DBliste
#
cat <<EOF |sort -u | grep -v '^$'| while read SID ; do
$(cat $DBliste |awk -F: '{print $1}')
$(ps -ef |grep smon|grep -v grep|awk -F_ '{print $3}'|sed 's/ //g')
EOF
# on initialise des choses
export oracle_sid=$SID
export MAJoracle_sid=`echo $SID|tr '[:lower:]' '[:upper:]'`
export MINoracle_sid=`echo $SID|tr '[:upper:]' '[:lower:]'`
export oracle_home=`cat $DBliste | grep -w ^${SID} | awk -F: '{print $2}'`
if [ "$oracle_sid" == "+ASM" ]
then
   echo "alias +ASM=asm" >>$DBalias
   echo "alias +asm=asm" >>$DBalias
else
   echo "alias $oracle_sid=\"export ORACLE_SID=$oracle_sid;export KMREMOTE=NO;. local_oraenv;b\" " >>$DBalias
   echo "alias $MAJoracle_sid=\"export ORACLE_SID=$oracle_sid;export KMREMOTE=NO;. local_oraenv;b\" " >>$DBalias
   echo "alias $MINoracle_sid=\"export ORACLE_SID=$oracle_sid;export KMREMOTE=NO;. local_oraenv;b\" " >>$DBalias
fi
done
. $DBalias
rm $DBliste 1>/dev/null 2>&1
rm $DBalias 1>/dev/null 2>&1
#
#############################################################
# alias des bases remote 
#
alias rdbliste='$KMscript/roratab.sh'
alias rdblist='$KMscript/roratab.sh'
export host=$(uname -n)
export DBliste=/tmp/kamel_DBliste_$$
export DBalias=/tmp/kamel_DBalias_$$
> $DBliste
> $DBalias
#
ls -1 $KMscript/conn/ | sed '/^$/d' | grep -v "*" > $DBliste
#
for SID in `cat $DBliste`
do
# on initialise des choses
export remote_sid=$SID
export MAJremote_sid=`echo $SID|tr '[:lower:]' '[:upper:]'`
export MINremote_sid=`echo $SID|tr '[:upper:]' '[:lower:]'`
#
echo "alias $remote_sid=\"export KMREMOTE_SID=$remote_sid;export KMREMOTE=YES;. remote_oraenv;b\" " >>$DBalias
echo "alias $MAJremote_sid=\"export KMREMOTE_SID=$remote_sid;export KMREMOTE=YES;. remote_oraenv;b\" " >>$DBalias
echo "alias $MINremote_sid=\"export KMREMOTE_SID=$remote_sid;export KMREMOTE=YES;. remote_oraenv;b\" " >>$DBalias
#
done
. $DBalias
rm $DBliste 1>/dev/null 2>&1
rm $DBalias 1>/dev/null 2>&1
#
#############################################################
#
# Function
#
dfxx ()
{
for i in 100 99 98 97 96 95 94 93 92 91 90 89 88 87 86 85
do
df -mP |grep ${i}%
done
}
#
db ()
{
        # Environnement Oracle pour asm
        #
        $KMscript/oratab.sh 
        echo -e "db ...? \c"
        read ORACLE_SID
        export PATH=$ORACLE_HOME/bin:$PATH:$ORACLE_HOME/OPatch
        export KMREMOTE=NO
        . local_oraenv
        b
}
#
rdb ()
{
        # Environnement Oracle remote
        #
        $KMscript/roratab.sh
        echo -e "db ...? \c"
        read KMREMOTE_SID
        export KMREMOTE_SID
        export KMREMOTE=YES
        . remote_oraenv
        b
}
#
asm ()
{
        # Environnement Oracle pour asm
        #
        export ORACLE_HOME=$ORA_ASM_HOME
        export ORACLE_SID=+ASM
        export PATH=$ORACLE_HOME/bin:$PATH:$ORACLE_HOME/OPatch
        export ORAENV_ASK=NO
        . oraenv
        export ORAENV_ASK=YES
        b
}
#
arc() {
   sqlplus -s '$conn' <<EOF
     select sequence#,
            to_char(first_time, 'YYYY/MM/DD HH24:MI:SS') first_time,
            applied || '    ' APPLIED
     from v\$archived_log order by 2 ;

     archive log list
     prompt
     select process, client_process, sequence#, status, BLOCKS, BLOCK#, DELAY_MINS from v\$managed_standby;
     prompt
     select database_role, current_scn from v\$database;
EOF
}
#
