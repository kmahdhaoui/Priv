#!/bin/ksh
# Author : Kamel Mahdhaoui
#
# set -x
# db_dfi:db_dfi.sh:DATA:Tablespaces:ALIAS:
#
#export LISTEDB="$KMscript/liste_libelle_script.txt"
#cat $LISTEDB|grep ":" |grep -v "^#"|awk -F: '{print $1":SCRIPT:"$1":NOALIAS"}'
#
export LISTEDB="$KMscript/liste_libelle_script.txt"
if [ "$1" == "" ]
then
   cat $LISTEDB|grep ":" |grep -v "^#"|awk -F: '{print $3":"$4}'
   exit 
fi
# 
export ii=`basename $1 .sh`
export RET=`grep "$ii" $LISTEDB|grep ":" |grep -v "^#"|awk -F: '{print $3":"$4}' -`
if [ "$RET" == "" ]
then
   export RET=$ii
fi
echo $RET
# 
