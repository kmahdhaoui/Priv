#!/bin/bash
# Author : Kamel Mahdhaoui
#
#
if [ "$2" == "" ]
then
   echo "Usage is : $0 <fichier> <nb pieces>"
   exit 1
fi
#
export lefic=$1
export lenb=$2
export nbmax=`wc -l $lefic|awk -F" " '{print $1}'`
export pas=`expr $nbmax / $lenb`
#
export i0=0
export i=0
export j=0
while [ $nbmax -ge $i ]
do
export i0=`expr $i + 1`
export i=`expr $i + $pas`
export j=`expr $j + 1`
sed -n "${i0},${i}p" $lefic > ${lefic}.${j}.txt
done
#
#
