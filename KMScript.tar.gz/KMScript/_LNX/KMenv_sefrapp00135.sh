#!/bin/bash
# set -x
export KMlogin_dw=$LOGNAME
export KMsite=IBM
#
export PS1="\[\033[1;36m\][\u@\h:\w]$\[\033[0m\] "
export PS1="\[\033[1;36m\][\u@\h-Integ:\w]$\[\033[0m\] "
export PS1="\[\033[1;31m\][\u@\h-Prod:\w]$\[\033[0m\] "
export PS1="\[\033[1;32m\][\u@\h-Valid:\w]$\[\033[0m\] "
export PS1="\[\033[1;33m\][\u@\h-Perso:\w]$\[\033[0m\] "
#
export PS1="\[\033[1;32m\][\u@\h-Valid:\w]$\[\033[0m\] "
######################
export Liste_host_dw="sefrapp00131 sefrapp00134 sefrapp00136"
export Liste_host_info=$Liste_host_dw
# echo "$Liste_host_dw  ..........................................."
######################
#
for lehost in $Liste_host_dw
do
case $lehost  in
sefrapp*) 
   alias $lehost="echo '. kamel.profile'; ssh -X $lehost" ;;
*) 
   echo "Pour : $lehost -> Pas de Host en aval ..." ;;
esac
done
#
