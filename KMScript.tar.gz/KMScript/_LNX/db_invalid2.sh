#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col OWNER format a22
col OBJECT_TYPE format a15
col OBJECT_NAME format a35
col STATUS
set pages 555
set lines 132
--
prompt "Nombre d'Indexes ..."
select owner,count(*) NB from dba_indexes
group by owner
;
--
prompt "Nombre d' Objets ..."
select owner,count(*) NB from dba_objects
where owner not like '%SYS%'
group by owner
;
--
prompt "... Dont Indexes invalides"
select owner,table_name,index_name,status from dba_indexes where status not in ('VALID','N/A');
--
prompt "... Dont Indexes Part/ssPartitions invalides"
SELECT index_name
FROM dba_ind_partitions
WHERE status != 'USABLE'
AND
(
status != 'N/A' OR index_name IN ( SELECT index_name FROM all_ind_subpartitions WHERE status != 'USABLE')
) 
;

--
prompt "... Dont Objets invalides"
select 'alter '||object_type||' '||owner||'.'||object_name||' compile;' from dba_objects
where owner not like '%SYS%'  and status != 'VALID'
;

exit
EOT
#
. $KMscript/KMlogout.sh
#
