#
# Author : Kamel Mahdhaoui
# Unautorized use is forbidden 
sqlplus -s "$conn" <<EOT
col RDBF format "9999999"
set pages 0
set feedb off
set verify off
set echo off
--
SELECT 100* a.VALUE/b.VALUE RDBF FROM V\$SYSSTAT a,V\$SYSSTAT b
WHERE a.NAME = 'redo buffer allocation retries'
and b.NAME = 'redo writes'
;
exit
EOT
#
