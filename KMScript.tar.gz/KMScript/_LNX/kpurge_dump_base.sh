#!/bin/bash
# kma
#
# set before $ORACLE_HOME
#
#
# la base
if [ "$1" == "" ]
then
   echo "Usage is : $0 <Base>"
  exit 101
else
   export leSID=$1
fi
#
# les variables pour le batch dont WINDOW_DUMP et WINDOW_RMAN
export ORACLE_SID=$leSID
. /usr/local/etc/oracle/kenv_batch.sh $leSID
. $BINDIR/kenv_nls.sh
#
cd $BINDIR
#
rm -f ${WORKDIR}/kpurge_dump_base_$$.tmp* 1>/dev/null 2>&1
#
export SQLTMP=${WORKDIR}/kpurge_dump_base_$$.tmp
#
export MAJoracle_sid=`echo $ORACLE_SID|tr '[:lower:]' '[:upper:]'`
export MINoracle_sid=`echo $ORACLE_SID|tr '[:upper:]' '[:lower:]'`
#
export a_error_svg=0
#
#
export myrep=$BACKUP_SITR_DUMP
mkdir -p $myrep
#
export LOGFILE=kpurge_dump_base_${ORACLE_SID}_FULL_$KMymdhms.log
export CONFILE=kpurge_dump_base_${ORACLE_SID}_FULL_$KMymdhms.cfg
#
##################################################################
#
# dump
find $BACKUP_SITR_DUMP -name "*${ORACLE_SID}*.dmp" -mtime +${WINDOW_DUMP} -exec rm -f {} \; 
find $BACKUP_SITR_DUMP -name "*${ORACLE_SID}*.log" -mtime +${WINDOW_DUMP} -exec rm -f {} \; 
#
#
###################################################################
#
# cp -f $LOGDIR/$LOGFILE $myrep 1>/dev/null 2>&1
# cp -f $WORKDIR/$CONFILE $myrep 1>/dev/null 2>&1
#
rm -f ${WORKDIR}/kpurge_dump_base_$$.tmp* 1>/dev/null 2>&1
rm -f $WORKDIR/$CONFILE 1>/dev/null 2>&1
#
