# date "+%Y%m%d"
cd
#
cd /sitr/app/mdm/app
tar -cvf /sitr/backup/mdm_ouaf_`hostname`_`date "+%Y%m%d"`.tar ./ouaf
mv -f mdm_ouaf*.tar.gz /tmp
gzip /sitr/backup/mdm_ouaf_`hostname`_*.tar
#
cd /sitr/app/oracle/middleware/user_projects/domains
tar -cvf /sitr/backup/mdm_domain_`hostname`_`date "+%Y%m%d"`.tar ./mdm_domain
mv -f mdm_domain*.tar.gz /tmp
gzip /sitr/backup/mdm_domain_`hostname`_*.tar
#
cd /sitr/backup/
echo sitr2014
scp *.tar.gz weblogic@sefrapp00153:/sitr/backup/
# scp *.tar.gz sefrapp00154:/sitr/backup/
#
#
