#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
set pages 132 lines 200

col SID format 999999
col SPID format 999999
col USERNAME format a20
col MACHINE format a15
col program format a44
set lines 155

col OPERATION format a12
col OWNER_NAME format a12
col JOB_MODE format a12
col nb_sess format 99999
col dp_sess format 99999
col state format a15


-- SESSIONS
!echo "-- SESSIONS "
select distinct ss.sid, ss.MACHINE,ss.PROGRAM , pp.spid SPID ,d.SESSION_TYPE,d.job_name
from v\$session ss, dba_datapump_sessions d,v\$process pp
where ss.saddr = d.saddr
and pp.addr=ss.paddr
order by ss.sid
;
--
-- JOBS
!echo "-- JOBS "
SELECT owner_name, job_name, rtrim(operation) "OPERATION",
       rtrim(job_mode) "JOB_MODE", state, attached_sessions
  FROM dba_datapump_jobs
 WHERE job_name NOT LIKE 'BIN$%'
 ORDER BY 1,2
;
-- where state not like 'NOT RUNNING'
exit
EOT
#
. $KMscript/KMlogout.sh
#
