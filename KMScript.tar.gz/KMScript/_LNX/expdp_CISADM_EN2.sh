#!/bin/bash
#
export NLS_LANG=AMERICAN_AMERICA.WE8MSWIN1252
export a_error_svg=0
#
b
#
export myrep=/sitr/backup/$ORACLE_SID/dump
mkdir -p $myrep
cp $ORACLE_SID.EN2_?.CISADM.par $myrep/
#
echo "$myrep >>>>>>>>>>>>>>>>>>>>>>"
ls -ltr $myrep/$ORACLE_SID.EN2_?.CISADM*
echo "$myrep <<<<<<<<<<<<<<<<<<<<<<"
#
echo "BASE : $ORACLE_SID"
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export FLASHBACK_TIME="TO_TIMESTAMP('$KMymdhms','YYYYMMDDHH24MISS')"
sleep 5
#
cd $myrep
#
sqlplus '/ as sysdba' <<EOT
create or replace DIRECTORY kamel as '$myrep/';
exit
EOT
#
# parfile : $ORACLE_SID.EN2_?.CISADM.par
#
# COMPRESSION=all
# dumpfile=$ORACLE_SID.EN2_?.CISADM.%u.dmp
# logfile=$ORACLE_SID.EN2_?.CISADM.log
# exclude=statistics
# exclude=TABLE:\"LIKE \'SYS_IMPORT%\'\"
# exclude=TABLE:\"LIKE \'SYS_IMPORT%\'\"
# exclude=TABLE:\"LIKE \'SYS_EXPORT%\'\"
# exclude=TABLE:\"LIKE \'Q%_CONSO_%\'\"
# exclude=TABLE:\"LIKE \'ID_DOUBLONS%\'\"
# exclude=TABLE:\"LIKE \'HORS_Q%_CONSO_%\'\"
# exclude=TABLE:\"LIKE \'DOUBLE_Q%_CONSO%\'\"
# exclude=TABLE:\"LIKE \'DP_1%_%B\'\"
# exclude=TABLE:\"LIKE \'DP_1%_%A\'\"
# exclude=TABLE:\"LIKE \'TEST%NLAO%\'\"
# exclude=TABLE:\"LIKE \'KK\'\"
# exclude=TABLE:\"LIKE \'PLAN_TABLE\'\"
# exclude=TABLE:\"LIKE \'TOAD_PLAN_TABLE\'\"
#
# expdp "cisadm/cisadm" FLASHBACK_TIME=systimestamp-1/96 schemas=CISADM directory=kamel parfile=$ORACLE_SID.EN2_?.CISADM.par 
set -x
#echo "DATA but not for all tables ..."
#expdp "cisadm/kamel" schemas=CISADM directory=kamel parfile=$ORACLE_SID.EN2_1.CISADM.par  
set +x
echo "metata ONLY for the other tables ..."
set -x
expdp "cisadm/kamel" directory=kamel parfile=$ORACLE_SID.EN2_2.CISADM.par 
set +x
#
echo "RetCode : $?"
#
ls -ltr $myrep/$ORACLE_SID.EN2_?.CISADM*
#
