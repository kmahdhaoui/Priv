#!/bin/bash
#
export NLS_LANG=AMERICAN_AMERICA.WE8MSWIN1252
export a_error_svg=0
#
    oratab.sh;
    echo -e "db ...? \c";
    read ORACLE_SID;
    export PATH=$ORACLE_HOME/bin:$PATH:$ORACLE_HOME/OPatch;
    export ORAENV_ASK=NO;
    . oraenv;
    export ORAENV_ASK=YES;
    b
#
echo "BASE : $ORACLE_SID"
echo "OK ... ? <Enter> or <CTRL-C> : "
read toto
#
export myrep=/sitr/backup/$ORACLE_SID/dump
mkdir -p $myrep
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export FLASHBACK_TIME="TO_TIMESTAMP('$KMymdhms','YYYYMMDDHH24MISS')"
sleep 5
#
cd $myrep
#
sqlplus '/ as sysdba' <<EOT
create or replace DIRECTORY kamel as '$myrep/';
exit
EOT
#
#
#expdp "'/ as sysdba'" FLASHBACK_TIME=\"$FLASHBACK_TIME\" schemas=CISADM directory=kamel parallel=4 COMPRESSION=all dumpfile=$ORACLE_SID.$KMymdhms.CISADM.%u.dmp logfile=$ORACLE_SID.$KMymdhms.CISADM.log exclude=statistics
#
echo expdp "'/ as sysdba'" FLASHBACK_TIME=systimestamp-1/96 schemas=CISADM directory=kamel parallel=4 COMPRESSION=all dumpfile=$ORACLE_SID.$KMymdhms.CISADM.%u.dmp logfile=$ORACLE_SID.$KMymdhms.CISADM.log exclude=statistics
#
echo "RetCode : $?"
#
ls -ltr $myrep
#
