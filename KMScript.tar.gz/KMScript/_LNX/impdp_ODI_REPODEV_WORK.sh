# alter session set DEFERRED_SEGMENT_CREATION=false ;
#
# export ORACLE_SID=ISITREMT
export SITR_APP=ODI_REPODEV_WORK
export KMymdhms=`date "+%Y%m%d%H%M%S"`
#
export SITR_DMP=${SITR_APP}_${KMymdhms}_%U.dmp
export SITR_LOG=${SITR_APP}_${KMymdhms}.log
#
# pour l'import :
export KMymdhms=20150305111116
export SITR_DMP=${SITR_APP}_${KMymdhms}_%U.dmp
export SITR_LOG=${SITR_APP}_${KMymdhms}.imp.log
#
sqlplus "/ as sysdba" <<EOT
create or replace directory kamel as '/sitr/backup/ISITREMT/dump/' ;
exit
EOT
#
# query="nom_schema1.nom_table1:where rownum<1"
# query="nom_schema2.nom_table2:where rownum<1"
# echo QUERY="${SITR_APP}.EMT_LOT:WHERE rownum<1"> expAPP_Restrict_LOT.par
#
# expdp "'/ as sysdba'" DIRECTORY=kamel CONTENT=ALL PARALLEL=8 SCHEMAS=${SITR_APP} DUMPFILE=${SITR_DMP} LOGFILE=${SITR_LOG} PARFILE=expAPP_Restrict_LOT.par compression=ALL
#
impdp "'/ as sysdba'" DIRECTORY=kamel CONTENT=ALL PARALLEL=8 SCHEMAS=${SITR_APP} DUMPFILE=${SITR_DMP} LOGFILE=${SITR_LOG} 
#
#
