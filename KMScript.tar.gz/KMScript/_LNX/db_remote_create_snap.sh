#!/bin/bash
# Author : Kamel Mahdhaoui
#
#
if [ "$1" == "" ]
then
   echo "Usage : $0 <SidLocal> <RemoteSid> "
   echo "      : Sid local absent (necessaire pour tns ... !"
   exit 101
fi
#
if [ "$2" == "" ]
then
   echo "Usage : $0 <SidLocal> <RemoteSid> "
   echo "      : Remote Sid absent ... !"
   exit 102
else
   export KMREMOTE_SID=$2
   export KMREMOTE=YES
   export ORACLE_SID=$1
fi
#
#
export PATH=$PATH:/usr/local/bin
export BINDIR=/home/oracle/kamel/KMscript
export KMscript=$BINDIR
cd $BINDIR
#
##########################
# Le sid local c est pour oracle/tns
export ORACLE_SID=$1
export ORAENV_ASK=NO
. /usr/local/bin/oraenv 1>/dev/null
export ORAENV_ASK=YES
export PATH=$ORACLE_HOME/bin:$PATH
#
# La base c'est remote SID 
export KMREMOTE_SID=$2
export KMREMOTE=YES
. $BINDIR/remote_oraenv 1>/dev/null
#
sqlplus -s "$conn" <<EOT
--
EXEC dbms_workload_repository.create_snapshot;
--
exit
EOT
#
date
#
