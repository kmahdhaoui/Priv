#
#
#
export myrep=/sitr/backup/$ORACLE_SID/dump
#
sqlplus / as sysdba <<EOT
--
create or replace DIRECTORY kamel as '$myrep/';
--
drop sequence CISADM.CIFKVALSEQ ;
drop sequence CISADM.CI_LOGID_SEQ ;
drop sequence CISADM.CI_NTUPID_SEQ ;
drop sequence CISADM.F1_COL_SEQ ;
drop sequence CISADM.SEQ_MIG_DATA_MSRT_204 ;
exit
EOT
#
impdp "'/ as sysdba'" schemas=CISADM PARALLEL=4 EXCLUDE=INDEX,constraint directory=kamel dumpfile=CISADM_AM.dmp logfile=imp_data_AM_kamel_$$.log table_exists_action=truncate
#
impdp "'/ as sysdba'" schemas=CISADM PARALLEL=4 CONTENT=METADATA_ONLY INCLUDE=INDEX,constraint directory=kamel dumpfile=CISADM_AM.dmp logfile=imp_indx_AM_kamel_$$.log 
#
# impdp "'/ as sysdba'" schemas=CISADM directory=kamel dumpfile=CISADM_AM.dmp logfile=imp_AM_kamel_$$.log table_exists_action=truncate
#
# impdp "'/ as sysdba'" schemas=CISADM directory=kamel dumpfile=CISADM_AM.dmp logfile=imp_seq_AM_kamel_$$.log include=SEQUENCE sqlfile=seqseq.sql
#
nohup bash copie_TO_cm_tables.sh 1>copie_TO_cm_tables.out 2>&1 &
#
grep "ORA-" imp_actions_metier_parallel.out |grep -v ORA-31684|grep -v ORA-39111
echo "grep \"ORA-\" imp_actions_metier_parallel.out |grep -v ORA-31684|grep -v ORA-39111"
echo tail -f copie_TO_cm_tables.out
#
