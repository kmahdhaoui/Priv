#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
export LISTE_DB=""
export mydb=""
for mydb in $Liste_dbsingle
do
export ORACLE_SID=$mydb
export mydbrole=`bash $KMscript/db_role.sh $ORACLE_SID`
case $mydbrole  in
    PRIMARY*) export LISTE_DB="$LISTE_DB $ORACLE_SID" ;;
    *)        export LISTE_DB="$LISTE_DB" ;;
esac
done
#
export mydb=""
for mydb in $LISTE_DB
#################################################
do
export ORACLE_SID=$mydb
export ORAENV_ASK=NO
. oraenv
export ORAENV_ASK=YES
#
cd ~oracle/kamel/KMscript
mkdir -p log
mkdir -p svg
date          				1> awr_${KMsite}_${KMhost}_${ORACLE_SID}_${KMymd}.txt
sh db_fra.sh  				1>>awr_${KMsite}_${KMhost}_${ORACLE_SID}_${KMymd}.txt
sh db_asm.sh  				1>>awr_${KMsite}_${KMhost}_${ORACLE_SID}_${KMymd}.txt
echo "Top 5 Timed Events" 		1>>awr_${KMsite}_${KMhost}_${ORACLE_SID}_${KMymd}.txt
echo "Segments by Logical Reads" 	1>>awr_${KMsite}_${KMhost}_${ORACLE_SID}_${KMymd}.txt
echo "Segments by Physical Reads" 	1>>awr_${KMsite}_${KMhost}_${ORACLE_SID}_${KMymd}.txt
echo "Segments by Row Lock Waits" 	1>>awr_${KMsite}_${KMhost}_${ORACLE_SID}_${KMymd}.txt
echo "SQL ordered by CPU Time"		1>>awr_${KMsite}_${KMhost}_${ORACLE_SID}_${KMymd}.txt
echo "SQL ordered by Reads" 		1>>awr_${KMsite}_${KMhost}_${ORACLE_SID}_${KMymd}.txt
echo "SQL ordered by Executions" 	1>>awr_${KMsite}_${KMhost}_${ORACLE_SID}_${KMymd}.txt
echo " " 				1>>awr_${KMsite}_${KMhost}_${ORACLE_SID}_${KMymd}.txt
sh db_awr.sh 250  			1>>awr_${KMsite}_${KMhost}_${ORACLE_SID}_${KMymd}.txt   # 10jours et 6 heures
#
sqlplus -s '/ as sysdba' <<EOT
@$KMscript/$SQLLOGIN
--
spool stats_${KMsite}_${KMhost}_${ORACLE_SID}_${KMymd}.txt
set verify off 
set echo off
set feedback off
set colsep";"
set lines  250
set pages 1000
@$KMscript/KMstats ${KMhost}
prompt " "
prompt " "
spool off
exit
EOT
#
#
cd ~oracle/kamel/KMscript
mv -f awr_*.txt log 2>/dev/null
mv -f stats_*.txt log 2>/dev/null
gzip -f log/awr_*.txt
gzip -f log/stats_*.txt
#
#################################################
done
#
. $KMscript/KMlogout.sh
#
