#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
set pages 555
set lines 132
col TRIGGERING_EVENT format a22
select OWNER,TRIGGER_NAME,TRIGGER_TYPE ,TRIGGERING_EVENT from dba_triggers
where TRIGGERING_EVENT like 'START%' or TRIGGERING_EVENT like 'SHUT%'
/
--
-------------------------------------------------------
/*
SET LONG 2000000
SET PAGESIZE 0
execute DBMS_METADATA.SET_TRANSFORM_PARAM(DBMS_METADATA.SESSION_TRANSFORM,'STORAGE',false);
execute DBMS_METADATA.SET_TRANSFORM_PARAM(DBMS_METADATA.SESSION_TRANSFORM,'PRETTY',true);
execute DBMS_METADATA.SET_TRANSFORM_PARAM(DBMS_METADATA.SESSION_TRANSFORM,'SQLTERMINATOR',true);

select DBMS_METADATA.GET_DDL('TRIGGER','ACTIVE_SERVICE_TRG','SYS') from dual;

EXECUTE DBMS_METADATA.SET_TRANSFORM_PARAM(DBMS_METADATA.SESSION_TRANSFORM,'DEFAULT');
*/
-------------------------------------------------------
--
exit
EOT
#
#-- CREATE OR REPLACE TRIGGER "SYS"."ACTIVE_SERVICE_TRG" after startup on database
#-- DECLARE
#--   role VARCHAR(30);
#-- BEGIN
#--   SELECT DATABASE_ROLE INTO role FROM V$DATABASE;
#--   IF role = 'PRIMARY' THEN
#--     DBMS_SERVICE.START_SERVICE('bol_rw');
#--     DBMS_SERVICE.START_SERVICE('bol_batch_rw');
#--     DBMS_SERVICE.START_SERVICE('bol_oltp_rw');
#--     DBMS_SERVICE.START_SERVICE('eco_rw');
#--     DBMS_SERVICE.START_SERVICE('eco_batch_rw');
#--     DBMS_SERVICE.START_SERVICE('eco_low_rw');
#--     DBMS_SERVICE.START_SERVICE('eco_oltp_rw');
#--   END IF;
#-- END;
#-- /
#-- ALTER TRIGGER "SYS"."ACTIVE_SERVICE_TRG" ENABLE;
#
. $KMscript/KMlogout.sh
#
