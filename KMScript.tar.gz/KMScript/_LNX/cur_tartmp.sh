#!/bin/bash
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
#
export nom=`pwd`
export nom=`echo $nom|tr '/' '_'|tr -d 'a'|tr -d 'e'|tr -d 'i'|tr -d 'o'|tr -d 'u'`
export nom=SVG_$nom
#
tar -cvf /tmp/$nom.$KMymdhms.tar ./ --exclude "*log*" --exclude "*tmp*" --exclude "*dmp*" --exclude "*tar*" --exclude "*temp*" --exclude "*diag*" --exclude "*trace*" --exclude "*DMP*"
gzip /tmp/$nom.$KMymdhms.tar &
#
ll /tmp/$nom.$KMymdhms.tar*
#
