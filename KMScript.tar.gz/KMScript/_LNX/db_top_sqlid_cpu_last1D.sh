#!/bin/bash
# Author : Kamel Mahdhaoui
#
#
if [ "$1" != "" ]
then
   export nbjour=$1
else
   export nbjour=1
fi
#
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export KMymd=`date "+%Y%m%d"`
#
# export Ftmp=/tmp/tmp_event_trends.$KMymdhms.tmp
# rm -f $Ftmp
#
# date
#
sqlplus -s "$conn"  <<EOT
--
set lines 132
set pages 44
--
set time off timi off echo off verify off feedback off 
set heading on
set pagesize 555
--
col username format a26
col sid format 9999
col state format a18
col event format a40
col wait_time format 99999999
col CPU_TIME_DELTA format 999,999,999,999,999
col DISK_READS_DELTA format 999,999,999,999,999
col Comptage format 999,999,999
--
select * from (
select
	SQL_ID,
	sum(CPU_TIME_DELTA) CPU_TIME_DELTA,
	sum(DISK_READS_DELTA) DISK_READS_DELTA ,
	count(*) Comptage
from
	DBA_HIST_SQLSTAT a, dba_hist_snapshot s
where
 s.snap_id = a.snap_id
 and s.begin_interval_time > trunc(sysdate) + 1 - $nbjour
	group by
	SQL_ID
order by
	2 desc
)
where rownum < 11
/
--
exit
EOT
#
#######################################
#
date
#
#
