#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s '/ as sysdba' <<EOT
@$KMscript/$SQLLOGIN
--
set lines 132
set pages 132
col ArchApp format a15 heading "Archived -|Applied Thread"
--
select substr(DESTINATION,1,10) DEST_3,DATABASE_MODE,RECOVERY_MODE, PROTECTION_MODE,
ARCHIVED_THREAD# || '/'||ARCHIVED_SEQ# ||' - '||APPLIED_THREAD#|| '/'||APPLIED_SEQ# ArchApp ,
SYNCHRONIZED SYNC,SYNCHRONIZATION_STATUS SYNC_STATUS,STATUS DEST3_STATUS
from v\$ARCHIVE_DEST_STATUS
where DEST_NAME like 'LOG_ARCHIVE_DEST_3'
;
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
