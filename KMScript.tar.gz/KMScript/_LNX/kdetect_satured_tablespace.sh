#!/bin/bash
# kma
#
# set before $ORACLE_HOME
# $0 % None 80 90 95
#
# quels tbs traiter (like)
if [ "$1" == "" ]
then
   export lestbs="%"
else
   export lestbs=$1
fi
#
# les tbs a ne pas traiter (not like)
if [ "$2" == "" ]
then
   export nottbs="None"
else
   export nottbs=$2
fi
#
# seuils c'est $3 $4 et $5
if [ "$3" == "" ]
then
   export SEUIL_1=80
else
   export SEUIL_1=$3
fi
#
if [ "$4" == "" ]
then
   export SEUIL_2=90
else
   export SEUIL_2=$4
fi
#
if [ "$5" == "" ]
then
   export SEUIL_3=95
else
   export SEUIL_3=$5
fi
#
# les variables pour le batch
. /usr/local/etc/oracle/kenv_batch.sh
#
cd $BINDIR
#
rm -f ${WORKDIR}/kresult_tbs_$$.tmp* 1>/dev/null 2>&1
#
export SUPFILE_OLD=$SUPTBSFILE_OLD
export SUPFILE_NEW=$SUPTBSFILE_NEW
export SUPFILE=$SUPTBSFILE
export MAILFILE=$MAILTBSFILE
#
rm -f $MAILFILE
tail -100 $SUPFILE > $SUPFILE_OLD
#
#
export SQLTMP=${WORKDIR}/kresult_tbs_$$.tmp
export FICTMP=${WORKDIR}/ktmp_tbs_$$.tmp
#
##########################
export ListeDesSID=""
# La liste c'est les bases qui tournent
cat <<EOF |sort -u | grep -v '^$'| while read leSID ; do
$(ps -ef |grep smon|grep -v grep|grep -v '+ASM'|awk -F_ '{print $3}'|sed 's/ //g')
EOF
#
if [ "$ListeDesSID" == "" ]
then
   export ListeDesSID="$leSID"
else
   export ListeDesSID="${ListeDesSID},$leSID"
fi
#
export ORACLE_SID=$leSID
. /usr/local/etc/oracle/kenv_batch.sh $leSID
. $BINDIR/kenv_nls.sh
#
sqlplus -s '/ as sysdba' 1>/dev/null 2>&1 <<EOT
set echo off heading off feedback off verify off
--
whenever sqlerror exit 1; 
whenever oserror exit 2; 
--
spool $SQLTMP.$leSID.2
-- tbs;allocable;occup;true_pct_used 
select aa.TABLESPACE_NAME||';'||to_char(round(aa.Allocable))||';'||
to_char(round(nvl(aa.allocated,0)-nvl(bb.libre,0)))||';'||
to_char(round(100*(nvl(aa.allocated,0)-nvl(bb.libre,0))/(aa.Allocable+1))) ligne from 
(
SELECT a.TABLESPACE_NAME,
sum(decode(AUTOEXTENSIBLE,'YES',nvl(bytes,0)+least(nvl(MAXBYTES,0)-nvl(bytes,0),b.free_b/1),nvl(BYTES,0))/1024/1024) Allocable,
sum(nvl(BYTES,0))/1024/1024 Allocated
FROM DBA_DATA_FILES a ,
(SELECT dg.name,sum(dg.free_mb)*1024*1024/count(distinct c.file_name) free_b FROM v\$asm_diskgroup dg ,DBA_DATA_FILES c
where c.file_name like '+'||dg.name||'/%'
group by dg.NAME
) b
where a.file_name like '+'||b.name||'/%'
and a.TABLESPACE_NAME like '$lestbs'
and a.TABLESPACE_NAME not like '$nottbs'
group by a.TABLESPACE_NAME
) aa ,
(
select 	TABLESPACE_NAME,
sum(nvl(BYTES,0)/1024/1024) libre 
from 	dba_free_space 
where   TABLESPACE_NAME like '$lestbs'  and TABLESPACE_NAME not like '$nottbs'
group 	by TABLESPACE_NAME
) bb
where aa.TABLESPACE_NAME=bb.TABLESPACE_NAME (+) 
and aa.TABLESPACE_NAME like '$lestbs' 
and aa.TABLESPACE_NAME not like '$nottbs' 
and round(100*(nvl(aa.allocated,0)-nvl(bb.libre,0))/(aa.Allocable+1)) > $SEUIL_1
/
exit 0
EOT
#
export STATUS=$?
if [ $STATUS != 0 ]
then
   echo "Erreur $0 : $STATUS : SQL/OS 1/2 ..." >&2
   exit 3
fi
#
sed '/^$/d' ${SQLTMP}.$leSID.2 >${SQLTMP}.$leSID.1
export nb=`cat ${SQLTMP}.$leSID.1|wc -l`
#
##############
for ((i=1;i<=$nb;i++))
do
export tbs=`sed -n ${i}p ${SQLTMP}.$leSID.1|awk -F";" '{print $1}'`
export seuil=`sed -n ${i}p ${SQLTMP}.$leSID.1|awk -F";" '{print $4}'`
export SEUIL=`echo $seuil`
export seuil=$SEUIL
#
#echo $tbs $seuil $SEUIL_1 $SEUIL_2 $SEUIL_3
#
#set -x
if [ ${seuil} -ge $SEUIL_3 ] 
then 
   # bash db_logsup.sh <Instance> <CodeInfo> <Severite> <Texte> <Objet> <MailFile> <SupFile>
   export LInstance="$leSID"
   export CodeInfo="AlerteTablespace"
   export LaSeverite="CRITIQUE__"
   export LeTexte="tablespace ${seuil}% a depasse ${SEUIL_3}%"
   export LObjet=`sed -n ${i}p ${SQLTMP}.$leSID.1|awk -F";" '{print $1}'`
   export LeMailFile="$MAILFILE"
   export LeSupFile="$SUPFILE"
   bash db_logsup.sh "$LInstance" "$CodeInfo" "$LaSeverite" "$LeTexte" "$LObjet" "$LeMailFile" "$LeSupFile"
   # en double pour test
   #echo -n `date +%Y/%m/%d" "%H:%M:%S` 					|tee -a $MAILFILE >>$SUPFILE
   #echo -n "|"`hostname`"|$leSID|CRITIQUE__|tablespace ${seuil}%" 	|tee -a $MAILFILE >>$SUPFILE
   #echo -n " depasse ${SEUIL_3}%|" 				 	|tee -a $MAILFILE >>$SUPFILE
   #echo    `sed -n ${i}p ${SQLTMP}.$leSID.1|awk -F";" '{print $1}'` 	|tee -a $MAILFILE >>$SUPFILE
#
else
   if [ ${seuil} -ge $SEUIL_2 ] 
   then 
      # bash db_logsup.sh <Instance> <CodeInfo> <Severite> <Texte> <Objet> <MailFile> <SupFile>
      export LInstance="$leSID"
      export CodeInfo="AlerteTablespace"
      export LaSeverite="MAJEUR____"
      export LeTexte="tablespace ${seuil}% depasse ${SEUIL_2}%"
      export LObjet=`sed -n ${i}p ${SQLTMP}.$leSID.1|awk -F";" '{print $1}'`
      export LeMailFile="$MAILFILE"
      export LeSupFile="$SUPFILE"
      bash db_logsup.sh "$LInstance" "$CodeInfo" "$LaSeverite" "$LeTexte" "$LObjet" "$LeMailFile" "$LeSupFile"
      # en double pour test
      #echo -n `date +%Y/%m/%d" "%H:%M:%S` 				|tee -a $MAILFILE >>$SUPFILE
      #echo -n "|"`hostname`"|$leSID|MAJEUR____|tablespace ${seuil}%" 	|tee -a $MAILFILE >>$SUPFILE
      #echo -n " depasse ${SEUIL_2}%|" 					|tee -a $MAILFILE >>$SUPFILE
      #echo    `sed -n ${i}p ${SQLTMP}.$leSID.1|awk -F";" '{print $1}'`	|tee -a $MAILFILE >>$SUPFILE
   #
   else
      if [ ${seuil} -ge $SEUIL_1 ] 
      then 
         # bash db_logsup.sh <Instance> <CodeInfo> <Severite> <Texte> <Objet> <MailFile> <SupFile>
         export LInstance="$leSID"
         export CodeInfo="AlerteTablespace"
         export LaSeverite="ATTENTION_"
         export LeTexte="tablespace ${seuil}% depasse ${SEUIL_1}%"
         export LObjet=`sed -n ${i}p ${SQLTMP}.$leSID.1|awk -F";" '{print $1}'`
         export LeMailFile="$MAILFILE"
         export LeSupFile="$SUPFILE"
         bash db_logsup.sh "$LInstance" "$CodeInfo" "$LaSeverite" "$LeTexte" "$LObjet" "$LeMailFile" "$LeSupFile"
         # en double pour test
         #echo -n `date +%Y/%m/%d" "%H:%M:%S` 					|tee -a $MAILFILE >>$SUPFILE
         #echo -n "|"`hostname`"|$leSID|ATTENTION_|tablespace ${seuil}%" 	|tee -a $MAILFILE >>$SUPFILE
         #echo -n " depasse ${SEUIL_1}%|" 					|tee -a $MAILFILE >>$SUPFILE
         #echo    `sed -n ${i}p ${SQLTMP}.$leSID.1|awk -F";" '{print $1}'` 	|tee -a $MAILFILE >>$SUPFILE
      fi
      #
   fi
   #
fi
#set +x
#
done
##############
echo "export ListeDesSID=$ListeDesSID" > $FICTMP
done
. $FICTMP
echo $ListeDesSID
##########################
#
#
tail -100 $SUPFILE > $SUPFILE_NEW
export NBR=`diff $SUPFILE_OLD $SUPFILE_NEW |wc -l `
if [ "$NBR" -ne 0 ]
then
   #
   if [ -r $MAILFILE ]
   then
   echo bash $BINDIR/db_mailx.sh $MAILFILE AlerteTablespace "$LISTEMAIL" "$ListeDesSID"
   bash $BINDIR/db_mailx.sh $MAILFILE AlerteTablespace "$LISTEMAIL" "$ListeDesSID"
   echo " "
   fi
#
fi
#
rm -f ${WORKDIR}/kresult_tbs_$$.tmp* 1>/dev/null 2>&1
rm -f ${WORKDIR}/ktmp_tbs_$$.tmp* 1>/dev/null 2>&1
#
