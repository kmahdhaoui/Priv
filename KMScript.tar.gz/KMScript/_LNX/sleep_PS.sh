#!/bin/bash
#
# $0 <grep_1> <grep_2> <limite> <secondes>
# Attente si plus de LIMITE_NBPROC GREP_1 GREP_2 sur la machine !!!
# set -x
#
#
if [ "$1" == "" ]
then
   echo "Usage is : $0 <grep_1> <grep_2> <limite> <secondes>"; exit 1
else
   export GREP_1=$1
fi
#
if [ "$2" == "" ]
then
   echo "Usage is : $0 <grep_1> <grep_2> <limite> <secondes>"; exit 2
else
   export GREP_2=$2
fi
#
if [ "$3" == "" ]
then
   echo "Usage is : $0 <grep_1> <grep_2> <limite> <secondes>"; exit 3
else
   export LIMITE_NBPROC=$3
fi
#
if [ "$4" == "" ]
then
   echo "Usage is : $0 <grep_1> <grep_2> <limite> <secondes>"; exit 4
else
   export ATTENTE=$4
fi
#
export NombrePS=0
export NombrePS=`ps -ef |grep $GREP_1|grep $GREP_2|grep -v grep|grep -v sleep_PS|wc -l`
while [ $NombrePS -ge $LIMITE_NBPROC ]
do
  export NombrePS=`ps -ef |grep $GREP_1|grep $GREP_2|grep -v grep|grep -v sleep_PS|wc -l`
  echo "$GREP_1 : `date` : Nb $GREP_2 $NombrePS trop grand : Attente $ATTENTE secondes ..."
  sleep $ATTENTE
done
#
