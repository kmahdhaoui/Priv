#!/usr/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
#-- ALTER DATABASE RECOVER MANAGED STANDBY DATABASE CANCEL; 
#-- ALTER DATABASE RECOVER MANAGED STANDBY DATABASE disconnect ; 
#-- ALTER DATABASE RECOVER MANAGED STANDBY DATABASE USING CURRENT LOGFILE disconnect ;
#
#-- ALTER DATABASE RECOVER MANAGED STANDBY DATABASE FINISH force;
#-- ALTER DATABASE ACTIVATE PHYSICAL STANDBY DATABASE;
#
# SQL> alter database recover managed standby database cancel;
# DGMGRL> edit database 'stby_dbname' set state='LOG-APPLY-OFF';
# 
# SQL> alter database recover managed standby database using current logfile disconnect;
# 
# SQL> alter database recover managed standby database disconnect;
# DGMGRL> edit database 'stby_dbname' set state='ONLINE';
# 
# SQL> alter system set log_archive_max_processes=4;
# DGMGRL> edit database 'dbname' set property 'LogArchiveMaxProcesses'=4;
# 
# SQL> alter system set log_archive_dest_state_2='enable' scope=both;
# DGMGRL> edit database 'stby_dbname' set property 'LogShipping'='ON';
# 
# SQL> alter system set log_archive_dest_state_2='defer' scope=both;
# DGMGRL> edit database 'stby_dbname' set property 'LogShipping'='OFF';
# 
# DGMGRL> edit database 'pri_dbname' set state='LOG-TRANSPORT-OFF';
# ---> will defer all standby databases
#
#  create configuration bol as primary database is bol connect identifier is bol ;
#  add database shopres as connect identifier is shopres maintained as physical ;
#  edit database front set property 'LogXptMode'='SYNC' ;
#  edit database frontbck set property 'LogXptMode'='SYNC' ;
#  edit database frontbck set property 'LogXptMode'='ASYNC' ;
#  edit database front set property 'StandbyFileManagement'='AUTO' ;
#  edit configuration set protection mode as maxavalability ;
#  edit database 'bolbck' set state='LOG-APPLY-OFF';
#  edit database 'bolbck' set state='ONLINE';
#   StandbyFileManagement
#
if [ "$KSHOUTPUT" == "HTML" ]
then
   echo "<table border='1' width='90%' align='center' summary='Script output'>"
   echo "<PLAINTEXT>"
fi
##################
#
# get database name in config dg
#
export Liste_dgm=`sh $KMscript/dgm_config.sh|grep "-"|egrep -e "Primary database|Physical standby database"|cut -d"-" -f1`
#
for labase in $Liste_dgm
do
echo "-----------------------------------------------"
sh $KMscript/dgm_config.sh
echo "-----------------------------------------------"
dgmgrl -silent sys/f6tem <<EOT
SHOW DATABASE verbose '$labase' ;
SHOW DATABASE '$labase' 'LogXptStatus';
SHOW DATABASE '$labase' 'InconsistentLogXptProps';
EOT
echo "-----------------------------------------------"
done
#
if [ "$KSHOUTPUT" == "HTML" ]
then
   echo " "
fi
#
. $KMscript/KMlogout.sh
#
#  create configuration ecom as primary database is ecom connect identifier is ecom ;
#  add database ecombck as connect identifier is ecombck maintained as physical ;
#  add database ecomres as connect identifier is ecomres maintained as physical ;
#  edit database ecom set property 'LogXptMode'='SYNC' ;
#  edit database ecombck set property 'LogXptMode'='SYNC' ;
#  edit database ecomres set property 'LogXptMode'='ASYNC' ;
#  edit database ecom set property 'StandbyFileManagement'='AUTO' ;
#  edit configuration set protection mode as maxavalability ;
#  edit database 'ecombck' set state='LOG-APPLY-OFF';
#  edit database 'ecombck' set state='ONLINE';
#  edit database 'ecomres' set state='LOG-APPLY-OFF';
#  edit database 'ecomres' set state='ONLINE';
#   StandbyFileManagement
#

