#!/bin/bash
# Author : Kamel Mahdhaoui
#
#
if [ "$1" != "" ]
then
   export nbjour=$1
else
   export nbjour=1
fi
#
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export KMymd=`date "+%Y%m%d"`
#
# export Ftmp=/tmp/tmp_event_trends.$KMymdhms.tmp
# rm -f $Ftmp
#
# date
#
sqlplus -s "$conn"  <<EOT
--
set lines 132
set pages 44
--
set time off timi off echo off verify off feedback off 
set heading on
set pagesize 555
--
col username format a26
col sid format 9999
col state format a18
col event format a40
col wait_time format 99999999
col ash_secs format 999,999,999
--
select * from
(
SELECT /*+LEADING(x h) USE_NL(h)*/
       h.sql_id
,      SUM(10) ash_secs
FROM   dba_hist_snapshot x
,      dba_hist_active_sess_history h
WHERE   x.begin_interval_time > trunc(sysdate) + 1 - $nbjour
AND    h.SNAP_id = X.SNAP_id
AND    h.dbid = x.dbid
AND    h.instance_number = x.instance_number
AND    h.event in  ('db file sequential read','db file scattered read')
GROUP BY h.sql_id
ORDER BY ash_secs desc )
where rownum < 11
/
--
exit
EOT
#
#######################################
#
date
#
#
