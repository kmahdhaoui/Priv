#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
#
if [ "$1" == "" ]
then
#
sqlplus -s "$conn" <<EOT
--
col req format  a110
set lines 130
set pages 130
--
set heading off feedback off verify off
select tt.sql_id ||' '|| ss.username||'('||ss.sid||','||ss.serial#||
                ') ospid = ' ||  ss.process || ' program = ' || substr(program,1,20) ||
       ' '||to_char(ss.LOGON_TIME,'dd/mm HH24:MI') ||' '|| to_char(sysdate,'dd/mm HH24:MI') req,
       tt.sql_text
from v\$session ss ,v\$sqltext_with_newlines tt
where 
	-- ss.status = 'ACTIVE' and 
	rawtohex(ss.sql_address) <> '00' and 
	ss.username is not null and ss.username not in ('SYS','SYSTEM','sysMAN') 
	and tt.address = ss.sql_address
        and tt.piece < 1
order by ss.username, tt.sql_id,tt.piece
;
--
exit
EOT
#
echo "Entrer un sql_id ... : \c"
read v_sql_id
#
else
  export v_sql_id=$1
fi
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col RESOURCE_CONSUMER_GROUP format a25
col sid format 999999
col USERNAME format a18
col MACHINE format a18
col program format a26
col spid format  a13
--
-- tuning task
set heading on  feedback off verify off
set serveroutput on
declare
  l_sql_tune_task_id  varchar2(100);
begin
  l_sql_tune_task_id := dbms_sqltune.create_tuning_task (
                          sql_id      => '$v_sql_id',
                          scope       => dbms_sqltune.scope_comprehensive,
                          time_limit  => 60,
                          task_name   => 'task_$v_sql_id',
                          description => 'tuning task for statement $v_sql_id .');
  dbms_output.put_line('sql_tune_task_id: ' || l_sql_tune_task_id);
end;
/
--
-- executing 
exec dbms_sqltune.execute_tuning_task(task_name => 'task_$v_sql_id');
--
-- displaying the recommendations
set long 100000;
set longchunksize 1000
set pagesize 10000
set linesize 100
select dbms_sqltune.report_tuning_task('task_$v_sql_id') as recommendations from dual;
--
exec dbms_sqltune.drop_tuning_task(task_name => 'task_$v_sql_id');
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
