#!/bin/bash
#
#
if [ "$2" == "" ]
then
    export ORACLE_SID=$ORACLE_SID
else
    export ORACLE_SID=$2
fi
#
if [ "$3" == "" ]
then
   export ORACLE_HOSTNAME=`hostname`
else
   export ORACLE_HOSTNAME=$3
fi
#
export v_unqname=`sqlplus -s "$conn" 2>/dev/null <<EOT
set heading off
show parameter db_unique_name
exit
EOT`
#
if [ $? -eq 0 ]
then 
export ORACLE_UNQNAME=`echo $v_unqname|grep -i db_unique_name|cut -d' ' -f3`
echo "ORACLE_UNQNAME=$ORACLE_UNQNAME"
else
echo "Error ORACLE_UNQNAME ..."
return 1
fi
#
case $1 in 
stop|start) emctl $1 dbconsole
            if [ $? -ne 0 ]
            then
               echo "$0 $1 $ORACLE_SID $ORACLE_HOSTNAME error ..."
            fi
            ;;
         *) echo "$0 <stop|start> <oracle sid|$ORACLE_SID> <hostname|`hostname`> "
            ;;
esac
#
