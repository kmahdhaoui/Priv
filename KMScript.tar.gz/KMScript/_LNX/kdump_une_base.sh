#!/bin/bash
# kma
#
# set before $ORACLE_HOME
#
#
# la base
if [ "$1" == "" ]
then
   echo "Usage is : $0 <Base>"
  exit 101
else
   export leSID=$1
fi
#
# les variables pour le batch
export ORACLE_SID=$leSID
. /usr/local/etc/oracle/kenv_batch.sh $leSID
. $BINDIR/kenv_nls.sh
#
cd $BINDIR
#
export DATE=$(date "+%d/%m/%Y %H:%M:%S")
rm -f ${WORKDIR}/kdump_une_$$.tmp* 1>/dev/null 2>&1
#
export SQLTMP=${WORKDIR}/kdump_une_$$.tmp
#
##########################
export a_error_svg=0
#
export myrep=$BACKUP_SITR_DUMP
#
mkdir -p $myrep
#
if [ -w $myrep ]
then
# 
export FLASHBACK_TIME=systimestamp
#
cd $BINDIR
#
sqlplus '/ as sysdba' <<EOT
create or replace DIRECTORY kdump_$ORACLE_SID as '$myrep/';
exit
EOT
#
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
#
echo expdp "'/ as sysdba'" FLASHBACK_TIME=systimestamp full=Y directory=kdump_$ORACLE_SID parallel=8 COMPRESSION=all dumpfile=$ORACLE_SID.$KMymdhms.full.%u.dmp logfile=$ORACLE_SID.$KMymdhms.full.log exclude=SCHEMA:"in\('SYS'\,'SYSTEM'\,'OUTLN'\,'DIP'\,'DBSNMP'\,'APPQOSSYS'\,'WMSYS'\,'SYSMAN'\,'MGMT_VIEW'\,'ORDSYS'\,'ORDDATA'\,'ORDPLUGINS'\,'MDSYS'\,'MDDATA'\,'SPATIAL_WFS_ADMIN_USR'\,'SPATIAL_CSW_ADMIN_USR'\,'XDB'\,'OLAPSYS'\,'OWBSYS'\,'OWBSYS_AUDIT'\,'APEX_PUBLIC_USER'\,'APEX_030200'\,'SCOTT'\,'XS$NULL'\)" 
#
expdp "'/ as sysdba'" FLASHBACK_TIME=systimestamp full=Y directory=kdump_$ORACLE_SID parallel=8 COMPRESSION=all dumpfile=$ORACLE_SID.$KMymdhms.full.%u.dmp logfile=$ORACLE_SID.$KMymdhms.full.log exclude=SCHEMA:"in\('SYS'\,'SYSTEM'\,'OUTLN'\,'DIP'\,'DBSNMP'\,'APPQOSSYS'\,'WMSYS'\,'SYSMAN'\,'MGMT_VIEW'\,'ORDSYS'\,'ORDDATA'\,'ORDPLUGINS'\,'MDSYS'\,'MDDATA'\,'SPATIAL_WFS_ADMIN_USR'\,'SPATIAL_CSW_ADMIN_USR'\,'XDB'\,'OLAPSYS'\,'OWBSYS'\,'OWBSYS_AUDIT'\,'APEX_PUBLIC_USER'\,'APEX_030200'\,'SCOTT'\,'XS$NULL'\)" 
#
if [ $? -ne 0 ]
then
   export a_error_svg=1
fi
else
   export a_error_svg=0
fi 
#
#########
#
export STATUS=$a_error_svg
if [ $STATUS != 0 ]
then
   echo bash $BINDIR/db_mailx.sh $myrep/$ORACLE_SID.$KMymdhms.full.log ProblemeExpdp "$LISTEMAIL"
   bash $BINDIR/db_mailx.sh $myrep/$ORACLE_SID.$KMymdhms.full.log ProblemeExpdp "$LISTEMAIL"
   # Mail et continuer
fi
#
# sed '/^$/d' ${SQLTMP}.$leSID.2 >${SQLTMP}.$leSID.1
# export nb=`cat ${SQLTMP}.$leSID.1|wc -l`
#
##############
#
rm -f ${WORKDIR}/kdump_une_$$.tmp* 1>/dev/null 2>&1
#
