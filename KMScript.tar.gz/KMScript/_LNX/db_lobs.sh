#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col TABLE_NAME format a25
col COLUMN_NAME format a22
col DATA_TYPE format a15
col OWNER format a15
col table_OWNER format a15
col segment_name format a25 new_value segname
col index_name format a25  new_value indname
set lines 133
set pages 555

prompt "---------------- dba_tab_columns -------------------"
select OWNER,TABLE_NAME,COLUMN_NAME,DATA_TYPE from dba_tab_columns where DATA_TYPE like '%LO%'
and DATA_TYPE not like 'FLOAT'
and OWNER not in
      ('SYS','SYSTEM','OUTLN','QUEST','SYSMAN','MDSYS','OLAPSYS','XDB','ORACLE_OCM','DBSNMP',
       'APPQOSSYS','MDDATA','EXFSYS','CTXSYS','ORDSYS','ORDDATA','ORDPLUGINS','SPATIAL_WFS_ADMIN_USR',
       'SPATIAL_CSW_ADMIN_USR','MGMT_VIEW','PATROL','KAMEL','XS$NULL')
and table_name not in ('PLAN_TABLE','TOAD_PLAN_TABLE')
;
--
prompt "---------------- dba_lobs -------------------"
select OWNER,table_name, column_name, segment_name, index_name
from dba_lobs where
OWNER not in 
      ('SYS','SYSTEM','OUTLN','QUEST','SYSMAN','MDSYS','OLAPSYS','XDB','ORACLE_OCM','DBSNMP',
       'APPQOSSYS','MDDATA','EXFSYS','CTXSYS','ORDSYS','ORDDATA','ORDPLUGINS','SPATIAL_WFS_ADMIN_USR',
       'SPATIAL_CSW_ADMIN_USR','MGMT_VIEW','PATROL','KAMEL','XS$NULL')
and table_name not in ('PLAN_TABLE','TOAD_PLAN_TABLE')
;
--
prompt "---------------- dba_lob_partitions -------------------"
select TABLE_OWNER,TABLE_NAME,COLUMN_NAME,PARTITION_NAME,LOGGING from dba_lob_partitions
where 
TABLE_OWNER not in 
      ('SYS','SYSTEM','OUTLN','QUEST','SYSMAN','MDSYS','OLAPSYS','XDB','ORACLE_OCM','DBSNMP',
       'APPQOSSYS','MDDATA','EXFSYS','CTXSYS','ORDSYS','ORDDATA','ORDPLUGINS','SPATIAL_WFS_ADMIN_USR',
       'SPATIAL_CSW_ADMIN_USR','MGMT_VIEW','PATROL','KAMEL','XS$NULL')
and table_name not in ('PLAN_TABLE','TOAD_PLAN_TABLE')
order by 4
/
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
