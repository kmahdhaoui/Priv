#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col OWNER format a22
col OBJECT_TYPE format a15
col OBJECT_NAME format a35
col STATUS
set pages 555
set lines 132
--
prompt "... Dont index  nologging"
select distinct '-- '||index_name||chr(10)||
'alter index '||owner||'.'||index_name||' nologging;' from dba_indexes where logging like 'YES' and owner='CISADM';
--
prompt "... Dont index  Part/ssPartitions invalides"
SELECT distinct '-- '||index_name||chr(10)||
'alter index '||index_owner||'.'||index_name||'  nologging; '
FROM dba_ind_partitions WHERE logging in ( 'YES')  and index_owner='CISADM' ; 
--
SELECT distinct '-- '||index_name||chr(10)||
'alter index '||index_owner||'.'||index_name||'  nologging; '
FROM dba_ind_subpartitions WHERE logging in ( 'YES')  and index_owner='CISADM' ;
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
