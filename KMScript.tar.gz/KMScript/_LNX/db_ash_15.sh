#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
# $KSHOUTPUT:HTML/TEXT
sqlplus -s "$conn" <<EOT
-- @$KMscript/$SQLLOGIN
--
set feedback off
set echo off
col OUTPUT format a130
col BEGIN_INTERVAL_TIME format a22
col END_INTERVAL_TIME format a22
--
SELECT output FROM TABLE(dbms_workload_repository.ash_report_$KSHOUTPUT
(
(select dbid from v\$database)
,1,
sysdate-1/24/4,
sysdate-1/2400
)
);
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
