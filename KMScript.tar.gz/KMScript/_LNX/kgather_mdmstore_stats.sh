#!/bin/bash
# kma
#
# set before $ORACLE_HOME
#
#
# quels tbs traiter (like)
if [ "$1" == "" ]
then
   export lestbs="%"
else
   export lestbs=$1
fi
#
# les tbs a ne pas traiter (not like)
if [ "$2" == "" ]
then
   export nottbs="None"
else
   export nottbs=$2
fi
#
# les variables pour le batch
. /usr/local/etc/oracle/kenv_batch.sh 
#
cd $BINDIR
#
rm -f ${WORKDIR}/kgather$$.tmp* 1>/dev/null 2>&1
#
export SQLTMP=${WORKDIR}/kgather$$.tmp
#
##########################
# La liste c'est les bases qui tournent
cat <<EOF |sort -u | grep -v '^$'| while read leSID ; do
$(ps -ef |grep smon|grep -v grep|grep -v '+ASM'|grep SITREMT|awk -F_ '{print $3}'|sed 's/ //g')
EOF
#
# les variables pour le batch
export ORACLE_SID=$leSID
. /usr/local/etc/oracle/kenv_batch.sh $leSID
. $BINDIR/kenv_nls.sh
#
sqlplus -s '/ as sysdba' 2>/dev/null <<EOT
set echo off heading off feedback off verify off
--
whenever sqlerror exit 1; 
whenever oserror exit 2; 
--
spool $SQLTMP.$leSID.2
--
prompt "------------- $ORACLE_SID -----------------------"
--
prompt gather statstics ... 
--
set echo on
set time on timi on

exec dbms_stats.gather_schema_stats('MDMSTORE1',cascade=>true,estimate_percent=>100,degree=>18);


exec dbms_stats.gather_schema_stats('MDMSTORE2',cascade=>true,estimate_percent=>100,degree=>18);


exec dbms_stats.gather_schema_stats('MDMSTORE3',cascade=>true,estimate_percent=>100,degree=>18);

--
select owner,table_name,num_rows nombre from dba_tables where owner like 'MDMSTORE%' 
and table_name like 'MDM3%STORE%' ;
--
prompt "-------------------------------------------------"
--
exit 0
EOT
#
export STATUS=$?
if [ $STATUS != 0 ]
then
   echo "Erreur $0 : $STATUS : SQL/OS 1/2 ..." >&2
   exit 3
fi
#
sed '/^$/d' ${SQLTMP}.$leSID.2 >${SQLTMP}.$leSID.1
export nb=`cat ${SQLTMP}.$leSID.1|wc -l`
#
##############
done
##########################
#
rm -f ${WORKDIR}/kgather$$.tmp* 1>/dev/null 2>&1
#
