#!/bin/bash
# Author : Kamel Mahdhaoui
#
#
if [ "$1" == "" ] 
then
   echo "Usage is : $0 <deb:yyyy-mm-dd_hh:mi:ss> <fin>"
   echo "Exemple  : $0 2015-06-24_08:00:00 2015-06-24_09:00:00"
   exit 1
else
   export dateheure_d=$1
fi
#
if [ "$2" == "" ]
then
   echo "Usage is : $0 <deb:yyyy-mm-dd_hh:mi:ss> <fin>"
   echo "Exemple  : $0 2015-06-24_08:00:00 2015-06-24_09:00:00"
   exit 2
else
   export dateheure_f=$2
fi
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export KMymd=`date "+%Y%m%d"`
#
#
sqlplus -s "$conn"  <<EOT
--
set time off timi off echo off verify off feedback off heading off
set time off timi off echo off verify off feedback off heading off pages 0 lines 80
--
select trim(to_char(min(snap_id) )) || ' ' ||trim(to_char(max(snap_id) )) snapids
from dba_hist_snapshot
where begin_interval_time >= to_date('$dateheure_d','yyyy-mm-dd_hh24:mi:ss') - 10/24/60
  and begin_interval_time <= to_date('$dateheure_f','yyyy-mm-dd_hh24:mi:ss') + 10/24/60
;
--
exit
EOT
#
#######################################
#
#
#
