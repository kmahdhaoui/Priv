#!/bin/bash
# Author : Kamel Mahdhaoui
#
#
if [ "$1" == "" ] 
then
   export NBJOURS=2
else
   export NBJOURS=$1
fi
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export KMymd=`date "+%Y%m%d"`
#
#
sqlplus -s "$conn"  <<EOT
--
set time off timi off echo off verify off feedback off 
set heading off 
set pagesize 0
set feedback off
--
--
SELECT (CASE WHEN NUMTODSINTERVAL ( (SYSDATE - MAX(CAST(END_INTERVAL_TIME AS DATE))), 'DAY') < 
SNAP_INTERVAL THEN 'AWR : OK' ELSE 'AWR : STOPPED' END) "RESULT"
FROM DBA_HIST_SNAPSHOT, DBA_HIST_WR_CONTROL
GROUP BY SNAP_INTERVAL;
--
exit
EOT
#
#######################################
#
date
#
#
