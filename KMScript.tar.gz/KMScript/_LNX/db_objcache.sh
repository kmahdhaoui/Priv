#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
#
export Filtre=10
if [ "$1" != "" ] 
then
   export Filtre=$1
else
   export Filtre=10
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
set lines 132
COLUMN OBJECT_NAME FORMAT A40
COLUMN NUMBER_OF_BLOCKS FORMAT 999,999,999,999
prompt NUMBER_OF_BLOCKS > $Filtre ..............
SELECT o.owner,o.OBJECT_NAME, COUNT(*) NUMBER_OF_BLOCKS
     FROM DBA_OBJECTS o, V\$BH bh
    WHERE o.DATA_OBJECT_ID = bh.OBJD
      AND o.OWNER         != 'SYS'
      AND o.OWNER         != 'SYSTEM'
    having COUNT(*) > $Filtre
    GROUP BY o.owner,o.OBJECT_NAME
    ORDER BY COUNT(*) desc 
;
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
