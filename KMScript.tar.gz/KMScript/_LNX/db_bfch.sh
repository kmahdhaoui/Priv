#
# Author : Kamel Mahdhaoui
# Unautorized use is forbidden 
sqlplus -s "$conn" <<EOT
col BFCH format "9999999"
set pages 0
set feedb off
set verify off
set echo off
--
select round(((1-(sum(
decode(name,'physical reads',value,0))/        (sum(decode(name,'db block gets',value,0))+
(sum(decode(name,'consistent gets',value,0))))))	*100),4)  BFCH
from v\$sysstat
;
exit
EOT
#
