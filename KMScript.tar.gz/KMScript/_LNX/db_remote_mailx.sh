#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$1" == "" ] 
then
   echo "Usage : $0 <fichier> <sujet> <mail> ..."
   exit 101
fi
#
if [ ! -r $1 ]
then
   echo "Usage : $0 <fichier> <sujet> <mail> <RemoteSid> <Force envoi mail O/N> ..."
   echo "$1 : mauvais fichier !"
   exit 101
fi
#
if [ "$2" == "" ] 
then
   echo "Usage : $0 <fichier> <sujet> <mail> <RemoteSid> <Force envoi mail O/N> ..."
   echo "      : sujet absent !"
   exit 102
fi
#
if [ "$3" == "" ]
then
   echo "Usage : $0 <fichier> <sujet> <mail> <RemoteSid> <Force envoi mail O/N> ..."
   echo "      : mail absent !"
   exit 103
fi
#
if [ "$4" == "" ]
then
   echo "Usage : $0 <fichier> <sujet> <mail> <RemoteSid> <Force envoi mail O/N> ..."
   echo "      : Remote Sid absent !"
   exit 104
fi
#
export FORCE_ENVOI=Non
if [ "$5" == "" ]
then
   export FORCE_ENVOI=Non
   echo "      : FORCE_ENVOI=Non"
fi
#
# positionner des choses pour les scripts
export KMhost=`hostname`
export KMsid=$ORACLE_SID
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export KMymd=`date "+%Y%m%d"`
#
export FICHIER=$1
export SUJETMAIL="[$2]:$4"
export LEMAIL=$3
export LEMAIL=kamel.mahdhaoui@suez-env.com
#
export KMficlck=/tmp/db_remote_mailx_$KMymdhms.$$.lck
export KMfictmp=/tmp/db_remote_mailx_$KMymdhms.$$.tmp
export SUJETMAIL_SS=`echo "$SUJETMAIL" | tr -d '&"()[]{}=@#,;/:!<> ' `
export KMficsvg=/tmp/db_remote_mailx_$KMymd.$SUJETMAIL_SS.tmp
#
export from="${KMhost}.$ORACLE_SID@ondeosystems.com"
export smtp=10.34.34.67
#
date > $KMfictmp
cat $FICHIER >> $KMfictmp
#
echo "$SUJETMAIL" > $KMficsvg.1
#
if [ ! -f $KMficsvg.2 ]
then
   echo "New" > $KMficsvg.2
fi
#
case "$FORCE_ENVOI" in
     O*|o*) echo "Force" > $KMficsvg.2 ;;
esac
#
export NBDIFF=`diff $KMficsvg.1 $KMficsvg.2|wc -l`
if [ "$NBDIFF" -eq 0 ]
then
   echo "Message deja envoyee !"
else
   cat $KMfictmp |mailx -s "$SUJETMAIL" "$LEMAIL"
fi
#
rm -f $KMfictmp 
mv -f $KMficsvg.1 $KMficsvg.2
#
