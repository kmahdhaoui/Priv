#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
select l.group#, member,  TYPE, bytes/1024/1024 MB, thread#
from v\$logfile f, v\$log l
where type='ONLINE'
and f.group#=l.group#
UNION
select v\$standby_log.group#, member, TYPE, bytes/1024/1024 MB, thread#
from v\$logfile, v\$standby_log
where type='STANDBY'
and v\$logfile.group#=v\$standby_log.group#
order by group#;

col Date format a9
col Day format a4
col total format 9999
col "0-1" format 999
col "2-3" format 999
col "4-5" format 999
col "6-7" format 999
col "8-9" format 999
col "10-11" format 999
col "12-13" format 999
col "14-15" format 999
col "16-17" format 999
col "18-19" format 999
col "20-21" format 999
col "22-23" format 999


SELECT  trunc(first_time) "Date",
to_char(first_time, 'Dy') "Day",
count(1) "Total",
SUM(decode(to_char(first_time, 'hh24'),'00',1,0))
+ SUM(decode(to_char(first_time, 'hh24'),'01',1,0)) "0-1",
SUM(decode(to_char(first_time, 'hh24'),'02',1,0))
+ SUM(decode(to_char(first_time, 'hh24'),'03',1,0)) "2-3",
SUM(decode(to_char(first_time, 'hh24'),'04',1,0))
+ SUM(decode(to_char(first_time, 'hh24'),'05',1,0)) "4-5",
SUM(decode(to_char(first_time, 'hh24'),'06',1,0))
+ SUM(decode(to_char(first_time, 'hh24'),'07',1,0)) "6-7",
SUM(decode(to_char(first_time, 'hh24'),'08',1,0))
+ SUM(decode(to_char(first_time, 'hh24'),'09',1,0)) "8-9",
SUM(decode(to_char(first_time, 'hh24'),'10',1,0))
+ SUM(decode(to_char(first_time, 'hh24'),'11',1,0)) "10-11",
SUM(decode(to_char(first_time, 'hh24'),'12',1,0))
+ SUM(decode(to_char(first_time, 'hh24'),'13',1,0)) "12-13",
SUM(decode(to_char(first_time, 'hh24'),'14',1,0))
+ SUM(decode(to_char(first_time, 'hh24'),'15',1,0)) "14-15",
SUM(decode(to_char(first_time, 'hh24'),'16',1,0))
+ SUM(decode(to_char(first_time, 'hh24'),'17',1,0)) "16-17",
SUM(decode(to_char(first_time, 'hh24'),'18',1,0))
+ SUM(decode(to_char(first_time, 'hh24'),'19',1,0)) "18-19",
SUM(decode(to_char(first_time, 'hh24'),'20',1,0))
+ SUM(decode(to_char(first_time, 'hh24'),'21',1,0)) "20-21",
SUM(decode(to_char(first_time, 'hh24'),'22',1,0))
+ SUM(decode(to_char(first_time, 'hh24'),'23',1,0)) "22-23"
FROM v\$log_history
WHERE first_time > sysdate-34
GROUP BY trunc(first_time), to_char(first_time, 'Dy')
ORDER BY 1 desc;

exit
EOT
#
. $KMscript/KMlogout.sh
#
