#
for tb in MSRMT INIT_MSRMT_DATA_K INIT_MSRMT_DATA
do
#
sqlplus -s "cisadm/cisadm" <<EOT &
--
set time on timi on echo on
host echo "<<<<<<<<<<<<<<<<<<<< `date` : $tb "
--
alter session set current_schema=cisadm;
--
drop table cm_$tb ;
--
create table cm_$tb tablespace MSRMT_HIST_TBL nologging as select * from D1_$tb ;
commit;
--
exit
--
EOT
#
done
#
