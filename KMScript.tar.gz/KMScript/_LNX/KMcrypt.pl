#!/usr/bin/perl -w
$pass = shift or die "Usage: ", $0 =~ /([^\/]*$)/, " passwd < file\n";
undef $/;                 
@file = split //, <>;     
@pass = map{
  $x = ord;
  $y = ( $x + 10 ) ** 2 % 256;
  $z = ( $x - 10 ) ** 2 % 256;
  chr ( $y ^ $z )
} split //, $pass;
print chr( ord $file[$_] ^ ord $pass[$_ % scalar @pass] ) for 0 .. $#file
