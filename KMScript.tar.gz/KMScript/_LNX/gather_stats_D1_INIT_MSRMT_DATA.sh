#!/bin/bash
# Author : Kamel Mahdhaoui
#
#============================================
if [ "$1" == "" ]
then
   if [ "$ORACLE_SID" == "" ]
   then
      export ORACLE_SID=XSITRMDO
   fi
else
    export ORACLE_SID=$1
fi
export ORAENV_ASK=NO
. oraenv 1>/dev/null
export ORAENV_ASK=YES
#
export PATH=$ORACLE_HOME/bin:$PATH
#============================================
#
export latable=D1_INIT_MSRMT_DATA
export leowner=CISADM
#
date
sqlplus -s '/ as sysdba' <<EOT
set feedback off
set lines 133
col value format a80
--
col OWNER format a10
col TABLE_NAME format a30
col INCREMENTAL format a10
col GRANULARITY format a10
col STALE_PERCENT format A6
col ESTIMATE_PERCENT format a30
col CASCADEA format a10
col METHOD_OPT format a20
--
-- exec dbms_stats.gather_table_stats(ownname=>'$leowner',tabname=>'$latable',estimate_percent=>dbms_stats.auto_sample_size,method_opt=>'for all indexed columns',cascade=>true,degree=>42);
--
--
SELECT owner, table_name,
  DBMS_STATS.get_prefs(ownname=>USER,tabname=>table_name,pname=>'INCREMENTAL') incremental,
  DBMS_STATS.get_prefs(ownname=>USER,tabname=>table_name,pname=>'GRANULARITY') granularity,
  DBMS_STATS.get_prefs(ownname=>USER,tabname=>table_name,pname=>'STALE_PERCENT') stale_percent,
  DBMS_STATS.get_prefs(ownname=>USER,tabname=>table_name,pname=>'ESTIMATE_PERCENT') estimate_percent,
  DBMS_STATS.get_prefs(ownname=>USER,tabname=>table_name,pname=>'CASCADE') cascadea,
  DBMS_STATS.get_prefs(pname=>'METHOD_OPT') method_opt
FROM dba_tables where owner='$leowner' and table_name like '$latable'
ORDER BY owner, table_name
;
--
exec dbms_stats.gather_table_stats(ownname=>'$leowner',tabname=>'$latable',ESTIMATE_PERCENT=>100,GRANULARITY=>'APPROX_GLOBAL AND PARTITION',cascade=>true,degree=>42);
--
col PARTITION_NAME format a15
select TABLE_NAME,PARTITION_NAME,NUM_ROWS,LAST_ANALYZED from dba_tab_partitions where TABLE_OWNER='$leowner' and TABLE_NAME='$latable'
;
--
--
--
exit
EOT
date
#
#
