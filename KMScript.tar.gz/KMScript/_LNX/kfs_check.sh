#!/bin/bash
# kma
#
# quel fs
if [ "$1" == "" ]
then
   export lefs="/sitr"
else
   export lefs=$1
fi
#
# le seuil
if [ "$2" == "" ]
then
   export lepct=80
else
   export lepct=$2
fi
#
#
# les variables pour le batch
. /usr/local/etc/oracle/kenv_batch.sh
#
export SUPFILE=$SUPOTHERFILE 
#
cd $BINDIR
#
export DATE=$(date "+%d/%m/%Y %H:%M:%S")
rm -f ${WORKDIR}/kfs_check_$$.tmp* 1>/dev/null 2>&1
export SQLTMP=${WORKDIR}/kfs_check_$$.tmp
export PATH=$PATH:/usr/local/bin
export PATH=$PATH:$ORACLE_HOME/bin
#
##########################
export a_error_svg=0
export myrep=$lefs
export LOGFILE=kfs_check_${ORACLE_SID}_$KMymdhms.log
#
##################################################################
#
export PCT=`df -mP "$lefs" |grep "$lefs" |awk -F" "  '{print $5 }'|awk -F"%" '{print $1 }' `
#
#########
#
if [ "$PCT" -gt "$lepct" ]
then
   df -mP > $LOGDIR/$LOGFILE
   # bash db_logsup.sh <Instance> <CodeInfo> <Severite> <Texte> <Objet> <MailFile> <SupFile>
   export LInstance="n/a"
   export CodeInfo="EspaceFS"
   export LaSeverite="CRITIQUE__"
   export LeTexte="$lefs $PCT a depasse $lepct%"
   export LObjet="n/a"
   export LeMailFile="$LOGDIR/$LOGFILE"
   export LeSupFile="$SUPFILE"
   bash db_logsup.sh "$LInstance" "$CodeInfo" "$LaSeverite" "$LeTexte" "$LObjet" "$LeMailFile" "$LeSupFile"
   #
   bash $BINDIR/db_mailx.sh $LOGDIR/$LOGFILE EspaceFS "$LISTEMAIL" "$lefs > $lepct%"
   echo ""
fi
#
##############
#
rm -f ${WORKDIR}/kfs_check_$$.tmp* 1>/dev/null 2>&1
#
