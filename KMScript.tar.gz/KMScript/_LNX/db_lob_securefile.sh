#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col COLUMN_NAME format a22
col owner format a15
col table_owner format a15
col index_owner format a15
--
set lines 132
col COLUMN_NAME format a30
col OWNER format a12
select OWNER,TABLE_NAME,COLUMN_NAME,CACHE,COMPRESSION,DEDUPLICATION,SECUREFILE from dba_lobs
where OWNER='CISADM' and TABLE_NAME not like '%2014%' and TABLE_NAME not like '%CONSO%' and TABLE_NAME not like 'SYS%PORT_%'
and TABLE_NAME not like '%DP_1%' and TABLE_NAME not like '%PLAN_TABLE%' ;
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
