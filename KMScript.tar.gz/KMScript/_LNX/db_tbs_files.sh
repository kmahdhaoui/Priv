#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
-- DEBUT SQL
--
set verify off
set feedback off
set echo off
--
ttitle skip center "*** Oracle Files ***"
set pages 1000
--
--
SET LINES 130
SET TRIMS ON
COL name FOR A60
col mb format 999,999,999.9
SELECT 'DATA' type, file_name name ,bytes/1024/1024 mb FROM dba_DATA_FILEs where tablespace_name like '$1'
UNION
SELECT 'TEMP' type, file_name name ,bytes/1024/1024 mb FROM dba_TEMP_FILEs where tablespace_name like '$1'
ORDER BY
1,2
/
-- FIN SQL
--
exit
EOT
#
echo " "
echo "############################################################# "
#echo "*** RMAN Files ***"
#rman target=/ <<EOT
#report schema;
#exit
#EOT
#
. $KMscript/KMlogout.sh
#
