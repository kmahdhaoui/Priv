#!/bin/bash
# kma
#
# set before $ORACLE_HOME
#
#
# la base c'est +ASM
export leSID="+ASM"
# 
# les variables pour le batch
export ORACLE_SID="$leSID"
. /usr/local/etc/oracle/kenv_batch.sh "$leSID"
. $BINDIR/kenv_nls.sh
#
cd $BINDIR
#
export DATE=$(date "+%d/%m/%Y %H:%M:%S")
rm -f ${WORKDIR}/kstop_listener_$$.tmp* 1>/dev/null 2>&1
#
export SQLTMP=${WORKDIR}/kstop_listener_$$.tmp
#
##########################
export a_error_svg=0
#
export FLASHBACK_TIME=systimestamp
#
cd $BINDIR
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
#
echo "=========== AVANT : tnslsnr : "
ps -ef |grep tnslsnr |grep -v grep
echo "======================================================="
srvctl  stop listener -l SITR         1> $SQLTMP 2>&1
srvctl  stop listener -l LISTENER     1>>$SQLTMP 2>&1
srvctl  stop listener -l LISTENER_DB  1>>$SQLTMP 2>&1
srvctl  stop listener -l LISTENER_ASM 1>>$SQLTMP 2>&1
lsnrctl stop SITR                     1>>$SQLTMP 2>&1
lsnrctl stop LISTENER                 1>>$SQLTMP 2>&1
lsnrctl stop LISTENER_DB              1>>$SQLTMP 2>&1
lsnrctl stop LISTENER_ASM             1>>$SQLTMP 2>&1
echo "=========== APRES : tnslsnr : "
ps -ef |grep tnslsnr |grep -v grep
echo "======================================================="
#
if [ $? -ne 0 ]
then
   export a_error_svg=1
fi
#
#########
#
export STATUS=$a_error_svg
if [ $STATUS != 0 ]
then
   echo bash $BINDIR/db_mailx.sh $SQLTMP ProblemeStopLsnr "$LISTEMAIL"
   bash $BINDIR/db_mailx.sh $$SQLTMP ProblemeStopLsnr "$LISTEMAIL"
   # Mail et continuer
fi
#
# sed '/^$/d' ${SQLTMP}.$leSID.2 >${SQLTMP}.$leSID.1
# export nb=`cat ${SQLTMP}.$leSID.1|wc -l`
#
##############
#
rm -f ${WORKDIR}/kstop_listener_$$.tmp* 1>/dev/null 2>&1
#
