#!/bin/bash
# kma
#
# seuil (non utilise pour l'instant)
if [ "$1" == "" ]
then
   export SEUIL_1=5
else
   export SEUIL_1=$1
fi
#
export DATE=$(date "+%d/%m/%Y %H:%M:%S")
#
export PATH=$PATH:/usr/local/bin
export PATH=$PATH:$ORACLE_HOME/bin
#
##########################
# La liste c'est la base SITREMT qui tourne
cat <<EOF |sort -u | grep -v '^$'| grep SITREMT|while read leSID ; do
$(ps -ef |grep smon|grep -v grep|grep -v '+ASM'|awk -F_ '{print $3}'|sed 's/ //g')
EOF
export ORACLE_SID=$leSID
export ORAENV_ASK=NO
. oraenv 1>/dev/null
export ORAENV_ASK=YES
export PATH=$ORACLE_HOME/bin:$PATH
#
sqlplus -s '/ as sysdba'  <<EOT
set echo off heading on feedback off verify off
--
whenever sqlerror exit 1; 
whenever oserror exit 2; 
--
col project format a10
--
--
col DBTIMEZONE format a15
prompt DBTIMEZONE
prompt ===============================================================
select DBTIMEZONE  from dual;
prompt
--
prompt correspond au nombre de compteurs ayant au moins un index 
prompt (VAL_INDEX_EMC dans EMC_PROJET_LOG)
prompt ===============================================================
SELECT REPORTING_DATE+(SYSTIMESTAMP-SYS_EXTRACT_UTC(SYSTIMESTAMP)) REPORTING_DATE
,count(1) Comptage FROM SITR_EMC.F_DAILY_MEASURE
WHERE REPORTING_DATE > sysdate - 15 and index_presence='OUI' group by REPORTING_DATE
;
prompt
--
prompt Log de l'alimentation
prompt ==============================================================================
prompt reporting_date --> date minuit GMT heure locale
prompt val_index_sitr --> nombre d'index dans MDM (reultat R2)
prompt val_index_emc --> SITR_EMC.F_DAILY_MEASURE : nombre de compteurs ayant au moins un index
prompt num_meters --> nombre d'index associés
prompt
--
select reporting_date+(SYSTIMESTAMP-SYS_EXTRACT_UTC(SYSTIMESTAMP)) reporting_date 
, project, val_index_sitr, val_index_emc, num_meters 
from sitr_emc.emc_projet_log 
where reporting_date >= trunc(sysdate -15)
order by reporting_date desc
;
prompt
--
col REF_FICHIER_LOT format a44
prompt Suivi des lots genere par EMT
prompt ===============================================================
select id, reporting_date,   ref_fichier_lot, dat_creation_fichier, 
round(DBMS_LOB.GETLENGTH(contenu_fichier)/1024/1024, 2) size_mo 
from sitr_emc.emt_lot where liste_projets='OCEA' order by reporting_date desc
;
prompt
--
exit 0
EOT
#
export STATUS=$?
if [ $STATUS != 0 ]
then
   echo "Erreur $0 : $STATUS : SQL/OS 1/2 ..." >&2
   exit 3
fi
#
done
##########################
#
#
