#!/bin/bash
# Author : Kamel Mahdhaoui
#
#
if [ "$1" == "" ] 
then
   export NBJOURS=1
else
   export NBJOURS=$1
fi
#
if [ "$2" == "" ]
then
   export levent="db file sequential read"
else
   export levent=$2
fi
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export KMymd=`date "+%Y%m%d"`
#
# export Ftmp=/tmp/tmp_event_trends.$KMymdhms.tmp
# rm -f $Ftmp
#
# date
#
sqlplus -s "$conn"  <<EOT
set time off timi off echo off verify off feedback off heading off
--
set lines 132
set pages 44
--
col systimestamp form a35 
col most_recent_snap_time form a25 
col snap_interval form a17 
--
col instance_number form 999 head INST 
col begin_interval_time form a25 
col flush_elapsed form a17 
col status form 999 
col error_count form 999 head ERR 
col snap_flag form 999 head SNAP 
--
--
select systimestamp, most_recent_snap_time, snap_interval from sys.wrm\$_wr_control where dbid = (select dbid from v\$database); 
--
select * from 
  (select snap_id, 
  instance_number, 
  end_interval_time, 
  flush_elapsed, 
  status, 
  error_count, 
  snap_flag 
  from sys.wrm\$_snapshot 
  where dbid = (select dbid from v\$database) 
  order by snap_id desc) 
  where rownum <= 10 
  order by snap_id 
;
--
select * from sys.wrm\$_snap_error 
  where dbid = (select dbid from v\$database) 
  order by snap_id;
 
--
exit
EOT
#
sqlplus -s "$conn"  <<EOT
set time off timi off echo off verify off feedback off heading off 
set pagesize 555
-- set trimspool on
set lines 133
col value format a20
--
col OWNER format a10
col TABLE_NAME format a30
col INCREMENTAL format a10
col GRANULARITY format a10
col STALE_PERCENT format A6
col ESTIMATE_PERCENT format a30
col CASCADEA format a10
col METHOD_OPT format a20
--
define m_event_name = '$levent'
 
column  instance_number   new_value m_instance  noprint
column  dbid              new_value m_dbid      noprint
 
select
        ins.instance_number,
        db.dbid
from
        v\$instance        ins,
        v\$database        db
;
--
column        "value nbr"      format        999,999,999,999
column        "value µs"       format        999,999,999,999
column        curr_value format        999,999,999,999
column        prev_value format        999,999,999,999
col event_name format a40
set heading on
--
select distinct
after.snap_id,
'"'||after.event_name||'"'   event_name ,
to_char(sn.end_interval_time,'Mon-dd hh24:mi:ss')     end_time
from 
DBA_HIST_SYSTEM_EVENT after,
DBA_HIST_SNAPSHOT sn
where 
sn.end_interval_time > trunc(sysdate - $NBJOURS + 1)
and
after.event_name like '$levent' and
after.instance_number=1 and
after.snap_id=sn.snap_id and
after.instance_number=sn.instance_number 
order by 2,1
;
--
--
exit
EOT
#
#######################################
#
date
#
#
