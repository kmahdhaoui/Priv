#!/bin/bash
# kma
#
# seuil (non utilise pour l'instant)
if [ "$1" == "" ]
then
   export NBJOURS=20
else
   export NBJOURS=$1
fi
#
export DATE=$(date "+%d/%m/%Y %H:%M:%S")
#
export PATH=$PATH:/usr/local/bin
export PATH=$PATH:$ORACLE_HOME/bin
#
##########################
# La liste c'est la base SITRMDC qui tourne
cat <<EOF |sort -u | grep -v '^$'| grep SITRMDC|while read leSID ; do
$(ps -ef |grep smon|grep -v grep|grep -v '+ASM'|awk -F_ '{print $3}'|sed 's/ //g')
EOF
export ORACLE_SID=$leSID
export ORAENV_ASK=NO
. oraenv 1>/dev/null
export ORAENV_ASK=YES
export PATH=$ORACLE_HOME/bin:$PATH
#
sqlplus -s '/ as sysdba'  <<EOT
set echo off heading on feedback off verify off
--
whenever sqlerror exit 1; 
whenever oserror exit 2; 
--
col project format a10
col name format a16
set lines 133
--
--
col DBTIMEZONE format a15
prompt DBTIMEZONE
prompt ===============================================================
select DBTIMEZONE  from dual;
prompt
-- REDUNDANCYCACHE
-- Acquisition ; In: files; Out:MSMQ(redundancy),TXREDUNDANTFRAME,ORPHANFRAME
-- InMemoryRed ; In:MSMQ(redund) Out:MSMQ(mdmO),TXFRAME
--
prompt SUBCONTRACT
prompt ===============================================================
select name,SUBCONTRACTTYPEID,CONTRACTID  from  TELECOLLECT_ACQUISITION.subcontract s_c where s_c.NAME='OCEA'
;
prompt
--
prompt DOCUMENTS $NBJOURS jours
prompt ===============================================================
select trunc(CREATEDDATE)CREATEDDATE,count(*) Documents from TELECOLLECT_ACQUISITION.document where CREATEDDATE >
to_date(to_char(sysdate - $NBJOURS ,'yyyymmdd'),'yyyymmdd')
group by trunc(CREATEDDATE)
order by 1 desc
;
prompt
--
prompt TXREDUNDANTFRAME $NBJOURS jours
prompt ===============================================================
select trunc(TIMESTAMP) "Date", count(*) Comptage from TELECOLLECT_ACQUISITION.TXREDUNDANTFRAME where TIMESTAMP >
to_date(to_char(sysdate - $NBJOURS ,'yyyymmdd'),'yyyymmdd')
group by trunc(TIMESTAMP)
;
prompt
--
-- prompt ORPHANFRAME $NBJOURS jours
-- prompt ===============================================================
-- select trunc(TIMESTAMP) "Date", count(*) Orphans from TELECOLLECT_ACQUISITION.ORPHANFRAME where TIMESTAMP >
-- to_date(to_char(sysdate - $NBJOURS ,'yyyymmdd'),'yyyymmdd')
-- group by trunc(TIMESTAMP)
-- ;
prompt
--
prompt TXFRAME $NBJOURS jours
prompt ==============================================================================
select trunc(TXF.timestamp) "Date",S_C.NAME as PROJET,
sum(decode( NVL(TXF.businesstransactionid,hextoraw('00')),hextoraw('00'),1,0) ) Non_traite,
sum(decode( NVL(TXF.businesstransactionid,hextoraw('00')),hextoraw('00'),0,1) ) Traite,
count(1) Total
from telecollect_business.txframe TXF,telecollect_acquisition.subcontract S_C
where TXF.subcontractid=S_C.ID
and TXF.timestamp > sysdate- $NBJOURS
and upper(S_C.NAME) in ('OCEA')
group by trunc(TXF.timestamp),S_C.NAME
order by 1 desc,2
/
prompt
--
prompt DOC sans les trames Test/Alarm/SMS
prompt ==============================================================================
select trunc(doc.CREATEDDATE)CREATEDDATE,count(*) Documents from TELECOLLECT_ACQUISITION.document doc,
TELECOLLECT_ACQUISITION.document_vhf vhf
where doc.CREATEDDATE >
to_date(to_char(sysdate - 10,'yyyymmdd'),'yyyymmdd') and
vhf.name not like '%T.xml%' and
vhf.name not like '%A.xml%' and
vhf.name not like 'InterfSMSC%' and
vhf.id=doc.id
group by trunc(doc.CREATEDDATE)
order by 1 desc
/
--
prompt
--
col REF_FICHIER_LOT format a44
prompt 
prompt ===============================================================
-- ;
prompt
--
exit 0
EOT
#
export STATUS=$?
if [ $STATUS != 0 ]
then
   echo "Erreur $0 : $STATUS : SQL/OS 1/2 ..." >&2
   exit 3
fi
#
done
##########################
#
#
