#!/bin/bash
#
# Alreadey set 
# export ORACLE_HOME=
# export ORA_ASM_HOME=
# export ORACLE_HOME_LISTNER=
#
# Variables defaut
#
#
#
if [ -r "/usr/local/etc/oracle/kenv_batch.sh" ]
then
. /usr/local/etc/oracle/kenv_batch.sh
else
ln -s -f /sitr/exploit/dba/kenv_batch.sh /usr/local/etc/oracle/kenv_batch.sh
. /usr/local/etc/oracle/kenv_batch.sh
fi
#
# export ORACLE_SID=NONE # default
#if [ "$ORACLE_HOME" == "" ]
#then
export ORACLE_BASE=/sitr/app/oracle
#export ORACLE_HOME=/sitr/app/oracle/product/11.2.0/asm
export ORACLE_HOME_LISTNER=/sitr/app/oracle/product/11.2.0/asm
export NLS_LANG=AMERICAN_AMERICA.WE8MSWIN1252
export NLS_LANG=FRENCH_FRANCE.WE8MSWIN1252
export ORA_ASM_HOME=/sitr/app/oracle/product/11.2.0/asm
#export ORACLE_SID=NONE
#
export MW_HOME=/sitr/app/oracle/middleware
. $MW_HOME/wlserver_10.3/server/bin/setWLSEnv.sh 1>/dev/null 2>&1
#fi
#
export SITRlogin_dw=oracle # default
#
export SITRlog=$SITRscript/log ;mkdir -p $SITRlog
export SITRhost=`hostname`
#
if [ ! -r $SITRscript/psw.$SITRhost ]
then
   echo "$SITRhost:Inco" > $SITRscript/psw.$SITRhost
fi
#
export SITRenv=`grep $SITRhost $SITRscript/psw.$SITRhost |cut -d':' -f2`
#########################################
export PS_rouge="\[\033[1;31m\][\u@\h-$SITRenv:\w]$\[\033[0m\] "
export PS_vert="\[\033[1;32m\][\u@\h-$SITRenv:\w]$\[\033[0m\] "
export PS_jaune="\[\033[1;33m\][\u@\h-$SITRenv:\w]$\[\033[0m\] "
export PS_magenta="\[\033[1;35m\][\u@\h-$SITRenv:\w]$\[\033[0m\] "
export PS_bleu="\[\033[1;36m\][\u@\h-$SITRenv:\w]$\[\033[0m\] "
export PS_autre="\[\033[1;36m\][\u@\h:\w]$\[\033[0m\] "
export PS_I_rouge="\[\033[1;41m\][\u@\h-$SITRenv:\w]$\[\033[0m\] "
export PS_I_vert="\[\033[1;42m\][\u@\h-$SITRenv:\w]$\[\033[0m\] "
export PS_I_jaune="\[\033[1;43m\][\u@\h-$SITRenv:\w]$\[\033[0m\] "
export PS_I_magenta="\[\033[1;45m\][\u@\h-$SITRenv:\w]$\[\033[0m\] "
export PS_I_bleu="\[\033[1;46m\][\u@\h-$SITRenv:\w]$\[\033[0m\] "
export PS_I_autre="\[\033[1;36m\][\u@\h:\w]$\[\033[0m\] "
#########################################
#
export SITRlogin=`logname`
export Liste_dbsingle="" # default
export Liste_dbrac="" # default
export PATH=$PATH:$SITRscript:/usr/local/bin:/bin:/usr/bin
export SITRymdhms=`date "+%Y%m%d%H%M%S"`
export SITRymdhm=`date "+%Y%m%d%H%M"`
export SITRymdh=`date "+%Y%m%d%H"`
export SITRymd=`date "+%Y%m%d"`
export SITRym=`date "+%Y%m"`
export SITRy=`date "+%Y"`
export LS_COLORS='di=1:fi=0:ln=31:pi=5:so=5:bd=5:cd=5:or=31:mi=0:ex=35:*.rpm=90'
#
if [ "$SITRlogin" == "" ]
then 
   export SITRlogin=$LOGNAME
fi
if [ "$SITRlogin" == "" ]
then 
   export SITRlogin=$USER
fi
#############################################################
#
# Libelles des scripts : dans fichier db_libelle_script.sh
#
#############################################################
#
# Aliases
#
#############################################################
#  linux
alias SITRstatus='echo SITRenv=$SITRenv;echo SITRhost=$SITRhost;echo SITRlogin=$SITRlogin;echo SITRlogin_dw=$SITRlogin_dw;echo Liste_host_dw=$Liste_host_dw;echo Liste_dbsingle=$Liste_dbsingle;b'
#
alias mw='cd $MW_HOME'
alias sw='cd $HOME/sw'
alias mdm='cd $HOME/mdm/app/ouaf'
#
alias Ss='. $SITRscript/SITR.profile';alias sS=Ss
alias SITR='cd $SITRscript';alias sitr=SITR
# alias ksh=/usr/bin/ksh
alias sh=/usr/bin/ksh
alias vi=vi
alias ls=ls
alias ll='ls -ial'
alias ltr='ls -ltr'
alias lsd='ls -l|grep "^d"'
alias lt='ls -lt'
alias dfdb='df -mP |grep $ORACLE_SID'
alias dfi2013='ksh db_dfi.sh |grep 2013'
alias df100='df -mP |grep 100%'
alias df99='df -mP |grep 99%'
alias df98='df -mP |grep 98%'
alias df97='df -mP |grep 97%'
alias df96='df -mP |grep 96%'
alias df95='df -mP |grep 95%'
alias df_m="sh $SITRscript/df_m.sh"
alias dfm="sh $SITRscript/df_m.sh"
alias SITRpass="sh $SITRscript/SITRpass.sh"
alias kora='. $SITRscript/kora'
alias b='$SITRscript/b'
alias cdr='cd $BACKUP_SITR_RMAN'
alias cdd='cd $BACKUP_SITR_DUMP'
alias df='df -P'
alias elog='cd /sitr/exploit/log'
alias wlog='cd /sitr/exploit/work/log'
#
#############################################################
#  oracle
alias sql='sqlplus / as sysdba'
alias sysdba='sqlplus / as sysdba'
alias sysasm='sqlplus / as sysasm'
alias oratab='echo "----------------------------";grep -v "^#" /etc/oratab|grep oracle;echo "----------------------------"'
alias oratab.sh='oratab.sh'
alias oh='cd $ORACLE_HOME'
alias oe="env | egrep 'ORA|LANG|PATH'"
alias tns='cd /sitr/oradata/$ORACLE_SID/network'
alias dbs='cd $ORACLE_HOME/dbs'
alias fra='cd /sitr/backup/$ORACLE_SID/flash_recovery_area/'
alias bck='cd /sitr/backup/$ORACLE_SID'
alias admin='cd /sitr/backup/$ORACLE_SID/admin'
alias logasm='tail -42 $ORA_ASM_HOME/admin/+ASM/bdump/alert_+ASM.log'
alias oradb='ps -eaf | grep ora_pmon_ | grep -v grep | awk -F "_" "{print \$3}"'
#
#############################################################
# tous les db_
export LISTEDB="$SITRscript/liste_libelle_script.txt"
for ii in `cat $LISTEDB|grep ":" |grep -v "^#"|grep -v "NOALIAS"|awk -F: '{print $1}' -`
do
   alias $ii="sh $SITRscript/$ii.sh"
done
#
#############################################################
alias expl='cd $SITRscript'
alias exploit='cd $SITRscript'
alias arch='cd /sitr/oradata/$ORACLE_SID/arch'
alias conf='cd /sitr/admin/scripts; ll;'; 
alias adm='cd /sitr/admin/$ORACLE_SID; ll;'; 
alias trace='cd /sitr/diag/rdbms/*/$ORACLE_SID/trace; ls -ltr'
alias alert='tail -100 /sitr/diag/rdbms/*/$ORACLE_SID/trace/alert_$ORACLE_SID.log'
alias dbs='cd $ORACLE_HOME/dbs'; 
alias fsdb='df -mP  | grep $ORACLE_SID'; 
alias dbtab='cat /etc/oratab'; 
alias rtab='cat /sitr/admin/scripts/rmantab'; 
alias etns='vi /sitr/oradata/$ORACLE_SID/network/tnsnames.ora'; 
alias elsnr='vi /sitr/oradata/$ORACLE_SID/network/listener.ora';
#
#############################################################
# tous les dgm_ prd_ sec_
# dgmgrl
alias dgm='dgmgrl sys/f6tem'
alias dgm_config="sh $SITRscript/dgm_config.sh"
alias dgm_status="sh $SITRscript/dgm_status.sh"
#
# dataguard
alias prd_dest2status="sh $SITRscript/prd_dest2status.sh"
alias prd_dest3status="sh $SITRscript/prd_dest3status.sh"
alias sec_managed_stdby="sh $SITRscript/sec_managed_stdby.sh"
#
#############################################################
# alias des bases 
alias dbliste='$SITRscript/oratab.sh'
alias dblist='$SITRscript/oratab.sh'
#
export host=$(uname -n)
export DBliste=/tmp/SITR_DBliste_$$
export DBalias=/tmp/SITR_DBalias_$$
> $DBliste
> $DBalias
if [ "$host" == "dsgide" ]
then 
   export OraTab=/var/opt/oracle/oratab
else
   export OraTab=/etc/oratab
fi
cat $OraTab | sed '/^#/d' | grep -v "*" | grep -v '^db:' | grep -v '^asm:'|grep -v "lastbase" > $DBliste
#
cat <<EOF |sort -u | grep -v '^$'| while read SID ; do
$(cat $DBliste |awk -F: '{print $1}')
$(ps -ef |grep smon|grep -v grep|awk -F_ '{print $3}'|sed 's/ //g')
EOF
# on initialise des choses
export oracle_sid=$SID
export MAJoracle_sid=`echo $SID|tr '[:lower:]' '[:upper:]'`
export MINoracle_sid=`echo $SID|tr '[:upper:]' '[:lower:]'`
export oracle_home=`cat $DBliste | grep -w ^${SID} | awk -F: '{print $2}'`
if [ "$oracle_sid" == "+ASM" ]
then
   echo "alias +ASM=asm" >>$DBalias
   echo "alias +asm=asm" >>$DBalias
else
   echo "alias $oracle_sid=\"export ORACLE_SID=$oracle_sid;export ORAENV_ASK=NO;. local_oraenv;export ORAENV_ASK=YES;b\" " >>$DBalias
   echo "alias $MAJoracle_sid=\"export ORACLE_SID=$oracle_sid;export ORAENV_ASK=NO;. local_oraenv;export ORAENV_ASK=YES;b\" " >>$DBalias
   echo "alias $MINoracle_sid=\"export ORACLE_SID=$oracle_sid;export ORAENV_ASK=NO;. local_oraenv;export ORAENV_ASK=YES;b\" " >>$DBalias
fi
done
. $DBalias
rm $DBliste 1>/dev/null 2>&1
rm $DBalias 1>/dev/null 2>&1
#
#############################################################
#
# Function
#
dfxx ()
{
for i in 100 99 98 97 96 95 94 93 92 91 90 89 88 87 86 85
do
df -mP |grep ${i}%
done
}
#
db ()
{
        # Environnement Oracle pour asm
        #
        $SITRscript/oratab.sh 
        echo -e "db ...? \c"
        read ORACLE_SID
        export PATH=$ORACLE_HOME/bin:$PATH:$ORACLE_HOME/OPatch
        export ORAENV_ASK=NO
        . local_oraenv
        export ORAENV_ASK=YES
        b
}
#
asm ()
{
        # Environnement Oracle pour asm
        #
        export ORACLE_HOME=$ORA_ASM_HOME
        export ORACLE_SID=+ASM
        export PATH=$ORACLE_HOME/bin:$PATH:$ORACLE_HOME/OPatch
        export ORAENV_ASK=NO
        . local_oraenv
        export ORAENV_ASK=YES
        b
}
#
arc() {
   sqlplus -s "/ as sysdba" <<EOF
     select sequence#,
            to_char(first_time, 'YYYY/MM/DD HH24:MI:SS') first_time,
            applied || '    ' APPLIED
     from v\$archived_log order by 2 ;

     archive log list
     prompt
     select process, client_process, sequence#, status, BLOCKS, BLOCK#, DELAY_MINS from v\$managed_standby;
     prompt
     select database_role, current_scn from v\$database;
EOF
}
#
