ssh -L 1158:localhost:1158 oracle@db1-psw-sup

