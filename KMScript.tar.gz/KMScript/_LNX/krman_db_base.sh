#!/bin/bash
# kma
#
# set before $ORACLE_HOME
#
#
# la base
if [ "$1" == "" ]
then
   echo "Usage is : $0 <Base>"
  exit 101
else
   export leSID=$1
fi
#
# les variables pour le batch
export ORACLE_SID=$leSID
. /usr/local/etc/oracle/kenv_batch.sh $leSID
. $BINDIR/kenv_nls.sh
#
cd $BINDIR
#
rm -f ${WORKDIR}/krman_db_$$.tmp* 1>/dev/null 2>&1
#
export SQLTMP=${WORKDIR}/krman_db_$$.tmp
#
export a_error_svg=0
#
export myrep=$BACKUP_SITR_RMAN
mkdir -p $myrep
#
if [ -x $myrep ]
then
# 
export KMymdhms=`date "+%Y%m%d%H%M%S"`
# %d : db name, %s : set num, %p : piece in set
export BACKUP_LEVEL=0
export BACKUP_TYPE=FULL # full ou incr
ARCTAG=${ORACLE_SID}_ARC_1_${KMymdhms}
DTBTAG=${ORACLE_SID}_DTB_${BACKUP_LEVEL}_${KMymdhms}
CTLTAG=${ORACLE_SID}_CTL_${BACKUP_LEVEL}_${KMymdhms}
SPFTAG=${ORACLE_SID}_SPF_${BACKUP_LEVEL}_${KMymdhms}
ARCSET=${ARCTAG}_s%s_p%p
DTBSET=${DTBTAG}_s%s_p%p
CTLSET=${CTLTAG}_s%s_p%p
SPFSET=${SPFTAG}_s%s_p%p
export LOGFILE=krman_db_${ORACLE_SID}_FULL_$KMymdhms.log
export CONFILE=krman_db_${ORACLE_SID}_FULL_$KMymdhms.cfg
echo $LOGDIR/$LOGFILE
#
##################################################################
#
rm -f $WORKDIR/$CONFILE
echo "CONFIGURE RETENTION POLICY TO RECOVERY WINDOW OF ${WINDOW_RMAN} DAYS; " >> $WORKDIR/$CONFILE
echo "CONFIGURE BACKUP OPTIMIZATION ON; " >> $WORKDIR/$CONFILE
echo "CONFIGURE DEFAULT DEVICE TYPE TO DISK; " >> $WORKDIR/$CONFILE
echo "CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE DISK TO '$myrep/ctl_auto_${ORACLE_SID}_%F'; " >> $WORKDIR/$CONFILE
echo "CONFIGURE DEVICE TYPE DISK PARALLELISM 8 BACKUP TYPE TO compressed BACKUPSET; " >> $WORKDIR/$CONFILE
echo "CONFIGURE DATAFILE BACKUP COPIES FOR DEVICE TYPE DISK TO 1; " >> $WORKDIR/$CONFILE
echo "CONFIGURE ARCHIVELOG BACKUP COPIES FOR DEVICE TYPE DISK TO 1; " >> $WORKDIR/$CONFILE
echo "CONFIGURE CHANNEL DEVICE TYPE DISK FORMAT '$myrep/${ORACLE_SID}_%t_s%s_p%p' MAXOPENFILES 10; " >> $WORKDIR/$CONFILE
echo "CONFIGURE AUXILIARY CHANNEL DEVICE TYPE DISK FORMAT '$myrep/${ORACLE_SID}_%t_s%s_p%p'; " >> $WORKDIR/$CONFILE
echo "CONFIGURE MAXSETSIZE TO UNLIMITED; " >> $WORKDIR/$CONFILE 
echo "CONFIGURE ENCRYPTION FOR DATABASE OFF; " >> $WORKDIR/$CONFILE
echo "CONFIGURE ENCRYPTION ALGORITHM 'AES128'; " >> $WORKDIR/$CONFILE
echo "CONFIGURE COMPRESSION ALGORITHM 'BASIC' AS OF RELEASE 'DEFAULT' OPTIMIZE FOR LOAD TRUE; " >> $WORKDIR/$CONFILE
echo "CONFIGURE ARCHIVELOG DELETION POLICY TO NONE; " >> $WORKDIR/$CONFILE
echo "CONFIGURE SNAPSHOT CONTROLFILE NAME TO '$myrep/snapcf_${ORACLE_SID}.f'; " >> $WORKDIR/$CONFILE
echo "CONFIGURE CONTROLFILE AUTOBACKUP ON; " >> $WORKDIR/$CONFILE
#
rman target=/ nocatalog log="$LOGDIR/$LOGFILE" <<EOT
#
@$WORKDIR/$CONFILE
#
show all ;
#
CONFIGURE CONTROLFILE AUTOBACKUP ON;
#
crosscheck backup; 
crosscheck archivelog all ;
#
sql 'alter system archive log current';
backup archivelog all delete input  tag ${ARCTAG} format='$myrep/$ARCSET' ;
#
backup database tag ${DTBTAG} format='$myrep/$DTBSET' ;
#
sql 'alter system archive log current';
backup archivelog all delete input  tag ${ARCTAG} format='$myrep/$ARCSET' ;
#
backup tag ${CTLTAG} format='$myrep/$CTLSET' current controlfile;
backup tag ${SPFTAG} format='$myrep/$SPFSET' spfile ;
#
CONFIGURE CONTROLFILE AUTOBACKUP OFF;
exit
#
EOT
###################################################################
#
#
if [ $? -ne 0 ]
then
   export a_error_svg=1
else
   export a_error_svg=0
fi 
#
#########
#
export STATUS=$a_error_svg
if [ $STATUS != 0 ]
then
   echo bash $BINDIR/db_mailx.sh $LOGDIR/$LOGFILE ProblemeRMAN "$LISTEMAIL"
   bash $BINDIR/db_mailx.sh $LOGDIR/$LOGFILE ProblemeRMAN "$LISTEMAIL"
   # Mail et continuer 
   echo ""
fi
#
##############
#
fi
#
cp -f $LOGDIR/$LOGFILE $myrep 1>/dev/null 2>&1
cp -f $WORKDIR/$CONFILE $myrep 1>/dev/null 2>&1
#
rm -f ${WORKDIR}/krman_db_$$.tmp* 1>/dev/null 2>&1
#
