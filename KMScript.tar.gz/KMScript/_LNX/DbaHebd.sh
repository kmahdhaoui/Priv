#!/bin/bash
# 
# Author : Kamel Mahdhaoui
# Unautorized use is forbidden 
#
export MyHost=`hostname`
export petithost=`hostname | awk -F. '{print $1}' -`
#
export alert_dir=`sqlplus -s / as sysdba <<EOT
set pages 0
set headi off
set feedb off
set verify off
set pages 155
col value format a70
select value from v\\$parameter where name='background_dump_dest';
exit
EOT
`
export alert_log="alert_${ORACLE_SID}.log"
# *****************************************************************************
#
echo $alert_dir/$alert_log
#
if [ "$1" = "1" ]
then
#
echo "************************************************************************"
echo "*                        Last Analyzed                                 *"
echo "************************************************************************"
date
#
#
#
echo "************************************************************************"
echo "-                        Calcul pour AWR                                 -"
echo "************************************************************************"
date
sqlplus -s / as sysdba <<EOT
set pages 600
drop table KMscript_stat_dat;
create table KMscript_stat_dat 
as select 
'$KMhost' machine,
'$ORACLE_SID' base,
to_char(sysdate,'yymmdd') dateH,
'SYSSTAT' typeD ,
name name,
to_char(value) value1,
' '  value2,
' '  value3,
' '  value4,
' '  value5,
' '  value6,
' '  value7,
' '  value8,
' '  value9
from v\$sysstat where 
name in (
'bytes received via SQL*Net from client',
'bytes received via SQL*Net from dblink',
'bytes sent via SQL*Net to client',
'bytes sent via SQL*Net to dblink',
'consistent gets',
'db block gets',
'physical reads',
'physical writes',
'sorts (disk)',
'sorts (memory)',
'user calls',
'user commits',
'user rollbacks'
)
union all
select 
'$petithost' machine,
'$ORACLE_SID' base,
to_char(sysdate,'yymmdd') dateH,'TABSTAT' typeD, 
table_name name, 
owner value1,
to_char(num_rows) value2,
to_char(AVG_ROW_LEN)  value3,
to_char(CHAIN_CNT)  value4,
' '  value5,
' '  value6,
' '  value7,
' '  value8,
' '  value9
from dba_tables where 
owner not like '%SYS%'
and owner not like 'ORACLE'
and owner not like 'OPS%ORACLE'
and owner not like 'DBSNMP'
and owner not like 'SCOTT'
and owner not like 'OUTLN'
and owner not like '%KAMEL%'
;
exit;
EOT
#
echo "************************************************************************"
echo "-                        generation des stat AWR                       -"
echo "************************************************************************"
date
sqlplus -s / as sysdba <<EOT
set pages 0
set headi off
set feedback off
set verify off
set lines 250
spool  KM_${KMsite}_${KMhost}_${ORACLE_SID}.txt
select 
machine||':'||base||':'||dateH||':'||typeD||':'||name||':'||
value1||':'||
value2||':'||
value3||':'||
value4||':'||
value5||':'||
value6||':'||
value7||':'||
value8||':'||
value9
from  KMscript_stat_dat
;
spool off
exit;
EOT
#
fi
#
date
#
