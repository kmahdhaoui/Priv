#!/bin/bash
#
echo sitr2014
read
#
ssh cinstall@sefrapp00153 'sudo chgrp -R oinstall kamel kamel/* /sitr/exploit/*'
ssh cinstall@sefrapp00154 'sudo chgrp -R oinstall kamel kamel/* /sitr/exploit/*'
ssh cinstall@sefrapp00148 'sudo chgrp -R oinstall kamel kamel/* /sitr/exploit/*'
ssh cinstall@sefrapp00155 'sudo chgrp -R oinstall kamel kamel/* /sitr/exploit/*'
#
ssh cinstall@sefrapp00153 'sudo chmod -R g+rwx kamel kamel/* /sitr/exploit/*'
ssh cinstall@sefrapp00154 'sudo chmod -R g+rwx kamel kamel/* /sitr/exploit/*'
ssh cinstall@sefrapp00148 'sudo chmod -R g+rwx kamel kamel/* /sitr/exploit/*'
ssh cinstall@sefrapp00155 'sudo chmod -R g+rwx kamel kamel/* /sitr/exploit/*'
#
