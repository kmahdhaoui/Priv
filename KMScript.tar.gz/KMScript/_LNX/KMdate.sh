export chaine=`date "+day=%d; month=%m; year=%Y ; myHour=%k ; jour=%w ; semaine=%W "`
export chaine=`echo $chaine | tr -d ' ' `
eval $chaine
#jour=$(printf "%01d" $jour)
#day=$(printf "%02d" $day)
#month=$(printf "%02d" $month)
#myHour=$(printf "%02d" $myHour)
#year=$(printf "%04d" $year)
export day month year myHour jour
echo "day	 month	 year	 myHour	 jour"
echo "$day	 $month	 $year	 $myHour	 $jour"

