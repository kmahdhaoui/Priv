#!/bin/ksh
# Author : Kamel Mahdhaoui
# 
. ~oracle/.profile 1>/dev/null 2>&1
export ORACLE_SID=lastbase
. ~oracle/scripts/kamel/kamel.profile silent 1>/dev/null 2>&1
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh 1>/dev/null 1>/dev/null 2>&1
#
export host=$(uname -n)
export listbases=/tmp/kamel_listbases_$$
export OK=`echo "OK"`
export KO=`echo "KO"`
#
> $listbases
if [ "$host" == "dsgide" ]
then 
   export OraTab=/var/opt/oracle/oratab
else
   export OraTab=/etc/oratab
fi
cat $OraTab | sed '/^#/d' | grep -v "*" | grep -v "lastbase" > $listbases
#
cat <<EOF |sort -u | grep -v '^$' | while read SID ; do
$(cat $listbases |awk -F: '{print $1}')
$(ps -ef |grep smon|grep -v grep|awk -F_ '{print $3}'|sed 's/ //g')
EOF
# on initialise des choses
TimU="-1"
UPTime="-1"
Version="-1"
Version2="-1"
XPUVD="ERR"
codeappli="ERR"
portlsnr=-1
spfile="ERR"
nbdbf=-1
Dem="ERR"
STS="ERR"
MSG="ERR"
keeptime="-1"
compression="ERR"
parallelisme="-1"
tdpo="ERR"
verins="-1"
bundlepsu="ERR"
V_SEEE="ERR"
logmode="ERR"
nbdbf=-1
taillego=-1
fsappli="ERR"
compat="-1"
# 2eme char
export XPUVD=`echo $SID|cut -c2-2`
export codeappli=`echo $SID|cut -c3-5`
#
STS=$OK ; MSG=''
export TimU=$(ps -eo etime,user,args| grep "smon_${SID} *$"|awk '{print $1}')
export UPTime=`echo $TimU |awk '{print $1}'`
export Version=$(cat $listbases |grep -w ^${SID} | awk -F: '{print $2}'| awk 'FS="/" {print $5}')
export Inter=$(cat $listbases |grep -w ^${SID} | awk -F: '{print $4}'| awk 'FS=" " {print $1}')
export Dem=$(cat $listbases |grep -w ^${SID} | awk -F: '{print $3}'| awk 'FS=" " {print $1}')
#
export fictmp=/tmp/kamel_$$_$SID.txt
>$fictmp
#
export lsnr=$(ps -ef |grep lsnr |grep ${SID} |awk '{print $10}')
#
export ORACLE_SID=$SID
export ORACLE_HOME=`cat $listbases | grep -w ^${SID} | awk -F: '{print $2}'`
export PATH=$ORACLE_HOME/bin:$PATH
export LIBPATH=/usr/lib:$ORACLE_HOME/lib32:$ORACLE_HOME/lib:$ORACLE_HOME/jlib:$ORACLE_HOME/network/jlib
#
sqlplus -s "$conn" 1>/dev/null 2>&1 <<EOT >/dev/null
set echo off termout off head off verify off feedback off serveroutput off
spool $fictmp
select STATUS from v\$instance;
spool off
exit
EOT
#
if [ -z "$UPTime" ]
then
    UPTime="-1"
    STA='DOWN'
  #  MSG=`echo "$R {{(([[Pas de mode Intervention]]))}} $F"`
else
    UPTime="+"`echo $UPTime|grep "\-" |awk -F\- '{print $1}'`
    if [ "$UPTime" == "+" ] 
    then
       UPTime="+0"
    fi
    if [ -z "$lsnr" ]
    then
      STA='LSNR'
      MSG=`echo "$J PB_LSNR $F"`
    else
      STA=`cat $fictmp | sed '/^$/d' | sed 's/[ \t]*$//'`
    fi
#
#
#
# ---------- verins
# ---------- keeptime
# ---------- spfile
export mystatut=9
>$fictmp
sqlplus -s "$conn" 1>/dev/null 2>&1 <<EOT >/dev/null
set echo off termout off head off verify off feedback off serveroutput off
spool $fictmp
whenever sqlerror exit 1
select 'keeptime'||':'||'v'||':'||VALUE from v\$parameter where name like 'control_file_record_keep_time';
whenever sqlerror exit 2
select 'spfile'||':'||'v'||':'||'Y'||'ES' from v\$parameter where name like 'spfile' and value is not null;
whenever sqlerror exit 3
select 'verins'||':'||'v'||':'||VERSION from v\$instance where INSTANCE_NUMBER=1 ;
whenever sqlerror exit 4
select 'compat'||':'||'v'||':'||VALUE from v\$parameter where name like 'compatible' ;
spool off
exit 0
EOT
export mystatut=$?
if [ $mystatut -eq 0 ]
then
   export verins=`cat $fictmp|grep verins | sed '/^$/d' | sed 's/[ \t]*$//'|awk -F:v: '{print $2}' `
   export keeptime=`cat $fictmp | grep keeptime |sed '/^$/d' | sed 's/[ \t]*$//'|awk -F:v: '{print $2}' `
   export spfile=`cat $fictmp | grep spfile |sed '/^$/d' | sed 's/[ \t]*$//'|awk -F:v: '{print $2}' `
   export compat=`cat $fictmp|grep compat | sed '/^$/d' | sed 's/[ \t]*$//'|awk -F:v: '{print $2}' `
else
   export verins="-1"
   export keeptime="-1"
   export spfile="N"
   export compat="-1"
fi
#
# ---------- compression
# ---------- parallelisme
# ---------- tdpo
#
export mystatut=9
>$fictmp
sqlplus -s "$conn" 1>/dev/null 2>&1 <<EOT >/dev/null
set echo off termout off head off verify off feedback off serveroutput off
spool $fictmp
whenever sqlerror exit 1
select rtrim(ltrim(a1.VALUE)) from v\$rman_configuration a1
  where a1.NAME='DEVICE TYPE'
  and a1.VALUE like '%SBT_TAPE%'
union
select rtrim(ltrim(a2.VALUE)) from v\$rman_configuration a2
  where a2.NAME='CHANNEL'
  and a2.VALUE like '%SBT_TAPE%'
  and not exists (select 'x' from v\$rman_configuration b where b.NAME='DEVICE TYPE')
  and exists (select 'x' from v\$rman_configuration c where c.NAME like 'DEFAULT DEVICE TYPE%'
              and c.VALUE like '%SBT_TAPE%')
;
spool off
exit 0
EOT
export mystatut=$?
if [ $mystatut -eq 0 ]
then
   export compression='NOCOMP'
   export parallelisme=1
   for i in 1 2 3 4 5 6 7 8 9 10 11 12
   do
   export UnMot=`cat $fictmp |grep SBT_TAPE | cut -d' ' -f$i`
   case "$UnMot" in 
        COMPRESSED)  compression="COMP"
                     ;;
        PARALLELISM) iplus1=`expr $i + 1 `
                     parallelisme=` cat $fictmp |grep SBT_TAPE | cut -d' ' -f$iplus1`
                     ;;
   esac
   done
else
   export compression="N"
   export parallelisme="-1"
fi
#
export mystatut=9
>$fictmp
sqlplus -s "$conn" 1>/dev/null 2>&1 <<EOT >/dev/null
set echo off termout off head off verify off feedback off serveroutput off
spool $fictmp
whenever sqlerror exit 1
select 'tdpo'||':'||'v'||':'||
substr ( c1,instr(c1,'/',1,3)+1,20) from
(select
substr( VALUE, instr(VALUE,'TDPO_OPTFILE')+13, 1+
instr(VALUE,'.',instr(VALUE,'TDPO_OPTFILE')) - instr(VALUE,'TDPO_OPTFILE')-13 ) c1
from V\$RMAN_CONFIGURATION where NAME='CHANNEL'
)
;
spool off
exit 0
EOT
export mystatut=$?
if [ $mystatut -eq 0 ]
then
   export tdpo=`cat $fictmp|grep tdpo | sed '/^$/d' | sed 's/[ \t]*$//'|awk -F:v: '{print $2}' `
   export tdpo=`echo $tdpo |tr -d ' '|tr -d ')'|tr -d '/'|tr -d '.'`
   if [ "$tdpo" == "tdpo_$ORACLE_SID" ]
   then 
      export tdpo="Ok"
   else
      export tdpo="Pb Cfg"
   fi
else
   export tdpo="Non"
fi
#
# ---------- logmode
# ---------- taillego
# ---------- nbdbf
# ---------- fsappli
# ---------- bundlepsu
export mystatut=9
>$fictmp
sqlplus -s "$conn" 1>/dev/null 2>&1 <<EOT >/dev/null
set echo off termout off head off verify off feedback off serveroutput off
spool $fictmp
whenever sqlerror exit 1
select 'logmode'||':'||'v'||':'||decode(substr(LOG_MODE,1,4),'NOAR','NO',substr(LOG_MODE,1,4))  from  v\$database ;
whenever sqlerror exit 2
select 'taillego'||':'||'v'||':'||round(sum(bytes)/1024/1024/1024) GB from v\$datafile; 
whenever sqlerror exit 3
select 'nbdbf'||':'||'v'||':'||count(*) NBDBF from v\$datafile;
whenever sqlerror exit 4
select 'fsappli'||':'||'v'||':'||SUBSTR(name,INSTR(name,'/',1,1)+1,INSTR(name,'/',1,2)-2) from v\$datafile where FILE#=1;
-- 999 erreur speciale car elle peut arriver si pas de psu
whenever sqlerror exit 999
select 'bundlepsu'||':'||'v'||':'||a.bundle_series||' '||ID from dba_registry_history a where a.action_time in
(select max(b.action_time) from dba_registry_history b where b.bundle_series like 'PSU%') ;
spool off
exit 0
EOT
export mystatut=$?
if [ $mystatut -eq 999 ]
then 
   export bundlepsu=`cat $fictmp|grep bundlepsu | sed '/^$/d' | sed 's/[ \t]*$//'||awk -F:v: '{print $2}' `
else
   export bundlepsu="N"
   export mystatut=0
fi
#
if [ $mystatut -eq 0 ]
then
   export logmode=`cat $fictmp | grep logmode |sed '/^$/d' | sed 's/[ \t]*$//'|awk -F:v: '{print $2}' `
   export taillego=`cat $fictmp | grep taillego |sed '/^$/d' | sed 's/[ \t]*$//'|awk -F:v: '{print $2}' `
   export nbdbf=`cat $fictmp | grep nbdbf |sed '/^$/d' | sed 's/[ \t]*$//'|awk -F:v: '{print $2}' `
   export fsappli=`cat $fictmp | grep fsappli |sed '/^$/d' | sed 's/[ \t]*$//'|awk -F:v: '{print $2}' `
   export bundlepsu=`cat $fictmp|grep bundlepsu | sed '/^$/d' | sed 's/[ \t]*$//'|awk -F:v: '{print $2}' `
else
   export logmode="N"
   export taillego="-1"
   export nbdbf="-1"
   export fsappli="N"
   export bundlepsu="N"
fi
#
# -----------------------------
fi
# ---------- port listener
#
renvoi_port() {
ARGS="$*"
for arg in ${ARGS}
do
    case "$arg" in
         PORT=*|port=*) leport=`echo "$arg" | sed -e 's/^[^=]*=//'` ;;
    esac
done
echo $leport
}
>$fictmp
lsnrctl 1> $fictmp 2>&1 <<EOT
status $ORACLE_SID
exit
EOT
#
export lsnrgrep=`grep -i port $fictmp|grep \= |grep \(|grep \) `
export lsnrgrep=`echo $lsnrgrep|tr "()" "  " `
export lsnrgrep=`echo $lsnrgrep|sed 's/ =/=/g'|sed 's/= /=/g' `
export portlsnr=`renvoi_port $lsnrgrep`
# -----------------------------------------------------------------
#
if [ "$Inter" == "I" ]
then
     MSG=`echo "$M MODE_I $MSG $F"`
fi
#
if [ -z "$Version" ]
then
     Version2='N/A'
     STS=$KO
     Dem='?'
     MSG=`echo "$J PB_ORATAB $F"`
else
     if [ $Version == "distrib" ]
     then
       Version2=$(cat $listbases | grep -w ^${SID} | awk -F: '{print $2}'| awk 'FS="/" {print $6}')
     else
       Version2=`echo ${Version} | awk -Fa '{print $2}'`
    fi
fi
#
patchOA=`expr substr ${Version2} 1 1`
#
if [ $patchOA == "o" ]
then
Version2=`expr substr ${Version2} 4 6`
fi
#
# verins c ce qui vient de v$instance
export VersionX=$(cat $listbases | grep -w ^${SID} | awk -F: '{print $2}'| awk 'FS="/" {print $7}')
#
if [ $Version2 == "se" ]
then
   VersionX=$(cat $listbases | grep -w ^${SID} | awk -F: '{print $2}'| awk 'FS="/" {print $7}')
   if [ "$verins" != "-1" ]
   then
      VersionX=$verins
   fi
   Version2=`echo $VersionX`
   V_SEEE="SE"
else
   if [ "$verins" != "-1" ]
   then
      VersionX=$verins
   fi
   Version2=`echo $VersionX`
   V_SEEE="EE"
fi
#
if [ -z "$STA" ]
then
   STS=`echo "$R FAILED $F"`
else
   if [ $STA == "OPEN" ]
   then
      STS=`echo "$V $STA $F"`
   else
      if [ $STA == "STARTED" ] && [ "$SID" == "+ASM" ]
      then
          STS=`echo "$V $STA $F"`
      else
          STS=`echo "$R $STA $F"`
      fi
  fi
fi
#
rm -f $fictmp 1>/dev/null 2>&1
#
echo "$host;" "$SID;" "$logmode;" "$XPUVD;" "$codeappli;" "$fsappli;" "$portlsnr;" "$Version2;" "$V_SEEE;" "$bundlepsu;" "$spfile;" "$compat;" "$nbdbf;" "$taillego;" "$keeptime;" "$compression;" "$parallelisme;" "$tdpo;" "$UPTime;" "$Dem;" "$STS;" "$MSG;"
done
#
rm $listbases 1>/dev/null 2>&1
#
. $KMscript/KMlogout.sh 1>/dev/null 2>&1
#

