#!/bin/bash
# kamel Mahdhaoui
# la base c'est $ORACLE_SID
# si pas de ORACLE_SID on ne sette pas le sid
#
#
export PATH=$PATH:/usr/local/bin
#
# Param principal : SITR_TOP 
#----------------------------
#
export SITR_TOP=/sitr
#
export SITREXPL=${SITR_TOP}/exploit
# on doit trouver les scripts dans $BINDIR
export BINDIR=${SITREXPL}/dba
#
# Les mails
#---------------------------
#
export MAIL_ADM_ORA="kamel.mahdhaoui@suez-env.com"
export MAIL_ADM_MDO="kamel.mahdhaoui@suez-env.com"
export MAIL_ADM_MDS="kamel.mahdhaoui@suez-env.com"
export MAIL_ADM_LNX="kamel.mahdhaoui@suez-env.com"
export MAIL_ADM_WLS="kamel.mahdhaoui@suez-env.com"
export MAIL_EXP_ORA="kamel.mahdhaoui@suez-env.com"
export MAIL_EXP_MDO="kamel.mahdhaoui@suez-env.com"
export MAIL_EXP_MDS="kamel.mahdhaoui@suez-env.com"
export MAIL_EXP_LNX="kamel.mahdhaoui@suez-env.com"
export MAIL_EXP_WLS="kamel.mahdhaoui@suez-env.com"
#
export MAIL_ADM_ORA="patrick.hamelin@suez-env.com,kamel.mahdhaoui@suez-env.com,faical.ellani.ext@suez-env.com"
export MAIL_ADM_ORA="Thierry.rakotoarison@suez-env.com,faical.ellani.ext@suez-env.com,patrick.hamelin@suez-env.com,kamel.mahdhaoui@suez-env.com,sebastien.nayrolles@suez-env.com,mathieu.dailly@suez-env.com"
export LISTEMAIL=$MAIL_ADM_ORA
#
# un lien
#---------------------------
#
if [ ! -f /usr/local/etc/oracle/kenv_batch.sh ]
then
   ln -s $BINDIR/kenv_batch.sh /usr/local/etc/oracle/kenv_batch.sh 1>/dev/null 2>&1
fi
#
# des repertoires
#---------------------------
#
export LOGDIR=${SITREXPL}/work/log
export WORKDIR=${SITREXPL}/work/log
export SUPDIR=${SITREXPL}/sup
#
# ProblemePfile ProblemeExpdp EspaceFS ProblemeStats  ProblemeRMAN
# ProblemeStartLsnr ProblemeStartup ProblemeStopLsnr ProblemeShutdown
export SUPOTHERFILE_OLD=${SUPDIR}/kother_o.sup
export SUPOTHERFILE_NEW=${SUPDIR}/kother_n.sup
export SUPOTHERFILE=${SUPDIR}/kother.sup
export MAILOTHERFILE=${SUPDIR}/kmailother.sup
#
# Oracle Errors
export SUPORAERRORSFILE_OLD=${SUPDIR}/koraerrors_o.sup
export SUPORAERRORSFILE_NEW=${SUPDIR}/koraerrors_n.sup
export SUPORAERRORSFILE=${SUPDIR}/koraerrors.sup
export MAILORAERRORSFILE=${SUPDIR}/kmailoraerrors.sup
#
# TBS Errors
export SUPTBSFILE_OLD=${SUPDIR}/ktbs_o100.sup
export SUPTBSFILE_NEW=${SUPDIR}/ktbs_n100.sup
export SUPTBSFILE=${SUPDIR}/ktbs.sup
export MAILTBSFILE=${SUPDIR}/kmailtbs.sup
#
mkdir -p $WORKDIR $LOGDIR $SUPDIR
chmod 775 $WORKDIR $LOGDIR $SUPDIR
#
# variables
#---------------------------
#
export DATE=$(date "+%d/%m/%Y %H:%M:%S")
export KMymdhms=`date "+%Y%m%d%H%M%S"`
#
#
# leSID cad $ORACLE_SID si pas vide
#-----------------------------------
#
if [ "$ORACLE_SID" != "" ]
then
export ORAENV_ASK=NO
. oraenv 1>/dev/null
export ORAENV_ASK=YES
export PATH=$ORACLE_HOME/bin:$PATH
export PATH=$PATH:$ORACLE_HOME/bin
export leSID=$ORACLE_SID
else
export leSID=$ORACLE_SID
fi
#
#
# valeurs par defaut ou specifiques backup tar
#-----------------------------------------------
#
export BACKUP_SITR_LOCAL=$SITR_TOP/backup
#
case `hostname` in
     sefrapp00148*|SEFRAPP00148*) # weblogic node
                export BACKUP_SITR_TOPA=/sitrbck_01 # dump/tars 
                export BACKUP_SITR_TOPR=/sitrbck_01 # Rman
                ;;
     sefrapp00155*|SEFRAPP00155*) # weblogic node
                export BACKUP_SITR_TOPA=/sitrbck_01 # dump/tars
                export BACKUP_SITR_TOPR=/sitrbck_01 # Rman
                ;;
     sefrapp00153*|SEFRAPP00153*) # oracle node
                export BACKUP_SITR_TOPA=/sitrbck_01 # dump/tars
                export BACKUP_SITR_TOPR=/sitrbck_01 # Rman
                ;;
     sefrapp00154*|SEFRAPP00154*) # oracle node
                export BACKUP_SITR_TOPA=/sitrbck_01 # dump/tars
                export BACKUP_SITR_TOPR=/sitrbck_01 # Rman
                ;;
     sitr-dtb2-rec*|SITR-DTB2-REC*) # oracle node
                export BACKUP_SITR_TOPA=/sitrbck_02 # dump/tars recette sur /sitrbck_02
                export BACKUP_SITR_TOPR=/sitrbck_01 # rman recette sur /sitrbck_01 sauf RMDMEMET
                ;;
     oslnx001*|OSLNX001*) # oracle node
                export BACKUP_SITR_TOPA=/sitrbck_02 # dump/tars 
                export BACKUP_SITR_TOPR=/sitrbck_02 # rman
                ;;
                               *) # other
                export BACKUP_SITR_TOPA=/sitrbck_02
                export BACKUP_SITR_TOPR=/sitrbck_02
                ;;
esac
#
# doit etre un pointde montage
mountpoint -q $BACKUP_SITR_TOPA 1>/dev/null 2>&1 
export ISMOUNTPOINT=$?
if [ "$ISMOUNTPOINT" != "0" ]
then 
   export BACKUP_SITR_TOPA=$BACKUP_SITR_LOCAL
fi
#
case `hostname` in
     sefrapp00148*|SEFRAPP00148*) # weblogic node
                export BACKUP_SITR_TAR=${BACKUP_SITR_TOPA}/sefrapp00148
                ;;
     sefrapp00155*|SEFRAPP00155*) # weblogic node
                export BACKUP_SITR_TAR=${BACKUP_SITR_TOPA}/sefrapp00155
                ;;
     sefrapp00153*|SEFRAPP00153*) # oracle node
                export BACKUP_SITR_TAR=${BACKUP_SITR_TOPA}/sefrapp00153
                ;;
     sefrapp00154*|SEFRAPP00154*) # oracle node
                export BACKUP_SITR_TAR=${BACKUP_SITR_TOPA}/sefrapp00154
                ;;
     sitr-dtb2-rec*|SITR-DTB2-REC*) # oracle node
                export BACKUP_SITR_TAR=${BACKUP_SITR_TOPA}/sitr-dtb2-rec
                ;;
     oslnx001*|OSLNX001*) # oracle node
                export BACKUP_SITR_TAR=${BACKUP_SITR_TOPA}/oslnx001
                ;;
     *) # other
                export BACKUP_SITR_TAR=${BACKUP_SITR_TOPA}/other
                ;;
esac
#
export BACKUP_SITR=${SITR_TOPA}/backup
#
# valeurs par defaut ou specifiques backup oracle
#---------------------------------------------------
#
if [ "${ORACLE_SID}" != "" ]
then
case ${ORACLE_SID} in 
     RMDMEMET) # cas particulier
         export WINDOW_DUMP=8
         export WINDOW_RMAN=8
         export BACKUP_SITR_DUMP=${BACKUP_SITR_TOPA}/$ORACLE_SID/dump
         export BACKUP_SITR_RMAN=/sitrbck_02/RMDMEMET/rman # cas particulier
         ;;
     X*) # Exploitation (Production)
         export WINDOW_DUMP=15
         export WINDOW_RMAN=15 
         export BACKUP_SITR_DUMP=${BACKUP_SITR_TOPA}/$ORACLE_SID/dump
         export BACKUP_SITR_RMAN=${BACKUP_SITR_TOPR}/$ORACLE_SID/rman
         ;;
     P*) # Pre-production
         export WINDOW_DUMP=15
         export WINDOW_RMAN=15 
         export BACKUP_SITR_DUMP=${BACKUP_SITR_TOPA}/$ORACLE_SID/dump
         export BACKUP_SITR_RMAN=${BACKUP_SITR_TOPR}/$ORACLE_SID/rman
         ;;
     R*) # Recette
         export WINDOW_DUMP=8
         export WINDOW_RMAN=8 
         export BACKUP_SITR_DUMP=${BACKUP_SITR_TOPA}/$ORACLE_SID/dump
         export BACKUP_SITR_RMAN=${BACKUP_SITR_TOPR}/$ORACLE_SID/rman
         ;;
     I*) # Integration
         export WINDOW_DUMP=8
         export WINDOW_RMAN=8 
         export BACKUP_SITR_DUMP=${BACKUP_SITR_TOPA}/$ORACLE_SID/dump
         export BACKUP_SITR_RMAN=${BACKUP_SITR_TOPR}/$ORACLE_SID/rman
         ;;
     D*) # Developement
         export WINDOW_DUMP=8
         export WINDOW_RMAN=8 
         export BACKUP_SITR_DUMP=${BACKUP_SITR_TOPA}/$ORACLE_SID/dump
         export BACKUP_SITR_RMAN=${BACKUP_SITR_TOPR}/$ORACLE_SID/rman
         ;;
      *) 
         export WINDOW_DUMP=15
         export WINDOW_RMAN=15
         export BACKUP_SITR_RMAN=${BACKUP_SITR_LOCAL}/$ORACLE_SID/rman
         export BACKUP_SITR_DUMP=${BACKUP_SITR_LOCAL}/$ORACLE_SID/dump
         ;;
esac
fi
#
# echo WINDOW_RMAN WINDOW_DUMP 
# echo $WINDOW_RMAN $WINDOW_DUMP 
# echo BACKUP_SITR_RMAN  BACKUP_SITR_DUMP et BACKUP_SITR_TAR
# echo $BACKUP_SITR_RMAN  $BACKUP_SITR_DUMP et $BACKUP_SITR_TAR
#
#
