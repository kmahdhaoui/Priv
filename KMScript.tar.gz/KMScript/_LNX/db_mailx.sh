#!/bin/ksh
# Author : Kamel Mahdhaoui
#
# en plus du mail message dans 
# /sitr/exploit/sup dans le bon fichier sous une forme du style :
# 2015/08/10 15:00:27|SITR-DTB2-REC|RMDMEMET|CRITIQUE__|tablespace 100% depasse 95%|UNDOTBS1 
#
if [ "$1" == "" ] 
then
   echo "Usage : $0 <fichier> <sujet> <mail> ..."
   exit 101
fi
#
if [ ! -r $1 ]
then
   echo "Usage : $0 <fichier> <sujet> <mail> <BASE:optionnel> ..."
   echo "$1 : mauvais fichier !"
   exit 101
fi
#
if [ "$2" == "" ] 
then
   echo "Usage : $0 <fichier> <sujet> <mail> <BAS:optionnel> ..."
   echo "      : sujet absent !"
   exit 102
fi
#
if [ "$3" == "" ]
then
   echo "Usage : $0 <fichier> <sujet> <mail> <BAS:optionnel> ..."
   echo "      : mail absent !"
   exit 103
fi
#
if [ "$4" == "" ]
then
   echo "Base $ORACLE_SID ? !"
fi
#
# positionner des choses pour les scripts
export KMhost=`hostname`
export KMsid=$ORACLE_SID
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export KMymd=`date "+%Y%m%d"`
#
export FICHIER=$1
if [ "$4" == "" ]
then
   export SUJETMAIL="[$2]:$KMhost:$ORACLE_SID"
else
   export SUJETMAIL="[$2]:$KMhost:$4"
fi
export LEMAIL=$3
#
export KMficlck=/tmp/db_mailx_$KMymdhms.$$.lck
export KMfictmp=/tmp/db_mailx_$KMymdhms.$$.tmp
export SUJETMAIL_SS=`echo "$SUJETMAIL" | tr -d '&"()[]{}=@#,;/:!<> ' `
export KMficsvg=/tmp/db_mailx_$KMymd.$SUJETMAIL_SS.tmp
#
export from="${KMhost}.$ORACLE_SID@ondeosystems.com"
export smtp=10.34.34.67
#
date > $KMfictmp
cat $FICHIER >> $KMfictmp
#
echo "$SUJETMAIL" > $KMficsvg.1
#
if [ ! -f $KMficsvg.2 ]
then
   echo "New" > $KMficsvg.2
fi
#
export NBDIFF=`diff $KMficsvg.1 $KMficsvg.2|wc -l`
if [ "$NBDIFF" -eq 0 ]
then
   echo "Message deja envoyee !"
else
   cat $KMfictmp |mailx -s "$SUJETMAIL" "$LEMAIL"
fi
#
rm -f $KMfictmp 
mv -f $KMficsvg.1 $KMficsvg.2
#
