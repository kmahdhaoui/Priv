#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
#
#
if [ "$1" == "" ]
then
   echo "Usage is : $0 <fichier liste cde SQL a lancer ...>"
   exit 1
else
   export ListeCdeSql=$1
fi
#
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
cat $ListeCdeSql |while read CdeSql
do
#
###############################################
#
export LIMITE_NBPROC_SMALL=16
export LIMITE_NBPROC_BIG=16
export SQL_PARALLEL_SMALL=42
export SQL_PARALLEL_BIG=42
export SQL_SLEEP_SMALL=60
export SQL_SLEEP_BIG=60
. db_lance_SQL_parallel.cfg
#
bash sleep_PS.sh "oracle" "sqlplus" $LIMITE_NBPROC_SMALL $SQL_SLEEP_SMALL
#
sqlplus -s "$conn" <<EOT &
set time on timi on echo on
$CdeSql
host echo "<<<<<<<<<<<<<<<<<<<< `date` : $CdeSql "
exit
EOT
###############################################
#
done
#
. $KMscript/KMlogout.sh
#
