#!/bin/bash
# kma
#
# set before $ORACLE_HOME
#
#
. /usr/local/etc/oracle/kenv_batch.sh
#
cd $BINDIR
#
rm -f ${WORKDIR}/kresult_oraerrors_$$.tmp* 1>/dev/null 2>&1
#
#
export ORAERRORS="ORA-"
# un seul mail
echo "MAILFILE=$MAILORAERRORSFILE"
export MAILFILE=$MAILORAERRORSFILE
date > $MAILFILE
#
export SQLTMP=${WORKDIR}/kresult_oraerrors_$$.tmp
export FICTMP=${WORKDIR}/ktmp_oraerrors_$$.tmp
#
##########################
export ListeDesSID=""
# La liste c'est les bases qui tournent
cat <<EOF |sort -u | grep -v '^$'| while read leSID ; do
$(ps -ef |grep smon|grep -v grep|grep -v '+ASM'|awk -F_ '{print $3}'|sed 's/ //g')
EOF
#
if [ "$ListeDesSID" == "" ]
then
   export ListeDesSID="$leSID"
else
   export ListeDesSID="${ListeDesSID},$leSID"
fi
#
export ORACLE_SID=$leSID
. /usr/local/etc/oracle/kenv_batch.sh 
. $BINDIR/kenv_nls.sh
#
export SUPFILE_OLD=$SUPORAERRORSFILE_OLD.$ORACLE_SID
export SUPFILE_NEW=$SUPORAERRORSFILE_NEW.$ORACLE_SID
export SUPFILE=$SUPORAERRORSFILE.$ORACLE_SID
# 
export FICALERT=$SITR_TOP/diag/rdbms/*/$ORACLE_SID/trace/alert_$ORACLE_SID.log
#
##############
#
grep -n "$ORAERRORS" $FICALERT |tail -1|cut -f1 -d: > $SUPFILE_NEW
if [ ! -r "$SUPFILE_OLD" ]
then 
   echo 1 > $SUPFILE_OLD
fi
#
rm -f $SUPFILE
export NBR=`diff $SUPFILE_NEW $SUPFILE_OLD |wc -l `
export NUMLIG=`cat $SUPFILE_OLD`
if [ "$NUMLIG" == "" ]
then
   export NUMLIG=1
fi
#
if [ "$NBR" -ne 0 ]
then 
   sed -n "$NUMLIG",'$p' $FICALERT |grep "$ORAERRORS"  > $SUPFILE
   echo ">>>>>>>>>>>>>>>>>>>> BASE : $ORACLE_SID <<<<<<<<<<<<<<<<<<<<<" >> $MAILFILE
   cat $SUPFILE >> $MAILFILE
fi
#
cp -f $SUPFILE_NEW $SUPFILE_OLD
#
##############
echo "export ListeDesSID=$ListeDesSID" > $FICTMP
done
. $FICTMP
echo $ListeDesSID
##########################
#
export LISTEMAIL="kamel.mahdhaoui@suez-env.com"
#
export NBR=`cat $MAILFILE |wc -l `
if [ "$NBR" -ne 1 ]
then
   #
   if [ -r $MAILFILE ]
   then
   echo bash $BINDIR/db_mailx.sh $MAILFILE AlerteORAERRORS "$LISTEMAIL" "$ListeDesSID"
   bash $BINDIR/db_mailx.sh $MAILFILE AlerteORAERRORS "$LISTEMAIL" "$ListeDesSID,pid=$$"
   echo " "
   fi
#
fi
#
rm -f ${WORKDIR}/kresult_oraerrors_$$.tmp* 1>/dev/null 2>&1
rm -f ${WORKDIR}/ktmp_oraerrors_$$.tmp* 1>/dev/null 2>&1
#
