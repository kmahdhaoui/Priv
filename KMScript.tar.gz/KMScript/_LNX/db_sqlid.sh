#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
if [ "$1" == "" ]
then
   echo "Texte Recherche ... ?"
   read TexteRecherche
else
   export TexteRecherche=$1
fi
#
export TexteRecherche
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
set pages 132
set lines 132
col TEXT format a88
col SQL_ID format a22
--
SELECT sql_id, hash_value, SUBSTR(sql_text,1,40) Text
FROM v\$sql
WHERE sql_text LIKE '%$TexteRecherche%';
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
