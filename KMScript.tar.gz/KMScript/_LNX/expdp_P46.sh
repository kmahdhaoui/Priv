#
export PRT=P46
#
export OWN=CISADM
export KMymdhms=`date "+%Y%m%d%H%M%S"`
#
export myrep=/sitr/backup/$ORACLE_SID/dump
#
sqlplus '/ as sysdba' <<EOT
create or replace DIRECTORY kamel as '$myrep/';
exit
EOT
#
#
export TBL=D1_MSRMT
expdp "'/ as sysdba'" FLASHBACK_TIME=systimestamp TABLES=$OWN.$TBL:$PRT directory=kamel parallel=16 COMPRESSION=all dumpfile=$ORACLE_SID.$OWN.$TBL.$PRT.$KMymdhms.%u.dmp logfile=$ORACLE_SID.$OWN.$TBL.$PRT.$KMymdhms.log content=DATA_ONLY exclude=statistics
#
export TBL=D1_INIT_MSRMT_DATA
expdp "'/ as sysdba'" FLASHBACK_TIME=systimestamp TABLES=$OWN.$TBL:$PRT directory=kamel parallel=16 COMPRESSION=all dumpfile=$ORACLE_SID.$OWN.$TBL.$PRT.$KMymdhms.%u.dmp logfile=$ORACLE_SID.$OWN.$TBL.$PRT.$KMymdhms.log content=DATA_ONLY exclude=statistics
#
export TBL=D1_INIT_MSRMT_DATA_K
expdp "'/ as sysdba'" FLASHBACK_TIME=systimestamp TABLES=$OWN.$TBL:$PRT directory=kamel parallel=16 COMPRESSION=all dumpfile=$ORACLE_SID.$OWN.$TBL.$PRT.$KMymdhms.%u.dmp logfile=$ORACLE_SID.$OWN.$TBL.$PRT.$KMymdhms.log content=DATA_ONLY exclude=statistics
#
