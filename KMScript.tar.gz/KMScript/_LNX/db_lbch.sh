#
# Author : Kamel Mahdhaoui
# Unautorized use is forbidden 
sqlplus -s "$conn" <<EOT
col LBCH format "9999999"
set pages 0
set feedb off
set verify off
set echo off
--
select 100-(round((((sum(reloads)/sum(pins)))),4)) LBCH 
from v\$librarycache
;
exit
EOT
#
