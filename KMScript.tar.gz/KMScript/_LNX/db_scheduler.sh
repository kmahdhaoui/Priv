#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col sid format 999999
col USERNAME format a20
col MACHINE format a15
col program format a44

col OPERATION format a12
col OWNER_NAME format a12
col JOB_MODE format a12
col nb_sess format 9999
col dp_sess format 9999
col state format a12
--
set lines 132
col JOB_NAME format a30
col program_name format a30
col ENABLED format a5 
col WINDOW_NAME format a18
col SCHEDULE_NAME format a20
col start_date format a20
--
SELECT
   a.job_name,
--   a.program_name,
   a.enabled,
   c.window_name,
   c.schedule_name,
   c.start_date
-- ,c.repeat_interval
FROM
   dba_scheduler_jobs             a,
   dba_scheduler_wingroup_members b,
   dba_scheduler_windows          c
WHERE
   job_name like '%'
And
   a.schedule_name=b.window_group_name
And
   b.window_name=c.window_name
/
--
SELECT owner, program_name, enabled FROM dba_scheduler_programs;
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
