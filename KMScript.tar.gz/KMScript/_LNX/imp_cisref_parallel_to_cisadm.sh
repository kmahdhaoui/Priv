#
#
#
export myrep=/sitr/backup/$ORACLE_SID/dump
#
sqlplus / as sysdba <<EOT
--
create or replace DIRECTORY kamel as '$myrep/';
--
exit
EOT
#
impdp "'/ as sysdba'" schemas=CISREF REMAP_SCHEMA=CISREF:CISADM REMAP_tablespace=TEMP2:TEMP PARALLEL=4 EXCLUDE=INDEX,constraint directory=kamel dumpfile=LL-02102015-CISREF.DMP logfile=imp_LL-02102015-CISREF_kamel_$$.log table_exists_action=truncate
#
echo tail -f imp_LL-02102015-CISREF_kamel_$$.log
#
impdp "'/ as sysdba'" schemas=CISREF REMAP_SCHEMA=CISREF:CISADM REMAP_tablespace=TEMP2:TEMP PARALLEL=4 CONTENT=METADATA_ONLY INCLUDE=INDEX,constraint directory=kamel dumpfile=LL-02102015-CISREF.DMP logfile=imp_indx_LL-02102015-CISREF_kamel_$$.log
#
echo tail -f imp_indx_LL-02102015-CISREF_kamel_$$.log
#
