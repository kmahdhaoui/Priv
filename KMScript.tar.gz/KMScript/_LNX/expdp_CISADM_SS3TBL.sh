#
# export ORACLE_SID=XSITRMDO
export SITR_APP=CISADM
export SITR_PAR=expdp_CISADM_SS3TBL.par
export KMymdhms=`date "+%Y%m%d%H%M%S"`
#
export SITR_DMP=${SITR_APP}_${KMymdhms}_%U.dmp
export SITR_LOG=${SITR_APP}_${KMymdhms}.log
#
sqlplus "/ as sysdba" <<EOT
create or replace directory kamel as '/sitr/backup/$ORACLE_SID/dump/' ;
exit
EOT
#
     > $SITR_PAR
echo QUERY="\"${SITR_APP}.D1_MSRMT:WHERE rownum<1\"" >> $SITR_PAR
echo QUERY="\"${SITR_APP}.D1_INIT_MSRMT_DATA:WHERE rownum<1\"" >> $SITR_PAR
echo QUERY="\"${SITR_APP}.D1_INIT_MSRMT_DATA_K:WHERE rownum<1\"" >> $SITR_PAR
#
cp -f $SITR_PAR /sitr/backup/$ORACLE_SID/dump/$SITR_PAR
#
expdp "'/ as sysdba'" DIRECTORY=kamel FLASHBACK_TIME=systimestamp PARALLEL=16 SCHEMAS=${SITR_APP} DUMPFILE=${SITR_DMP} LOGFILE=${SITR_LOG} PARFILE=$SITR_PAR compression=ALL content=DATA_ONLY exclude=statistics
#
#
#
