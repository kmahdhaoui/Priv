#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
set pages 555
set lines 133
col COMPONENT format a33
col OPER_TYPE format a15
alter session set nls_date_format='yyyy-mon-dd hh24:mi:ss' ;
--
select COMPONENT,OPER_TYPE,INITIAL_SIZE,FINAL_SIZE,START_TIME,
(END_TIME-START_TIME)*24*60*60 secondes
from V\$MEMORY_RESIZE_OPS where INITIAL_SIZE != 0
order by COMPONENT,START_TIME
;
--
select COMPONENT,USER_SPECIFIED_SIZE,CURRENT_SIZE,MIN_SIZE,MAX_SIZE from V\$MEMORY_DYNAMIC_COMPONENTS 
;
exit
EOT
#
. $KMscript/KMlogout.sh
#
