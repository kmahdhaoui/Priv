#!/bin/bash
# Author : Kamel Mahdhaoui
# 
. ~oracle/.profile 1>/dev/null 2>&1
export ORACLE_SID=+ASM
. ~oracle/kamel/KMscript/kamel.profile silent 1>/dev/null 2>&1
#
# set -x
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   return 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh 1>/dev/null 1>/dev/null 2>&1
#
export host=$(uname -n)
export DBliste=/tmp/kamel_DBliste_$$
export OK=`echo "OK"`
export KO=`echo "KO"`
#
> $DBliste
#
ls -1 $KMscript/conn/ | sed '/^$/d' | grep -v "*" > $DBliste
cat $DBliste
#
#
rm $DBliste 1>/dev/null 2>&1
#
. $KMscript/KMlogout.sh 1>/dev/null 2>&1
#
