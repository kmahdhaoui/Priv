#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col "Decimal" format 999999.999
col "Jours" format 999999
col "Heures" format 99999
col "Minutes" format 9999
set tab off
select 
SYSDATE-STARTUP_TIME "Decimal"
from   v\$instance
/
exit
EOT
#
. $KMscript/KMlogout.sh
#
