#!/bin/bash
# 
# Author : Kamel Mahdhaoui
# Unautorized use is forbidden 
#
#
cd $KMscript
#
export c_e_p1=101
export l_e_p1="Usage is $0 <Sid>"
#
if  [ "$1" = "" ]
then
    echo $l_e_p1
    exit $c_e_p1
fi
#
export RETOUR="0"
export RETOUR=`ps -ef |grep  $1|grep pmon|grep -v grep |wc -l`
if [ $RETOUR = 0 ]
then
   echo "$1 is not running. Exiting ..."
   exit 101
fi
#
sh dbup.sh $1
#
############################################### Customize here
export ORACLE_SID=$1
export ORAENV_ASK="NO"
. oraenv
export ORAENV_ASK=""
export SendMailCde="/usr/lib/sendmail -t "
export MyFileId1=`date "+%Y%m%d%H%M%S"`H1
export MyFileId2=`date "+%Y%m%d%H%M%S"`H2
export MyBinDir="."
export MyLogDir="."
export MyOutDir="."
export MyErrDir="."
export MyHost=`hostname` 
export petithost=`hostname | awk -F. '{print $1}' -`
export InterDbaMail1="kamel.mahdhaoui@suez-env.com"
export InterDbaMail2="kamel.mahdhaoui@suez-env.com"
############################################### End customize 
#
for i in 1 
do
#
case  $i in
      1) export MyFileId=$MyFileId1; export InterDbaMail=$InterDbaMail1 ;;
      2) export MyFileId=$MyFileId2; export InterDbaMail=$InterDbaMail2 ;;
esac
#
rm -f $MyOutDir/$MyFileId$$ 1>/dev/null 2>/dev/null
rm -f $MyOutDir/${MyFileId}* 1>/dev/null 2>/dev/null
#
date
#
$MyBinDir/DbaHebd.sh $i 1>$MyOutDir/$MyFileId.out 2>$MyErrDir/$MyFileId.err
#
date
#
# compress $MyOutDir/$MyFileId.out
# compress $MyErrDir/$MyFileId.err
#
#echo "To:$InterDbaMail" >$MyOutDir/$MyFileId$$
#echo "From:$InterDbaMail1" >>$MyOutDir/$MyFileId$$
#echo "Subject:TraiteHebdo.Dba sur $petithost:$1" >>$MyOutDir/$MyFileId$$
#echo "" >>$MyOutDir/$MyFileId$$
#
#
#cat $MyOutDir/$MyFileId.out >>$MyOutDir/$MyFileId$$
#echo "==========================================================" >>$MyOutDir/$MyFileId$$
#cat $MyOutDir/$MyFileId.err >>$MyOutDir/$MyFileId$$
#
#cat $MyOutDir/$MyFileId$$ | $SendMailCde $InterDbaMail
#sleep 5
#rm -f $MyOutDir/$MyFileId$$ 1>/dev/null 2>/dev/null
#rm -f $MyOutDir/${MyFileId}* 1>/dev/null 2>/dev/null
#
done
#
