#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export LISTE_ROLES=/tmp/tmp_role_grants_$KMymdhms.$$.tmp
#
export CLAUSENOTIN="('CONNECT', 'RESOURCE', 'DBA', 'SELECT_CATALOG_ROLE',"
export CLAUSENOTIN="$CLAUSENOTIN 'EXECUTE_CATALOG_ROLE', 'DELETE_CATALOG_ROLE', 'EXP_FULL_DATABASE',"
export CLAUSENOTIN="$CLAUSENOTIN 'IMP_FULL_DATABASE', 'LOGSTDBY_ADMINISTRATOR', 'DBFS_ROLE',"
export CLAUSENOTIN="$CLAUSENOTIN 'AQ_ADMINISTRATOR_ROLE', 'AQ_USER_ROLE', 'DATAPUMP_EXP_FULL_DATABASE',"
export CLAUSENOTIN="$CLAUSENOTIN 'DATAPUMP_IMP_FULL_DATABASE', 'ADM_PARALLEL_EXECUTE_TASK',"
export CLAUSENOTIN="$CLAUSENOTIN 'GATHER_SYSTEM_STATISTICS', 'JAVA_DEPLOY', 'RECOVERY_CATALOG_OWNER',"
export CLAUSENOTIN="$CLAUSENOTIN 'SCHEDULER_ADMIN', 'HS_ADMIN_SELECT_ROLE', 'HS_ADMIN_EXECUTE_ROLE',"
export CLAUSENOTIN="$CLAUSENOTIN 'HS_ADMIN_ROLE', 'GLOBAL_AQ_USER_ROLE', 'OEM_ADVISOR', 'OEM_MONITOR',"
export CLAUSENOTIN="$CLAUSENOTIN 'WM_ADMIN_ROLE', 'JAVAUSERPRIV', 'JAVAIDPRIV', 'JAVASYSPRIV',"
export CLAUSENOTIN="$CLAUSENOTIN 'JAVADEBUGPRIV', 'EJBCLIENT', 'JMXSERVER', 'JAVA_ADMIN', 'CTXAPP',"
export CLAUSENOTIN="$CLAUSENOTIN 'XDBADMIN', 'XDB_SET_INVOKER', 'AUTHENTICATEDUSER', 'XDB_WEBSERVICES',"
export CLAUSENOTIN="$CLAUSENOTIN 'XDB_WEBSERVICES_WITH_PUBLIC', 'XDB_WEBSERVICES_OVER_HTTP', 'OLAP_DBA',"
export CLAUSENOTIN="$CLAUSENOTIN 'ORDADMIN', 'OLAP_XS_ADMIN', 'CWM_USER','OLAP_USER','SPATIAL_WFS_ADMIN',"
export CLAUSENOTIN="$CLAUSENOTIN 'WFS_USR_ROLE', 'SPATIAL_CSW_ADMIN', 'CSW_USR_ROLE', 'MGMT_USER',"
export CLAUSENOTIN="$CLAUSENOTIN 'APEX_ADMINISTRATOR_ROLE','OWB\$CLIENT','OWB_DESIGNCENTER_VIEW','OWB_USER')"
#
sqlplus -s "$conn" <<EOT
col ROLE format a32
set heading off
set feedback off
set verify off
set pages 0 
spool $LISTE_ROLES
select role from dba_roles  where role not in 
$CLAUSENOTIN
;
spool off
--
exit
EOT
#
for lerole in `cat $LISTE_ROLES`
do
sqlplus -s "$conn" <<EOT
--
@$KMscript/$SQLLOGIN
--
set long 20000 longchunksize 20000 pagesize 0 linesize 300 feedback off verify off trimspool on
column ddl format a300

begin
   dbms_metadata.set_transform_param (dbms_metadata.session_transform, 'SQLTERMINATOR', true);
   dbms_metadata.set_transform_param (dbms_metadata.session_transform, 'PRETTY', true);
end;
/
 
variable v_role VARCHAR2(30);

exec :v_role := upper('$lerole');
--
prompt
prompt ===================== DB ROLE GRANTS : $lerole =================
--
select dbms_metadata.get_ddl('ROLE', r.role) AS ddl
from   dba_roles r
where  r.role = :v_role
union all
select dbms_metadata.get_granted_ddl('ROLE_GRANT', rp.grantee) AS ddl
from   dba_role_privs rp
where  rp.grantee = :v_role
and    rownum = 1
union all
select dbms_metadata.get_granted_ddl('SYSTEM_GRANT', sp.grantee) AS ddl
from   dba_sys_privs sp
where  sp.grantee = :v_role
and    rownum = 1
union all
select dbms_metadata.get_granted_ddl('OBJECT_GRANT', tp.grantee) AS ddl
from   dba_tab_privs tp
where  tp.grantee = :v_role
and    rownum = 1
/
--
--
exit
EOT
#
done
#
. $KMscript/KMlogout.sh
#

