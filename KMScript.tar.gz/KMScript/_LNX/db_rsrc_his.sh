#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col TYPE format a15
col name form a32 heading "Name"
col plan form a27 heading "Plan Name"
col Sub-Plan format a27
--
SELECT sequence# seq, name plan_name,
to_char(start_time, 'DD-MON-YY HH24:MM') start_time,
to_char(end_time, 'DD-MON-YY HH24:MM') end_time, window_name
FROM v\$rsrc_plan_history
;
select sequence# seq, name, cpu_wait_time, cpu_waits,
consumed_cpu_time from V\$RSRC_CONS_GROUP_HISTORY
;
--
exit
EOT
#
. $KMscript/KMlogout.sh
#
