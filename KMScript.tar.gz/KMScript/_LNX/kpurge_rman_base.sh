#!/bin/bash
# kma
#
# set before $ORACLE_HOME
#
#
# la base
if [ "$1" == "" ]
then
   echo "Usage is : $0 <Base>"
  exit 101
else
   export leSID=$1
fi
#
# les variables pour le batch dont WINDOW_DUMP et WINDOW_RMAN
export ORACLE_SID=$leSID
. /usr/local/etc/oracle/kenv_batch.sh $leSID
. $BINDIR/kenv_nls.sh
#
cd $BINDIR
#
rm -f ${WORKDIR}/kpurge_rman_base_$$.tmp* 1>/dev/null 2>&1
#
export SQLTMP=${WORKDIR}/kpurge_rman_base_$$.tmp
#
export MAJoracle_sid=`echo $ORACLE_SID|tr '[:lower:]' '[:upper:]'`
export MINoracle_sid=`echo $ORACLE_SID|tr '[:upper:]' '[:lower:]'`
#
export a_error_svg=0
#
export myrep=$BACKUP_SITR_RMAN
mkdir -p $myrep
#
#
##################################################################
#
# rman filesets
set -x
find $BACKUP_SITR_RMAN -name "*${ORACLE_SID}*SPF*" -mtime +${WINDOW_RMAN} -exec rm -f {} \; 
find $BACKUP_SITR_RMAN -name "*${ORACLE_SID}*CTL*" -mtime +${WINDOW_RMAN} -exec rm -f {} \; 
find $BACKUP_SITR_RMAN -name "*${ORACLE_SID}*ARC*" -mtime +${WINDOW_RMAN} -exec rm -f {} \; 
find $BACKUP_SITR_RMAN -name "*${ORACLE_SID}*DTB*" -mtime +${WINDOW_RMAN} -exec rm -f {} \; 
set -x
#
##################################################################
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
# %d : db name, %s : set num, %p : piece in set
export BACKUP_LEVEL=0
export BACKUP_TYPE=FULL # full ou incr
ARCTAG=${ORACLE_SID}_ARC_1_${KMymdhms}
DTBTAG=${ORACLE_SID}_DTB_${BACKUP_LEVEL}_${KMymdhms}
CTLTAG=${ORACLE_SID}_CTL_${BACKUP_LEVEL}_${KMymdhms}
SPFTAG=${ORACLE_SID}_SPF_${BACKUP_LEVEL}_${KMymdhms}
ARCSET=${ARCTAG}_s%s_p%p
DTBSET=${DTBTAG}_s%s_p%p
CTLSET=${CTLTAG}_s%s_p%p
SPFSET=${SPFTAG}_s%s_p%p
export LOGFILE=kpurge_rman_base_${ORACLE_SID}_FULL_$KMymdhms.log
export CONFILE=kpurge_rman_base_${ORACLE_SID}_FULL_$KMymdhms.cfg
echo $LOGDIR/$LOGFILE
#
##################################################################
#
rm -f $WORKDIR/$CONFILE
echo "CONFIGURE RETENTION POLICY TO RECOVERY WINDOW OF ${WINDOW_RMAN} DAYS; " >> $WORKDIR/$CONFILE
echo "CONFIGURE BACKUP OPTIMIZATION ON; " >> $WORKDIR/$CONFILE
echo "CONFIGURE DEFAULT DEVICE TYPE TO DISK; " >> $WORKDIR/$CONFILE
echo "CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE DISK TO '$myrep/ctl_auto_${ORACLE_SID}_%F'; " >> $WORKDIR/$CONFILE
echo "CONFIGURE DEVICE TYPE DISK PARALLELISM 8 BACKUP TYPE TO compressed BACKUPSET; " >> $WORKDIR/$CONFILE
echo "CONFIGURE DATAFILE BACKUP COPIES FOR DEVICE TYPE DISK TO 1; " >> $WORKDIR/$CONFILE
echo "CONFIGURE ARCHIVELOG BACKUP COPIES FOR DEVICE TYPE DISK TO 1; " >> $WORKDIR/$CONFILE
echo "CONFIGURE CHANNEL DEVICE TYPE DISK FORMAT '$myrep/${ORACLE_SID}_%t_s%s_p%p' MAXOPENFILES 10; " >> $WORKDIR/$CONFILE
echo "CONFIGURE AUXILIARY CHANNEL DEVICE TYPE DISK FORMAT '$myrep/${ORACLE_SID}_%t_s%s_p%p'; " >> $WORKDIR/$CONFILE
echo "CONFIGURE MAXSETSIZE TO UNLIMITED; " >> $WORKDIR/$CONFILE
echo "CONFIGURE ENCRYPTION FOR DATABASE OFF; " >> $WORKDIR/$CONFILE
echo "CONFIGURE ENCRYPTION ALGORITHM 'AES128'; " >> $WORKDIR/$CONFILE
echo "CONFIGURE COMPRESSION ALGORITHM 'BASIC' AS OF RELEASE 'DEFAULT' OPTIMIZE FOR LOAD TRUE; " >> $WORKDIR/$CONFILE
echo "CONFIGURE ARCHIVELOG DELETION POLICY TO NONE; " >> $WORKDIR/$CONFILE
echo "CONFIGURE SNAPSHOT CONTROLFILE NAME TO '$myrep/snapcf_${ORACLE_SID}.f'; " >> $WORKDIR/$CONFILE
echo "CONFIGURE CONTROLFILE AUTOBACKUP ON; " >> $WORKDIR/$CONFILE
#
rman target=/ nocatalog log="$LOGDIR/$LOGFILE" <<EOT
#
@$WORKDIR/$CONFILE
#
show all ;
#
report need backup;
report obsolete;
crosscheck backup;
crosscheck copy;
crosscheck archivelog all;
ALLOCATE CHANNEL FOR MAINTENANCE DEVICE TYPE DISK ;
DELETE NOPROMPT OBSOLETE DEVICE TYPE DISK ;

crosscheck backup;
crosscheck copy;
crosscheck archivelog all;

ALLOCATE CHANNEL FOR MAINTENANCE DEVICE TYPE DISK ;
delete noprompt obsolete DEVICE TYPE DISK ;
delete noprompt expired backup;
delete noprompt expired copy;
delete noprompt expired archivelog all;
exit
EOT
#
###################################################################
#
cp -f $LOGDIR/$LOGFILE $myrep 1>/dev/null 2>&1
cp -f $WORKDIR/$CONFILE $myrep 1>/dev/null 2>&1
#
rm -f ${WORKDIR}/kpurge_rman_base_$$.tmp* 1>/dev/null 2>&1
rm -f $WORKDIR/$CONFILE 1>/dev/null 2>&1
#
