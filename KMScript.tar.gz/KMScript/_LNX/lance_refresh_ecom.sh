date
sqlplus '/ as sysdba' <<EOT
connect ecomreportoa/ecomreportoa
exec dbms_refresh.refresh('"ECOMREPORTOA"."REF_ECOM_TABLES"');
exit
EOT
date
