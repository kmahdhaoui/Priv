#!/bin/bash
#
cd ~oracle/kamel/KMscript
mkdir -p svg
mv -f *.out svg
mv -f *.lst svg
mv -f *.log svg
mv -f *.gz svg
mv -f *.201????? svg
echo sitr2014
#
#
if [ "$1" == "" ] 
then
# export liste_leuserhost="oracle@sefrapp00154 oracle@sefrapp00153 oracle@sefrapp00148 oracle@sefrapp00155"
export liste_leuserhost="oracle@sefrapp00154 oracle@sefrapp00153"
else
export liste_leuserhost="oracle@$1"
fi
#
for leuserhost in $liste_leuserhost
do
#ssh $leuserhost "mkdir -p kamel/KMscript/"
scp ~oracle/kamel/KMscript/* $leuserhost:kamel/KMscript 1>/dev/null 
#
done
#
