#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
-- DEBUT SQL
--
set verify off
set feedback off
set echo off
--
ttitle skip center "*** Oracle Files ***"
set pages 1000
--
--
SET LINES 130
SET TRIMS ON
COL name FOR A80
SELECT 'DATA' type, name FROM V\$DATAFILE
UNION
SELECT 'TEMP' type, name FROM V\$TEMPFILE
UNION
SELECT 'REDO' type, member name FROM V\$LOGFILE
UNION
SELECT 'CTRL' type, name FROM V\$CONTROLFILE
UNION
SELECT 'BCT' type, filename name FROM V\$BLOCK_CHANGE_TRACKING
UNION
SELECT 'FDBLOG' type, name FROM V\$FLASHBACK_DATABASE_LOGFILE
ORDER BY
type
/
select group#,archived,thread#,bytes,status from v\$log;
select group#,archived,thread#,bytes,status from v\$standby_log;
-- FIN SQL
--
exit
EOT
#
echo " "
echo "############################################################# "
#echo "*** RMAN Files ***"
#rman target=/ <<EOT
#report schema;
#exit
#EOT
#
. $KMscript/KMlogout.sh
#
