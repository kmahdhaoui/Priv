#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
prompt ========================== shared pool SGASTAT  ======================
select * 
from ( select name, bytes/(1024*1024) MB from v\$sgastat where pool in ('shared pool')
       order by bytes desc) 
where rownum < 20
;
prompt ========================== large pool SGASTAT   ======================
select *
from ( select name, bytes/(1024*1024) MB from v\$sgastat where pool in ('large pool')
       order by bytes desc)
where rownum < 20
;
-- 
prompt ========================== cursor_sharing=force ======================
select 
   count(1) num_sql, sum(decode(executions, 1, 1, 0)) one_use_sql, sum(sharable_mem)/1024/1024      meg_used, sum(decode(
      executions,   1, sharable_mem, 0))/1024/1024                      mb_per
from v\$sqlarea where sharable_mem > 0
;
-- 
-- 
-- 
-- 
exit
EOT
#
. $KMscript/KMlogout.sh
#
