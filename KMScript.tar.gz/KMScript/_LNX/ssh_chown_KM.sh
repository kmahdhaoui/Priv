#!/bin/bash
#
echo sitr2014
read
#
#
ssh cinstall@sefrapp00153 'sudo chown -R oracle:oinstall kamel kamel/*'
ssh cinstall@sefrapp00154 'sudo chown -R oracle:oinstall kamel kamel/*'
ssh cinstall@sefrapp00148 'sudo chown -R oracle:oinstall kamel kamel/*'
ssh cinstall@sefrapp00155 'sudo chown -R oracle:oinstall kamel kamel/*'
#
