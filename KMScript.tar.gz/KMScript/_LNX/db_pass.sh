#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
export FGENSQL=db_pass.gen.$K_ORASID.$KMymdhms.txt
export FGENLST=db_pass.gen.$K_ORASID.$KMymdhms.lst
#
sqlplus -s "$conn" 1>/dev/null 2>&1 <<EOT
@$KMscript/$SQLLOGIN
--
col DB_LINK format a22 HOST  format a22 OWNER format a22 USERNAME format a22 heading off lines 152
set long 20000 longchunksize 20000 pagesize 0 linesize 1000 feedback off verify off trimspool on
col ddl format a1000
set ECHO OFF VER OFF SHOW OFF serverout off
--
set termout off
spool $FGENSQL
select 'select ''---------------------------------------------------------------------------------''||
chr(10)|| trim(DBMS_METADATA.get_ddl (''USER'', '''||username||''')) ddl from dual;' from dba_users ;
spoo off
set termout on
--
exit
EOT
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col DB_LINK format a22
col HOST  format a22
col OWNER format a22
col USERNAME format a22
set heading off
set lines 152
prompt 
prompt =========================== USERS/PASSWORD ===========================
--
set long 20000 longchunksize 20000 pagesize 0 linesize 1000 feedback off verify off trimspool on
col ddl format a1000
set ECHO OFF VER OFF SHOW OFF serverout off
--
begin
   DBMS_METADATA.SET_TRANSFORM_PARAM(DBMS_METADATA.SESSION_TRANSFORM,'STORAGE',false);
   dbms_metadata.set_transform_param (dbms_metadata.session_transform, 'SQLTERMINATOR', true);
   dbms_metadata.set_transform_param (dbms_metadata.session_transform, 'PRETTY', true);
end;
/
--
spool $FGENLST
@@$FGENSQL
--
EXECUTE DBMS_METADATA.SET_TRANSFORM_PARAM(DBMS_METADATA.SESSION_TRANSFORM,'DEFAULT');
--
!rm $FGENSQL
--
exit
EOT
#
. $KMscript/KMlogout.sh
#

