#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col MB format 9999999990
SELECT owner,sum(bytes)/1024/1024 MB 
FROM dba_segments
group by owner
order by 2 desc
;
exit
EOT
#
. $KMscript/KMlogout.sh
#
