#!/bin/bash
# kma
#
# set before $ORACLE_HOME
#
#
# la base
if [ "$1" == "" ]
then
   echo "Usage is : $0 <Base>"
  exit 101
else
   export leSID=$1
fi
# 
# s_startoption: -o startoption
if [ "$2" == "" ]
then
   export s_startoption="" 
else
   export s_startoption=" -o $2"
fi
#
# les variables pour le batch
export ORACLE_SID=$leSID
. /usr/local/etc/oracle/kenv_batch.sh $leSID
. $BINDIR/kenv_nls.sh
#
cd $BINDIR
#
export DATE=$(date "+%d/%m/%Y %H:%M:%S")
rm -f ${WORKDIR}/kstart_une_$$.tmp* 1>/dev/null 2>&1
#
export SQLTMP=${WORKDIR}/kstart_une_$$.tmp
#
##########################
export a_error_svg=0
#
export FLASHBACK_TIME=systimestamp
#
cd $BINDIR
#
export KMymdhms=`date "+%Y%m%d%H%M%S"`
#
echo "=========== AVANT : ora_pmon_$ORACLE_SID : "
ps -ef |grep $ORACLE_SID|grep pmon
echo "======================================================="
srvctl start database -d $ORACLE_SID $s_startoption 1>$SQLTMP 2>&1
echo "=========== APRES : ora_pmon_$ORACLE_SID : "
ps -ef |grep $ORACLE_SID|grep pmon
echo "======================================================="
#
if [ $? -ne 0 ]
then
   export a_error_svg=1
fi
#
#########
#
export STATUS=$a_error_svg
if [ $STATUS != 0 ]
then
   echo bash $BINDIR/db_mailx.sh $SQLTMP ProblemeStartup "$LISTEMAIL"
   bash $BINDIR/db_mailx.sh $$SQLTMP ProblemeStartup "$LISTEMAIL"
   # Mail et continuer
fi
#
# sed '/^$/d' ${SQLTMP}.$leSID.2 >${SQLTMP}.$leSID.1
# export nb=`cat ${SQLTMP}.$leSID.1|wc -l`
#
##############
#
rm -f ${WORKDIR}/kstart_une_$$.tmp* 1>/dev/null 2>&1
#
