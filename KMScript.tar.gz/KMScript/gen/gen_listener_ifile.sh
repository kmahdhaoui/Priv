#!/bin/ksh
#
echo "-------------------------------------------------------------"
#
export LISTE=`ls -1 /*/oradata/*/network/listener.ora|sort -u`
export TISTE=`ls -1 /*/oradata/*/network/tnsnames.ora|sort -u`
export FICL=/tmp/listener.ora
export FICT=/tmp/tnsnames.ora
echo "# `date`" > $FICL
echo "# /*/oradata/*/network/listener.ora" >> $FICL
echo "#" >> $FICL
echo "# `date`" > $FICT
echo "# /*/oradata/*/network/tnsnames.ora" >> $FICT
echo "#" >> $FICT
#
for ii in $LISTE
do
  echo "ifile=\"$ii\"" >> $FICL 
done
#
for ii in $TISTE
do
  echo "ifile=\"$ii\"" >> $FICT
done
#
echo "Generation de $FICL $FICT ..."
echo "a copier vers /usr/local/etc/oracle "
echo "-------------------------------------------------------------"
#
# mkdir -p /usr/local/etc/oracle
# chmod 775 /usr/local/etc/oracle
# chown oracle:dba /usr/local/etc/oracle
# cp /tmp/listener.ora /usr/local/etc/oracle 
# cp /tmp/tnsnames.ora /usr/local/etc/oracle 
# chown oracle:dba  /usr/local/etc/oracle/*.ora 
# chmod 664  /usr/local/etc/oracle/*.ora 
# ADR_BASE_LISTENER=/sitr
# 
# srvctl config listener -l listener
# srvctl stop listener -l listener
# srvctl remove listener
# srvctl add listener -l listener -p "TCP:41521" -o /sitr/app/oracle/product/11.2.0/asm
# srvctl modify listener -l listener -p TCP:41521
# srvctl setenv listener -l listener -T TNS_ADMIN=/usr/local/etc/oracle
# srvctl getenv listener -l listener
# srvctl start listener -l listener
# srvctl config listener -l listener
#
#
