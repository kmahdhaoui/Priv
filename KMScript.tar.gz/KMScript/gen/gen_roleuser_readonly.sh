export User=$1
export Role=$2
export Owner=$3
export Table=$4
export Tbs=$5
export Tmp=$6
#
if [ "$User" == "" ] || [ "$Role" == "" ] || [ "$Owner" == "" ] || [ "$Table" == "" ] || [ "$Tbs" == "" ] || [ "$Tmp" == "" ]
then 
   export User=DTB_${ORACLE_SID}_READ
   export Role=DTB_${ORACLE_SID}_ROLE
   export Owner=DWADM
   export Table=%
   export Tbs=USERS
   export Tmp=TEMP
   #
   echo "Usage is : $0 <User> <Role> <Owner> <Table> <Tbs> <Tmp>"
   echo "Exemple  : $0 $User $Role $Owner $Table $Tbs $Tmp"
   exit 1
fi
#
echo "create user $User identified by ${User}00 default tablespace $Tbs temporary tablespace $Tmp ; "
echo "create role $Role ;"
echo "grant connect to $User ; "
echo "grant $Role to $User ; "
#
sqlplus -s "$conn" <<EOT
set feedback off heading off verify off 
--
select 'grant select on '||owner||'.'||table_name||' to $Role ;' from dba_tables 
where owner like '$Owner' and table_name like '$Table' ;
--
exit
EOT
#
sqlplus -s "$conn" <<EOT
set feedback off heading off verify off
--
select 'create synonym $User.'||table_name||' for '||owner||'.'||table_name||' ;' from dba_tables
where owner like '$Owner' and table_name like '$Table' ;
--
exit
EOT
#


