#!/bin/ksh
#
echo "-------------------------------------------------------------"
#
export LISTE=`ls -1 /*/oradata/*/network/listener.cfg|sort -u`
export TISTE=`ls -1 /*/oradata/*/network/tnsnames.cfg|sort -u`
export FICL=/tmp/listener.ora
export FICT=/tmp/tnsnames.ora
echo "# `date`" > $FICL
echo "# /*/oradata/*/network/listener.cfg" >> $FICL
echo "#" >> $FICL
echo "# `date`" > $FICT
echo "# /*/oradata/*/network/tnsnames.cfg" >> $FICT
echo "#" >> $FICT
#
for ii in $LISTE
do
  cat $ii >> $FICL 
done
#
for ii in $TISTE
do
  cat $ii >> $FICT
done
#
echo "Generation de $FICL $FICT ..."
echo "a copier : "
echo "cp $FICL /usr/local/etc/oracle "
echo "cp $FICT /usr/local/etc/oracle "
echo "eventuellement vers : "
for ligne in `ls -1 -d /*/oradata/*/network `
do
echo "cp $FICL $ligne "
echo "cp $FICT $ligne "
done
#
echo "-------------------------------------------------------------"
#
# mkdir -p /usr/local/etc/oracle
# chmod 775 /usr/local/etc/oracle
# chown oracle:dba /usr/local/etc/oracle
# cp /tmp/listener.ora /usr/local/etc/oracle 
# cp /tmp/tnsnames.ora /usr/local/etc/oracle 
# chown oracle:dba  /usr/local/etc/oracle/*.ora 
# chmod 664  /usr/local/etc/oracle/*.ora 
# ADR_BASE_LISTENER=/sitr
# 
# srvctl config listener -l listener
# srvctl stop listener -l listener
# srvctl remove listener
# srvctl add listener -l listener -p "TCP:41521" -o /sitr/app/oracle/product/11.2.0/asm
# srvctl modify listener -l listener -p TCP:41521
# srvctl setenv listener -l listener -T TNS_ADMIN=/usr/local/etc/oracle
# srvctl getenv listener -l listener
# srvctl start listener -l listener
# srvctl config listener -l listener
#
#
