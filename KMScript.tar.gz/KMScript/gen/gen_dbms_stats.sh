#
sqlplus "$conn" <<EOT
select 'dbms_stats.gather_table_stats(''CISADM'','''||table_name||''',cascade=>true);' 
from dba_tables where table_name like '%';
exit
EOT
#
