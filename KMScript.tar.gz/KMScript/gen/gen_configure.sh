#
for laligne in `cat listedb10203`
do
#
export labase=`echo $laligne|awk -F: '{print $1}'`
export lerep=`echo $laligne|awk -F: '{print $2}'`
export lefic=rman_conf_10g.$labase
>$lefic
#   
echo "CONFIGURE RETENTION POLICY TO RECOVERY WINDOW OF 30 DAYS;" >> $lefic
echo "CONFIGURE BACKUP OPTIMIZATION ON; " >> $lefic
echo "CONFIGURE DEFAULT DEVICE TYPE TO 'SBT_TAPE'; " >> $lefic
echo "CONFIGURE CONTROLFILE AUTOBACKUP ON; " >> $lefic
echo "CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE SBT_TAPE TO '%F'; # default " >> $lefic
echo "CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE DISK TO '%F'; # default " >> $lefic
echo "CONFIGURE DEVICE TYPE 'SBT_TAPE' PARALLELISM 2 BACKUP TYPE TO COMPRESSED BACKUPSET; " >> $lefic
echo "CONFIGURE DEVICE TYPE DISK PARALLELISM 1 BACKUP TYPE TO BACKUPSET; # default " >> $lefic
echo "CONFIGURE DATAFILE BACKUP COPIES FOR DEVICE TYPE SBT_TAPE TO 1; # default " >> $lefic
echo "CONFIGURE DATAFILE BACKUP COPIES FOR DEVICE TYPE DISK TO 1; # default " >> $lefic
echo "CONFIGURE ARCHIVELOG BACKUP COPIES FOR DEVICE TYPE SBT_TAPE TO 1; # default " >> $lefic
echo "CONFIGURE ARCHIVELOG BACKUP COPIES FOR DEVICE TYPE DISK TO 1; # default " >> $lefic
echo "CONFIGURE CHANNEL DEVICE TYPE 'SBT_TAPE' PARMS  'ENV=(TDPO_OPTFILE=/$lerep/config/tdpo_$labase.opt)' MAXOPENFILES 10; " >> $lefic
echo "CONFIGURE AUXILIARY CHANNEL DEVICE TYPE 'SBT_TAPE' PARMS  'ENV=(TDPO_OPTFILE=/$lerep/config/tdpo_$labase.opt)'; " >> $lefic
echo "CONFIGURE MAXSETSIZE TO UNLIMITED; # default " >> $lefic
echo "CONFIGURE ENCRYPTION FOR DATABASE OFF; # default " >> $lefic
echo "CONFIGURE ENCRYPTION ALGORITHM 'AES128'; # default " >> $lefic
echo "CONFIGURE ARCHIVELOG DELETION POLICY TO NONE; # default " >> $lefic
echo "CONFIGURE SNAPSHOT CONTROLFILE NAME TO '/$lerep/sgbd/$labase/disk03/snapcf_$labase.f'; " >> $lefic
#
done
