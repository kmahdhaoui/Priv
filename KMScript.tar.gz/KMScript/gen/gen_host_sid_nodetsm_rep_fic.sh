#
for laligne in `cat listedb10203`
do
#
export lehost=`uname -n`
export labase=`echo $laligne|awk -F: '{print $1}'`
export lerep=`echo $laligne|awk -F: '{print $2}'`
export lesfichiers="TDPO.${labase} ${labase}_rman.opt tdpo_${labase}.opt"
export lenodetsm=${labase}_rman
#
>$lefic
#   
echo "$lehost; $labase; $lenodetsm; /$lerep/config; $lesfichiers;" 
#
done
