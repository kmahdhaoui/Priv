#!/bin/ksh
# Author : Kamel Mahdhaoui
#
# set -x
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
if [ "$1" == "" ]
then
   export leFic=vv
else
   export leFic=$1
fi
#
cat $KMscript/log/$leFic |while read LINE
do
    echo $LINE |awk -F. '{print "insert into tmp_table_tmp values (\x27"$1"\x27,\x27"$2"\x27,\x27"$3"\x27,\x27"$4"\x27);" }'
done
#
. $KMscript/KMlogout.sh
#
#--create table tmp_table_tmp
#--as select index_owner,table_owner,column_position,column_name from dba_ind_columns where 1=2
#
