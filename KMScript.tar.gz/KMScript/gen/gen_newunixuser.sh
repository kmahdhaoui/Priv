#
export leuser=$1
export legrp=$2
#
if [ "$leuser" == "" ]
then 
   echo "Usage is : $0 <user> <primary group|default=user>" 
   exit 1
fi
if [ "$legrp" == "" ]
then
   # echo "user=$leuser and group is defaulted to : $leuser !!!"
   export legrp=$leuser
fi
#
export etcpass=/etc/passwd
export etcgrp=/etc/group
#
export USEREXISTE=`grep $leuser $etcpass |wc -l`
export GRPEXISTE=`grep $legrp $etcgrp |wc -l`
#
if [ "$USEREXISTE" -gt 0 ]
then
   echo "Error user : $leuser existe ... !"
   exit 2
fi
#
if [ "$GRPEXISTE" -gt 0 ]
then
   echo "Error group : $legrp existe ... !"
   exit 3
fi
#
export leuid=`awk -F: {'print $3'} $etcpass |grep "^2"|awk '$0>x{x=$0};END{print x}'`
export leuid=`expr $leuid + 1`
export legid=`awk -F: {'print $3'} $etcgrp |grep "^2"|awk '$0>x{x=$0};END{print x}'`
export legid=`expr $legid + 1`
#
if [ "$leuid" -lt 20000 ]
then
   echo "Error uid : $leuid <= 20000 ... !"
   exit
fi
#
echo "groupadd -g $legid $legrp"
echo "useradd  -u $leuid -g $legrp $leuser" 
echo "passwd -d $leuser ; passwd -e $leuser"
#
