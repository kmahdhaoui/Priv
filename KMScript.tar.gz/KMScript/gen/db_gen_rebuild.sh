#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh 1>/dev/null
#
#---------------------------------------------------------------------
# VARIABLES
export ARGS="$*"
export PID=${$}
export mycoderror=0
export a_error_warn=4
# Logs et journaux
export LOG_RETENTION=10
export LOGDIR=./log                           
export JOBNAME=`basename ${0} .sh`                
export TMPLOG=/tmp/$JOBNAME.${INSTANCE}.${PID}.${RANDOM}.log
export LOGFILE="${LOGDIR}/${JOBNAME}.log"              
export DET_LOGFILE=/dev/null                    
#
export mycoderror=0
#---------------------------------------------------------------------
# FONCTIONS
Usage() {
   echo -e "\n\t-> Usage :"
   echo -e "\t\t`basename ${0}` "
   echo -e "\t\t                --tablespace|-tbs    =<Tablespace> "
   echo -e "\t\t                --schema|-s          =<Schema> "
   echo -e "\t\t                --table|-t           =<Table> "
   echo -e "\t\t                --verbose|-v              "
   echo -e "\n\t\tDependances : n/a"
   echo -e ""
   exit 1
   }

fMsgLog() {
   TYPINFO=${1}
   CODAPLI=${2}
   MSGINFO=${3}
   if [ ${MODE_VERBOSE} ]; then  
	case "${TYPINFO}" in
		TITRE*)	echo -e "\n\t=> ${MSGINFO}"|tee -a ${DET_LOGFILE};;
		TEXTE*)	echo -e "\t${MSGINFO}"|tee -a ${DET_LOGFILE};;
		INFO*) 	echo -e "\t- ${MSGINFO}"|tee -a ${DET_LOGFILE};;
		*)	echo -e "\t${TYPINFO} : ${MSGINFO}"|tee -a ${DET_LOGFILE};;
	esac 
   fi
   case "${TYPINFO}" in
	INFO*|ALERTE*|ERR*) 
		echo -e "`/bin/date +\%Y%m%d-%Hh%M`:${TYPINFO}:${CODAPLI}:${MSGINFO}" >> ${LOGFILE}		
		;;
   esac
}
#
fFinJob() {
   . $KMscript/KMlogout.sh
   #
   CODRETOUR=${1}
   # Suppression des fichiers temporaires et lock
   rm -f $TMPLOG

   fMsgLog "TEXTE" "" "\n"
   fMsgLog "TEXTE" "" "Le job ${JOBNAME} s'est termine le `/bin/date +\%A\ %d\ %B\ %Y\ \a\ %H\h%M` avec le code ${CODRETOUR}.\n"
   exit ${CODRETOUR}
}

#---------------------------------------------------------------------
# CONTROL PARAMETRES ET TESTS

if [ "${1}" = "" ]; then Usage; fi

for arg in ${ARGS} 
do
    case "$arg" in
      --tablespace=*|-tbs=*)     TABLESPACE=`echo -e "$arg" | sed -e 's/^[^=]*=//'` ;;
      --schema=*|-s=*)           SCHEMA=`echo -e "$arg" | sed -e 's/^[^=]*=//'` ;;
      --table=*|-t=*)            TABLE=`echo -e "$arg" | sed -e 's/^[^=]*=//'` ;;
      --verbose|-v)          MODE_VERBOSE=0;;
      --help|-h)             Usage;;
      *)                     Usage;;         
    esac
done
#
if [ ! -w /tmp ]; then
        echo -e "\n\t-> Impossible d'ecrire dans le repertoire temporaire"
        exit 1
fi

#---------------------------------------------------------------------
# INITIALISATIONS

fMsgLog "TEXTE" "" "\n\t----------------------------------------------------" 
fMsgLog "TEXTE" "" "Generation de Rebuild Index  " 
fMsgLog "TEXTE" "" "----------------------------------------------------" 

fMsgLog "TITRE" "" "Starting at ... `/bin/date +\%A\ %d\ %B\ %Y\ \a\ %H\h%M`" 
fMsgLog "TEXTE" "" "          ORACLE_SID = ${ORACLE_SID}" 
fMsgLog "TEXTE" "" "          TABLESPACE = ${TABLESPACE}" 
fMsgLog "TEXTE" "" "              SCHEMA = ${SCHEMA}" 
fMsgLog "TEXTE" "" "               TABLE = ${TABLE}" 
fMsgLog "TEXTE" "" "       LOG DETAILLEE = ${DET_LOGFILE}"
#
#---------------------------------------------------------------------
# AUTOPURGES DES LOGS DU JOB

# Purge des anciens fichiers de LOG
fMsgLog "TITRE" "" "Purge des logs de $0 :"
NB_PURGE=$(expr `find ${DET_LOGDIR} -name "${JOBNAME}.${ORACLE_SID}.*.log" -mtime +${LOG_RETENTION} -print |wc -l`)
find ${DET_LOGDIR} -name "${JOBNAME}.${ORACLE_SID}.*.log" -mtime +${LOG_RETENTION} -exec rm {} \;
if [ ${?} -ne 0 ]; then
   fMsgLog "ALERTE " ${ORACLE_SID} "Purge des logs impossible..."
else
   fMsgLog "TEXTE" "" "...Ok - ${NB_PURGE} fichier(s) purge(s)"
fi
#
#
if [ "$SCHEMA" != "" ]
then
    export leowner=$SCHEMA
else
    export leowner=CISADM
fi
if [ "$TABLE" != "" ]
then
    export lestb=$TABLE
else
    export lestb=%
fi
if [ "$TABLESPACE" != "" ]
then
    export letbs=$TABLESPACE
else
    export letbs=%
fi
#
echo "$leowner:$lestb:$letbs" 
#
sqlplus -s "$conn" <<EOT
@$KMscript/$SQLLOGIN
--
col OWNER format a22
col OBJECT_TYPE format a15
col OBJECT_NAME format a35
col STATUS format a15
set pages 0
set lines 132
set feedback off verify off echo off
--
prompt -- Indexes 
select '-- '||table_name||chr(10)||
'alter index '||owner||'.'||index_name||' rebuild online parallel 8;' from dba_indexes where 
OWNER=upper('$leowner') and table_name like upper('$lestb') and index_type not like '%LOB%' 
and tablespace_name like '$letbs'
and table_name not like 'Q1%'
and table_name not like 'ID_DOUB%'
and table_name not like 'HORS_Q1%'
and table_name not like 'DOUBLE_Q%'
and table_name not like 'CM_%'
and table_name not like 'TB_D1_INIT_MSRMT_DATA_K%'
and status not in ('N/A');
-- status not in ('VALID','N/A');
-- OWNER INDEX_NAME TABLE_NAME
--
prompt -- Indexes Partitions
SELECT '-- '||index_name||chr(10)||
'alter index '||index_owner||'.'||index_name||' rebuild partition '||partition_name||' online ;'  
FROM dba_ind_partitions WHERE INDEX_OWNER=upper('$leowner') 
and tablespace_name like '$letbs'
and INDEX_NAME in 
(select INDEX_NAME from dba_indexes where OWNER=upper('$leowner') 
and table_name like upper('$lestb') 
and table_name not like 'Q1%'
and table_name not like 'ID_DOUB%'
and table_name not like 'HORS_Q1%'
and table_name not like 'DOUBLE_Q%'
and table_name not like 'CM_%'
and table_name not like 'TB_D1_INIT_MSRMT_DATA_K%'
and index_type not like '%LOB%')
and status not in ('N/A');
-- status in ( 'UNUSABLE') ; 
-- INDEX_OWNER INDEX_NAME
--
prompt -- Indexes SubPartitions 
SELECT '-- '||index_name||chr(10)||
'alter index '||index_owner||'.'||index_name||' rebuild subpartition '||subpartition_name||' online ;'
FROM dba_ind_subpartitions WHERE INDEX_OWNER=upper('$leowner') 
and tablespace_name like '$letbs'
and INDEX_NAME in
(select INDEX_NAME from dba_indexes where OWNER=upper('$leowner') 
and table_name like upper('$lestb') 
and table_name not like 'Q1%'
and table_name not like 'ID_DOUB%'
and table_name not like 'HORS_Q1%'
and table_name not like 'DOUBLE_Q%'
and table_name not like 'CM_%'
and table_name not like 'TB_D1_INIT_MSRMT_DATA_K%'
and index_type not like '%LOB%')
and status not in ('N/A');
-- status in ( 'UNUSABLE') ; 
-- INDEX_OWNER INDEX_NAME
--
exit
EOT
#
. $KMscript/KMlogout.sh 1>/dev/null
#
