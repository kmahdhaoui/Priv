#!/bin/ksh
# Author : Kamel Mahdhaoui
#
if [ "$KMscript" == "" ] || [ ! -r $KMscript/KMlogin.sh ]
then
   echo "Problem KMlogin.sh or \$KMscript ..."
   exit 101
fi
#
export Filtre=10
if [ "$1" != "" ]
then
   export Filtre=$1
else
   export Filtre=10
fi
# positionner des choses pour les scripts
. $KMscript/KMlogin.sh
#
export FicInput=$KMscript/work/listserv.conf.20120314
export FicInputTRi=$KMscript/work/listserv.conf.20120314.tri
sort -u $FicInput > $FicInputTRi
#
#---------------------------------------------------------
export ListeHostsPGI="dapgisimulc1 dapgiprodc1"
export ListeHostsDMZ="dasgbdformb2 dasgbdbasb2 dasgbddevb2 dasgbdrab2 dasgbdintb2 dasgbdrecb2 dasgbdrefb2 dasgbdsasb2 "
export ListeHostsProd_1="dasgbdproda1 dasgbdprodb1 dasgbdprodc1 dasgbdprodc2 dasgbdprodd1 "
export ListeHostsProd_ssd1=" dasgbdproda1 dasgbdprodb1 dasgbdprodc1 dasgbdprodc2 "
export ListeHostsProd_2=" dainfproda1 dssgbdprod1 "
export ListeHostsPrexTest=" dasgbdprexa1 dasgbdprexb1 dasgbdprexd1 "
export ListeHostsRecTest=" dasgbdreca1 dasgbdrecb1 dasgbdrecd1  "
export ListeHostsDevTest=" dasgbddeva1 dasgbddevb1 dasgbddevd1 "
export ListeHostsSaturneTest=""
export ListeHostsAutreTest=""
export ListeHostsQuarantaine=" dsdevc1 dsdfpe1 daprodd3"
export ListeHostsTest="$ListeHostsPrexTest $ListeHostsRecTest $ListeHostsDevTest $ListeHostsSaturneTest"
#---------------------------------------------------------
export ListeHostsProd=""
export ListeHostsSimu=""
export ListeHostsPrex=""
export ListeHostsInt=""
export ListeHostsRec=""
export ListeHostsDev=""
export ListeHostsSaturne=""
export ListeHostsAutre=""
#---------------------------------------------------------
#
cat $FicInputTri |grep -v '^$'|grep -v "^#"| while read LIGNE ; do
#
export LeProjet=`echo $LIGNE|cut -d' ' -f2`
export LeHost=`echo $LIGNE|cut -d' ' -f1`
#
case $LeProjet in 
     Prod*|prod*|PROD*)    export LeProjet=Prod 
                           export ListeHostsProd="$ListeHostsProd $LeHost" 
                           if [ "$LeHost" != "dasgbdprodd1" ]
                           then
                           export ListeHostsProd_ssd="$ListeHostsProd $LeHost" 
                           fi
     ;;
     Prex*|prex*|PREX*)    export LeProjet=Prex 
                           export ListeHostsPrex="$ListeHostsPrex $LeHost"
     ;;
     Rec*|rec*|REC*)       export LeProjet=Rec 
                           export ListeHostsRec="$ListeHostsRec $LeHost"
     ;;
     Dev*|dev*|DEV*)       export LeProjet=Dev 
                           export ListeHostsDev="$ListeHostsDev $LeHost"
     ;;
     Int*|int*|INT*)       export LeProjet=Int 
                           export ListeHostsInt="$ListeHostsInt $LeHost"
     ;;
     Satur*|satur*|SATUR*) export LeProjet=Saturne 
                           export ListeHostsSaturne="$ListeHostsSaturne $LeHost"
     ;;
     *)                    export LeProjet=Autre 
                           export ListeHostsAutre="$ListeHostsAutre $LeHost"
     ;;
esac
#
# echo $LeProjet $LeHost
#
done
#
#---------------------------------------------------------
export ListeHostsTout_1="$ListeHostsProd $ListeHostsSimu $ListeHostsPrex $ListeHostsInt $ListeHostsRec $ListeHostsDev $ListeHostsSaturne"
export ListeHostsTout_ssd1="$ListeHostsProd_ssd $ListeHostsSimu $ListeHostsPrex $ListeHostsInt $ListeHostsRec $ListeHostsDev"
export ListeHostsTout_2="$ListeHostsProd $ListeHostsSimu $ListeHostsPrex $ListeHostsInt $ListeHostsRec $ListeHostsDev $ListeHostsSaturne $ListeHostsAutre"
export ListeHostsTout_ssd2="$ListeHostsProd_ssd $ListeHostsSimu $ListeHostsPrex $ListeHostsInt $ListeHostsRec $ListeHostsDev $ListeHostsAutre"
#---------------------------------------------------------
#
echo $ListeHostsTout_ssd2
#
. $KMscript/KMlogout.sh
#
