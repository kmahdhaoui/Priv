#
#export SID=$ORACLE_SID
export SID=$K_ORASID
export MAJoracle_sid=`echo $SID|tr '[:lower:]' '[:upper:]'`
export MINoracle_sid=`echo $SID|tr '[:upper:]' '[:lower:]'`
#
export DF="+DATARECE/$MINoracle_sid/"
export TF=datafile
export TT=" "
#
cat mdmrece.dat |while read LINE
do
   export letbs=`echo $LINE |awk -F" " '{print $1}'`
   export alloc=`echo $LINE |awk -F" " '{print $2}'`
   export nbrdf=`expr $alloc / 32000`
   export nbrdf=`expr $nbrdf + 1`
   #
   if [ $letbs == "TEMP" ] || [ $letbs == "SITR_TEMP" ] || [ $letbs == "MDC_ODI_TMP" ]
   then 
      export TF=tempfile
      export TT="temporary"
   else
      export TF=datafile
      export TT=" "
   fi
   # echo $letbs $nbrdf
   if [ $nbrdf -eq 1 ]
   then
       export taille=100m
   else
       export taille=1g
   fi
   #
   export i=1
   while [ $nbrdf -ge $i ]
   do
         export CDE=" "
         if [ $i -eq 1 ]
         then 
            export CDE="create $TT tablespace $letbs $TF "
         else
            export CDE="alter tablespace $letbs add $TF "
         fi
         #
	 echo "$CDE '$DF${letbs}_$i.dbf' size $taille autoextend on next $taille maxsize unlimited;"
         #
         export i=`expr $i + 1`
   done
done
#
