#!/bin/bash
# Author : Kamel Mahdhaoui
#
if [ "$1" == "" ] 
then
   echo "Usage is $0 <user> <grep string> "
   exit 101
fi
#
ps -ef |grep "^$1" |grep "$2" |grep -v "\-bash" |awk -F" " '{print $2}'
#
#

