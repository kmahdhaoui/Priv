#
. $KMscript_WIN/KMenv.ps1 PROD 
#
# $Liste_conn=" $args "
# $Liste_conn="MDMEMET_5007","MDMRECE_5010","SITREMT_5009","SITRSUP_5009","SITRMDC_5005","SITRMDM2_5006","SITRMDCP_5002","SITRMDMP_5002","MDMJDBC_5007"
# $Liste_conn=$Liste_conn.trim()
#
if ($Liste_conn)
   {$Liste_conn=$Liste_conn}
else
   {$Liste_conn=(ls -name $KMscriptconn)}
#
$Liste_conn="XSITRMDO_TMC","XSITRMDC_TMC","XSITREMT_TMC"
#
#echo $args
#echo $KMscriptconn
#echo ": $Liste_conn :"
#
# $reponse = read-host "Enter to continue ..."
#
foreach ($myconn in $Liste_conn) {
write-host -foregroundcolor red  "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
write-host -foregroundcolor red -backgroundcolor white "                                       $myconn                                         "
write-host -foregroundcolor red  "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
. rdb_$myconn

foreach ($sqlprog in "db_detect_tbs") 
	{
    write-host -foregroundcolor Green "$myconn : $sqlprog"
    runsql $sqlprog
	# $reponse = read-host "Enter to continue ..."
    }

}
#