$From = "kamel.mahdhaoui@gmail.com"
$To = "kamel.mahdhaoui@gmail.com"
$Cc = "kamel.mahdhaoui@gmail.com"
$Attachment = "C:\temp\kamel.txt"
$Subject = "tbs isec"
$Body = "tbs isec"
$SMTPServer = "smtp.gmail.com"
$SMTPPort = "587"
Send-MailMessage -From $From -to $To -Cc $Cc -Subject $Subject `
-Body $Body -SmtpServer $SMTPServer -port $SMTPPort -UseSsl `
-Credential (Get-Credential) -Attachments $Attachment