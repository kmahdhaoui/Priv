$JOUR=$argv[0]
echo  ================================================================================
runsql db_event_trends '"RMAN backup % recovery I/O"'   $JOUR
echo  ================================================================================
runsql db_event_trends '"RMAN Disk slave I/O"'   $JOUR
echo  ================================================================================
runsql db_event_trends '"RMAN Tape slave I/O"'   $JOUR
echo  ================================================================================
runsql db_event_trends '"LGWR slave I/O"'   $JOUR
echo  ================================================================================
runsql db_event_trends '"Log archive I/O"'   $JOUR
echo  ================================================================================
runsql db_event_trends '"log file parallel write"'   $JOUR
echo  ================================================================================
runsql db_event_trends '"log file sequential read"'   $JOUR
echo  ================================================================================
runsql db_event_trends '"log file single write"'   $JOUR
echo  ================================================================================
runsql db_event_trends '"db file parallel write"'   $JOUR
echo  ================================================================================
runsql db_event_trends '"buffer busy waits"'   $JOUR
echo  ================================================================================
runsql db_event_trends '"enq: HV - contention"'   $JOUR
echo  ================================================================================
runsql db_event_trends '"enq: TX - index contention"'   $JOUR
echo  ================================================================================
runsql db_event_trends '"enq: WG - lock fso"'   $JOUR
echo  ================================================================================
runsql db_event_trends '"library cache load lock"'   $JOUR
echo  ================================================================================
runsql db_event_trends '"library cache lock"'   $JOUR
echo  ================================================================================
runsql db_event_trends '"row cache lock"'   $JOUR
echo  ================================================================================
runsql db_event_trends '"securefile chain update"'   $JOUR
echo  ================================================================================
runsql db_event_trends '"SecureFile mutex"'   $JOUR
echo  ================================================================================
runsql db_event_trends '"db file parallel read"'   $JOUR
echo  ================================================================================
runsql db_event_trends '"db file scattered read"'   $JOUR
echo  ================================================================================
runsql db_event_trends '"db file sequential read"'   $JOUR
echo  ================================================================================
runsql db_event_trends '"db file single write"'   $JOUR
echo  ================================================================================
runsql db_event_trends '"securefile direct-read completion"'   $JOUR
echo  ================================================================================
runsql db_event_trends '"securefile direct-write completion"'   $JOUR
echo  ================================================================================
 