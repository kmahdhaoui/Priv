#
#. $KMscript_WIN/KMenv.ps1 JOUR 
#
$Liste_prog=" $args "
$Liste_prog=$Liste_prog.trim()
#
if ($Liste_prog)
   {$Liste_prog=$Liste_prog}
else
   {$Liste_prog="db_dfi"}
#   
$Liste_conn=(ls -name $KMscriptconn)
#
#echo $args
#echo $KMscriptconn
#echo ": $Liste_conn :"
#
$reponse = read-host "Enter to continue ..."
#
foreach ($myconn in $Liste_conn) {
write-host -foregroundcolor red  "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
write-host -foregroundcolor red -backgroundcolor white "                                       $myconn                                         "
write-host -foregroundcolor red  "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
. rdb_$myconn

foreach ($sqlprog in "$Liste_prog") 
	{
    write-host -foregroundcolor Green "$myconn : $sqlprog"
    runsql $sqlprog
	$reponse = read-host "Enter to continue ..."
    }

}