#
$KMscript_WIN="C:\kamel\KMscript\_WIN"
. $KMscript_WIN/KMenv.ps1 ISEC 
#
net use k: \\10.34.32.242\KmData
#
# $Liste_conn=" $args "
$Liste_conn="MDMEMET_5007","MDMRECE_5010","SITREMT_5009","SITRSUP_5009","SITRMDC_5005","SITRMDM2_5006","SITRMDCP_5002","SITRMDMP_5002","MDMJDBC_5007"
# $Liste_conn=$Liste_conn.trim()
#
if ($Liste_conn)
   {$Liste_conn=$Liste_conn}
else
   {$Liste_conn=(ls -name $KMscriptconn)}
#
# $Liste_conn="MDMRECE_5010"
$Liste_conn="MDMEMET_5007","MDMRECE_5010","SITREMT_5009","SITRSUP_5009","SITRMDC_5005","SITRMDM2_5006","SITRMDCP_5002","SITRMDMP_5002","MDMJDBC_5007"
#
#echo $args
#echo $KMscriptconn
#echo ": $Liste_conn :"
#
# $reponse = read-host "Enter to continue ..."
#
foreach ($myconn in $Liste_conn) {
write-host -foregroundcolor red  "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
write-host -foregroundcolor red -backgroundcolor white "                                       $myconn                                         "
write-host -foregroundcolor red  "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
. rdb_$myconn

foreach ($sqlprog in "db_sess","db_asm","db_longops","db_detect_tbs","db_dfi","db_loghis","db_event_trends","db_hist_auto_stats","db_holder") 
	{
    # Get-Content $SourceFile | ConvertTo-Html | Out-File $TargetFile
	# write-host -foregroundcolor Green "$myconn : $sqlprog"
	$lerepout="K:/"+$myconn+"/"+(date -format yyyyMMdd)+"/"+(date -format HH)
	$lefichier=$lerepout+"/"+$sqlprog+"."+(date -format yyyyMMdd_HHmm)+"."+"html"
	mkdir $lerepout 2>&1>$null
    runsqlm $sqlprog > $lefichier
	# $reponse = read-host "Enter to continue ..."
    }
foreach ($sqlprog in "db_access","db_autotask","db_check_database_stats","db_invalid","db_link","db_iowait","db_memory","db_owner_vol") 
	{
    # Get-Content $SourceFile | ConvertTo-Html | Out-File $TargetFile
	# write-host -foregroundcolor Green "$myconn : $sqlprog"
	$lerepout="K:/"+$myconn+"/"+(date -format yyyyMMdd)+"/"+(date -format HH)
	$lefichier=$lerepout+"/"+$sqlprog+"."+(date -format yyyyMMdd_HHmm)+"."+"html"
	mkdir $lerepout 2>&1>$null
	runsqlm $sqlprog > $lefichier
	# $reponse = read-host "Enter to continue ..."
    }
foreach ($sqlprog in "db_status","db_tempusage","db_undo","db_running_job","db_redolog","db_sysaux_occ","db_schedule_details") 
	{
    # Get-Content $SourceFile | ConvertTo-Html | Out-File $TargetFile
	# write-host -foregroundcolor Green "$myconn : $sqlprog"
	$lerepout="K:/"+$myconn+"/"+(date -format yyyyMMdd)+"/"+(date -format HH)
	$lefichier=$lerepout+"/"+$sqlprog+"."+(date -format yyyyMMdd_HHmm)+"."+"html"
	mkdir $lerepout 2>&1>$null
	runsqlm $sqlprog > $lefichier
	# $reponse = read-host "Enter to continue ..."
    }	
foreach ($sqlprog in "db_view_alert") 
	{
    # Get-Content $SourceFile | ConvertTo-Html | Out-File $TargetFile
	# write-host -foregroundcolor Green "$myconn : $sqlprog"
	$lerepout="K:/"+$myconn+"/"+(date -format yyyyMMdd)+"/"+(date -format HH)
	$lefichier=$lerepout+"/"+$sqlprog+"."+(date -format yyyyMMdd_HHmm)+"."+"html"
	mkdir $lerepout 2>&1>$null
	runsql db_new_alert 2>&1>$null
	runsqlm $sqlprog > $lefichier
	runsql db_ack_alert 2>&1>$null
	# $reponse = read-host "Enter to continue ..."
    }
}
#
cd $KMscript_PSH
#