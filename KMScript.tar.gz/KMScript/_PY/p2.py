import os
os.system("sqlplus /nolog")

