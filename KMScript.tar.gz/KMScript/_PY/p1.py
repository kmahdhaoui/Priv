#!/usr/bin/python3

import sys;

N = len(sys.argv) - 1
NOFF = N * N

print ('N:',N)

inpv = []
ranv = []
outv = []

inpv = [sys.argv[i + 1] for i in range(N)]
ranv = [0 for i in range(N)]
outv = [0 for i in range(N)]

for i in range(N):
  x = i + NOFF 
  if 
  ranv[i]
  print(inpv[i],outv[i])

