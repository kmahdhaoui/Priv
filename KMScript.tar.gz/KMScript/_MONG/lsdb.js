db.adminCommand('listDatabases') ;
