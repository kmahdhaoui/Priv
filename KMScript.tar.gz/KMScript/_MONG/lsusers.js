
printjson(db.getUsers()).toArray())
printjson(db.getUsers())
db.getRoles({showBuiltinRoles: true});
