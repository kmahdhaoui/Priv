--
-- Automatic Statistics Gathering does not Complete - Diagnostics Interpretation Guidelines (Doc ID 1902112.1)
--
set pages 555
set feedback on 
set lines 150
col attributes format a44
col OPERATION_NAME format a30
col client_name format a33
col task_name format a30
col comments format a40
col WINDOW_GROUP_NAME format a30
col NEXT_START_DATE format a40
col max7 format a15
col max30 format a15
col WINDOW_GROUP format a20
col WINDOW_NAME format a20
col jcreat format 9999
col jstart format 9999
col jcompl format 9999
col window_start_time format a35
col JOB_NAME format a30
col STATUS format a12
col ADDITIONAL_INFO format a20
col RUN_DURATION format a15
col ACTUAL_START_DATE format a40
col error# format 9999
col JOB_START_TIME format a40
col log_date format a40
col JOB_INFO format a30
col job_scheduler_status format a20
col WINDOW_NEXT_TIME format a40
col WINDOW_ACTIVE format a15
col AUTOTASK_STATUS format a15
col OPTIMIZER_STATS format a15
--
prompt 
prompt 
--
prompt ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
prompt Is 'auto optimizer stats collection' enabled ?  
prompt DBA_AUTOTASK_CLIENT : This view contains statistics about automated maintenance tasks. 
prompt You can check DBA_AUTOTASK_CLIENT to see that the automated maintenance task is enabled:
prompt The Job needs to be enabled to run
prompt ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
select client_name,status,window_group from DBA_AUTOTASK_CLIENT;
-- 
prompt ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
prompt Is ORA$AT_WGRP_OS window group is enabled ?  
prompt DBA_AUTOTASK_OPERATION displays all automated maintenance task operations for each client
prompt The Job needs to be enabled to run
prompt ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
select client_name,operation_name,operation_tag,attributes,status from DBA_AUTOTASK_OPERATION ;
--
prompt ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
prompt When is the ORA$AT_WGRP_OS window group scheduled to start next ?
prompt DBA_AUTOTASK_TASK displays information about current and past automated maintenance tasks.
prompt The first half Shows auto task tasks and status so that you can see that it is  enabled.
prompt If the window group is not being scheduled to run then this may be why statistics are not being collected
prompt ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
select client_name,task_name,operation_name,status from DBA_AUTOTASK_TASK;
--
prompt ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
prompt Has the 'auto optimizer stats collection' run in the last 7/30 days and how did it perform ? 
prompt Once you have established that the job is enabled, have a look at the dba_scheduler_window_groups 
prompt view to see that the ORA$AT_WGRP_OS window group is enabled and when it is scheduled to start next:
prompt If the job has not run/completed recently then this may be why statistics are not being collected
prompt If it is not enabled or is not scheduled to start in a reasonable timeframe, enable it or modify the timeframe
prompt ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
select window_group_name,enabled,next_start_date,comments from DBA_SCHEDULER_WINDOW_GROUPS;
select client_name,status,window_group,MAX_DURATION_LAST_7_DAYS max7,MAX_DURATION_LAST_30_DAYS max30 from DBA_AUTOTASK_CLIENT;
--
prompt ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
prompt Has 'auto optimizer stats collection' ever successfully completed? 
prompt If the job completed at some time in the past then something has changed such that it no longer completes
prompt ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
select client_name,window_name,window_start_time,jobs_created jcreat,jobs_started jstart,jobs_completed jcompl 
from DBA_AUTOTASK_CLIENT_HISTORY order by WINDOW_START_TIME desc;
select job_name,status,error#,ACTUAL_START_DATE,run_duration,additional_info from dba_scheduler_job_run_details 
where job_name not like '%QUEST%' and job_name not like '%CLEAN%' and job_name not like '%PURGE%' and 
job_name not like '%REEVALUATE%' and
ACTUAL_START_DATE > sysdate - 17 order by ACTUAL_START_DATE desc;
--
prompt ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
prompt When did 'auto optimizer stats collection' last successfully complete? When did it start to fail?
prompt If a change has occurred then it was after the last successful completion
prompt ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
select job_name,JOB_START_TIME,job_error,job_info from DBA_AUTOTASK_JOB_HISTORY 
where JOB_START_TIME > sysdate - 17 order by JOB_START_TIME desc ;
--
prompt ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
prompt Is 'auto optimizer stats collection' job running currently? Is it supposed to be running?
prompt If the job is still running it may be that since it never completes the statistics are not being collected
prompt Check to see if any jobs are currently running. If they are, why are they still running? Are they supposed to be running? 
prompt Do they usually take this long? If not then look into what has changed since the last successful run.
prompt Once you have looked at this, search for any outstanding/running jobs in DBA_SCHEDULER_JOB_LOG. What is their status?:
prompt ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
select client_name,job_name,job_scheduler_status, task_name, task_operation from DBA_AUTOTASK_CLIENT_JOB ;
--
prompt ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
prompt If the job is still running, is there a history of this occurring? When did it start?
prompt Identifying when the behavior changed provides a target for investigating what might have changed
prompt Did the Job stop with an error?
prompt An error may or may not be an indicator of a problem	
prompt When did the Job last run successfully?	
prompt Something changed after this time such that it was unsuccessful	
prompt What was the duration of the last successful job? What is the duration of the unsuccessful jobs? 
prompt If unsuccessful jobs have an excessive duration then this may be preventing completion	
prompt ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
select job_name,log_date,operation,status from DBA_SCHEDULER_JOB_LOG where job_name not like '%QUEST%' 
and job_name not like '%CLEAN%' and job_name not like '%PURGE%' and job_name not like '%REEVALUATE%' 
and log_date > sysdate -17  and operation = 'RUN'  order by log_date desc ;
--
prompt ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
prompt Are the maintenance window jobs that run the 'auto optimizer stats collection' enabled ?	
prompt These need to be enabled for the 'auto optimizer stats collection' to run	
prompt Is the optimizer task enabled?	
prompt The optimizer task needs to be enabled for the 'auto optimizer stats collection' to run	
prompt Are the WEEKNIGHT_WINDOW and WEEKEND_WINDOW disabled?	
prompt These are the old 10g windows and may interfere with collection if  enabled	
prompt Check that the daily windows are enabled. Check next start and that the last start actually happened.
prompt Check for WEEKNIGHT_WINDOW and WEEKEND_WINDOW, these are the old 10g windows and should not be enabled
prompt ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
select window_name,window_next_time,WINDOW_ACTIVE,AUTOTASK_STATUS,OPTIMIZER_STATS  from DBA_AUTOTASK_WINDOW_CLIENTS
order by window_next_time desc ;
select window_name,next_start_date,enabled,active from dba_scheduler_windows order by next_start_date desc ;
--
prompt ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
prompt Is there a group for 'auto optimizer stats collection'? Is it enabled? Is the next start date ok?
prompt The group needs to be enabled and the next start date should be scheduled in the future	
prompt Is there a group for 'auto optimizer stats collection'? Is it enabled? Is the next start date ok?
prompt ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
select window_group_name,enabled,next_start_date,comments  from dba_scheduler_window_groups 
order by next_start_date ;
--

