set pages 155
set lines 155

SET FEEDBACK OFF VERIFY OFF
set tab off
SET TERMOUT OFF

/* Fetch db_block_size */
COLUMN value  NOPRINT NEW_VALUE db_block_size
SELECT value
FROM   v$parameter
WHERE  name = 'db_block_size'
/

/* Some dummy code, in case there is no autextend option enabled */
COLUMN t      NOPRINT NEW_VALUE tname
COLUMN d1     NOPRINT NEW_VALUE decode1
COLUMN d2     NOPRINT NEW_VALUE decode2
COLUMN c1     NOPRINT NEW_VALUE condition1
SELECT 'sys.dual' t
,      '0'        d1
,      '0'        d2
,      '1=1'      c1
FROM dual
/

/* Overwrite the dummy code, when autextend option is enabled */
SELECT 'sys.filext$'                              t
,      'sum((d2.inc * &db_block_size) / 1048576)'       d1
,      'sum((d2.maxextend * &db_block_size) / 1048576)' d2
,      'd1.file_id = d2.file#'                    c1
FROM   sys.dba_objects
WHERE  owner     = 'SYS'
AND    object_name = 'FILEXT$'
AND    object_type IN ('TABLE', 'VIEW')
/

CLEAR BREAKS
SET TERMOUT ON
COL tablespace_name FORMAT A20        HEADING 'Tablespace'
COL file_name       FORMAT A55        HEADING 'Datafile'
COL maxauto         FORMAT 9999999      HEADING 'Max.|auto'
COL nextauto        FORMAT 99999        HEADING 'Next|auto'
COL total           FORMAT 9999999     HEADING 'Alloc|Mb'
COL free            FORMAT 9999999    HEADING 'Free|Mb'
COL pct             FORMAT 999        HEADING 'Pct|used'
COL min_size        FORMAT 9999999     HEADING 'Min.|Size'

BREAK ON REPORT ON tablespace_name
COMPUTE SUM OF total free min_size ON REPORT

PROMPT Datafiles, sizes in Mb
SELECT    b.tablespace_name
,         b.file_name
,         d.maxauto
,         d.nextauto
,         b.bytes/(1048576)                             total
,         NVL(c.sumbytes,0)/1048576                     free
,         ((b.bytes - NVL(c.sumbytes,0))/b.bytes) * 100 pct
,         NVL(e.min_size, 0)                            min_size
FROM dba_data_files b
, ( SELECT   tablespace_name, file_id, sum(bytes) sumbytes
    FROM     dba_free_space
    GROUP BY tablespace_name, file_id
  ) c
, ( SELECT d1.tablespace_name
    ,      d1.file_id
    ,      &decode1           nextauto
    ,      &decode2           maxauto
    FROM   dba_data_files d1
    ,      &tname         d2
    WHERE  &condition1
    GROUP BY d1.tablespace_name, d1.file_id
  ) d
, ( SELECT f.file_id
    , CEIL((f.block_id-1) * &db_block_size / 1048576) min_size
    FROM dba_free_space f
    , dba_data_files ddf
    WHERE f.file_id = ddf.file_id
    AND f.block_id + f.blocks - 1 = ddf.blocks
  ) e
WHERE b.file_id = c.file_id (+)
AND   b.file_id = d.file_id (+)
AND   b.file_id = e.file_id (+)
ORDER BY 1,2
;
--------------------------------
--
COL file_name       FORMAT A55        HEADING 'Tempfile'
PROMPT Temp Files, sizes in Mb
SELECT    b.tablespace_name
,         b.file_name
,         d.maxauto
,         d.nextauto
,         b.bytes/(1048576)                             total
,         NVL(c.sumbytes,0)/1048576                     free
,         ((b.bytes - NVL(c.sumbytes,0))/b.bytes) * 100 pct
,         0 min_size
FROM dba_temp_files b
, ( SELECT   tablespace_name, file_id,sum(BYTES_FREE) sumbytes
    FROM     V$TEMP_SPACE_HEADER
    GROUP BY tablespace_name,file_id
  ) c
, ( SELECT d1.tablespace_name
    ,      d1.file_id
    ,      &decode1           nextauto
    ,      &decode2           maxauto
    FROM   dba_temp_files d1
    ,      &tname         d2
    WHERE  &condition1
    GROUP BY d1.tablespace_name, d1.file_id
  ) d
WHERE b.tablespace_name = c.tablespace_name (+)
AND   b.file_id = d.file_id (+)
AND   b.file_id = c.file_id (+)
ORDER BY 1,2
/
--
--
prompt ==================================================================================
--
select  a.tablespace_name,
       round(a.bytes_alloc / 1024 / 1024)megs_alloc,
       round(nvl(b.bytes_free, 0) / 1024 /1024) megs_free,
       round((a.bytes_alloc - nvl(b.bytes_free, 0))/ 1024 / 1024) megs_used,
       round((nvl(b.bytes_free, 0) /a.bytes_alloc) * 100) Pct_Free,
       100 - round((nvl(b.bytes_free, 0) /a.bytes_alloc) * 100) Pct_used,
       round(maxbytes/1048576) Max
from  ( select f.tablespace_name,
               sum(f.bytes) bytes_alloc,
               sum(decode(f.autoextensible,'YES',f.maxbytes,'NO', f.bytes)) maxbytes
        from dba_data_files f
        group by tablespace_name) a,
      ( select f.tablespace_name,
               sum(f.bytes)  bytes_free
        from dba_free_space f
        group by tablespace_name) b
where a.tablespace_name =b.tablespace_name (+)
union all
select h.tablespace_name,
       round(sum(h.bytes_free + h.bytes_used) /1048576) megs_alloc,
       round(sum((h.bytes_free + h.bytes_used)- nvl(p.bytes_used, 0)) / 1048576) megs_free,
       round(sum(nvl(p.bytes_used, 0))/1048576) megs_used,
       round((sum((h.bytes_free + h.bytes_used)- nvl(p.bytes_used, 0)) / sum(h.bytes_used + h.bytes_free)) * 100) Pct_Free,
       100 - round((sum((h.bytes_free +h.bytes_used) - nvl(p.bytes_used, 0)) / sum(h.bytes_used + h.bytes_free)) *100) pct_used,
       round(sum(f.maxbytes) / 1048576) max
from   sys.v_$TEMP_SPACE_HEADER h, sys.v_$Temp_extent_pool p, dba_temp_files f
where  p.file_id(+) = h.file_id
and    p.tablespace_name(+) = h.tablespace_name
and    f.file_id = h.file_id
and    f.tablespace_name = h.tablespace_name
group by h.tablespace_name
ORDER BY 1
/
--
prompt ==================================================================================
--
CL COL
SET FEED ON

