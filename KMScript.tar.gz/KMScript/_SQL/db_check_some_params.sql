set pages 666 lines 132
--
select rpad(name,50,'.') || value Parametre from v$parameter 
where name in (
 'memory_target'
,'sga_target'
,'pga_aggregate_target'
,'open_links'
,'open_links_per_instance'
,'processes'
,'open_cursors'
)
order by name
;