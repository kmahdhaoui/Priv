create user dbaibm identified by h7l3suVb default tablespace users temporary tablespace temp ;
grant dba to dbaibm ;
