--
col FINDING_ALL_CHILDREN_FOR format a100
col CHILD_LVL_OBJID_ROWNUM format a100
--
accept ls_object_name prompt "Enter the exact object name to find info about:  " ;

select     object_type  ||  '   '  ||  owner || '.' || object_name   ||
               '    ' || object_id
          as the_object
from all_objects
where upper(object_name) like '%'||trim(upper('&ls_object_name'))||'%'
and object_type not like '%PARTITION'
and object_type not like 'INDEX'
order by object_type, owner, object_name
/

accept ls_obj_id prompt "From above, enter the exact object_id:  " ;

select  ao.object_type || '   ' ||   ao.owner || '.' || ao.object_name ||
           '   '  || ao.object_id
      as Finding_all_children_for
FROM  all_objects  ao
where    ao.object_id   =  &ls_obj_id
/

select object_name
   || '   '    ||  the_level
   || '   '    ||  object_id
   || '   '    ||  the_rownum
    as  child_lvl_objid_rownum
from
   (
   select  object_name     as object_name
   , OBJECT_ID
   , the_level
   , min (the_rownum)  as the_rownum
   from
       (  /* By Rodger Lepinsky */
       SELECT     LPAD(' ', 2*(LEVEL-1)) || '  '  ||
       ao.OBJECT_type || '  '  ||  ao.owner || '.' ||
       ao.object_name  || '   ' || ao.OBJECT_ID || '  ' || rownum
                AS THE_TREE
       , LPAD ( ' ', 2*(LEVEL-1) ) || '  '  ||
         ao.OBJECT_type || '  ' ||
         ao.owner ||  '.' ||
         ao.object_name
              as object_name
       , ao.owner ||  '.' || ao.object_name
            as object_name2
       , ao.OBJECT_type
       , ao.OBJECT_ID
       , ao.owner
       , rownum as the_rownum
       , level as the_level
       FROM               PUBLIC_DEPENDENCY   pd
       join         all_objects  ao
            on    ao.object_id   = pd.object_id
/*       where ao.owner NOT in  ( 'SYS', 'SYSTEM', 'PUBLIC' )    */
       START WITH         pd.REFERENCED_OBJECT_ID =  &ls_obj_id
       CONNECT BY PRIOR   pd.OBJECT_ID = pd.REFERENCED_OBJECT_ID
      )
   group by object_name, object_id, the_level
   )
order by the_rownum
/
--
exit
--
