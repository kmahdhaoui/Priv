select 'analyze table ecomoa.'||table_name||' list chained rows ;' 
from dba_tables 
where 
owner='ECOMOA' and
table_name in 
(
 'ECOM_CLIENT'
,'ECOM_CLIENT_PRO'
,'ECOM_MIGRATION_INFO'
,'ECOM_PAYER'
,'ECOM_MOBILE_PLAN'
,'ECOM_OPTION'
,'ECOM_FILES_TOBIRD'
,'ECOM_ORDER'
,'ECOM_HIST_MIGRATION'
,'ECOM_ARTICLE'
,'ECOM_MAAM_MEMBER'
,'ECOM_MAAM_IMPACT'
,'ECOM_MAAM_DISCOUNT'
,'ECOM_MAAM_COUNTERPART'
)
;

