-- drop PUBLIC DATABASE LINK SITR_LINK_ODI_MDMRECE ;
-- create PUBLIC DATABASE LINK SITR_LINK_ODI_MDMRECE connect to "ODI" IDENTIFIED BY "ODIUSER01" using 'MDMRECE' ;
select to_char(SQL_EXEC_START,'yyyy-mm-dd hh24') Heure,b.USERname,sql_id,count(*) Nombre from V$ACTIVE_SESSION_HISTORY a,all_users b
where SQL_EXEC_START > sysdate - 2
and sql_id like '&sql_id'
and a.user_id=b.user_id
group by to_char(SQL_EXEC_START,'yyyy-mm-dd hh24') ,b.USERname,sql_id
order by 1,4
;
