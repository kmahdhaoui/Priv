drop table t1 ;
drop table t2 ;

connect kamel/kamel as sysdba
-- connect / as sysdba

drop table t1 ;
drop table t2 ;

create table t2 (c1 number,c2 date) tablespace TS_TOOLS;

create table t1 (c1 varchar2(10),c2 date)
PARTITION BY RANGE (c2)
  (PARTITION p1 VALUES LESS THAN (TO_DATE('07-JAN-2012','DD-MON-YYYY')) tablespace TS_TOOLS,
   PARTITION p2 VALUES LESS THAN (TO_DATE('08-JAN-2012','DD-MON-YYYY')) tablespace TS_TOOLS,
   PARTITION p3 VALUES LESS THAN (TO_DATE('09-JAN-2012','DD-MON-YYYY')) tablespace TS_TOOLS,
   PARTITION p4 VALUES LESS THAN (TO_DATE('31-JAN-2012','DD-MON-YYYY')) tablespace TS_TOOLS
  )
;

-- insert into t1 values (1, sysdate - 4) ;
-- commit;

connect / as sysdba

col SEGMENT_NAME format a30
-- alter session set DEFERRED_SEGMENT_CREATION=true ;

-- select SEGMENT_NAME,PARTITION_NAME,BLOCKS from dba_extents where SEGMENT_NAME in ('T1' ,'T2');
select SEGMENT_NAME,PARTITION_NAME from dba_segments where SEGMENT_NAME in ('T1','T2') ;
select table_name,PARTITION_NAME,SEGMENT_CREATED from dba_tab_partitions where table_name in ( 'T1','T2') ;
select table_name,SEGMENT_CREATED from dba_tables where table_name in ( 'T1','T2') ;

