set pages 666 lines 132
--
select rpad(name,50,'.') || value Parametre from v$parameter 
where name in (
 'db_file_multiblock_read_count'
,'parallel_automatic_tuning'
,'optimizer_mode'
,'optimizer_index_cost_adj'
,'optimizer_index_caching'
)
order by name
;