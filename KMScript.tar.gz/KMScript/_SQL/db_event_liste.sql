--
/*
Administrative
Application
Cluster
Commit
Concurrency
Configuration
Idle
Network
Other
Queueing
Scheduler
System I/O
User I/O

Concurrency      buffer busy waits
User I/O         db file sequential read
*/
--
define DEF_V1="%"
define DEF_V2="%"
--
@@KMheaderinit
@@KMheaderdef2
--
define laclasse="&&1"
define levent="&&2"
--
--
set feedback off heading off verify off
set lines 133
--
col name format a65
col wait_class format a16
--
select distinct wait_class FROM V$EVENT_NAME
order by wait_class
;
--
SELECT wait_class, name FROM V$EVENT_NAME where 
name like '&&levent'
and
wait_class like '&&laclasse' 
ORDER BY wait_class,name 
;
--
spool off
exit
--
