--
create temporary tablespace TEMP_HQDB tempfile size 2g autoextend off ;
--
create tablespace TS_HQDB datafile size 1g autoextend on next 1g maxsize 25g ;
--
CREATE USER hypoa IDENTIFIED BY hypoa DEFAULT TABLESPACE TS_HQDB temporary tablespace TEMP_HQDB;
--
GRANT CONNECT, RESOURCE, CREATE VIEW TO hypoa;
--
SELECT GRANTED_ROLE, DEFAULT_ROLE FROM dba_role_privs WHERE grantee = 'HYPOA';
--
-- ALTER USER hypoa DEFAULT ROLE RESOURCE, CONNECT;
-- alter USER hypoa DEFAULT TABLESPACE TS_HQDB temporary tablespace TEMP_HQDB;
--

