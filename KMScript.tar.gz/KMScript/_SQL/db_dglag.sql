--
--
define DEF_V1="APP"
--
@@KMheaderinit
--
define lelag="&&1"
--
set lines 200
set pages 0
col ArchApp format a25 heading "Archived -|Applied Thread"
col SYNC_STATUS format a25
--
prompt
col "Lag Time" format a40
set pages 444
set heading on
select 
decode('&&lelag','TR','transport_lag: ','APP','apply_lag: ','apply_lag: ') || VALUE  "Lag Time" 
from v$dataguard_stats
where name like decode('&&lelag','TR','transport_lag','APP','apply_lag','apply_lag') 
;
prompt
exit