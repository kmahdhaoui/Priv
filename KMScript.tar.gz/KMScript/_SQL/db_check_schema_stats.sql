--
set heading off
set feedback off
set verify off
set lines 155
set pages 155
col pn format a22
col pv format a44
col comments format a33
col job_status format a22
col window_name format a22
col window_group format a22
col WINDOW_GROUP_NAME format a22
col NEXT_START_DATE format a44
col client_name format a33
col ddeb format a22
col dfin format a22
--
undef ownname
def ownname=&&1
--
prompt =================================> to enable auto stats <=================================
prompt exec DBMS_AUTO_TASK_ADMIN.ENABLE(client_name=>'auto optimizer stats collection',operation=>NULL,window_name=>NULL);
prompt =================================> to disable auto stats <=================================
prompt exec DBMS_AUTO_TASK_ADMIN.ENABLE(client_name=>'auto optimizer stats collection',operation=>NULL,window_name=>NULL);
prompt =================================> to exec manually <=================================
prompt exec DBMS_AUTO_TASK_IMMEDIATE.GATHER_OPTIMIZER_STATS;
prompt =================================> to set defaults <=================================
prompt exec DBMS_STATS.SET_GLOBAL_PREFS('pname','value');
prompt =================================> to set for all user-defined <=================================
prompt exec DBMS_STATS.SET_DATABASE_PREFS('pname','value');
prompt =================================> to lock stats <=================================
prompt exec DBMS_STATS.LOCK_SCHEMA_STATS('ownname');
prompt exec DBMS_STATS.LOCK_TABLE_STATS ('ownname','tabname');
--
prompt
prompt =================================> BASIC : auto stat are disabled <=================================
show parameter STATISTICS_LEVEL
--
prompt
prompt =================================> currently running auto stats jobs <=================================
select client_name, JOB_SCHEDULER_STATUS from DBA_AUTOTASK_CLIENT_JOB where client_name='auto optimizer stats collection';
--
prompt
prompt =================================> are stats job to run next windows <=================================
select window_group_name,window_name from DBA_SCHEDULER_WINGROUP_MEMBERS where window_group_name = 'ORA$AT_WGRP_OS';
SELECT CLIENT_NAME, STATUS,window_group FROM   DBA_AUTOTASK_CLIENT WHERE  CLIENT_NAME = 'auto optimizer stats collection';
select * from DBA_SCHEDULER_WINDOW_GROUPS where window_group_name = 'ORA$AT_WGRP_OS';
--
prompt
prompt =================================> history auto stats job <=================================
SELECT client_name, window_name,
to_char(WINDOW_START_TIME,'yyyy-mm-dd hh24:mi:ss') ddeb,
to_char(WINDOW_END_TIME,'yyyy-mm-dd hh24:mi:ss') dfin,
' CRE='||jobs_created||' BEG='|| jobs_started||' END='||jobs_completed Job_Status
FROM dba_autotask_client_history WHERE client_name like '%stats%' order by client_name,WINDOW_START_TIME;
--
prompt
prompt =================================> to check parameters <=================================
select pn,DBMS_STATS.GET_PARAM (pn) pv from
(select 'AUTOSTATS_TARGET' pn from dual
union all select 'CASCADE' pn from dual
union all select 'DEGREE' pn from dual
union all select 'ESTIMATE_PERCENT' pn from dual
union all select 'METHOD_OPT' pn from dual
union all select 'NO_INVALIDATE' pn from dual
union all select 'GRANULARITY' pn from dual
union all select 'PUBLISH' pn from dual
union all select 'INCREMENTAL' pn from dual
union all select 'STALE_PERCENT' pn from dual);
--
prompt
prompt =================================> prefs : &&ownname <=================================
select pn,DBMS_STATS.GET_PREFS (pn,'&&ownname') pv from
(select 'AUTOSTATS_TARGET' pn from dual
union all select 'CASCADE' pn from dual
union all select 'DEGREE' pn from dual
union all select 'ESTIMATE_PERCENT' pn from dual
union all select 'METHOD_OPT' pn from dual
union all select 'NO_INVALIDATE' pn from dual
union all select 'GRANULARITY' pn from dual
union all select 'PUBLISH' pn from dual
union all select 'INCREMENTAL' pn from dual
union all select 'STALE_PERCENT' pn from dual);
--
GRANULARITY            ALL
STALE_PERCENT          5
--
/* 
exec DBMS_STATS.SET_DATABASE_PREFS('DEGREE','8');
exec DBMS_STATS.SET_GLOBAL_PREFS('DEGREE','8');
exec DBMS_STATS.SET_DATABASE_PREFS('ESTIMATE_PERCENT','1');
exec DBMS_STATS.SET_GLOBAL_PREFS('ESTIMATE_PERCENT','1');
exec DBMS_STATS.SET_DATABASE_PREFS('GRANULARITY','ALL');
exec DBMS_STATS.SET_GLOBAL_PREFS('GRANULARITY','ALL');
exec DBMS_STATS.SET_DATABASE_PREFS('STALE_PERCENT','5');
exec DBMS_STATS.SET_GLOBAL_PREFS('STALE_PERCENT','5');
*/
--
--
