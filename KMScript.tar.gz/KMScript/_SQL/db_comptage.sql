--
set verify off
define latable=&&2
define leowner=&&1
col OWNER format a22
col OBJECT_TYPE format a20
col OBJECT_NAME format a35
col STATUS format a15
set pages 0
set lines 132
set feedback off
--
-- exec DBMS_STATS.GATHER_TABLE_STATS ('SYS', 'X\$KTFBUE',degree=>13) ;
--
prompt "... Tables "
select count(*) NBR from dba_tables ii where 
table_name like '&&latable' and owner like '&&leowner'
;
--
prompt "... Indexes "
select count(*) NBR from dba_indexes ii where 
table_name like '&&latable' and owner like '&&leowner'
;
--
prompt "... Vues "
select count(*) NBR from dba_views ii where 
view_name like '&&latable' and owner like '&&leowner'
;
--
prompt "... Synonyms "
select count(*) NBR from dba_synonyms ii where 
table_name like '&&latable' and owner like '&&leowner'
;
--
set pages 5555
prompt "... Objects "
select OBJECT_TYPE,count(*) NBR from dba_objects ii where 
OBJECT_NAME like '&&latable' and owner like '&&leowner'
group by OBJECT_TYPE
order by 1
;


--
exit

