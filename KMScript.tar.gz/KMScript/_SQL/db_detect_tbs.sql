--
--
define DEF_V1="80"
define DEF_V2="1"
--
@@KMheaderinit
@@KMheaderdef2
--
define seuil="&&1"
define nbjours="&&2"
--
define m_seuil = '&&seuil'
define m_jours = '&&nbjours'
--
--
set lines 132
col "Mo Alloues" format 999,999,999
col "Mo Occupes" format 999,999,999
col "Mo Libres" format 999,999,999
col "Max Extensible" format 999,999,999 heading 'Total Mo|Extension'
col "Mo Allouable" format 999,999,999
col "Pct Occ/T" format a10
--
Prompt =========================================== Seuil : &&m_seuil =========================================
--
set heading on
set feedback on
--
select aa.TABLESPACE_NAME "Tbsname",
round(aa.Allocated) "Mo Alloues",
round(nvl(aa.allocated,0)-nvl(bb.libre,0)) "Mo Occupes",
round(nvl(bb.libre,0)) "Mo Libres",
round(nvl(aa.allocable,0)-nvl(aa.allocated,0)) "Max Extensible",
round(aa.Allocable) "Mo Allouable",
'    '||to_char(round(100*(nvl(aa.allocated,0)-nvl(bb.libre,0))/(aa.Allocable+1))) "Pct Occ/T" from
(
SELECT a.TABLESPACE_NAME,
sum(decode(AUTOEXTENSIBLE,'YES',nvl(bytes,0)+least(nvl(MAXBYTES,0)-nvl(bytes,0),b.free_b/1),nvl(BYTES,0))/1024/1024) Allocable,
sum(nvl(BYTES,0))/1024/1024 Allocated
FROM DBA_DATA_FILES a ,
(SELECT dg.name,sum(dg.free_mb)*1024*1024/count(distinct c.file_name) free_b FROM v$asm_diskgroup dg ,DBA_DATA_FILES c
where c.file_name like '+'||dg.name||'/%'
group by dg.NAME
) b
where a.file_name like '+'||b.name||'/%'
and a.TABLESPACE_NAME like '%'
and a.TABLESPACE_NAME not like '%SYS%'
group by a.TABLESPACE_NAME
) aa ,
(
select  TABLESPACE_NAME,
sum(nvl(BYTES,0)/1024/1024) libre
from    dba_free_space
where   TABLESPACE_NAME like '%'  and TABLESPACE_NAME not like '%SYS%'
group   by TABLESPACE_NAME
) bb
where aa.TABLESPACE_NAME=bb.TABLESPACE_NAME (+)
and aa.TABLESPACE_NAME like '%'
and aa.TABLESPACE_NAME not like '%SYS%'
and round(100*(nvl(aa.allocated,0)-nvl(bb.libre,0))/(aa.Allocable+1)) > &&m_seuil
/
