--
set heading ON
set feedback off
set verify off
set lines 155
set pages 155
col pn format a22
col pv format a44
col comments format a33
col job_status format a22
col window_name format a22
col window_group format a22
col WINDOW_GROUP_NAME format a22
col NEXT_START_DATE format a44
col client_name format a33
col ddeb format a22
col dfin format a22
--
col operation form a60 
col CPU_USED format a18
col ACTUAL_START_DATE format a43
col JOB_NAME format a30
col log_date format a20
col RUN_DURATION format a20
col SESSION_ID format a18
--
--
prompt
prompt =================================> detail auto stats runs <=================================
select operation||decode(target,null,null,'-'||target) operation
      ,to_char(start_time,'yyyy-mm-dd hh24:mi:ss') ddeb
      ,to_char(  end_time,'yyyy-mm-dd hh24:mi:ss') dfin
from dba_optstat_operations
where start_time > sysdate - 3
and operation like '%gather%' 
and operation like '%%'
order by start_time, 1
/
--
prompt
--
set pages 155
set lines  200
prompt
prompt =================================> history job run details <=================================
select 
to_char(log_date,'yyyy-mm-dd hh24:mi:ss') log_date,
job_name,
to_char(actual_start_date,'yyyy-mm-dd hh24:mi:ss') ddeb
,run_duration,session_id,cpu_used 
from SYS.DBA_SCHEDULER_JOB_RUN_DETAILS where job_name 
in (
select job_name from DBA_AUTOTASK_JOB_HISTORY where 
client_name like '%stats%' 
-- and job_status = 'STOPPED' 
-- and job_duration > INTERVAL '3:50' HOUR TO MINUTE
) 
and log_date > sysdate -14 
order by log_date ;
--
prompt
--
--
--
