SET lines 200 
COL owner_name FORMAT a10; 
COL job_name FORMAT a25
COL state FORMAT a12
COL operation LIKE state 
COL job_mode LIKE state 
COL owner.object for a50

-- il y a les tables ET$... aussi
-- JOBS
prompt "-- JOBS "
SELECT owner_name, job_name, rtrim(operation) "OPERATION",
       rtrim(job_mode) "JOB_MODE", state, attached_sessions
  FROM dba_datapump_jobs
 WHERE job_name NOT LIKE 'BIN$%'
 ORDER BY 1,2
/

-- Master Tables
prompt "-- MASTER TABLES" 
SELECT o.status, o.object_id, o.object_type, 
       o.owner||'.'||object_name "OWNER.OBJECT" 
  FROM dba_objects o, dba_datapump_jobs j 
 WHERE o.owner=j.owner_name AND o.object_name=j.job_name 
   AND j.job_name NOT LIKE 'BIN$%' ORDER BY 4,2; 

prompt "-----------------------------------------------------------------------"
set feedback off heading off 
col CDESQL format a100
-- drop
prompt  "-- DROP MASTER TABLES" 
SELECT 'drop '||o.object_type||' '||o.owner||'.'||object_name||';' CdeSql
  FROM dba_objects o, dba_datapump_jobs j
 WHERE j.state in ( 'NOT RUNNING' , 'UNDEFINED' ) AND
   o.owner=j.owner_name AND o.object_name=j.job_name
   AND j.job_name NOT LIKE 'BIN$%' ORDER BY 1;

-- purge
prompt  "-- PURGE RECYCLEBIN "
prompt  'purge dba_recyclebin;'

set feedback on heading on 
--
prompt "-----------------------------------------------------------------------"
set feedback off heading off
col CDESQL format a100
prompt "-- STOP UNDEFINED JOBS "
SELECT
'SET serveroutput on '||chr(10)||
'SET lines 100 '||chr(10)||
'DECLARE '||chr(10)||
'   h1 NUMBER; '||chr(10)||
'BEGIN '||chr(10)||
'   h1 := DBMS_DATAPUMP.ATTACH('''||job_name||''','''||owner_name||'''); '||chr(10)||
'   DBMS_DATAPUMP.STOP_JOB (h1); '||chr(10)||
'END; '||chr(10)||
'/' CdeSql
FROM dba_datapump_jobs
WHERE job_name NOT LIKE 'BIN$%' and state='UNDEFINED'
ORDER BY 1
/
prompt "-----------------------------------------------------------------------"
set feedback off heading off
col CDESQL format a100
prompt "-- STOP ALL JOBS !!!!!!! "
SELECT
'SET serveroutput on '||chr(10)||
'SET lines 100 '||chr(10)||
'DECLARE '||chr(10)||
'   h1 NUMBER; '||chr(10)||
'BEGIN '||chr(10)||
'   h1 := DBMS_DATAPUMP.ATTACH('''||job_name||''','''||owner_name||'''); '||chr(10)||
'   DBMS_DATAPUMP.STOP_JOB (h1); '||chr(10)||
'END; '||chr(10)||
'/' CdeSql
FROM dba_datapump_jobs
WHERE job_name NOT LIKE 'BIN$%' and state != 'UNDEFINED'
ORDER BY 1
/
--
exit