--
set lines 132
set pages 132
col Message format a130
--
update tmp_db_new_alert_tmp_1 set Top='Y' where top='N' ;
set termout off
commit;
set termout on
--
