--
set verify off
define leowner=&&1
define latable=&&2
define letbs=%&&3
col OWNER format a22
col OBJECT_TYPE format a15
col OBJECT_NAME format a35
col STATUS format a15
set pages 5555
set lines 132
--
-- exec DBMS_STATS.GATHER_TABLE_STATS ('SYS', 'X\$KTFBUE',degree=>13) ;
--
prompt "... Dont Indexes "
select '-- '||table_name||chr(10)||
'alter index '||owner||'.'||index_name||' rebuild parallel 8 online;' 
||chr(10)|| 'alter index '||owner||'.'||index_name||' parallel 1;'
from dba_indexes ii
where table_name like '&&latable' and owner like '&&leowner'
and status not IN ('X','N/A')
and ii.tablespace_name like '&&letbs'
and ii.index_type not like '%LOB%'
and ii.index_type not like '%IOT%'
and not exists 
(select 'x' from dba_part_indexes pi where pi.index_name=ii.index_name and pi.owner=ii.owner)
;
--
prompt "... Dont Indexes Part "
SELECT '-- '||index_name||chr(10)||
'alter index '||index_owner||'.'||index_name||' rebuild partition '||partition_name||' parallel 8 online;'  
FROM dba_ind_partitions 
WHERE 
status != 'X USABLE'
 and tablespace_name like '&&letbs'
AND
(
status != 'N/A' OR index_name IN ( SELECT index_name FROM all_ind_subpartitions WHERE status != 'X USABLE')
) 
and index_name in 
(select index_name from dba_part_indexes where table_name like '&&latable' and owner like '&&leowner' 
and nvl(DEF_SUBPARTITION_COUNT,0) = 0)
and index_owner like '&&leowner'
and index_name not like 'BIN$%'
and index_name not like 'SYS%$'
order by PARTITION_POSITION
;
--
prompt "... Dont Indexes ssPartitions "
--
SELECT '-- '||index_name||' '||partition_name ||chr(10)||
'alter index '||index_owner||'.'||index_name||' rebuild subpartition '||subpartition_name||' parallel 8 online;'
FROM dba_ind_subpartitions WHERE 
status != 'X USABLE'
 and tablespace_name like '&&letbs'
and index_name in 
(select index_name from dba_part_indexes where table_name like '&&latable' and owner like '&&leowner' 
and nvl(DEF_SUBPARTITION_COUNT,0) > 0)
and index_owner like '&&leowner'
and index_name not like 'BIN$%'
and index_name not like 'SYS%$'
and (
partition_name not like 'PHV_205%' and 
partition_name not like 'PHV_204%' and 
partition_name not like 'PHV_203%' and 
partition_name not like 'PHV_202%' and 
partition_name not like 'PHV_2017%' and 
partition_name not like 'PHV_2016%' and 
partition_name not like 'PHV_2015%' and 
partition_name not like 'PHV_2014%'
)
order by PARTITION_NAME,SUBPARTITION_POSITION
;
--
exit

