--
set feedback off
alter session set nls_timestamp_tz_format='yyyy-mm-dd HH24:MI:SS';
set feedback on
--
col CLIENT_NAME  format a33
col LAST_GOOD_DATE format a23
col NEXT_TRY_DATE format a23
--
col WINDOW_NAME format a23
col SCHEDULE_NAME format a28
col START_DATE format a23
col REPEAT_INTERVAL format a40
--
col TYPE format a15
col resource_consumer_group form a22 heading "Consumer Group"
col name form a22 heading "Name"
col plan form a27 heading "Plan Name"
col Sub-Plan format a27
col group_or_subplan form a27 heading "Sub-Plan"
col status form a8 heading "Status"
col cpu_p1 form 999 heading "CPU1"
col cpu_p2 form 999 heading "CPU2"
col cpu_p3 form 999 heading "CPU3"
col cpu_p4 form 999 heading "CPU4"

col WINDOW_NAME format a20
col NEXT_START_DATE format a35
col LAST_START_DATE  format a35
col RESOURCE_PLAN format a27
--
select RESOURCE_PLAN,WINDOW_NAME,NEXT_START_DATE,LAST_START_DATE from DBA_SCHEDULER_WINDOWS 
;
--
select plan, group_or_subplan, type, cpu_p1, cpu_p2, cpu_p3, cpu_p4, status
from dba_rsrc_plan_directives
order by 8,1,2,3,4,5,6;
--
-- select CLIENT_NAME,STATUS from DBA_AUTOTASK_OPERATION ;
SELECT client_name ,status ,consumer_group FROM dba_autotask_client ORDER BY client_name
;
--
select CLIENT_NAME,STATUS,LAST_GOOD_DATE,NEXT_TRY_DATE from DBA_AUTOTASK_TASK ;
--
------------> disable/enable all/taska for all mainetance window
-- EXEC DBMS_AUTO_TASK_ADMIN.disable;
-- DBMS_AUTO_TASK_ADMIN.disable(client_name=>'sql tuning advisor',operation =>NULL,window_name=>NULL);
-- DBMS_AUTO_TASK_ADMIN.disable(client_name=>'auto optimizer stats collection',operation=>NULL,window_name=>NULL);
exec DBMS_AUTO_TASK_ADMIN.enable(client_name=>'auto optimizer stats collection',operation=>NULL,window_name=>NULL);
--
------------> modifier pour un window
-- DBMS_AUTO_TASK_ADMIN.disable(client_name=>'auto space advisor',operation=>NULL,window_name=>'MONDAY_WINDOW');
-- DBMS_AUTO_TASK_ADMIN.disable(client_name=>'sql tuning advisor',operation=>NULL,window_name=>'MONDAY_WINDOW');
--
------------> cahnge settings stats
-- EXEC DBMS_STATS.alter_stats_history_retention(10);
-- EXEC DBMS_STATS.set_global_prefs('estimate_percent', '5');
-- 
------------> disable all window group
-- exec DBMS_SCHEDULER.disable( name  => 'SYS.MAINTENANCE_WINDOW_GROUP', force => TRUE);
--
------------> modifier un window (dans le window group)
-- DBMS_SCHEDULER.disable(name => 'SYS.MONDAY_WINDOW', force => TRUE);
-- DBMS_SCHEDULER.set_attribute(name=>'SYS.MONDAY_WINDOW',attribute=>'DURATION',value=>numtodsinterval(180,'minute'));
-- DBMS_SCHEDULER.enable(name=>'SYS.MONDAY_WINDOW');
--
------------> modifier le resource plan
-- DBMS_SCHEDULER.disable(name=>'SYS.MONDAY_WINDOW',force=>TRUE);
-- DBMS_SCHEDULER.set_attribute(name=>'SYS.MONDAY_WINDOW',attribute=>'RESOURCE_PLAN',value=>'MY_NEW_PLAN');
-- DBMS_SCHEDULER.enable(name=>'SYS.MONDAY_WINDOW');
--
