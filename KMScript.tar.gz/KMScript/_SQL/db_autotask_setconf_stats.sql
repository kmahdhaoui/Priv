--
set heading on
set feedback off
set verify off
set lines 155
set pages 155
col pn format a22
col pv format a44
col comments format a33
col job_status format a22
col window_name format a22
col window_group format a22
col WINDOW_GROUP_NAME format a22
col NEXT_START_DATE format a44
col client_name format a33
col ddeb format a22
col dfin format a22
col JOB_DURATION format a30
col LAST_GOOD_DATE format a35
col NEXT_TRY_DATE format a35
--
-- enable optimzer job, disable others
EXEC DBMS_AUTO_TASK_ADMIN.enable;
exec DBMS_AUTO_TASK_ADMIN.enable(client_name=>'auto optimizer stats collection',operation=>NULL,window_name=>NULL);
--
exec DBMS_AUTO_TASK_ADMIN.disable(client_name=>'sql tuning advisor',operation =>NULL,window_name=>NULL);
exec DBMS_AUTO_TASK_ADMIN.disable(client_name=>'auto space advisor' ,operation =>NULL,window_name=>NULL);
--
exec DBMS_STATS.SET_GLOBAL_PREFS('ESTIMATE_PERCENT','1');
exec DBMS_STATS.SET_DATABASE_PREFS('ESTIMATE_PERCENT','1');
--
exec DBMS_AUTO_TASK_ADMIN.disable(client_name=>'sql tuning advisor' ,operation=>NULL,window_name=>NULL);
exec DBMS_AUTO_TASK_ADMIN.disable(client_name=>'auto space advisor' ,operation=>NULL,window_name=>NULL);
--
exec dbms_stats.set_global_prefs('PREFERENCE_OVERRIDES_PARAMETER','TRUE');
--
-
set serveroutput on
declare
v_stats_group_pct number;
v_seq_group_pct number;
v_tune_group_pct number;
v_health_group_pct number;
begin
dbms_auto_task_admin.get_p1_resources(v_stats_group_pct,v_seq_group_pct,v_tune_group_pct,v_health_group_pct);
dbms_output.put_line(a =>
   'Gather Statistics % : '||v_stats_group_pct||chr(10)||
   'Space Management  % : '||v_seq_group_pct||chr(10)||
   'SQL Tuning        % : '||v_tune_group_pct||chr(10)||
   'Health Checks     % : '||v_health_group_pct);
end;
/
-- select CLIENT_NAME,STATUS from DBA_AUTOTASK_OPERATION ;
SELECT client_name ,status ,consumer_group FROM dba_autotask_client ORDER BY client_name
;
--
select CLIENT_NAME,STATUS,LAST_GOOD_DATE,NEXT_TRY_DATE from DBA_AUTOTASK_TASK ;
--
prompt
prompt =================================> prefs : database <=================================
select pn,DBMS_STATS.GET_PREFS (pn) pv from
(select 'AUTOSTATS_TARGET' pn from dual
union all select 'CASCADE' pn from dual
union all select 'DEGREE' pn from dual
union all select 'ESTIMATE_PERCENT' pn from dual
union all select 'METHOD_OPT' pn from dual
union all select 'NO_INVALIDATE' pn from dual
union all select 'GRANULARITY' pn from dual
union all select 'PUBLISH' pn from dual
union all select 'INCREMENTAL' pn from dual
union all select 'STALE_PERCENT' pn from dual);
--
prompt
prompt =================================> Duration Windows <=================================
--
----------------------------------------
-- Samedi : 40h et pas de dimanche
BEGIN
dbms_scheduler.disable(name  => 'SYS.SATURDAY_WINDOW');
dbms_scheduler.disable(name  => 'SYS.SUNDAY_WINDOW');

-- to_dsInterval('+000 40:00:00')
dbms_scheduler.set_attribute(
    name      => 'SYS.SATURDAY_WINDOW',
    attribute => 'DURATION',
    value     => numtodsinterval(40, 'hour'));

dbms_scheduler.enable(name => 'SYS.SATURDAY_WINDOW');
END;
/
-----------------------------------------
-- lun : 6h
BEGIN
dbms_scheduler.disable(name  => 'SYS.MONDAY_WINDOW');
dbms_scheduler.set_attribute(name => 'SYS.MONDAY_WINDOW',attribute => 'DURATION',value => numtodsinterval(6, 'hour'));
dbms_scheduler.enable(name => 'SYS.MONDAY_WINDOW');
END;
/
--
-- mar : 6h
BEGIN
dbms_scheduler.disable(name  => 'SYS.TUESDAY_WINDOW');
dbms_scheduler.set_attribute(name => 'SYS.TUESDAY_WINDOW',attribute => 'DURATION',value => numtodsinterval(6, 'hour'));
dbms_scheduler.enable(name => 'SYS.TUESDAY_WINDOW');
END;
/
--
-- merc : 6h
BEGIN
dbms_scheduler.disable(name  => 'SYS.WEDNESDAY_WINDOW');
dbms_scheduler.set_attribute(name => 'SYS.WEDNESDAY_WINDOW',attribute => 'DURATION',value => numtodsinterval(6, 'hour'));
dbms_scheduler.enable(name => 'SYS.WEDNESDAY_WINDOW');
END;
/
--
-- jeu : 6h
BEGIN
dbms_scheduler.disable(name  => 'SYS.THURSDAY_WINDOW');
dbms_scheduler.set_attribute(name => 'SYS.THURSDAY_WINDOW',attribute => 'DURATION',value => numtodsinterval(6, 'hour'));
dbms_scheduler.enable(name => 'SYS.THURSDAY_WINDOW');
END;
/
--
-- ven : 6h
BEGIN
dbms_scheduler.disable(name  => 'SYS.FRIDAY_WINDOW');
dbms_scheduler.set_attribute(name => 'SYS.FRIDAY_WINDOW',attribute => 'DURATION',value => numtodsinterval(6, 'hour'));
dbms_scheduler.enable(name => 'SYS.FRIDAY_WINDOW');
END;
/
--
--
--
--
--
--
