--
col owner format a20
col OBJECT_NAME format a30
--
prompt ********************************** TABLES ****************************************
--
select OWNER,OBJECT_NAME from DBA_OBJECTS where ORACLE_MAINTAINED='Y'
and owner not like 'SYS%' and object_type like'TAB%'
and owner not like 'APEX%'
and owner not like 'ORDDATA%'
and owner not like '%SYS'
and owner not like 'GSMADMIN%'
and owner not like 'DBSNMP%'
and owner not like 'APPQOSSYS%'
and owner not like 'DVSYS%'
and owner not like 'XDB%'
and owner not like 'OUTLN%'
and owner not like 'FLOWS_FILES%'
order by 1,2
;
--
select username from dba_users where ORACLE_MAINTAINED='Y'
and username not like 'SYS%' 
and username not like 'APEX%'
and username not like 'ORDDATA%'
and username not like '%SYS'
and username not like 'GSMADMIN%'
and username not like 'DBSNMP%'
and username not like 'APPQOSSYS%'
and username not like 'DVSYS%'
and username not like 'XDB%'
and username not like 'OUTLN%'
and username not like 'FLOWS_FILES%'
order by 1;
-- 
