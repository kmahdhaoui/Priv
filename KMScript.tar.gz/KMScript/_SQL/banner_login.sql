
prompt
prompt ================================================================================================
prompt =                                 &&1    
prompt ================================================================================================
show user
set feedback off heading off
col HOST_NAME format a30
col ddate format a25 
select to_char(sysdate,'yyyy-mon-dd hh24:mi:ss') ddate, INSTANCE_NAME,HOST_NAME,VERSION from v$instance ;
set feedback on heading on
prompt ================================================================================================
undefine 1
