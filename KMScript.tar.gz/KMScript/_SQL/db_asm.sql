set pagesize 500
set feedback off heading off
alter session set nls_date_format = 'DD/MM/YYYY HH24:MI:SS';
-- select to_char(sysdate) heure from dual;
set feedback off heading on

SET LINESIZE  145
SET PAGESIZE  9999
SET VERIFY    off

col name format a15
col PATH format a15
COLUMN group_name             FORMAT a20           HEAD 'Disk Group|Name'
COLUMN type                   FORMAT a6            HEAD 'Type'
COLUMN total_mb               FORMAT 999,999,999   HEAD 'Total Size (MB)'
COLUMN free_mb                FORMAT 999,999,999   HEAD 'Free Size (MB)'
COLUMN used_mb                FORMAT 999,999,999   HEAD 'Used Size (MB)'
COLUMN total_gb               FORMAT 999999   HEAD 'Total Size (GB)'
COLUMN free_gb                FORMAT 999999   HEAD 'Free Size (GB)'
COLUMN used_gb                FORMAT 999999   HEAD 'Used Size (GB)'
COLUMN pct_used               FORMAT 999.99        HEAD 'Pct. Used'

-- break on report on disk_group_name skip 1
-- compute sum label "Grand Total: " of total_mb used_mb on report

SELECT
    name                                     group_name
  , type                                     type
  , total_mb/1024                                 total_gb
  , free_mb/1024                                  free_gb
  , (total_mb - free_mb)/1024                used_gb
  , ROUND((1- (free_mb / total_mb))*100, 2)  pct_used
FROM
    v$asm_diskgroup
ORDER BY
    name
;
--
-- where GROUP_NUMBER = 1
-- select GROUP_NUMBER, substr(name,1,10) name,substr(path,1,20) path, REDUNDANCY, TOTAL_MB, free_mb 
-- from V$ASM_DISK 
-- ;
--
-- XXXXX DISKGROUP data RESIZE DISK DATA size 300G;
--
--
prompt ============================================================
prompt sofar asm_operation
-- 
select sofar, est_rate, est_minutes from v$asm_operation;
prompt ============================================================
--
exit