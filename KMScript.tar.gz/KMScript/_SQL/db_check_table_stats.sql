--
--
define DEF_V1="%"
define DEF_V2="%"
--
@@KMheaderinit
@@KMheaderdef2
--
set verify off
set heading on
set feedback off
col LAST_ANALYZED format a30
col owner format a25
col stale_stats format a8
col min_LAST_ANALYZED format a30
col max_LAST_ANALYZED format a30

define LeOwner="&&1"
define LaTable="&&1"
--
set pages 88
--
set heading on
set feedback off
set verify off
set lines 155
set pages 155
col pn format a22
col pv format a44
col comments format a33
col job_status format a22
col window_name format a22
col window_group format a22
col WINDOW_GROUP_NAME format a22
col NEXT_START_DATE format a44
col client_name format a33
col ddeb format a22
col dfin format a22
col table_name format a54
col last_analyzed format a22
col owner format a25
--
undef ownname
def ownname=&&1
undef tabname
def tabname=&&2
--
prompt "Last Analyzed ancien ..."
-- 
select owner,table_name||'.'||partition_name||'.'||SUBPARTITION_NAME table_name,OBJECT_TYPE,NUM_ROWS,
to_char(LAST_ANALYZED,'yyyy-mm-dd hh24') LAST_ANALYZED
from dba_tab_statistics where 
owner like '&&LeOwner' and 
-- table_name like '&&LaTable' and 
SUBPARTITION_NAME is null and
table_name not like '%TMP' and 
table_name not like 'TMP%' and 
owner not in ('SPOTLIGHT','SYS','SYSTEM','SYSMAN','APEX_030200','APPQOSSYS','DBSNMP',
'EXFSYS','FLOWS_FILES','KAMEL','MDSYS','NAGIOS','ORDDATA','ORDSYS','TOAD','WMSYS','XDB','OUTLN')
and nvl(LAST_ANALYZED,sysdate-365) < sysdate - 4
and nvl(LAST_ANALYZED,sysdate-12) > sysdate - 13
order by 1,2,5
;
--
--
--
--
