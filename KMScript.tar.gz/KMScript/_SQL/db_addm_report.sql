@?/rdbms/admin/addmrpt.sql
