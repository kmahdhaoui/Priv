set pages 50
    set lines 100
    column c1 heading 'Event|Name'             format a30
    column c2 heading 'Total|Waits'            format 9,999,999,999
    column c3 heading 'Seconds_Wait'        format 999,999,999
    column c4 heading 'Total|Timeouts'         format 999,999,999
    column c5 heading 'Average|Wait|(in secs)' format 99.999

	select
       event                         c1,
      total_waits                   c2,
      time_waited / 1000             c3,
      total_timeouts                c4,
      average_wait    /1000          c5
   from
      sys.v_$system_event
   where
      upper(event) like '%LOG%SWITCH%'
  order by c3 desc
  ;
  
-- select to_char(first_time,'MM-DD-RRRR HH24:MI:SS') "log_swaps_today" from v$loghist where first_time > sysdate-1;


exit