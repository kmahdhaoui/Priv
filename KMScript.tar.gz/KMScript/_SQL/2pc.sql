--
set pages 555 set lines 155
col state format a16
col LOCAL_TRAN_ID format a18
col TRAN_COMMENT format a12
col OS_USER format a18
col OS_TERMINAL format a15
col "HOST" format a18
--
alter session set nls_date_format='dd:hh24miss' ;
--
/*
STATE Column	State of Global Transaction	State of Local Transaction	Normal Action	Alternative Action
Collecting		Rolled back	Rolled back	None	PURGE_LOST_DB_ENTRY (only if autorecovery cannot resolve transaction)
Committed		Committed	Committed	None	PURGE_LOST_DB_ENTRY (only if autorecovery cannot resolve transaction)
Prepared		Unknown		Prepared	None	Force commit or rollback
Forced commit	Unknown		Committed	None	PURGE_LOST_DB_ENTRY (only if autorecovery cannot resolve transaction)
Forced rollback	Unknown		Rolled back	None	PURGE_LOST_DB_ENTRY (only if autorecovery cannot resolve transaction)
Forced commit	Mixed		Committed			Manually remove inconsistencies then use PURGE_MIXED	-
Forced rollback	Mixed		Rolled back			Manually remove inconsistencies then use PURGE_MIXED	
*/
--
select LOCAL_TRAN_ID,STATE , FAIL_TIME, FORCE_TIME, RETRY_TIME, OS_TERMINAL,HOST,COMMIT#
from dba_2pc_pending ;
--
-- spool 2pc_1
select 'rollback force '''||LOCAL_TRAN_ID||''';' "Force" from dba_2pc_pending ;
-- spool off
--
-- spool 2pc_2
select 'exec DBMS_TRANSACTION.PURGE_LOST_DB_ENTRY('''||LOCAL_TRAN_ID||''');' "Purge" from dba_2pc_pending ;
-- spool off
--
