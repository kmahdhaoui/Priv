set pages 999
set lines 92
drop table adv_keep_temp_t1;
create table adv_keep_temp_t1 as
select
   o.owner          owner,
   o.object_name    object_name,
   o.subobject_name subobject_name,
   o.object_type    object_type,
   count(distinct file# || block#)         num_blocks
from dba_objects  o, v$bh         bh
where
   o.data_object_id  = bh.objd and
   o.owner not in ('SYS','SYSTEM') and
   bh.status != 'free'
group by
   o.owner, o.object_name, o.subobject_name, o.object_type
order by count(distinct file# || block#) desc
;

select
   'alter '||s.segment_type||' '||adv_keep_temp_t1.owner||'.'||s.segment_name||' storage (buffer_pool keep);'
from adv_keep_temp_t1, dba_segments s
where
   s.segment_name = adv_keep_temp_t1.object_name and
   s.owner = adv_keep_temp_t1.owner and
   s.segment_type = adv_keep_temp_t1.object_type and
   nvl(s.partition_name,'-') = nvl(adv_keep_temp_t1.subobject_name,'-') and
   buffer_pool <> 'KEEP' and
   object_type in ('TABLE','INDEX') group by
   s.segment_type, adv_keep_temp_t1.owner,
   s.segment_name
having (sum(num_blocks)/greatest(sum(blocks), .001))*100 > 66
order by 1
;
SELECT SIZE_FOR_ESTIMATE, BUFFERS_FOR_ESTIMATE, ESTD_PHYSICAL_READ_FACTOR, ESTD_PHYSICAL_READS
  FROM V$DB_CACHE_ADVICE
    WHERE NAME          = 'KEEP'
     AND BLOCK_SIZE    = (SELECT VALUE FROM V$PARAMETER WHERE NAME = 'db_block_size')
     AND ADVICE_STATUS = 'ON';

SELECT NAME, PHYSICAL_READS, DB_BLOCK_GETS, CONSISTENT_GETS,
      1 - (PHYSICAL_READS / (DB_BLOCK_GETS + CONSISTENT_GETS)) "Hit Ratio"
  FROM V$BUFFER_POOL_STATISTICS;

----------------------------------------------
/*
set lines 80;
set pages 999;
column avg_touches           format 999
column myname heading 'Name' format a30
column mytype heading 'Type' format a10
column buffers               format 999,999
drop table adv_keep_temp_t2 ;
create table adv_keep_temp_t2 tablespace msrmt_hist_tbl parallel as  
SELECT    object_type mytype,   object_name myname,   blocks
FROM    dba_objects b,   dba_segments s
WHERE    b.object_name = s.segment_name and s.owner=b.owner and   b.owner ='CISADM' and s.owner='CISADM'
; 

SELECT    object_type mytype,   object_name myname,   blocks,   COUNT(1) buffers,   AVG(tch) avg_touches
FROM    sys.x$bh a,   adv_keep_temp_t2 c
WHERE    a.obj = c.data_object_id and    c.owner = 'CISADM'
GROUP BY    object_name,   object_type,   blocks,   obj
HAVING    AVG(tch) > 5
AND    COUNT(1) > 20
; 
*/
----------------------------------------------
