SELECT tablespace_name, extent_management, segment_space_management
FROM dba_tablespaces where tablespace_name like '%&tbs%';


