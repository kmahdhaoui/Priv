--
set verify off
define OWN=&&1
define TAB=&&2
set lines 150
set pages 55
col num format 99999
col nullok format a7
col buckets format 999999
col histogram format a20
--
-- exec dbms_stats.gather_database_stats_job_proc;
SELECT rownum num,column_name,type,len,precision,scale,histogram,buckets, nullok
         FROM (
               SELECT c.owner, c.table_name, c.column_name,
                      c.data_type as type,
                      c.data_length as len,
                      c.data_precision as precision,
                      c.data_scale as scale,
                      c.histogram,
                      h.buckets,
                      c.nullable as nullok
               FROM dba_tab_columns c,
                    (SELECT owner,table_name,column_name, count(*) as buckets
                     FROM dba_histograms
                     WHERE owner like '&&OWN' and
                           table_name like '&&TAB'
                     GROUP BY owner,table_name,column_name ) h
               WHERE c.owner like '&&OWN' and
                     c.table_name like '&&TAB' and
                     c.table_name = h.table_name(+) and
                     c.column_name = h.column_name(+) and
                     c.owner = h.owner(+)
               ORDER BY c.column_id)
;
--
