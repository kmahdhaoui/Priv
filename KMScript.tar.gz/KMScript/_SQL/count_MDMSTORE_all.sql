select count(*) from MDMSTORE1.MDMEMET1WLSTORE;
select count(*) from MDMSTORE2.MDMEMET2WLSTORE;
select count(*) from MDMSTORE3.MDMEMET3WLSTORE;
select count(*) from MDMSTORE4.MDMEMET4WLSTORE;
select count(*) from MDMSTORE5.MDMEMET5WLSTORE;
select count(*) from MDMSTORE6.MDMEMET6WLSTORE;
select count(*) from MDMSTORE7.MDMEMET7WLSTORE;