select count(*) from cisadm.&tb 
/
