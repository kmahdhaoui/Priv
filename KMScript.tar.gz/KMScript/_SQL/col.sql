set verify off
set pagesize 100
column column_name format a20
column comments    format a50

select
   column_name,
   comments
from
   dba_col_comments
where
   owner like upper('&1')
and
   table_name like upper('&2')
order by
   column_name
;
