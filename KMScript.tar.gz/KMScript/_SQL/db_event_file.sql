--
--
define DEF_V1="read by other session"
define DEF_V2="1"
--
@@KMheaderinit
@@KMheaderdef2
--
define levent="&&1"
define NBJOURS="&&2"
--
--
define m_event_name = '&&levent'
--
set pages 132
set lines 132
column sid format 9999999
column sid_text format a12
column status format a10
column OWNER format a15
column object_name format a30
column subobject_name format a25
column event format a25
column object_type format a18
column NAME format a55
--
col event_name format a40
set heading on
break on event_name skip 1
--
select trim(sid) sid_text ,b.event,owner, object_name, subobject_name, object_type
from dba_objects o, v$session_wait b
where 
b.p1text like 'file#' and
b.event like '&&levent' and
object_id in 
(select objd from v$bh
where	b.p2=block#
and	b.p1=file#)
/
--
prompt
prompt ===================== event = 'read by other session' ========================
SELECT 
-- a.*,c.*
a.SID, c.obj, c.FILE#, c.dbablk 
	        FROM v$session_wait a, x$bh c 
	        WHERE 
			a.p1 = c.FILE#(+)
	        AND a.p2 = c.dbablk(+) 
	        AND a.event = '&&levent'
order by 2,3,4
/ 
--
select
   df.name,
   p1 "file#",
   p2 "block#",
   p3 "class#"
FROM
   v$session_wait ,v$datafile df
WHERE
   p1=df.file# and
   event = '&&levent'
/
prompt

exit