--
set linesize 155
set pagesize 155
set feedback off
set heading off
col DATE_LOGIN format a22
--
prompt + 
prompt +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
prompt +                               ACTIVE SESSIONS SQL
prompt +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

set heading on
col "Session__" format a44
break on "Session__" skip page
select s.sid||','||s.serial# ||' -start:'|| to_char(s.SQL_EXEC_START,'yyyy-mm-dd hh24:mi:ss') ||chr(10)||
s.machine ||chr(10)|| s.osuser ||'/'||s.username 
"Session__", q.sql_text from v$sqltext q, v$session s
where q.address = s.sql_address and s.status='ACTIVE'
and s.sid||','||s.serial# in 
( select toto from 
(select ss.sid||','||ss.serial# toto from v$session ss where ss.username!='NULL' and ss.status='ACTIVE' 
and upper(ss.osuser) not like '%WF5083%'
order by ss.SQL_EXEC_START desc) 
where rownum <31 )
order by s.sid||','||s.serial# , piece
;
prompt Liste incomplete ...

clear breaks
set heading off

prompt + 
prompt +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
prompt +                               ACTIVE SESSIONS IN DATABASE
prompt +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

set heading on
col MACHINE format a44
col "Session_" format a15
col Session_ format a15
col NB_SESS format a55
col OSDBUSER format a33
col exec_start format a22

select s.sid||','||s.serial# Session_ ,to_char(s.SQL_EXEC_START,'yyyy-mm-dd hh24:mi:ss') exec_start ,
s.machine, s.osuser ||'/'||s.username OSDBUSER from v$session s
where s.username!='NULL' and s.status='ACTIVE'
and s.sid||','||s.serial# in 
( select toto from 
(select ss.sid||','||ss.serial# toto from v$session ss where ss.username!='NULL' and ss.status='ACTIVE' 
and upper(ss.osuser) not like '%WF5083%'
order by ss.SQL_EXEC_START desc) 
where rownum <31 )
order by s.machine,s.username
;
prompt Liste incomplete ...
select 'Nombre de sessions actives :'|| count(*) NB_SESS from v$session s
where s.username!='NULL' and s.status='ACTIVE'
order by s.machine,s.username
;
set heading off