col name format a15
col PATH format a25
define _editor=vi
set pages 333
set lines 132
--
select GROUP_NUMBER, NAME,TOTAL_MB, FREE_MB, USABLE_FILE_MB from V$ASM_DISKGROUP;
--
select group_number,name ,path, REDUNDANCY, TOTAL_MB, free_mb 
from V$ASM_DISK 
--where GROUP_NUMBER = 1
;
--
-- XXXXX DISKGROUP data RESIZE DISK DATA size 300G;
--
