--
set lines 132 pages 155
col STATUS format a10
COLUMN category FORMAT a10
COLUMN sql_text FORMAT a55
SELECT NAME, TASK_EXEC_NAME, CATEGORY,FORCE_MATCHING, STATUS FROM   DBA_SQL_PROFILES ;
--
prompt 8czw4svw01804
prompt 95b2u3f8cagsg
--
select child_number, open_versions, fetches, rows_processed , executions, px_servers_executions, parse_calls, buffer_gets from v$sql
where sql_id = '&sql_id' order by child_number;
--
--
-- Exec DBMS_SQLTUNE.DROP_SQL_PROFILE (name=>'&nn');
--
--
