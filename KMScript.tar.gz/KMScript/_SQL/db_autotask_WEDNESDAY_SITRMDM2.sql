BEGIN
  SYS.DBMS_SCHEDULER.DROP_WINDOW
    (window_name  => 'SYS.WEDNESDAY_WINDOW');
END;
/

BEGIN
  SYS.DBMS_SCHEDULER.CREATE_WINDOW
    (
       window_name     => 'WEDNESDAY_WINDOW'
      ,start_date      => NULL
      ,repeat_interval => 'freq=daily;byday=WED;byhour=21;byminute=0; bysecond=0'
      ,end_date        => NULL
      ,resource_plan   => 'DEFAULT_MAINTENANCE_PLAN'
      ,duration        => to_dsInterval('+000 06:00:00')
      ,window_priority => 'LOW'
      ,comments        => 'Wednesday window for maintenance tasks'
    );
  SYS.DBMS_SCHEDULER.ENABLE
    (name => 'SYS.WEDNESDAY_WINDOW');

END;
/
------------------------------------------------------------------------------------
BEGIN
  DBMS_SCHEDULER.ADD_WINDOW_GROUP_MEMBER
    (group_name  => 'SYS.MAINTENANCE_WINDOW_GROUP',
     window_list => 'WEDNESDAY_WINDOW');
END;
/
BEGIN
  DBMS_SCHEDULER.ADD_WINDOW_GROUP_MEMBER
    (group_name  => 'SYS.ORA$AT_WGRP_OS',
     window_list => 'WEDNESDAY_WINDOW');
END;
/
------------------------------------------------------------------------------------