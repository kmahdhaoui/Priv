--
set verify off
define LeOwner=&&1
define LaTable=&&1
--
set pages 0
--
SELECT distinct 'execute DBMS_STATS.UNLOCK_TABLE_STATS('''||owner||''','''||TABLE_NAME||''');' FROM 
DBA_TAB_STATISTICS WHERE STATTYPE_LOCKED = 'ALL' and owner like '&&LeOwner' and TABLE_NAME like '&&LaTable'
/
SELECT distinct 'execute DBMS_STATS.UNLOCK_INDEX_STATS('''||owner||''','''||INDEX_NAME||''');' FROM 
DBA_IND_STATISTICS WHERE STATTYPE_LOCKED = 'ALL' and owner like '&&LeOwner' and INDEX_NAME like '&&LaTable'
/

--
-- ;
exit
--
