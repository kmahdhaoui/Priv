--
define DEF_V1="%"
define DEF_V2="%"
--
@@KMheaderinit
@@KMheaderdef2
--
set verify off
set heading on
set feedback off
col LAST_ANALYZED format a30
col owner format a25
col stale_stats format a8
col min_LAST_ANALYZED format a30
col max_LAST_ANALYZED format a30
col LAST_ANALYZED format a20
col PNAME format a12
col PPOS format 999999

define LeOwner="&&1"
define LaTable="&&1"
--
set pages 88
--
prompt Tables depuis 4 jours ...
select distinct owner,TABLE_NAME ,to_char(LAST_ANALYZED,'yyyy-mm-dd hh24') LAST_ANALYZED,
GLOBAL_STATS,
USER_STATS,
STALE_STATS 
from dba_tab_statistics where owner like '&&1' and table_name like '&&2'
and PARTITION_NAME is null
and stale_stats like '%' 
and LAST_ANALYZED > sysdate - 4
and owner not in ('SPOTLIGHT','SYS','SYSTEM','SYSMAN','APEX_030200','APPQOSSYS','DBSNMP',
'EXFSYS','FLOWS_FILES','KAMEL','MDSYS','NAGIOS','ORDDATA','ORDSYS','TOAD','WMSYS','XDB')
order by 1,2,6,3
;
--
prompt Table Partitions depuis 4 jours ...
select distinct owner,TABLE_NAME ,PARTITION_NAME pname,PARTITION_POSITION ppos,
to_char(LAST_ANALYZED,'yyyy-mm-dd hh24') LAST_ANALYZED,
GLOBAL_STATS,
USER_STATS,
STALE_STATS 
from dba_tab_statistics where owner like '&&1' and table_name like '&&2'
and PARTITION_NAME is not null
and stale_stats like '%' 
and LAST_ANALYZED > sysdate - 4
and owner not in ('SPOTLIGHT','SYS','SYSTEM','SYSMAN','APEX_030200','APPQOSSYS','DBSNMP',
'EXFSYS','FLOWS_FILES','KAMEL','MDSYS','NAGIOS','ORDDATA','ORDSYS','TOAD','WMSYS','XDB')
order by 1,2,4,8,5
;
--
select stale_stats,owner,max(LAST_ANALYZED) max_LAST_ANALYZED,min(LAST_ANALYZED) min_LAST_ANALYZED
from dba_tab_statistics where owner like '&&1' and table_name like '&&2'
and owner not in ('SPOTLIGHT','SYS','SYSTEM','SYSMAN','APEX_030200','APPQOSSYS','DBSNMP',
'EXFSYS','FLOWS_FILES','KAMEL','MDSYS','NAGIOS','ORDDATA','ORDSYS','TOAD','WMSYS','XDB')
group by owner,stale_stats
order by 1,2,3,4
;
-- 
exit
--
