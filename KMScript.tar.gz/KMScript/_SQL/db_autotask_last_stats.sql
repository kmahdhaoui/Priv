--
set heading on
set feedback off
set verify off
set lines 155
set pages 155
col pn format a22
col pv format a44
col comments format a33
col job_status format a22
col window_name format a22
col window_group format a22
col WINDOW_GROUP_NAME format a22
col NEXT_START_DATE format a44
col client_name format a33
col ddeb format a22
col dfin format a22
col JOB_DURATION format a30
col LAST_GOOD_DATE format a35
col NEXT_TRY_DATE format a35
--
--
prompt
prompt =================================> Last auto stats JOB <=================================
select * from (
SELECT client_name, window_name,
-- job_name,
job_status, 
to_char(job_start_time,'yyyy-mm-dd hh24:mi:ss') ddeb ,
job_duration
-- ,substr(JOB_INFO,1,80) JOB_INFO
FROM dba_autotask_job_history
WHERE 
client_name like '%stats%' AND
JOB_START_TIME > sysdate - 14 
ORDER BY client_name,job_start_time desc
             )
where rownum <14
and client_name like 'auto optimizer stats collection'
order by client_name,ddeb desc
;
--
--
--
