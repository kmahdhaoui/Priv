--
-- ALTER system SET db_keep_cache_size=2g scope=both;
-- ALTER system SET db_keep_cache_size=2g scope=SPFILE;
--
prompt
prompt
--
define LeOwner=CISADM
--
prompt ======================== Pool DDL              =============================
select 'ALTER TABLE '||owner||'.'||table_name||' STORAGE (BUFFER_POOL KEEP);' from dba_tables 
where  buffer_pool = 'KEEP' and owner='&&LeOwner';
select 'ALTER Index '||owner||'.'||index_name||' STORAGE (BUFFER_POOL KEEP);' from dba_Indexes 
where  buffer_pool = 'KEEP' and owner='&&LeOwner';
--
-- select 'select count(*) from '||owner||'.'||table_name||';' from dba_tables 
-- where  buffer_pool = 'KEEP' and owner='&&LeOwner';
--
prompt ======================== Pool Segments         =============================
col MB format 99999999
select sum(bytes)/1024/1024 MB from dba_segments ss where 
(ss.owner,ss.segment_name,ss.segment_type) in 
(
select owner,table_name,'TABLE' from dba_tables tt where tt.table_name=ss.segment_name 
and tt.buffer_pool = 'KEEP'
union all  
select owner,index_name,'INDEX' from dba_indexes ii where ii.index_name=ss.segment_name 
and ii.buffer_pool = 'KEEP'
)
;
--
prompt ======================== Pool Size             =============================
col mb format 999999999
SELECT NAME, BLOCK_SIZE, SUM(BUFFERS) buffers ,SUM(BUFFERS*BLOCK_SIZE/1024/1024) mb
  FROM V$BUFFER_POOL
  GROUP BY NAME, BLOCK_SIZE
  HAVING SUM(BUFFERS) > 0
;
--
prompt ======================== Pool to Resize        =============================
col ligne format a100
select ' alter system set db_keep_cache_size = '||trunc(sum(s.bytes)*1.2/1024/1024/1024)||'g scope=both;' ligne
from dba_segments s where s.buffer_pool = 'KEEP'
;
--
prompt ======================== Pool Statistics       =============================
SELECT Name, Block_size, Round(100*(CONSISTENT_GETS+DB_BLOCK_GETS-PHYSICAL_READS)/
(CONSISTENT_GETS+DB_BLOCK_GETS+1) ,2) AS HitRatio FROM v$buffer_pool_statistics;
--
prompt ======================== Pool Objects          =============================
col object_type format a10
col object_name format a20

SELECT oo.owner,object_name,object_type,object_type 
  FROM dba_objects oo, dba_indexes ii,dba_tables  tt
 WHERE oo.object_name = ii.index_name
   AND oo.object_name = tt.table_name
   AND oo.owner = ii.owner
   AND oo.owner = tt.owner
   AND tt.buffer_pool = 'KEEP' 
   AND ii.buffer_pool = 'KEEP' ;
--

