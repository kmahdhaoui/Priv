set lines 155
set pages 155
col OWN format a15
 col NBTAB format 9999
 col JOUR format  9999
 

col Jour format a22
break on own skip page
select OWNER own,to_char(LAST_ANALYZED,'yyyy-mm-dd') Jour,
count(distinct TABLE_NAME) NBTAB, null NBPART , null NBSUB
from dba_tables where OWNER not like '%SYS%'
and OWNER not like 'APEX%' and OWNER not in ('ORDDATA','OUTLN','SCOTT','XDB','DBSNMP','KAMEL')
group by OWNER,to_char(LAST_ANALYZED,'yyyy-mm-dd')
union all
select TABLE_OWNER own,to_char(LAST_ANALYZED,'yyyy-mm-dd') Jour,
count(distinct TABLE_NAME) NBTAB, count(distinct TABLE_NAME||PARTITION_NAME) NBPART , null NBSUB
from dba_tab_partitions where TABLE_OWNER not like '%SYS%'
and TABLE_OWNER not like 'APEX%' and TABLE_OWNER not in ('ORDDATA','OUTLN','SCOTT','XDB','DBSNMP','KAMEL')
group by TABLE_OWNER,to_char(LAST_ANALYZED,'yyyy-mm-dd')
union all
select TABLE_OWNER own,to_char(LAST_ANALYZED,'yyyy-mm-dd') Jour,
count(distinct TABLE_NAME) NBTAB, count(distinct TABLE_NAME||PARTITION_NAME) NBPART ,
count(distinct TABLE_NAME||PARTITION_NAME||SUBPARTITION_NAME) NBSUB
from dba_tab_subpartitions where TABLE_OWNER not like '%SYS%'
and TABLE_OWNER not like 'APEX%' and TABLE_OWNER not in ('ORDDATA','OUTLN','SCOTT','XDB','DBSNMP','KAMEL')
group by TABLE_OWNER,to_char(LAST_ANALYZED,'yyyy-mm-dd')
order by 1,2 desc,3,4,5
;
--
/*
select OWNER ,table_name,to_char(LAST_ANALYZED,'yyyy-mm-dd') Jour from
dba_tables where OWNER = 'DWHSUP_EDP' and LAST_ANALYZED is null ;

select TABLE_OWNER own,to_char(LAST_ANALYZED,'yyyy-mm-dd') Jour,
TABLE_NAME, PARTITION_NAME
from dba_tab_partitions where TABLE_OWNER='DWHSUP_EDP' and LAST_ANALYZED is null ;

DWHSUP_EDP 
CLUSTER_CARTO SYS_P26951
FAC_DAILY_ASSET_DENORM SYS_P26952 
CONNECTIVITY SYS_P26945

*/