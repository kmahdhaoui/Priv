--
set heading on
set feedback off
set verify off
set lines 155
set pages 155
col pn format a22
col pv format a44
col comments format a33
col job_status format a22
col window_name format a22
col window_group format a22
col WINDOW_GROUP_NAME format a22
col NEXT_START_DATE format a44
col client_name format a33
col ddeb format a22
col dfin format a22
col JOB_DURATION format a30
col LAST_GOOD_DATE format a35
col NEXT_TRY_DATE format a35
col DURATION format a20
col START_DATE format a44
col END_DATE format a44
col LAST_START_DATE format a44
col NEXT_START_DATE format a44
col REPEAT_INTERVAL fprmat a55
--
--
prompt =================================> to enable auto stats <=================================
prompt exec DBMS_AUTO_TASK_ADMIN.ENABLE(client_name=>'auto optimizer stats collection',operation=>NULL,window_name=>NULL);
prompt =================================> to disable auto stats <=================================
prompt exec DBMS_AUTO_TASK_ADMIN.ENABLE(client_name=>'auto optimizer stats collection',operation=>NULL,window_name=>NULL);
prompt =================================> to exec manually <=================================
prompt exec DBMS_AUTO_TASK_IMMEDIATE.GATHER_OPTIMIZER_STATS;
prompt =================================> to set defaults <=================================
prompt exec DBMS_STATS.SET_GLOBAL_PREFS('pname','value');
prompt =================================> to set for all user-defined <=================================
prompt exec DBMS_STATS.SET_DATABASE_PREFS('pname','value');
prompt =================================> to lock stats <=================================
prompt exec DBMS_STATS.LOCK_SCHEMA_STATS('ownname');
prompt exec DBMS_STATS.LOCK_TABLE_STATS ('ownname','tabname');
--
SELECT client_name ,status ,consumer_group FROM dba_autotask_client ORDER BY client_name ;
select CLIENT_NAME,STATUS,LAST_GOOD_DATE,NEXT_TRY_DATE from DBA_AUTOTASK_TASK ;
--
prompt
prompt =================================> BASIC = disabled, TYPICAL = ok ...  <=================================
show parameter STATISTICS_LEVEL
--
prompt
prompt =================================> currently running auto stats jobs <=================================
select client_name, JOB_SCHEDULER_STATUS from DBA_AUTOTASK_CLIENT_JOB where client_name='auto optimizer stats collection';
--
prompt
prompt =================================> Scheduled Windows <=================================
select window_name, repeat_interval, duration,ACTIVE, ENABLED 
from dba_scheduler_windows where ENABLED='TRUE' order by ENABLED desc , NEXT_START_DATE ;
--
prompt
prompt =================================> are stats job to run next windows <=================================
-- select window_group_name,window_name from DBA_SCHEDULER_WINGROUP_MEMBERS where window_group_name = 'ORA$AT_WGRP_OS';
SELECT CLIENT_NAME, STATUS,window_group FROM   DBA_AUTOTASK_CLIENT WHERE  CLIENT_NAME = 'auto optimizer stats collection';
select * from DBA_SCHEDULER_WINDOW_GROUPS where window_group_name = 'ORA$AT_WGRP_OS';
select WINDOW_NAME,DURATION,LAST_START_DATE,NEXT_START_DATE from DBA_SCHEDULER_WINDOWS
where NEXT_START_DATE > sysdate and NEXT_START_DATE <sysdate + 1;
--
prompt
prompt =================================> history auto stats CLIENT <=================================
SELECT client_name, window_name,
to_char(WINDOW_START_TIME,'yyyy-mm-dd hh24:mi:ss') ddeb,
to_char(WINDOW_END_TIME,'yyyy-mm-dd hh24:mi:ss') dfin,
' CRE='||jobs_created||' BEG='|| jobs_started||' END='||jobs_completed Job_Status
FROM dba_autotask_client_history WHERE 
WINDOW_START_TIME > sysdate - 14 and
client_name like '%stats%' 
order by client_name,WINDOW_START_TIME
;

prompt
prompt =================================> history auto stats JOB <=================================
SELECT client_name, window_name,
job_status, 
to_char(job_start_time,'yyyy-mm-dd hh24:mi:ss') ddeb ,
job_duration
-- ,substr(JOB_INFO,1,80) JOB_INFO
FROM dba_autotask_job_history
WHERE 
client_name like '%stats%' AND
JOB_START_TIME > sysdate - 14 
ORDER BY client_name,job_start_time
;

--
prompt
prompt =================================> to check parameters <=================================
select pn,DBMS_STATS.GET_PARAM (pn) pv from
(select 'AUTOSTATS_TARGET' pn from dual
union all select 'CASCADE' pn from dual
union all select 'DEGREE' pn from dual
union all select 'ESTIMATE_PERCENT' pn from dual
union all select 'METHOD_OPT' pn from dual
union all select 'NO_INVALIDATE' pn from dual
union all select 'GRANULARITY' pn from dual
union all select 'PUBLISH' pn from dual
union all select 'INCREMENTAL' pn from dual
union all select 'STALE_PERCENT' pn from dual);
--
prompt
prompt =================================> prefs : database <=================================
select pn,DBMS_STATS.GET_PREFS (pn) pv from
(select 'AUTOSTATS_TARGET' pn from dual
union all select 'CASCADE' pn from dual
union all select 'DEGREE' pn from dual
union all select 'ESTIMATE_PERCENT' pn from dual
union all select 'METHOD_OPT' pn from dual
union all select 'NO_INVALIDATE' pn from dual
union all select 'GRANULARITY' pn from dual
union all select 'PUBLISH' pn from dual
union all select 'INCREMENTAL' pn from dual
union all select 'STALE_PERCENT' pn from dual);
--
--
--
--
