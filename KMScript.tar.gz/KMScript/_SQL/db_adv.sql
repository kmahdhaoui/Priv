--
select * from V$DB_CACHE_ADVICE;
select * from V$PGA_TARGET_ADVICE;
select * from V$SGA_TARGET_ADVICE;
--
