--
--
col Ligne format a100
col owner format a15
col TABLE_NAME format a30
col COLUMN_NAME format a20
col DATA_TYPE format a20
col SEGMENT_NAME format a35
col mb format 99999999
set pages 155
set lines 166
--
select OWNER,TABLE_NAME,COLUMN_NAME,DATA_TYPE from dba_tab_columns 
where (
DATA_TYPE like '%SDO%' OR DATA_TYPE like '%GEO%'
)
;

exit
--
