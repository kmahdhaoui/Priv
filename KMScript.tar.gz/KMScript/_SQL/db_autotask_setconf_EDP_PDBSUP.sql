--
set heading on
set feedback off
set verify off
set lines 155
set pages 155
col pn format a22
col pv format a44
col comments format a33
col job_status format a22
col window_name format a22
col window_group format a22
col WINDOW_GROUP_NAME format a22
col NEXT_START_DATE format a44
col client_name format a33
col ddeb format a22
col dfin format a22
col JOB_DURATION format a30
col LAST_GOOD_DATE format a35
col NEXT_TRY_DATE format a35
--
-- enable optimzer job, disable others
EXEC DBMS_AUTO_TASK_ADMIN.enable;
exec DBMS_AUTO_TASK_ADMIN.enable(client_name=>'auto optimizer stats collection',operation=>NULL,window_name=>NULL);
--
exec DBMS_AUTO_TASK_ADMIN.disable(client_name=>'sql tuning advisor',operation =>NULL,window_name=>NULL);
exec DBMS_AUTO_TASK_ADMIN.disable(client_name=>'auto space advisor' ,operation =>NULL,window_name=>NULL);
--
-
set serveroutput on
declare
v_stats_group_pct number;
v_seq_group_pct number;
v_tune_group_pct number;
v_health_group_pct number;
begin
dbms_auto_task_admin.get_p1_resources(v_stats_group_pct,v_seq_group_pct,v_tune_group_pct,v_health_group_pct);
dbms_output.put_line(a =>
   'Gather Statistics % : '||v_stats_group_pct||chr(10)||
   'Space Management  % : '||v_seq_group_pct||chr(10)||
   'SQL Tuning        % : '||v_tune_group_pct||chr(10)||
   'Health Checks     % : '||v_health_group_pct);
end;
/
-- select CLIENT_NAME,STATUS from DBA_AUTOTASK_OPERATION ;
SELECT client_name ,status ,consumer_group FROM dba_autotask_client ORDER BY client_name
;
--
select CLIENT_NAME,STATUS,LAST_GOOD_DATE,NEXT_TRY_DATE from DBA_AUTOTASK_TASK ;
--
prompt
prompt =================================> prefs : database <=================================
select pn,DBMS_STATS.GET_PREFS (pn) pv from
(select 'AUTOSTATS_TARGET' pn from dual
union all select 'CASCADE' pn from dual
union all select 'DEGREE' pn from dual
union all select 'ESTIMATE_PERCENT' pn from dual
union all select 'METHOD_OPT' pn from dual
union all select 'NO_INVALIDATE' pn from dual
union all select 'GRANULARITY' pn from dual
union all select 'PUBLISH' pn from dual
union all select 'INCREMENTAL' pn from dual
union all select 'STALE_PERCENT' pn from dual);
--
prompt
prompt =================================> Duration Windows <=================================
--
----------------------------------------
-- 22h00 Samedi : 20 heures
-- 22h00 Dimanche : 4 heures
BEGIN
dbms_scheduler.disable(name  => 'SYS.SATURDAY_WINDOW');
dbms_scheduler.disable(name  => 'SYS.SUNDAY_WINDOW');

-- to_dsInterval('+000 20:00:00')
dbms_scheduler.set_attribute(name=> 'SYS.SATURDAY_WINDOW',attribute => 'DURATION',value=> numtodsinterval(20, 'hour'));
dbms_scheduler.set_attribute(name => 'SYS.SATURDAY_WINDOW',attribute => 'REPEAT_INTERVAL',value => 'freq=daily;byday=SAT;byhour=22;byminute=0; bysecond=0');


-- to_dsInterval('+000 04:00:00')
dbms_scheduler.set_attribute(name=> 'SYS.SUNDAY_WINDOW',attribute => 'DURATION',value=> numtodsinterval(4, 'hour'));
dbms_scheduler.set_attribute(name => 'SYS.SUNDAY_WINDOW',attribute => 'REPEAT_INTERVAL',value => 'freq=daily;byday=SUN;byhour=22;byminute=0; bysecond=0');

dbms_scheduler.enable(name => 'SYS.SATURDAY_WINDOW');
dbms_scheduler.enable(name => 'SYS.SUNDAY_WINDOW');

END;
/
-----------------------------------------
-- BSLN
BEGIN
  SYS.DBMS_SCHEDULER.CREATE_JOB
    (
       job_name        => 'BSLN_MAINTAIN_STATS_JOB'
      ,schedule_name   => 'BSLN_MAINTAIN_STATS_SCHED'
      ,program_name    => 'BSLN_MAINTAIN_STATS_PROG'
      ,comments        => 'Oracle defined automatic moving window baseline statistics computation job'
    );
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( name      => 'BSLN_MAINTAIN_STATS_JOB'
     ,attribute => 'RESTARTABLE'
     ,value     => FALSE);
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( name      => 'BSLN_MAINTAIN_STATS_JOB'
     ,attribute => 'LOGGING_LEVEL'
     ,value     => SYS.DBMS_SCHEDULER.LOGGING_OFF);
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE_NULL
    ( name      => 'BSLN_MAINTAIN_STATS_JOB'
     ,attribute => 'MAX_FAILURES');
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE_NULL
    ( name      => 'BSLN_MAINTAIN_STATS_JOB'
     ,attribute => 'MAX_RUNS');
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( name      => 'BSLN_MAINTAIN_STATS_JOB'
     ,attribute => 'STOP_ON_WINDOW_CLOSE'
     ,value     => FALSE);
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( name      => 'BSLN_MAINTAIN_STATS_JOB'
     ,attribute => 'JOB_PRIORITY'
     ,value     => 3);
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE_NULL
    ( name      => 'BSLN_MAINTAIN_STATS_JOB'
     ,attribute => 'SCHEDULE_LIMIT');
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( name      => 'BSLN_MAINTAIN_STATS_JOB'
     ,attribute => 'AUTO_DROP'
     ,value     => FALSE);
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( name      => 'BSLN_MAINTAIN_STATS_JOB'
     ,attribute => 'RESTART_ON_RECOVERY'
     ,value     => FALSE);
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( name      => 'BSLN_MAINTAIN_STATS_JOB'
     ,attribute => 'RESTART_ON_FAILURE'
     ,value     => FALSE);
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( name      => 'BSLN_MAINTAIN_STATS_JOB'
     ,attribute => 'STORE_OUTPUT'
     ,value     => TRUE);

  SYS.DBMS_SCHEDULER.ENABLE
    (name                  => 'BSLN_MAINTAIN_STATS_JOB');
END;
/
--
BEGIN
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( name      => 'SYS.BSLN_MAINTAIN_STATS_SCHED'
     ,attribute => 'START_DATE'
     ,value     => TO_TIMESTAMP_TZ('2020/03/27 05:00:00.000000 +02:00','yyyy/mm/dd hh24:mi:ss.ff tzh:tzm'));
END;
/
--
--
--
--
