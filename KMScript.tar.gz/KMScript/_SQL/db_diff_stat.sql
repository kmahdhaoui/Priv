--
set verify off
prompt OWN TAB TIME 
define OWN=&&1
define TAB=&&2
define letimestamp=&&3
--
set lines 150
set pages 55
col num format 99999
col nullok format a7
col buckets format 999999
col histogram format a20
--
col TABLE_NAME format a30
col PARTITION_NAME format a12
col subPARTITION_NAME format a15
col STATS_UPDATE_TIME format a20
--
select distinct table_name,to_char(stats_update_time,'yyyy-mm-dd') STATS_UPDATE_TIME
from dba_tab_stats_history
where owner='&&OWN' and table_name in ('&&TAB')
order by 2,1
;
--
col REPORT format a100
set long 32000
--
select * from table(dbms_stats.diff_table_stats_in_history(
                    ownname => '&&OWN',
                    tabname => upper('&&TAB'),
                    time1 => systimestamp,
                    time2 => to_timestamp('&&letimestamp','yyyy-mm-dd:hh24:mi:ss'),
                    pctthreshold => 0))
;   
--
